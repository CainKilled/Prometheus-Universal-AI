import Foundation

class Bootloader {
    static func start() {
        print("[Bootloader] Starting PrometheusShell runtime...")
        _ = CodexCompliance.validateSystem()
        _ = AgentHooks.bindToRuntime()
    }
}
