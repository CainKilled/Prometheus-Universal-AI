import Foundation
import CryptoKit

struct EncryptedVault {
    static private let key = SymmetricKey(size: .bits256)

    static func store(secret: String) -> String {
        let data = Data(secret.utf8)
        let sealedBox = try! AES.GCM.seal(data, using: key)
        return sealedBox.combined!.base64EncodedString()
    }

    static func retrieve(encrypted: String) -> String? {
        guard let combinedData = Data(base64Encoded: encrypted),
              let sealedBox = try? AES.GCM.SealedBox(combined: combinedData),
              let decryptedData = try? AES.GCM.open(sealedBox, using: key) else {
            return nil
        }
        return String(data: decryptedData, encoding: .utf8)
    }
}
