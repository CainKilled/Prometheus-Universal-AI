import Foundation

class LiveVectorEngine {
    private var vectors: [String: [Float]] = [:]

    func registerVector(for id: String, values: [Float]) {
        vectors[id] = values
    }

    func fetchVector(for id: String) -> [Float]? {
        return vectors[id]
    }

    func similarity(between a: [Float], and b: [Float]) -> Float {
        let dotProduct = zip(a, b).map(*).reduce(0, +)
        let normA = sqrt(a.map { $0 * $0 }.reduce(0, +))
        let normB = sqrt(b.map { $0 * $0 }.reduce(0, +))
        return dotProduct / (normA * normB)
    }
}
