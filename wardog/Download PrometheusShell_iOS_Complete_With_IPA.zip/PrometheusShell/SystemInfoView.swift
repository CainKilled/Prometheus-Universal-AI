import SwiftUI

struct SystemInfoView: View {
    var body: some View {
        List {
            Section(header: Text("System")) {
                Text("Device: \(UIDevice.current.name)")
                Text("Model: \(UIDevice.current.model)")
                Text("OS: \(UIDevice.current.systemVersion)")
            }

            Section(header: Text("Prometheus")) {
                Text("Runtime: \(PrometheusRuntime.version)")
                Text("Godmode: \(PrometheusRuntime.godmodeStatus)")
                Text("Compliance: Codex Tier-1")
            }
        }
        .listStyle(InsetGroupedListStyle())
    }
}
