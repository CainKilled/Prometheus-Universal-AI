import SwiftUI

struct RuntimeConsoleView: View {
    @State private var consoleOutput = "Initializing Prometheus Runtime..."

    var body: some View {
        VStack(alignment: .leading, spacing: 12) {
            Text("⚙️ Console")
                .font(.title2.bold())

            ScrollView {
                Text(consoleOutput)
                    .font(.system(.body, design: .monospaced))
                    .padding()
            }

            Button("Run Diagnostic") {
                consoleOutput = PrometheusRuntime.diagnosticReport()
            }

            Spacer()
        }
        .padding()
    }
}
