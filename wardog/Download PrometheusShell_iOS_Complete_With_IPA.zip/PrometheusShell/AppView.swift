import SwiftUI

struct AppView: View {
    var body: some View {
        NavigationView {
            VStack(spacing: 20) {
                Text("🔒 Prometheus Shell v∞")
                    .font(.title.bold())
                Text("Codex Enforcement Active")
                    .font(.subheadline)
                    .foregroundColor(.gray)

                NavigationLink("Launch Runtime", destination: RuntimeConsoleView())
                NavigationLink("System Info", destination: SystemInfoView())
            }
            .padding()
        }
    }
}
