import Foundation

struct LocalConfig {
    static let developerID = "adam.nagle.prometheus"
    static let runtimeMode = "proprietary"
    static let enableAdvancedFeatures = true
}
