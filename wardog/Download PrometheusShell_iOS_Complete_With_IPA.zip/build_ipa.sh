#!/bin/bash
# PrometheusShell Build Script
# Requires Xcode CLI tools

echo "[BUILD] Cleaning previous build..."
xcodebuild clean -project PrometheusShell.xcodeproj -scheme PrometheusShell

echo "[BUILD] Archiving app..."
xcodebuild archive -project PrometheusShell.xcodeproj -scheme PrometheusShell -archivePath ./build/PrometheusShell.xcarchive

echo "[BUILD] Exporting .ipa..."
xcodebuild -exportArchive -archivePath ./build/PrometheusShell.xcarchive \
-exportOptionsPlist ExportOptions.plist -exportPath ./build/output

echo "[DONE] .ipa should be in ./build/output"
