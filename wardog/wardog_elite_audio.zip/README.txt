
# Wardog Elite Audio

This is the Supreme Ultra Ultimate Hyper Atomic Subatomic Boson/Moson/Quark String Verbose Stem Splitter powered by Wardog AI.

## Features
- Local audio import and processing
- Spleeter-based stem separation
- Advanced voice isolation
- Noise-reduction enhanced vocals
- Fully scriptable with Siri/Scriptable compatibility
- CLI and GUI-ready for Pythonista integration
