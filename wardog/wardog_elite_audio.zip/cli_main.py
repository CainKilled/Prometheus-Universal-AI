
import os
import sys
from pathlib import Path
from splitter import EliteStemSplitter

def get_input_file():
    if len(sys.argv) > 1:
        return sys.argv[1]
    return input("Enter path to audio file: ").strip()

if __name__ == "__main__":
    input_file = get_input_file()
    if not os.path.exists(input_file):
        print(f"[Error] File not found: {input_file}")
        sys.exit(1)

    file_stem = Path(input_file).stem
    wardog_out_dir = os.path.join("wardog_output", file_stem)
    os.makedirs(wardog_out_dir, exist_ok=True)

    try:
        splitter = EliteStemSplitter(model='spleeter:2stems')
        stems_folder = splitter.split_audio(input_file, output_dir=wardog_out_dir)

        vocals_path = os.path.join(stems_folder, file_stem, "vocals.wav")
        if os.path.exists(vocals_path):
            enhanced_path = splitter.enhance_voice(vocals_path)
            print(f"[Success] Enhanced voice saved at: {enhanced_path}")
        else:
            print("[Warning] Vocal stem not found for enhancement.")
    except Exception as e:
        print(f"[Fatal] {e}")
