
import os
from spleeter.separator import Separator
import librosa
import soundfile as sf
import noisereduce as nr

class EliteStemSplitter:
    def __init__(self, model='spleeter:2stems'):
        self.separator = Separator(model)

    def split_audio(self, input_audio_path, output_dir='wardog_output'):
        if not os.path.exists(output_dir):
            os.makedirs(output_dir)
        self.separator.separate_to_file(input_audio_path, output_dir)
        return output_dir

    def enhance_voice(self, vocal_path):
        y, sr = librosa.load(vocal_path, sr=None)
        reduced_noise = nr.reduce_noise(y=y, sr=sr)
        enhanced_path = vocal_path.replace(".wav", "_enhanced.wav")
        sf.write(enhanced_path, reduced_noise, sr)
        return enhanced_path
