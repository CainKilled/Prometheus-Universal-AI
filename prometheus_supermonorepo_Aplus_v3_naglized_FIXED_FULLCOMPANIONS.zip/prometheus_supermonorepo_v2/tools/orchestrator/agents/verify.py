import subprocess, json
from pathlib import Path
def load_manifest(dir_path: Path):
  p = dir_path / ".manifest.json"
  return json.loads(p.read_text()) if p.exists() else None
def normalize(m):
  return sorted((it["path"], it["size"], it["sha256"]) for it in m.get("items", []))
class VerifyAgent:
  def run(self, **kwargs):
    name = kwargs["name"]
    root = Path(kwargs["root"]).resolve()
    companions = [".manifest.json", ".codex.lock.json", ".manifest.test.sh"]
    missing = [c for c in companions if not (root / c).exists()]
    dist_root = Path(__file__).resolve().parents[2] / "dist" / name
    if dist_root.exists():
      missing += [f"dist/{name}/{c}" for c in companions if not (dist_root / c).exists()]
    if missing:
      raise SystemExit(f"[verify:{name}] Missing companions: {', '.join(missing)}")
    for target in [root] + ([dist_root] if dist_root.exists() else []):
      test_sh = target / ".manifest.test.sh"
      if test_sh.exists():
        test_sh.chmod(0o755)
        rc = subprocess.call([str(test_sh)], cwd=str(target))
        if rc != 0:
          raise SystemExit(f"[verify:{name}] Manifest hash test failed at {target}")
    def rebuild(dirp: Path):
      from tools.orchestrator.agents.codex import walk_manifest
      return {"items": walk_manifest(dirp)["items"]}
    for t in [root] + ([dist_root] if dist_root.exists() else []):
      before = load_manifest(t)
      if before is None:
        raise SystemExit(f"[verify:{name}] No manifest in {t}")
      if normalize(before) != normalize(rebuild(t)):
        raise SystemExit(f"[verify:{name}] Idempotency drift in {t}")
    return True
