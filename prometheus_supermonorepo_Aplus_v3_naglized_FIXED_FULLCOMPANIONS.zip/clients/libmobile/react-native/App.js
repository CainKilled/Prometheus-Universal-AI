
import * as React from 'react';
import { StyleSheet, Text, View, TextInput, Button, FlatList } from 'react-native';

const API_BASE = process.env.API_BASE || 'http://10.0.2.2:8000'; // Android emulator loopback

export default function App() {
  const [status, setStatus] = React.useState('checking...');
  const [text, setText] = React.useState('');
  const [notes, setNotes] = React.useState([]);

  async function health() {
    try {
      const r = await fetch(`${API_BASE}/health`);
      setStatus(r.ok ? 'ok' : 'down');
    } catch (e) { setStatus('down'); }
  }
  async function load() {
    const r = await fetch(`${API_BASE}/v1/notes`);
    const j = await r.json();
    setNotes(j);
  }
  async function add() {
    if (!text) return;
    await fetch(`${API_BASE}/v1/notes`, {method:'POST', headers:{'Content-Type':'application/json'}, body: JSON.stringify({text})});
    setText(''); load();
  }

  React.useEffect(() => { health(); load(); }, []);

  return (
    <View style={styles.container}>
      <Text>libmobile — API {API_BASE} — {status}</Text>
      <View style={styles.row}>
        <TextInput style={styles.input} value={text} onChangeText={setText} placeholder="note" />
        <Button title="Add" onPress={add} />
      </View>
      <FlatList data={notes} keyExtractor={(item)=>String(item.id)} renderItem={({item}) => <Text>{item.id}: {item.text}</Text>} />
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, justifyContent: 'center', padding: 24 },
  row: { flexDirection: 'row', alignItems: 'center', marginVertical: 12 },
  input: { borderWidth: 1, borderColor: '#ccc', flex: 1, marginRight: 8, padding: 8 }
});
