> Prometheus Runtime — Codex-Locked (A+ v3)
> VaultTime Signed — 2025-08-31T11:36:24.438002Z


# React Native (Expo) client for libmobile

## Prereqs
- Node 18+
- `npm i -g expo-cli` (or use `npx expo`)

## Run
```bash
npm install
API_BASE=http://localhost:8000 npm run start
# press i for iOS simulator or a for Android
```
