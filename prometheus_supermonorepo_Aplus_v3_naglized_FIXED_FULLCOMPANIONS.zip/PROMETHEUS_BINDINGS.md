# Prometheus Bindings

- Codex-Lock: enabled
- VaultTime License: VaultTime-Private-v1
- Companion Protocol: Manifests & Tests next to each primary file
- Generated: 2025-08-31T11:55:58.950027Z
- Owner: Adam Nagle
