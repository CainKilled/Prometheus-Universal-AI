# Companion File Immutability Protocol

This repository enforces per-file manifests and executable tests.
Changes must be atomic and guarded.
