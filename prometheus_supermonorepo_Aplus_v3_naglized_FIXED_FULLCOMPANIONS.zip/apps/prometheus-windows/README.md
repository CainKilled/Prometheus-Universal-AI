> Prometheus Runtime — Codex-Locked (A+ v3)
> VaultTime Signed — 2025-08-31T11:36:24.438002Z


# Prometheus Windows

PowerShell module for running the monorepo services as Windows services.

## Quick start (elevated PowerShell)
```powershell
Import-Module .\Prometheus.Windows\Prometheus.Windows.psd1
Install-PrometheusService -RepoPath "$env:USERPROFILE\prometheus_supermonorepo_v2_PRO" -ProjectIndex 0
Start-PrometheusService -ProjectIndex 0
```


### Idempotency
- `Install-PrometheusService` creates or **updates** the service if it already exists.
- `Start-PrometheusService` is a no-op if already running.
- `Uninstall-PrometheusService` is safe to call repeatedly.
