
#!/usr/bin/env python3
import os, sys, json, hashlib
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
LOCKS = ROOT / "CODEX_LOCKS"
SEALS = ROOT / "SEALS"
SHA = ROOT / "SHA256SUMS.txt"

def sha256(p: Path):
    h = hashlib.sha256()
    with p.open('rb') as f:
        for chunk in iter(lambda: f.read(1024*1024), b''):
            h.update(chunk)
    return h.hexdigest()

def load_sha():
    m = {}
    if not SHA.exists():
        return m
    for line in SHA.read_text(encoding='utf-8').splitlines():
        if not line.strip(): continue
        digest, name = line.split(None, 1)
        name = name.strip()
        m[name] = digest
    return m

def main():
    fail = 0
    sha_map = load_sha()
    scanned = 0
    for f in ROOT.rglob("*"):
        if not f.is_file(): continue
        parts = set(f.relative_to(ROOT).parts)
        if parts & {".git",".venv","node_modules","dist","build"}: continue
        if f.parts and ("CODEX_LOCKS" in f.parts or "SEALS" in f.parts): continue

        rel = f.relative_to(ROOT).as_posix()
        digest = sha256(f)
        scanned += 1

        # Check CODEX lock
        lock = LOCKS / (rel.replace('/', '__') + ".codex.lock.json")
        if not lock.exists():
            print(f"[LOCK:MISS] {rel}")
            fail += 1
        else:
            try:
                j = json.loads(lock.read_text(encoding='utf-8'))
                if j.get("sha256") != digest:
                    print(f"[LOCK:MISMATCH] {rel} sha256 != lock.sha256")
                    fail += 1
            except Exception as e:
                print(f"[LOCK:BROKEN] {rel} {e}")
                fail += 1

        # Check SEAL
        seal = SEALS / (rel.replace('/', '__') + ".seal.json")
        if not seal.exists():
            print(f"[SEAL:MISS] {rel}")
            fail += 1
        else:
            try:
                s = json.loads(seal.read_text(encoding='utf-8'))
                if s.get("sha256") != digest:
                    print(f"[SEAL:MISMATCH] {rel} sha256 != seal.sha256")
                    fail += 1
            except Exception as e:
                print(f"[SEAL:BROKEN] {rel} {e}")
                fail += 1

        # Check .manifest.json if present
        mpath = f.with_suffix(f.suffix + ".manifest.json")
        if mpath.exists():
            try:
                m = json.loads(mpath.read_text(encoding='utf-8'))
                v = m.get("vaulttime",{}).get("last_seal",{}).get("sha256")
                if v and v != digest:
                    print(f"[MANIFEST:SEAL-MISMATCH] {rel}")
                    fail += 1
                l = m.get("codex_lock",{}).get("record",{}).get("sha256")
                if l and l != digest:
                    print(f"[MANIFEST:LOCK-MISMATCH] {rel}")
                    fail += 1
            except Exception as e:
                print(f"[MANIFEST:BROKEN] {rel} {e}")
                fail += 1

        # Optional SHA256SUMS
        if sha_map:
            if rel in sha_map and sha_map[rel] != digest:
                print(f"[SHA256SUMS:MISMATCH] {rel}")
                fail += 1

    print(f"[VERIFY] scanned={scanned} fail={fail}")
    sys.exit(1 if fail else 0)

if __name__ == "__main__":
    main()
