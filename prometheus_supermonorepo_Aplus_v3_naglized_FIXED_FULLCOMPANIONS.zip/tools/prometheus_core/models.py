
from dataclasses import dataclass, field
from typing import Dict, List, Optional

@dataclass
class HealthCheck:
    type: str = "http"              # http|tcp|process|none
    url: Optional[str] = None       # for http
    port: Optional[int] = None      # for tcp
    process: Optional[str] = None   # for process name
    interval: int = 10
    retries: int = 3
    timeout: int = 3

@dataclass
class Service:
    name: str
    type: str                        # python|node|compose|docker|swift|shell
    cwd: str
    command: str
    env: Dict[str,str] = field(default_factory=dict)
    health: HealthCheck = field(default_factory=HealthCheck)
    autorestart: bool = True

@dataclass
class Profile:
    name: str
    services: List[Service]
