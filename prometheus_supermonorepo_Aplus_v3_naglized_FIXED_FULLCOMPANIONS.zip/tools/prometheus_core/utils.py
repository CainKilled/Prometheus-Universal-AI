
import os, subprocess, shlex, time, json, socket, urllib.request
from contextlib import closing

def run(cmd, cwd=None, env=None):
    e = os.environ.copy()
    if env: e.update(env)
    return subprocess.run(cmd, cwd=cwd, env=e, shell=True, text=True,
                          stdout=subprocess.PIPE, stderr=subprocess.STDOUT)

def tcp_check(host, port, timeout=2):
    with closing(socket.socket(socket.AF_INET, socket.SOCK_STREAM)) as sock:
        sock.settimeout(timeout)
        try:
            sock.connect((host, port))
            return True
        except Exception:
            return False

def http_check(url, timeout=2):
    try:
        with urllib.request.urlopen(url, timeout=timeout) as r:
            return r.status < 400
    except Exception:
        return False
