> Prometheus Runtime — Codex-Locked (A+ v3)
> VaultTime Signed — 2025-08-31T11:36:24.438002Z

# System Snapshot — 2025-08-31T10:02:33.248244+00:00

- **Total files**: 390
- **Total size**: 143.72 KB
- **Companions**: manifests=3, tests=0
- **Locks & Seals**: codex_locks=65, vaulttime_seals=260

## Top directories by size
- `SEALS` — 260 files, 63.59 KB
- `prometheus_supermonorepo_v2` — 21 files, 35.08 KB
- `CODEX_LOCKS` — 65 files, 14.41 KB
- `apps` — 27 files, 9.76 KB
- `.github` — 6 files, 7.21 KB
- `tools` — 3 files, 6.85 KB
- `clients` — 6 files, 4.55 KB
- `README_RUN.md` — 1 files, 1.78 KB
- `Makefile` — 1 files, 491.00 B

## Top extensions by file count
- `.json` — 329 files, 80.36 KB
- `.yaml` — 14 files, 4.49 KB
- `.py` — 12 files, 31.40 KB
- `(none)` — 7 files, 1.03 KB
- `.yml` — 7 files, 8.07 KB
- `.md` — 6 files, 2.93 KB
- `.txt` — 4 files, 486.00 B
- `.sh` — 4 files, 4.34 KB
- `.ts` — 2 files, 5.41 KB
- `.ini` — 1 files, 38.00 B
- `.html` — 1 files, 1.51 KB
- `.tpl` — 1 files, 81.00 B
- `.dart` — 1 files, 1.96 KB
- `.js` — 1 files, 1.64 KB

## Notes
- Codex locks written under `CODEX_LOCKS/` and embedded into each file's `.manifest.json` if present.
- VaultTime seals written under `SEALS/` and embedded into manifests. Fallback unsigned seals used here if `VAULTTIME_KEY` is not set.
