
#!/usr/bin/env bash
set -euo pipefail
profile="${1:-}"
if [ -z "$profile" ]; then
  echo "Usage: ./stop.sh <libmobile|chatgpt|terminal|swiftserver|path/to/yml>"
  exit 2
fi
case "$profile" in
  libmobile|chatgpt|terminal|swiftserver) PROFILE="orchestrators/${profile}.yml" ;;
  *) PROFILE="$profile" ;;
esac
python3 tools/proctl.py stop -p "$PROFILE"
