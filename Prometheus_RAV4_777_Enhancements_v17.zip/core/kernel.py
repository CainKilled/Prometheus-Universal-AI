"""
Prometheus Kernel
=================

The Prometheus Kernel orchestrates the plugin ecosystem. It loads and
registers plugins, provides a simple API for executing them, and
maintains a context in which components can operate together. While not
a true operating system kernel, it serves as the heart of the
Prometheus monorepo by coordinating work across the back end, front
end and middleware layers.

Developed and maintained by Adam Henry Nagle. Contact: 603‑384‑8949,
cainkilledabrl@icloud.com, nagleadam75@gmail.com.

Usage:

    from core.kernel import PrometheusKernel
    kernel = PrometheusKernel(base_dir)
    kernel.load_plugins()
    result = kernel.run_plugin('terminal', {'command': 'echo Hello'})

This module deliberately avoids asynchronous complexity. In the future
it could be extended to support asyncio-based scheduling, but for now
calls are executed synchronously in the calling thread.
"""

from __future__ import annotations

import importlib.util
import os
from typing import Any, Dict, Optional

from plugins.manager import discover_plugins
from plugins.api.plugin_base import Plugin

from error_management.engine import ErrorManager


class PrometheusKernel:
    """Registry and dispatcher for Prometheus plugins."""

    def __init__(self, base_dir: str) -> None:
        self.base_dir = os.path.abspath(base_dir)
        self._plugins: Dict[str, Plugin] = {}
        self._metas: Optional[list[Dict[str, Any]]] = None

        # Central error manager for handling plugin exceptions
        self.error_manager = ErrorManager()

    def load_plugins(self) -> None:
        """Discover and import all plugins under the base directory."""
        metas = discover_plugins(self.base_dir)
        self._metas = metas
        for meta in metas:
            name = meta.get('name')
            path = meta.get('path')
            if not name or not path:
                continue
            full_path = os.path.join(self.base_dir, path)
            try:
                spec = importlib.util.spec_from_file_location(f"kernel_dyn_{name}", full_path)
                if spec and spec.loader:
                    mod = importlib.util.module_from_spec(spec)
                    spec.loader.exec_module(mod)  # type: ignore[call-arg]
                    plugin: Plugin = mod.get_plugin()  # type: ignore[attr-defined]
                    self._plugins[name] = plugin
                else:
                    raise ImportError(f"Cannot load spec for {name}")
            except Exception as exc:
                # Skip plugins that fail to import
                print(f"[Kernel] Failed to load plugin '{name}': {exc}")

    def list_plugins(self) -> list[Dict[str, Any]]:
        """Return metadata for all discovered plugins."""
        if self._metas is None:
            self.load_plugins()
        # type: ignore[return-value]
        return self._metas or []

    def get_plugin(self, name: str) -> Optional[Plugin]:
        """Return the plugin instance by name if loaded."""
        return self._plugins.get(name)

    def run_plugin(self, name: str, params: Dict[str, Any] | None = None) -> Any:
        """Invoke the specified plugin with the given runtime parameters.

        The ``log`` key in params will default to ``print`` if not
        provided. Returns the value returned by the plugin's activate
        method, if any.
        """
        if name not in self._plugins:
            raise KeyError(f"Plugin '{name}' is not loaded")
        runtime = dict(params or {})
        runtime.setdefault('log', print)
        plugin = self._plugins[name]
        try:
            # Activate and return result (may be None)
            return plugin.activate(runtime)  # type: ignore[no-any-return]
        except Exception as exc:
            # Delegate to error manager and return None on failure
            self.error_manager.handle(f"Kernel: error running plugin {name}", exc, context=runtime)
            return None

    def run_flow(self, flow_path: str, ctx: Dict[str, Any] | None = None) -> None:
        """Execute a wizard flow file using the internal WizardPlugin.

        This is a convenience wrapper around the Wizard plugin when
        orchestrating flows inside the kernel. It loads the Wizard
        plugin (creating it if necessary), then calls its activate method.
        """
        # Ensure the Wizard plugin is loaded
        if 'wizard' not in self._plugins:
            # Lazy load all plugins if not already done
            self.load_plugins()
        wizard = self._plugins.get('wizard')
        if not wizard:
            raise RuntimeError("Wizard plugin is not available")
        runtime = {
            'root': self.base_dir,
            'flow': flow_path,
            'ctx': ctx or {},
            'log': print,
        }
        wizard.activate(runtime)  # type: ignore[misc]
