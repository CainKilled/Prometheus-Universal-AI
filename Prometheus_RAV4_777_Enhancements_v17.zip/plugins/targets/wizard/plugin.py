"""
Prometheus Wizard Plugin
========================

This plugin provides guided workflows for project creation and automation.
Flows are defined in JSON files that list a sequence of steps. Each step
specifies a target plugin to invoke, an action name and arbitrary
parameters. The wizard reads the flow, loads the requested plugin from
the Prometheus plugin registry and calls its ``activate`` method with
the provided parameters. This allows complex multi‑stage operations to be
encoded declaratively and executed on demand.

Example flow JSON::

    {
      "steps": [
        {"action": "say_hello", "plugin": "terminal", "params": {"command": "echo Hello"}},
        {"action": "list_files", "plugin": "storage", "params": {"provider": "local", "action": "list", "directory": "."}}
      ]
    }

To run a flow, call this plugin with ``runtime={'flow': 'wizard/flows/basic.json', 'root': '<repo_root>'}``. The
runtime may also contain a ``ctx`` dictionary whose entries are merged
into the parameters of every step.
"""

# Prometheus Codex Lock v1
# This file is part of Prometheus RAV4 777 Enhancements. Do not edit manually.

from __future__ import annotations

import json
import importlib.util
from pathlib import Path
from typing import Dict, Any, List

from plugins.api.plugin_base import Plugin
from plugins.manager import discover_plugins


class WizardPlugin:
    """Execute a declarative flow of plugin actions."""

    def metadata(self) -> Dict[str, Any]:
        return {
            "name": "wizard",
            "version": "1.0.0",
            "description": "Guided project creation and orchestration",
            "targets": ["wizard"],
        }

    def _load_flow(self, base_dir: Path, flow_path: str) -> Dict[str, Any]:
        """Load a flow JSON file relative to base_dir."""
        flow_file = Path(flow_path)
        if not flow_file.is_absolute():
            flow_file = base_dir / flow_file
        with flow_file.open("r", encoding="utf-8") as f:
            return json.load(f)

    def activate(self, runtime: Dict[str, Any]) -> None:
        logger = runtime.get("log", print)
        base_dir = Path(runtime.get("root", ".")).resolve()
        flow_spec = runtime.get("flow", "wizard/flows/basic.json")
        context: Dict[str, Any] = runtime.get("ctx", {})
        try:
            flow = self._load_flow(base_dir, flow_spec)
        except Exception as exc:
            logger(f"[Wizard] Failed to load flow {flow_spec}: {exc}")
            return
        steps: List[Dict[str, Any]] = flow.get("steps", [])
        if not steps:
            logger(f"[Wizard] No steps found in flow {flow_spec}")
            return
        # Discover all plugins once
        try:
            metas = discover_plugins(base_dir)
        except Exception as exc:
            logger(f"[Wizard] Failed to discover plugins: {exc}")
            return
        # Map plugin name to path for quick lookup
        name_to_path: Dict[str, Path] = {meta.get("name"): base_dir / meta.get("path") for meta in metas if meta.get("name") and meta.get("path")}
        for idx, step in enumerate(steps, 1):
            action = step.get("action")
            plugin_name = step.get("plugin")
            params: Dict[str, Any] = step.get("params", {}).copy()
            # Merge runtime context into step params
            for k, v in context.items():
                params.setdefault(k, v)
            logger(f"[Wizard] Step {idx}/{len(steps)}: action={action}, plugin={plugin_name}")
            if not plugin_name:
                logger(f"[Wizard] Missing plugin name in step {idx}; skipping")
                continue
            plugin_path = name_to_path.get(plugin_name)
            if not plugin_path or not plugin_path.exists():
                logger(f"[Wizard] Plugin '{plugin_name}' not found; skipping step")
                continue
            # Dynamically import the plugin module
            try:
                spec = importlib.util.spec_from_file_location(f"wizard_dyn_{plugin_name}", str(plugin_path))
                if spec and spec.loader:
                    mod = importlib.util.module_from_spec(spec)
                    spec.loader.exec_module(mod)  # type: ignore[call-arg]
                    plug: Plugin = mod.get_plugin()  # type: ignore[attr-defined]
                else:
                    raise ImportError(f"Cannot load spec for {plugin_name}")
            except Exception as exc:
                logger(f"[Wizard] Failed to import plugin '{plugin_name}': {exc}")
                continue
            # Build a runtime for the plugin call
            step_runtime: Dict[str, Any] = runtime.copy()
            step_runtime.update(params)
            try:
                plug.activate(step_runtime)
            except Exception as exc:
                logger(f"[Wizard] Error executing plugin '{plugin_name}' at step {idx}: {exc}")


def get_plugin() -> Plugin:
    return WizardPlugin()  # type: ignore[return-value]