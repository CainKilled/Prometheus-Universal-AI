"""
Engineer Engine
===============

The Engineer Engine focuses on project structure and dependencies. It
provides a simple import dependency graph for Python files under a
given root. The graph lists each module and the modules it imports.
Currently this engine only handles Python files and recognises
``import X`` and ``from X import ...`` statements. You can pass a
    ``root`` key in the task to analyse a specific directory. The result
    is returned as a dictionary mapping file paths to lists of imported
    modules.

    Developed and maintained by Adam Henry Nagle. Contact: 603‑384‑8949,
    cainkilledabrl@icloud.com, nagleadam75@gmail.com.
"""

from __future__ import annotations

from typing import Dict, Any, List
from pathlib import Path
import os
import re


class EngineerEngine:
    def metadata(self) -> Dict[str, Any]:
        return {
            "name": "engineer",
            "version": "1.0.0",
            "description": "Generate a simple import dependency graph for Python files."
        }

    def run(self, task: Dict[str, Any]) -> Dict[str, Any]:
        root = Path(task.get("root", os.getcwd()))
        graph: Dict[str, List[str]] = {}
        import_re = re.compile(r"^\s*import\s+([\w\.]+)")
        from_re = re.compile(r"^\s*from\s+([\w\.]+)\s+import")
        for p in root.rglob("*.py"):
            if any(part in p.parts for part in [".git", "__pycache__"]):
                continue
            try:
                lines = p.read_text(errors="ignore").splitlines()
            except Exception:
                continue
            imports: List[str] = []
            for line in lines:
                m = import_re.match(line)
                if m:
                    imports.append(m.group(1))
                    continue
                m = from_re.match(line)
                if m:
                    imports.append(m.group(1))
            graph[str(p)] = imports
        return {"ok": True, "graph": graph}


def get_engine() -> EngineerEngine:
    return EngineerEngine()