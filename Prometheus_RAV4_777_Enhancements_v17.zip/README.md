# Prometheus RAV4 777 Enhancements

The **Prometheus RAV4 777 Enhancements** project turns the base
Prometheus Total Infinity Fusion monorepo into a self‑evolving
development environment. It introduces a cross‑platform plugin
framework, error management engine, templating and wizard systems,
vector storage for retrieval‑augmented generation, an extensible swarm
orchestrator and a unified command‑line interface. This release goes
far beyond scaffolds: most integrations now provide real, executable
functionality, and new core modules (kernel, OS helpers, HTTP server,
web dashboard and REPL) bind everything into a cohesive system.

## Highlights

### Plugin framework

* **API & manager** – A minimal, stable API for writing discoverable
  plugins. The manager finds and activates plugins under
  `plugins/targets/**/plugin.py`.

* **Fully realised plugins** – The repository includes working
  integrations for terminals, browsers, VS Code, Xcode, Android Studio,
  Visual Studio/MSBuild, Anaconda, Jupyter, MongoDB/SQLite, storage
  (local/S3/Azure), vector stores (local/Pinecone/Weaviate), universal
  device management (ADB/Fastboot/Magisk/libimobiledevice/Heimdall),
  mobile device operations (Android/iOS), external service wrappers
  (AWS, Firebase, Gemini CLI etc.), CI/CD orchestration, template
  generation and the wizard engine. Each plugin implements a
  metadata method and a full `activate()` that performs real work.

* **Tool builder** – A plugin capable of generating new plugin
  scaffolds programmatically. Pass a name, category and description,
  and it writes a ready‑to‑implement module under `plugins/targets`.

### Core and orchestration

* **Prometheus Kernel** (`core/kernel.py`) – The heart of the
  environment. It discovers and loads plugins, exposes methods for
  running them and executing wizard flows, and keeps contextual state.

* **OS helpers** (`core/os.py`) – Unified wrappers around common
  operating‑system operations: running commands, listing directories,
  reading and writing files and performing simple HTTP requests.  This
  module now includes additional helpers to copy, move and delete
  files, report disk usage, list running processes and get or set
  environment variables. Each helper returns a dictionary with
  structured results (`ok`/`error` keys) to aid in robust error
  handling.

* **DevSwarm v2** – A concurrency orchestrator that runs tasks via
  adapters. Adapters for LLM CLIs, LiveKit and WebKit are included and
  easily extendible.

* **New adapters for Git, Docker and HTTP** – Version 2 introduces
  first‑class adapters for common developer operations. The
  `GitAdapter` wraps the system `git` CLI to perform clones, pulls,
  pushes, commits and checkouts. The `DockerAdapter` drives container
  builds, runs, stops, pulls and pushes. The `HTTPAdapter` issues
  simple GET and POST requests using either the `requests` library or
  Python’s built‑in `urllib`. These adapters can be registered with
  the DevSwarm orchestrator or invoked directly via the unified CLI.

### User interfaces

* **Unified CLI** (`cli.py`) – The single entry point for most
  operations. It lists and runs plugins, executes flows, manages
  templates, generates plugin scaffolds and runs simple CI/CD pipelines.
  Example:

  ```bash
  python cli.py list
  python cli.py run terminal command="echo Hello World"
  python cli.py flow wizard/flows/basic.json ctx.project_dir=./output
  python cli.py create-plugin --name=my_plugin --category=tools --description="Custom logic"
  python cli.py template list
  python cli.py cicd --step="pytest -q" --step="echo Build complete"
  ```

### Introspection and auxiliary tools

Several utility modules have been added to aid developers in exploring and
extending the Prometheus runtime:

* **Truth Tree walker** (`scripts/truth_tree_walker.py`) – An interactive
  command‑line browser for the Prometheus Truth Tree. It loads
  `packages/datasets/truth_tree.json` and lets you navigate the full
  hierarchy, inspecting companions, dependencies and upstream/downstream
  links at each leaf. Run it with `python scripts/truth_tree_walker.py`.

* **Memory loader** (`tools/memory/load_memory.py`) – A small utility for
  reading JSON memory configuration files. It mirrors the behaviour of
  the original `loadMemory.js` but is written in Python. Use it to load
  and inspect `wardog_memory.json` or similar files.

* **Control Nexus v3** (`agents/interfaces/control_nexus_v3.py`) – A
  completely reworked version of the early monolithic control interface. It
  provides commands and macros for listing modules, executing pipelines,
  generating code via HuggingFace, compiling artifacts, creating safe
  snapshots and performing privileged rebuild or rollback operations. All
  actions are logged using VaultTime and validated against Codex signatures.

* **Datasets** – The dataset registry now includes the full Prometheus
  Truth Tree (`truth_tree`) and the RAV3 file inventory (`rav3_inventory`).
  These can be accessed via the CLI using `python cli.py datasets name=truth_tree`.

## Deploying to free‑tier cloud platforms

This repository includes a shell script under `scripts/` that automates
deployment of the Prometheus RAV4 777 Enhancements to several popular
free‑tier cloud services. The script supports four targets:

* **SageMaker** – Packages the repository, uploads it to an S3 bucket and
  registers a SageMaker model with your chosen execution role.
* **Firebase** – Configures a minimal `firebase.json`, creates a
  `public/` directory if needed and deploys it to Firebase Hosting.
* **Google Cloud** – Deploys a simple Cloud Function using the gcloud CLI.
* **Cloudflare** – Sets up a Wrangler project and publishes a Cloudflare
  Worker that returns a greeting.

Before running the script you must install and configure the respective
command‑line tools (`aws`, `firebase`, `gcloud`, `wrangler`). Then
execute:

```bash
cd Prometheus_RAV4_777_Enhancements/scripts
./deploy_free_tiers.sh <target> [options]
```

For example, to deploy to Firebase:

```bash
./deploy_free_tiers.sh firebase --project my‑firebase‑project
```

Or to publish a Cloudflare worker:

```bash
./deploy_free_tiers.sh cloudflare --name prometheus‑worker --account-id <your-account> --api-token <api-token>
```

See the top of the script for full usage details. The script is
idempotent and safe to re‑run; it will create missing buckets,
projects or files when necessary.

All code and scripts in this repository are developed and maintained
by Adam Henry Nagle (603‑384‑8949, cainkilledabrl@icloud.com,
nagleadam75@gmail.com).

* **Interactive REPL** (`repl.py`) – A read–eval–print loop for
  interactive exploration. Type `help` to see available commands.

* **HTTP server** (`server.py`) – Exposes a simple REST API for
  listing plugins (`GET /plugins`), listing templates (`GET /templates`),
  running plugins (`POST /run/<plugin>`) and executing flows (`POST
  /flow`). Start it with `python server.py` and point your browser at
  http://localhost:8000.

* **Web dashboard** (`webapp/index.html`) – A lightweight front end
  served by the HTTP server. It lists plugins and lets you run them
  directly from a browser without touching the command line.

### Templates and wizards

* **Template database** (`templates/template_db.py`) – Stores project
  skeletons as JSON files. Functions exist to list, add, retrieve and
  delete templates.

* **Template builder** (`templates/builder.py`) – Generates projects
  from templates, performing variable substitution, and creates new
  templates from existing directory trees.

* **Wizard engine** (`plugins/targets/wizard/plugin.py`) – Executes
  declarative flow specifications. A flow JSON file enumerates a
  sequence of plugin calls; the wizard loads each plugin and calls it
  with supplied parameters, merging in a context dictionary.

### Error handling and CI/CD

* **Error Management 777 Engine** (`error_management/engine.py`) –
  Classifies exceptions (transient, permanent, configuration, security,
  unknown) and dispatches them to registered handlers. Used by many
  plugins and the CI/CD system for consistent reporting.

* **CI/CD plugin** (`plugins/targets/cicd/plugin.py`) – Runs shell
  commands in sequence, streaming output to the logger and reporting
  non‑zero exit codes. Together with the error manager this provides a
  hardened loop for automated builds and deployments.

## Getting started

1. **Clone or extract** this repository into your development
   environment.

2. **Explore the CLI**: Run `python cli.py list` to see all available
   plugins. Use `python cli.py run <plugin>` with key=value arguments
   to execute them.

3. **Start the server**: `python server.py` launches a REST service on
   port 8000 and serves the web dashboard. Open `webapp/index.html` in
   your browser or navigate to http://localhost:8000 once the server is
   running.

4. **Build a project from a template**: Use `python cli.py template
   create --from=./existing_project --name=mytemplate` to capture a
   template, then generate a new project with `python cli.py template
   generate --name=mytemplate --out=./new_project --var.project_name=Demo`.

5. **Extend the system**: Create new plugins with `create-plugin` or
   build new flows under `wizard/flows`. The tool builder will generate
   skeletons ready for you to implement custom logic.

## License

This project is provided as an experimental framework and is intended
for educational and prototyping purposes. Use at your own risk.