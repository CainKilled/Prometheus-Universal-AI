"""
Template Database
=================

This module manages a simple file‑based database of project templates. Each
template is stored as a JSON file in the ``templates`` directory. A
template is a dictionary containing arbitrary keys describing the
structure of a project skeleton. Functions are provided to list
available templates, load a template by name, add a new template and
delete existing templates.

Example usage::

    from Prometheus_RAV4_777_Enhancements.templates.template_db import add_template, list_templates, get_template

    add_template("webapp", {"files": {"index.html": "<html></html>"}})
    names = list_templates()
    tmpl = get_template("webapp")
"""

import json
from pathlib import Path
from typing import Dict, Any, List


TEMPLATES_DIR = Path(__file__).parent  # Directory containing this file


def _template_path(name: str) -> Path:
    """Compute the path to the JSON file for a template."""
    return TEMPLATES_DIR / f"{name}.json"


def list_templates() -> List[str]:
    """Return a list of available template names (without extension)."""
    names = []
    for path in TEMPLATES_DIR.glob("*.json"):
        names.append(path.stem)
    return sorted(names)


def get_template(name: str) -> Dict[str, Any] | None:
    """Load a template by name. Returns None if the template does not exist."""
    path = _template_path(name)
    if not path.exists():
        return None
    with path.open("r", encoding="utf-8") as f:
        return json.load(f)


def add_template(name: str, data: Dict[str, Any], overwrite: bool = False) -> None:
    """Save a new template. Raises an error if the template exists and overwrite=False."""
    path = _template_path(name)
    if path.exists() and not overwrite:
        raise FileExistsError(f"Template {name} already exists")
    with path.open("w", encoding="utf-8") as f:
        json.dump(data, f, indent=2)


def delete_template(name: str) -> None:
    """Delete a template file. Does nothing if the file does not exist."""
    path = _template_path(name)
    if path.exists():
        path.unlink()