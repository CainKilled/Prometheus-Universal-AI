# Unified Blank Project (UBP)

A **single, unified, idempotent** project template you can inject any app into.
It ships with:
- In-browser editor (code-server ≈ VS Code).
- JupyterLab for notebooks.
- Firebase Emulators (Auth/Firestore/Functions/Storage/Hosting).
- AWS/SageMaker bootstrap (CLI + Terraform stubs).
- Google Cloud bootstrap (CLI steps + emulator-friendly dev).
- Devcontainer, Docker Compose, Makefile, scripts, tests, CI-ready layout.

**Generated:** 2025-08-10T16:11:23.382399

---

## Quick Start (no cloud creds required)
```bash
# 1) start local dev stack (editor+jupyter+firebase emulators)
make up

# 2) open services
# code-server:   http://localhost:8080   (password in .env)
# jupyterlab:    http://localhost:8888   (password in .env)
# firebase UI:   http://localhost:4000   (emulator hub)

# 3) stop
make down
```

### First-time setup
```bash
cp .env.example .env
# edit passwords & project names
make doctor
```

### Optional: devcontainer (VS Code / codespaces)
Open this folder in VS Code and re-open in container (uses `.devcontainer/devcontainer.json`).

---

## Stacks

### Editor (code-server)
- Web editor similar to VS Code, runs locally in a container.
- Default port: 8080. Password pulled from `.env` (`CODESERVER_PASSWORD`).

### JupyterLab
- Full notebooks, token-less login protected by password in `.env` (`JUPYTER_PASSWORD`).
- Mounts `notebooks/`.

### Firebase Emulators (free tier friendly)
- No GCP billable resources in local mode.
- Config in `firebase/` (emulators for auth/firestore/functions/storage/hosting).
- Use `make firebase-init` once; then `make firebase-emulators` is part of `make up`.

### AWS / SageMaker (free-tier aware)
- CLI bootstrap in `aws/scripts/`.
- Terraform stubs under `aws/terraform/` set up IAM roles and a minimal SageMaker Studio domain/user profile (no apply by default).
- **You control** when/if you run against your AWS account (`make aws-*`).

### Google Cloud (free-tier friendly)
- CLI bootstrap scripts under `gcp/scripts/` to init a project, enable common APIs, and create a service account.
- Firebase config can later target your real project (switch from emulators).

---

## Idempotent Commands

```bash
make doctor        # Checks local prerequisites
make up            # docker compose up -d (editor + jupyter + firebase emulators)
make down          # docker compose down
make reset         # prune volumes/containers for a clean slate

make firebase-init # installs deps & prepares emulators (idempotent)
make firebase-emulators  # runs emulators only

make aws-init      # guides aws configure + verifies boto3
make aws-terraform-plan   # terraform init/plan (no apply)
make aws-terraform-apply  # apply when you're ready (explicit)

make gcp-init      # gcloud init flow (interactive) + enable core APIs
```

---

## Security Notes
- Default passwords are **examples**—change them in `.env`.
- Docker ports are bound to `localhost` only by default.
- Cloud actions are opt-in and scripted to be **idempotent**. Review before running.

---

## Structure
```
unified_blank_project/
  .env.example
  docker-compose.yml
  Makefile
  .devcontainer/
  notebooks/
  firebase/
  aws/terraform/
  aws/scripts/
  gcp/scripts/
  scripts/         # project-agnostic helpers
  apps/            # your future project(s)
```
