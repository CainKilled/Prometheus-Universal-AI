#!/usr/bin/env bash
set -euo pipefail
echo "== UBP Doctor =="
for bin in docker make; do
  command -v "$bin" >/dev/null || { echo "Missing: $bin"; exit 1; }
done
echo "OK"
