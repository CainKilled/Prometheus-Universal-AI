#!/usr/bin/env python3
import shutil, sys
from pathlib import Path

def main():
  if len(sys.argv) < 2:
    print("Usage: render_project.py <target-dir>")
    sys.exit(1)
  target = Path(sys.argv[1]).resolve()
  if target.exists() and any(target.iterdir()):
    print("Target dir not empty; refusing to overwrite.")
    sys.exit(2)
  shutil.copytree(Path('.').resolve(), target)
  print(f"Rendered to {target}")
if __name__ == "__main__":
  main()
