#!/usr/bin/env sh
set -e
if ! command -v firebase >/dev/null 2>&1; then
  npm i -D firebase-tools
fi
export FIREBASE_EMULATORS_PATH="."
npx firebase emulators:start --project=${FIREBASE_PROJECT_ID:-demo-project} --import=./.cache --export-on-exit
