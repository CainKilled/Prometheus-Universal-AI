#!/usr/bin/env bash
set -euo pipefail
echo "AWS init (idempotent)"
aws --version || { echo "Install AWS CLI v2"; exit 1; }
python - <<'PY'
import boto3
print("boto3 OK")
PY
echo "Done."
