#!/usr/bin/env bash
set -euo pipefail
echo "GCP init (idempotent)"
gcloud --version || { echo "Install Google Cloud SDK"; exit 1; }
gcloud auth login || true
gcloud config set project "${GCP_PROJECT_ID:-demo-project}"
bash "$(dirname "$0")/gcloud_enable_apis.sh"
echo "Done."
