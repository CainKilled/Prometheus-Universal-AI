#!/usr/bin/env bash
set -euo pipefail
PROJECT_ID="${GCP_PROJECT_ID:-demo-project}"
echo "Enabling common APIs in project: ${PROJECT_ID}"
apis=(
  serviceusage.googleapis.com
  iam.googleapis.com
  storage.googleapis.com
  firestore.googleapis.com
  firebase.googleapis.com
)
for a in "${apis[@]}"; do
  gcloud services enable "$a" --project "${PROJECT_ID}" || true
done
echo "Done."
