## What this PR does

This PR adds a verifier CI workflow and a Prometheus exporter sidecar to continuously verify release provenance, run SAST/SCA scans, and expose metrics for monitoring.

Files added:
- `.github/workflows/verify-and-build.yml`
- `exporter/` (Dockerfile, metrics_exporter.py, requirements.txt)
- `k8s/deployment-exporter.yaml`
- `fastlane/` (Fastfile, Appfile)
- `scripts/insert_build_info.sh`
- `scripts/github_upload.py`

## Testing checklist
- [ ] GitHub Actions workflow exists and is runnable.
- [ ] Secrets added to repository.
- [ ] Exporter image built and deployed to k8s cluster.
- [ ] Prometheus scraping `/metrics`.
- [ ] Fastlane configured with App Store Connect credentials (if you want TestFlight upload).

## Notes
- To complete the deployment you must add the required secrets and push any code-signing certificates.
- See `README.md` for iPhone-based automation steps using iSH.

@maintainers please review and merge when ready.
