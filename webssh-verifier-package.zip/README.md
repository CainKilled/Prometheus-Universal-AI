# webssh-verifier — Deployment Package

This package contains a ready-to-commit set of CI, exporter, and helper scripts to automate verification and Prometheus metrics for the `isontheline/pro.webssh.net` project.

## What's included
- `.github/workflows/verify-and-build.yml` — GitHub Action for periodic verification, build, and scans.
- `exporter/` — Prometheus exporter (Flask) + Dockerfile.
- `k8s/deployment-exporter.yaml` — Example Kubernetes deployment manifest.
- `fastlane/` — Fastlane skeleton for TestFlight upload.
- `scripts/insert_build_info.sh` — Xcode build helper to embed git SHA.
- `scripts/github_upload.py` — Uploads this package into a branch using the GitHub Contents API.
- `PR_TEMPLATE.md` — A PR template you can paste into GitHub when creating the PR.

## Goal
After unzipping this package on a machine (or iPhone using iSH), you can run the included script to create a branch in your target repository and upload all files. This allows you to quickly create `feature/webssh-verifier` in your repo with everything in place.

---

## iPhone automation (recommended approach)

There are two practical ways to run this from an iPhone after unzipping:

### Option A — iSH (recommended)
1. Install **iSH** from the App Store (Alpine Linux in a sandbox).
2. Open iSH and ensure Python3 is available:
   ```sh
   apk add python3
   ```
3. Transfer the unzipped package into iSH (AirDrop / Files app).
4. In iSH, `cd` into the directory and run:
   ```sh
   export GITHUB_TOKEN=ghp_...         # set your PAT
   export REPO=your-username/your-repo # e.g. isontheline/pro.webssh.net
   python3 scripts/github_upload.py
   ```
   The script will prompt for repo if not set, and then create `feature/webssh-verifier` branch and upload files.

### Option B — Run the Python script on a remote machine via Shortcuts (SSH)
If you prefer to run on a remote server, create a Shortcut using "Run Script Over SSH" or use the Shortcuts `Get Contents of URL` actions to call GitHub API directly (more manual).

---

## After upload
1. Open GitHub and confirm branch `feature/webssh-verifier` exists.
2. Create a Pull Request from that branch into `main` (PR template is included in `PR_TEMPLATE.md`).
3. Configure repository secrets (Settings → Secrets):
   - `APP_STORE_CONNECT_KEY_ID`
   - `APP_STORE_CONNECT_ISSUER_ID`
   - `APP_STORE_CONNECT_KEY` (contents of .p8)
   - `GITHUB_TOKEN` (optional for actions)
   - `EXPORTER_PUSH_TOKEN`
   - `REGISTRY_USER`, `REGISTRY_PASS`, `REGISTRY_URL`
4. Build and deploy exporter image, deploy to k8s, wire Prometheus to scrape `/metrics` (see README for details).

---

## Notes & cautions
- This package does **not** contain or transmit any secrets or private keys.
- You must supply your own Apple App Store Connect credentials for Fastlane and a registry to host the exporter image.
- Use a least-privilege GitHub token with `repo` access for this operation.

