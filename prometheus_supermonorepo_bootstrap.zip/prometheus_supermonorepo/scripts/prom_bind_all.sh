#!/usr/bin/env bash
set -euo pipefail
if [[ $# -lt 2 ]]; then echo "Usage: $0 <chatgpt_export_zip_or_dir> <monorepo_root>"; exit 2; fi
EXPORT_SRC="$1"; MONO_ROOT="$2"; INGEST_TOOL="tools/chatgpt_export_ingestor.py"
mkdir -p "${MONO_ROOT}/knowledge/chatgpt"
python3 "${INGEST_TOOL}" --source "${EXPORT_SRC}" --dest "${MONO_ROOT}/knowledge/chatgpt" --seal-tar 1 || true
python3 "${INGEST_TOOL}" --rollup "${MONO_ROOT}/knowledge/chatgpt" || true
