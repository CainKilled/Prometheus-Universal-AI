#!/usr/bin/env bash
set -euo pipefail
ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
PY="${PYTHON_BIN:-python3}"
CLI="${ROOT_DIR}/tools/control_nexus/cli.py"
if [[ ! -d "${ROOT_DIR}/.venv" ]]; then
  "${PY}" -m venv "${ROOT_DIR}/.venv"
fi
source "${ROOT_DIR}/.venv/bin/activate"
pip install --upgrade pip >/dev/null
pip install -r "${ROOT_DIR}/tools/control_nexus/requirements.txt" >/dev/null
"${PY}" "${CLI}" "$@"
