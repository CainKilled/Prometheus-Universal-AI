// services/async_engine.ts
export type RunOptions = {
  timeoutMs?: number;
  signal?: AbortSignal;
  onProgress?: (checked: number) => void;
};
export type EngineInfo = {
  runtime: "web-worker" | "main-thread-fallback";
  workerSupported: boolean;
};
let _cachedWorkerUrl: string | null = null;
function getWorkerUrl(): string {
  if (_cachedWorkerUrl) return _cachedWorkerUrl;
  const workerSource = `
    (function(){
      function nthPrime(n) {
        if (n < 1 || !isFinite(n)) throw new Error("Invalid n");
        const primes = [];
        let candidate = 2;
        function isPrime(k) {
          if (k < 2) return false;
          for (let i = 0; i < primes.length; i++) {
            const p = primes[i];
            if (p * p > k) break;
            if (k % p === 0) return false;
          }
          return true;
        }
        let checked = 0;
        while (primes.length < n) {
          if (isPrime(candidate)) primes.push(candidate);
          candidate = candidate === 2 ? 3 : candidate + 2;
          checked++;
          if ((checked % 10000) === 0) {
            try { self.postMessage({ type: "progress", checked }); } catch(e){}
          }
        }
        return primes[primes.length - 1];
      }
      self.onmessage = function (ev) {
        const { n } = ev.data || {};
        try {
          const result = nthPrime(n);
          self.postMessage({ type: "result", result });
        } catch (err) {
          const message = (err && err.message) ? err.message : String(err);
          self.postMessage({ type: "error", message });
        }
      };
    })();
  `;
  const blob = new Blob([workerSource], { type: "application/javascript" });
  _cachedWorkerUrl = URL.createObjectURL(blob);
  return _cachedWorkerUrl;
}
function clearWorkerUrl(): void {
  if (_cachedWorkerUrl) {
    URL.revokeObjectURL(_cachedWorkerUrl);
    _cachedWorkerUrl = null;
  }
}
function featureDetectWorker(): boolean {
  try { return typeof window !== "undefined" && typeof Worker !== "undefined"; } catch { return false; }
}
function validateInput(n: unknown): asserts n is number {
  if (typeof n !== "number" || !Number.isFinite(n) || Math.floor(n) !== n || n < 1) {
    throw new TypeError("n must be a finite positive integer (>= 1).");
  }
  if (n > 5000000) throw new RangeError("n is too large for this engine configuration.");
}
async function nthPrimeFallback(n: number, onProgress?: (checked: number) => void, signal?: AbortSignal): Promise<number> {
  const primes: number[] = []; let candidate = 2; let checked = 0;
  function isPrime(k: number): boolean {
    if (k < 2) return false;
    for (let i = 0; i < primes.length; i++) {
      const p = primes[i]; if (p * p > k) break; if (k % p === 0) return false;
    } return true;
  }
  const CHUNK = 5000;
  while (primes.length < n) {
    if ((signal as any)?.aborted) throw new DOMException("Aborted", "AbortError");
    for (let i = 0; i < CHUNK && primes.length < n; i++) {
      if (isPrime(candidate)) primes.push(candidate);
      candidate = candidate === 2 ? 3 : candidate + 2;
      checked++; if ((checked % 10000) === 0 && onProgress) onProgress(checked);
    }
    await new Promise((r) => setTimeout(r, 0));
  }
  return primes[primes.length - 1];
}
export async function runNthPrime(n: number, opts: RunOptions = {}): Promise<{ result: number; info: EngineInfo }> {
  validateInput(n);
  const workerSupported = featureDetectWorker();
  const info: EngineInfo = { runtime: workerSupported ? "web-worker" : "main-thread-fallback", workerSupported };
  let timeoutId: any; const { timeoutMs, signal, onProgress } = opts;
  if ((signal as any)?.aborted) throw new DOMException("Aborted", "AbortError");
  if (!workerSupported) {
    const controller = new AbortController();
    const composite = mergeAbortSignals(signal as any, controller.signal as any);
    try {
      const killer = setupTimeout(() => controller.abort(), timeoutMs);
      const result = await nthPrimeFallback(n, onProgress, composite as any);
      if (killer) clearTimeout(killer);
      return { result, info };
    } finally {}
  }
  const workerUrl = getWorkerUrl();
  const worker = new Worker(workerUrl);
  if (typeof timeoutMs === "number" && timeoutMs > 0) {
    timeoutId = setTimeout(() => { try { worker.terminate(); } catch(e){} }, timeoutMs);
  }
  const abortHandler = () => { try { worker.terminate(); } catch(e){} };
  (signal as any)?.addEventListener?.("abort", abortHandler, { once: true });
  try {
    const result = await new Promise<number>((resolve, reject) => {
      worker.onmessage = (ev: MessageEvent) => {
        const msg: any = ev.data;
        if (!msg || typeof msg.type !== "string") return;
        if (msg.type === "progress" && typeof msg.checked === "number") { if (onProgress) onProgress(msg.checked); return; }
        if (msg.type === "result") { resolve(msg.result as number); return; }
        if (msg.type === "error") { reject(new Error(String(msg.message || "Unknown worker error"))); return; }
      };
      (worker as any).onerror = (e: any) => reject(new Error(`Worker error: ${e.message || "unknown"}`));
      (worker as any).postMessage({ n });
    });
    return { result, info };
  } finally {
    try { (worker as any).terminate(); } catch(e){}
    if (timeoutId !== undefined) clearTimeout(timeoutId);
    (signal as any)?.removeEventListener?.("abort", abortHandler);
  }
}
export function disposeAsyncEngine(): void { clearWorkerUrl(); }
function mergeAbortSignals(a?: AbortSignal, b?: AbortSignal): AbortSignal | undefined {
  if (!a && !b) return undefined;
  const ctrl = new AbortController();
  const onAbort = () => ctrl.abort();
  a?.addEventListener("abort", onAbort);
  b?.addEventListener("abort", onAbort);
  if ((a as any)?.aborted || (b as any)?.aborted) ctrl.abort();
  return ctrl.signal;
}
function setupTimeout(fn: () => void, ms?: number): any {
  if (!ms || ms <= 0) return undefined;
  return setTimeout(fn, ms);
}
