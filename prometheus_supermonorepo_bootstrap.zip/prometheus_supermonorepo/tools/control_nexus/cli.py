#!/usr/bin/env python3
import argparse, subprocess, sys, yaml
from pathlib import Path
from rich.console import Console
from rich.table import Table
ROOT = Path(__file__).resolve().parents[2]
ENTRY = ROOT / "scripts" / "prometheus_total_entrypoint.sh"
CONF = ROOT / "prometheus.config.yml"
console = Console()
def list_projects():
  cfg = yaml.safe_load(CONF.read_text())
  return [p["name"] for p in cfg["projects"]]
def run_entry(cmd, project=None):
  args = [str(ENTRY), cmd]
  if project: args += ["--project", project]
  return subprocess.call(args, cwd=str(ROOT))
def main():
  ap = argparse.ArgumentParser(description="Control Nexus CLI")
  ap.add_argument("--list", action="store_true")
  ap.add_argument("--project", default=None)
  ap.add_argument("--phase", choices=["forge","build","test","package","codex","verify","upload","all"], default="all")
  args = ap.parse_args()
  if args.list:
    table = Table(title="Projects")
    table.add_column("Name")
    for n in list_projects():
      table.add_row(n)
    console.print(table); sys.exit(0)
  rc = run_entry("forge" if args.phase=="all" else args.phase, args.project)
  sys.exit(rc)
if __name__ == "__main__":
  main()
