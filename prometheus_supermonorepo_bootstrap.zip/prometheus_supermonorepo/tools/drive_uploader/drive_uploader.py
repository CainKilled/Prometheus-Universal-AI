#!/usr/bin/env python3
import argparse, hashlib, json, mimetypes, os, queue, threading
from pathlib import Path
from typing import Optional, Dict
from tenacity import retry, wait_exponential, stop_after_attempt
from tqdm import tqdm
from googleapiclient.discovery import build
from googleapiclient.http import MediaFileUpload
from googleapiclient.errors import HttpError
from google.oauth2.credentials import Credentials
from google_auth_oauthlib.flow import InstalledAppFlow
from google.auth.transport.requests import Request

SCOPES = ["https://www.googleapis.com/auth/drive"]
CHUNK_MB = 8
CHUNK_SIZE = CHUNK_MB * 1024 * 1024

def sha256_file(p: Path) -> str:
    h = hashlib.sha256()
    with p.open("rb") as f:
        for chunk in iter(lambda: f.read(1024*1024), b""):
            h.update(chunk)
    return h.hexdigest()

def load_creds(creds_dir: Path) -> Credentials:
    creds = None
    token_path = creds_dir / "token.json"
    client_secret = creds_dir / "client_secret.json"
    if token_path.exists():
        creds = Credentials.from_authorized_user_file(token_path, SCOPES)
    if not creds or not creds.valid:
        if creds and creds.expired and creds.refresh_token:
            creds.refresh(Request())
        else:
            if not client_secret.exists():
                raise FileNotFoundError(f"Missing {client_secret}.")
            flow = InstalledAppFlow.from_client_secrets_file(str(client_secret), SCOPES)
            creds = flow.run_local_server(port=0)
        token_path.write_text(creds.to_json())
    return creds

def drive_service(creds: Credentials):
    return build("drive", "v3", credentials=creds, cache_discovery=False)

def ensure_folder(service, name: str, parent_id: Optional[str]) -> str:
    q = f"name = '{name.replace(\"'\",\"\\\\'\")}' and mimeType = 'application/vnd.google-apps.folder' and trashed = false"
    if parent_id: q += f" and '{parent_id}' in parents"
    resp = service.files().list(q=q, spaces="drive", fields="files(id, name)", pageSize=100).execute()
    files = resp.get("files", [])
    if files: return files[0]["id"]
    meta = {"name": name, "mimeType": "application/vnd.google-apps.folder"}
    if parent_id: meta["parents"] = [parent_id]
    f = service.files().create(body=meta, fields="id").execute()
    return f["id"]

def path_to_drive_tree(service, root_id: str, local_root: Path, path: Path, cache: Dict[Path, str]) -> str:
    rel = path.relative_to(local_root)
    if rel == Path("."): return root_id
    parent = path_to_drive_tree(service, root_id, local_root, path.parent, cache)
    seg = rel.name
    key = path
    if key in cache: return cache[key]
    folder_id = ensure_folder(service, seg, parent)
    cache[key] = folder_id
    return folder_id

@retry(wait=wait_exponential(min=1, max=60), stop=stop_after_attempt(7))
def upload_one(service, local_file: Path, parent_id: str, sha256: str, bar: tqdm):
    mime, _ = mimetypes.guess_type(local_file.as_posix())
    media = MediaFileUpload(local_file.as_posix(), mimetype=mime or "application/octet-stream", chunksize=CHUNK_SIZE, resumable=True)
    metadata = {"name": local_file.name, "parents": [parent_id], "description": json.dumps({"sha256": sha256})}
    req = service.files().create(body=metadata, media_body=media, fields="id, name, md5Checksum")
    response = None
    while response is None:
        status, response = req.next_chunk()
        if status and bar: bar.update(int(status.resumable_progress))
    return response["id"], response.get("md5Checksum", "")

def should_skip(existing_index: Dict[str, dict], rel: str, sha256: str) -> bool:
    e = existing_index.get(rel)
    return bool(e and e.get("sha256") == sha256)

def collect_files(root: Path):
    for p in root.rglob("*"):
        if p.is_file(): yield p

def worker_thread(service, tasks: queue.Queue, results: list, pbar: tqdm):
    while True:
        item = tasks.get()
        if item is None: break
        local_file, parent_id, sha, rel = item
        try:
            file_id, md5 = upload_one(service, local_file, parent_id, sha, pbar)
            results.append({"rel": rel, "sha256": sha, "drive_id": file_id, "md5": md5})
        except HttpError as e:
            results.append({"rel": rel, "error": str(e)})
        finally:
            tasks.task_done()

def main():
    ap = argparse.ArgumentParser(description="Prometheus → Google Drive uploader")
    ap.add_argument("--source", required=True)
    ap.add_argument("--drive-root-name", default="Prometheus")
    ap.add_argument("--dest-subpath", default="supermonorepo")
    ap.add_argument("--creds-dir", default="tools/drive_uploader/creds")
    ap.add_argument("--threads", type=int, default=max(2, os.cpu_count() or 2))
    ap.add_argument("--index", default="tools/drive_uploader/upload_index.json")
    args = ap.parse_args()

    src = Path(args.source).expanduser().resolve()
    if not src.exists() or not src.is_dir():
        raise SystemExit(f"Source not found: {src}")

    creds_dir = Path(args.creds_dir); creds_dir.mkdir(parents=True, exist_ok=True)
    creds = load_creds(creds_dir)
    service = drive_service(creds)

    root_id = ensure_folder(service, args.drive_root_name, None)
    dest_root_id = ensure_folder(service, args.dest_subpath, root_id)

    index_path = Path(args.index)
    existing_index = json.loads(index_path.read_text()) if index_path.exists() else {}

    folder_cache: Dict[Path, str] = {src: dest_root_id}
    files = list(collect_files(src))
    plan = []
    for f in files:
        rel = f.relative_to(src).as_posix()
        sha = sha256_file(f)
        if should_skip(existing_index, rel, sha): continue
        parent = path_to_drive_tree(service, dest_root_id, src, f.parent, folder_cache)
        plan.append((f, parent, sha, rel))

    if not plan:
        print("Nothing to upload (idempotent)."); return

    total_bytes = sum(p[0].stat().st_size for p in plan)
    tasks: queue.Queue = queue.Queue()
    results = []
    pbar = tqdm(total=total_bytes, unit="B", unit_scale=True, desc="Uploading")

    threads = []
    for _ in range(max(1, args.threads)):
        t = threading.Thread(target=worker_thread, args=(service, tasks, results, pbar), daemon=True)
        t.start(); threads.append(t)

    for item in plan: tasks.put(item)
    tasks.join()
    for _ in threads: tasks.put(None)
    for t in threads: t.join()
    pbar.close()

    for r in results:
        if "error" in r: continue
        existing_index[r["rel"]] = {"sha256": r["sha256"], "drive_id": r["drive_id"], "md5": r.get("md5", "")}

    index_path.parent.mkdir(parents=True, exist_ok=True)
    index_path.write_text(json.dumps(existing_index, indent=2))
    print(f"Uploaded {len([r for r in results if 'error' not in r])} files. Index written to {index_path}")

if __name__ == "__main__":
    main()
