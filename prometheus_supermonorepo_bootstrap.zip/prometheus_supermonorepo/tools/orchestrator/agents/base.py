class Agent:
  def run(self, **kwargs):
    raise NotImplementedError
