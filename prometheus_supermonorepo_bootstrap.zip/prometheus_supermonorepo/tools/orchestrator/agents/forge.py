import subprocess
from pathlib import Path
class ForgeAgent:
  def run(self, **kwargs):
    root = Path(kwargs["root"])
    for candidate in ["scripts/bootstrap.sh", "bootstrap.sh"]:
      p = root / candidate
      if p.exists():
        p.chmod(0o755)
        subprocess.check_call([str(p)], cwd=str(root))
    return True
