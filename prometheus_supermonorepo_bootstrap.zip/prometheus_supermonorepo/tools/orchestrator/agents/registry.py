from .forge import ForgeAgent
from .codex import CodexAgent
from .uploader import UploadAgent
from .verify import VerifyAgent
def get_agent(key: str):
  m = {"forge": ForgeAgent, "codex": CodexAgent, "upload": UploadAgent, "verify": VerifyAgent}
  cls = m.get(key)
  if not cls: raise KeyError(f"Unknown agent: {key}")
  return cls()
