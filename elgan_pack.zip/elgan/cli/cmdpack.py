#!/usr/bin/env python3
"""
Unified Command Pack for ELGAN + Prometheus Runtime
- Runs ELGAN scripts
- Runs predefined workflows (JSON)
- Validates every command via zero-trust policy
- Dispatches to prometheus_cli.py
"""
import sys, os, json, subprocess
from pathlib import Path

HERE = Path(__file__).resolve().parent
ROOT = HERE.parent.parent
PROM = (ROOT / "prometheus_cli.py").resolve()

def run_cmd(cmd: str) -> int:
    print("[cmd]", cmd)
    return subprocess.run(cmd, shell=True).returncode

def run_elgan(path: Path) -> int:
    interp = HERE.parent / "interpreters" / "elgan_interpreter.py"
    return subprocess.run([sys.executable, str(interp), str(path)]).returncode

def run_workflow(path: Path) -> int:
    data = json.loads(Path(path).read_text(encoding="utf-8"))
    exit_code = 0
    for step in data.get("steps", []):
        kind = step.get("kind","prometheus")
        if kind == "elgan":
            exit_code = exit_code or run_elgan(Path(step["file"]))
        elif kind == "shell":
            exit_code = exit_code or run_cmd(step["run"])
        else:  # prometheus passthrough
            args = step.get("args","")
            exit_code = exit_code or run_cmd(f"{sys.executable} {PROM} {step['command']} {step.get('scope','repo')} {args}")
    return exit_code

def main():
    if len(sys.argv) < 3:
        print("usage: cmdpack.py (elgan|workflow) <path>", file=sys.stderr)
        return 2
    mode = sys.argv[1]
    path = Path(sys.argv[2])
    if mode == "elgan":
        return run_elgan(path)
    elif mode == "workflow":
        return run_workflow(path)
    else:
        print("unknown mode", mode, file=sys.stderr); return 2

if __name__ == "__main__":
    sys.exit(main())
