#!/usr/bin/env python3
"""
Prometheus CLI (Tier-1++ Scaffold)
- Implements core commands & macros from commands.md
- Pure standard library; deterministic behavior; idempotent where applicable.

Exit codes:
 0 = success/clean
 1 = generic failure
 2 = findings/violations detected (non-zero but actionable)
 3 = configuration/runtime error
 4 = policy/codex lock violation
"""
import os, sys, re, json, stat, shutil, zipfile, hashlib, fnmatch
from pathlib import Path
from datetime import datetime
from argparse import ArgumentParser, Namespace

# ---------- Utilities ----------

def now_iso():
    return datetime.utcnow().strftime("%Y-%m-%dT%H:%M:%SZ")

def ensure_dir(p: Path):
    p.mkdir(parents=True, exist_ok=True)
    return p

def sha256_file(p: Path) -> str:
    h = hashlib.sha256()
    with p.open("rb") as f:
        for chunk in iter(lambda: f.read(65536), b""):
            h.update(chunk)
    return h.hexdigest()

def write_json(p: Path, data: dict):
    ensure_dir(p.parent)
    p.write_text(json.dumps(data, indent=2), encoding="utf-8")

def write_text(p: Path, text: str):
    ensure_dir(p.parent)
    p.write_text(text, encoding="utf-8")

def list_files(root: Path, includes=None, excludes=None):
    files = []
    for dp,_,fnames in os.walk(root):
        d = Path(dp)
        # apply exclude directory patterns
        if excludes:
            skip = any(fnmatch.fnmatch(str(d.relative_to(root)), ex) for ex in excludes if "*" in ex or "*/" in ex or "/" in ex)
            if skip:
                continue
        for fn in fnames:
            fp = d / fn
            if includes:
                if any(fnmatch.fnmatch(str(fp.relative_to(root)), pat) for pat in includes):
                    files.append(fp)
            else:
                files.append(fp)
    return files

def human(s: int) -> str:
    units = ["B","KB","MB","GB"]
    v = float(s)
    for u in units:
        if v < 1024 or u == units[-1]:
            return f"{v:.1f}{u}"
        v /= 1024

# ---------- Command Implementations ----------

class CommandBase:
    def __init__(self, args: Namespace):
        self.args = args
        self.cwd = Path(args.path or ".").resolve()
        self.reports = ensure_dir(self.cwd / "reports")
        self.dist = ensure_dir(self.cwd / "dist")

    # default execute (override)
    def run(self) -> int:
        return 0

class Wake(CommandBase):
    def run(self) -> int:
        report = {
            "command": "wake",
            "scope": self.args.scope,
            "agents": self.args.agents or ["HAL","VaultTime","Wardog","Phoenix","Hivemind","ControlNexus"],
            "safe": bool(self.args.safe),
            "force": bool(self.args.force),
            "ts": now_iso()
        }
        write_json(self.reports / "wake.json", report)
        print("[wake] agents online:", ", ".join(report["agents"]))
        return 0

class Sync(CommandBase):
    def run(self) -> int:
        report = {
            "command":"sync","scope":self.args.scope,
            "mode": "two-way" if self.args.two_way or not(self.args.pull or self.args.push) else ("pull" if self.args.pull else "push"),
            "index": bool(self.args.index),
            "vectors": bool(self.args.vectors),
            "ci": bool(self.args.ci),
            "normalized": True,
            "ts": now_iso()
        }
        write_json(self.reports / "sync.json", report)
        print(f"[sync] mode={report['mode']} index={report['index']} vectors={report['vectors']}")
        return 0

class RepairInits(CommandBase):
    def run(self) -> int:
        changes = []
        for dp, dirnames, _ in os.walk(self.cwd):
            d = Path(dp)
            # skip typical ignore dirs
            rel = str(d.relative_to(self.cwd))
            if rel.startswith(("dist","reports",".git","__pycache__")):
                continue
            # if directory has .py files, ensure __init__.py
            py_present = any(f.endswith(".py") for f in os.listdir(d) if os.path.isfile(d / f))
            if py_present and not (d / "__init__.py").exists():
                if self.args.write:
                    (d / "__init__.py").write_text("# auto-created by repair_inits\n", encoding="utf-8")
                changes.append(str(d))
        report = {"command":"repair_inits","dry_run": not self.args.write,"created":changes,"ts":now_iso()}
        write_json(self.reports / "repair_inits.json", report)
        print(f"[repair_inits] created: {len(changes)} (dry_run={not self.args.write})")
        return 0

PLACEHOLDER_TERMS_DEFAULT = ["PLACEHOLDER","STUB","LOREM","TBD","TODO","FIXME"]

class PlaceholderGate(CommandBase):
    def run(self) -> int:
        terms = (self.args.terms or ",".join(PLACEHOLDER_TERMS_DEFAULT)).split(",")
        findings = []
        for f in list_files(self.cwd):
            rel = f.relative_to(self.cwd).as_posix()
            if rel.startswith(("sandbox/","examples/","dist/","reports/",".git/","__pycache__/")):
                continue
            # scan only text-ish files
            try:
                text = f.read_text(encoding="utf-8", errors="ignore")
            except Exception:
                continue
            for t in terms:
                if t and t in text:
                    findings.append({"file":rel,"term":t})
        report = {"command":"placeholder_gate","findings":findings,"ts":now_iso()}
        write_json(self.reports / "placeholder_report.json", report)
        print(f"[placeholder_gate] findings: {len(findings)}")
        return 0 if not findings else 2

SECRET_PATTERNS = [
    (r"AKIA[0-9A-Z]{16}", "aws_access_key"),
    (r"(?i)secret[_-]?key\s*=\s*['\"][A-Za-z0-9/\+=_:\-]{16,}['\"]", "generic_secret_key"),
    (r"(?i)api[_-]?key\s*[:=]\s*['\"][A-Za-z0-9/\+=_:\-]{16,}['\"]", "api_key_literal"),
    (r"-----BEGIN (?:RSA|EC|OPENSSH) PRIVATE KEY-----", "private_key_block"),
]

DANGEROUS_APIS = [
    (r"os\.system\(", "os_system_call"),
    (r"subprocess\.Popen\(", "subprocess_popen"),
    (r"eval\(", "eval_usage"),
    (r"exec\(", "exec_usage"),
]

class SecureGuard(CommandBase):
    def run(self) -> int:
        ruleset = self.args.ruleset or "default"
        includes = self.args.include.split(",") if self.args.include else None
        excludes = self.args.exclude.split(",") if self.args.exclude else None
        path = self.cwd if self.args.path in (None, ".", "") else Path(self.args.path).resolve()

        files = [path] if path.is_file() else list_files(path, includes, excludes)
        findings = []

        for f in files:
            if f.is_dir():
                continue
            size = f.stat().st_size
            text = ""
            try:
                text = f.read_text(encoding="utf-8", errors="ignore")
            except Exception:
                # binary or unreadable; flag if suspicious extension
                if size > 0 and any(f.suffix.lower() == ext for ext in [".pem",".key",".p12",".der"]):
                    findings.append({"file": str(f), "rule": "binary_secret_artifact"})
                continue

            if self.args.secrets:
                for rx, name in SECRET_PATTERNS:
                    if re.search(rx, text):
                        findings.append({"file": str(f), "rule": f"secret:{name}"})

            if self.args.sast:
                for rx, name in DANGEROUS_APIS:
                    if re.search(rx, text):
                        findings.append({"file": str(f), "rule": f"sast:{name}"})

            # crude license header presence check
            if self.args.licenses:
                if f.suffix in (".py",".ts",".js",".swift",".go",".rs",".java",".md"):
                    if "Copyright" not in text and "Licensed under" not in text and "SPDX-License-Identifier" not in text:
                        findings.append({"file": str(f), "rule": "license:missing_header"})

        report = {
            "command":"secure_guard",
            "scope": self.args.scope,
            "ruleset": ruleset,
            "findings": findings,
            "ts": now_iso()
        }
        write_json(self.reports / "secure_guard.json", report)
        print(f"[secure_guard] scanned={len(files)} findings={len(findings)} ruleset={ruleset}")
        return 0 if not findings else 2

class SBOM(CommandBase):
    def run(self) -> int:
        out = Path(self.args.out or "sbom.json")
        # Simple SBOM: enumerate files & hashes
        entries = []
        total = 0
        for f in list_files(self.cwd, excludes=[".git/*","dist/*","reports/*","__pycache__/*"]):
            if f.is_file():
                h = sha256_file(f)
                s = f.stat().st_size
                entries.append({"path": str(f.relative_to(self.cwd)), "sha256": h, "size": s})
                total += s
        data = {"schema":"prometheus/sbom@v1","created":now_iso(),"total_size": total,"files":entries}
        write_json(self.cwd / out, data)
        print(f"[sbom] files={len(entries)} size={total} -> {out}")
        return 0

class ForgeZip(CommandBase):
    def run(self) -> int:
        source = Path(self.args.source or ".").resolve()
        out = self.dist / (self.args.out or f"{source.name}.zip")
        ensure_dir(out.parent)
        # inject starter script into a temp dir copy
        temp = self.dist / "_forge_temp"
        if temp.exists():
            shutil.rmtree(temp)
        shutil.copytree(source, temp, dirs_exist_ok=True, ignore=shutil.ignore_patterns("dist","reports","__pycache__",".git"))
        starter = temp / "PROMETHEUS_STARTER.sh"
        starter.write_text("#!/bin/sh\nset -e\nprintf 'Prometheus Starter\\n'\n", encoding="utf-8")
        os.chmod(starter, os.stat(starter).st_mode | stat.S_IEXEC)
        # zip
        with zipfile.ZipFile(out, "w", zipfile.ZIP_DEFLATED) as zf:
            for dp,_,fnames in os.walk(temp):
                for fn in fnames:
                    p = Path(dp) / fn
                    zf.write(p, p.relative_to(temp).as_posix())
        # provenance
        checksum = sha256_file(out)
        prov = {"artifact": out.name, "sha256": checksum, "created": now_iso()}
        write_json(self.reports / f"{out.stem}_provenance.json", prov)
        shutil.rmtree(temp, ignore_errors=True)
        print(f"[forge_zip] created {out} sha256={checksum[:12]}...")
        return 0

class TBoxAudit(CommandBase):
    def run(self) -> int:
        # Run sub-commands in-process
        code = 0
        # repair_inits
        code |= RepairInits(self.args).run()
        # placeholder_gate
        pg_args = Namespace(**{**self.args.__dict__,"terms":None})
        code |= PlaceholderGate(pg_args).run()
        # secure_guard strict
        sg_args = Namespace(**{**self.args.__dict__,"ruleset":"strict","include":None,"exclude":None,"secrets":True,"licenses":True,"deps":False,"sast":True})
        code |= SecureGuard(sg_args).run()
        # sbom
        sb_args = Namespace(**{**self.args.__dict__,"out":"build/sbom.json"})
        code |= SBOM(sb_args).run()
        report = {"command":"tbox_audit","result_code":code,"ts":now_iso()}
        write_json(self.reports / "tbox_audit.json", report)
        print(f"[tbox] audit exit={code}")
        return code

class Release(CommandBase):
    def run(self) -> int:
        version = self.args.version or "0.0.0"
        channel = self.args.channel or "beta"
        notes = self.args.notes or "CHANGELOG.md"
        rec = {"command":"release","version":version,"channel":channel,"notes":notes,"ts":now_iso()}
        write_json(self.reports / f"release_{version}.json", rec)
        print(f"[release] v{version} channel={channel}")
        return 0

# Stubs (deterministic)
class WakeSyncStub(CommandBase):
    def run(self) -> int:
        write_json(self.reports / f"{self.args.command}.json", {"command":self.args.command,"ts":now_iso()})
        print(f"[{self.args.command}] ok")
        return 0

# ---------- Macro Engine ----------

DEFAULT_MACROS = {
    ":bootstrap": [
        "wake repo --agents=* --safe",
        "sync repo --two-way --index",
        "repair_inits repo --write",
        "format all --write",
        "lint repo --strict"
    ],
    ":hardening-pass": [
        "tbox audit all --fix",
        "secure_guard repo --ruleset=strict --secrets --deps --licenses --sast",
        "policy_enforcer all --fail-on=warning",
        "sbom repo --format=cyclonedx --out=build/sbom.json",
        "vaulttime all --owner=Adam --license=Proprietary --attest"
    ],
    ":ship-beta": [
        ":hardening-pass",
        "test all --unit --integration",
        "forge repo --zip --release --version=${version} --with=tbox,cst++ --sign",
        "release repo --version=${version} --channel=beta --notes=CHANGELOG.md"
    ],
    ":truth-run": [
        "truth_analysis all --depth=full --report=reports/truth.json",
        "awareness++ all --validate --report=reports/awareness.json",
        "index all --full",
        "vectors docs --providers=local --namespace=prometheus"
    ],
    ":fork-cycle": [
        "fork.create ${name} --type=forward",
        "fork.validate ${name} --profiles=composite",
        "fork.collapse ${name} --metric=composite"
    ],
    ":release-stable": [
        ":hardening-pass",
        "test all --unit --integration --e2e",
        "forge repo --zip --release --version=${version} --with=tbox,cst++ --sign --provenance",
        "vaulttime all --owner=Adam --license=Proprietary --attest --pdf",
        "release repo --version=${version} --channel=stable --notes=CHANGELOG.md"
    ]
}

def run_shell_like(cmdline: str, cli_entry):
    # very small parser: split by spaces; no quotes handling for simplicity
    parts = [p for p in cmdline.strip().split() if p]
    if not parts:
        return 0
    return cli_entry(parts)

# ---------- CLI Wiring ----------

def build_parser():
    p = ArgumentParser(prog="prometheus", description="Prometheus CLI")
    sub = p.add_subparsers(dest="command", required=True)

    # wake
    sp = sub.add_parser("wake")
    sp.add_argument("scope", nargs="?", default="repo")
    sp.add_argument("--agents")
    sp.add_argument("--safe", action="store_true")
    sp.add_argument("--force", action="store_true")
    sp.add_argument("--path")
    sp.set_defaults(handler=Wake)

    # sync
    sp = sub.add_parser("sync")
    sp.add_argument("scope", nargs="?", default="repo")
    sp.add_argument("--pull", action="store_true")
    sp.add_argument("--push", action="store_true")
    sp.add_argument("--two-way", action="store_true")
    sp.add_argument("--index", action="store_true")
    sp.add_argument("--vectors", action="store_true")
    sp.add_argument("--ci", action="store_true")
    sp.add_argument("--path")
    sp.set_defaults(handler=Sync)

    # repair_inits
    sp = sub.add_parser("repair_inits")
    sp.add_argument("scope", nargs="?", default="repo")
    sp.add_argument("--write", action="store_true")
    sp.add_argument("--path")
    sp.set_defaults(handler=RepairInits)

    # placeholder_gate
    sp = sub.add_parser("placeholder_gate")
    sp.add_argument("scope", nargs="?", default="repo")
    sp.add_argument("--root")
    sp.add_argument("--terms")
    sp.add_argument("--path")
    sp.set_defaults(handler=PlaceholderGate)

    # secure_guard
    sp = sub.add_parser("secure_guard")
    sp.add_argument("scope", nargs="?", default="repo")
    sp.add_argument("--path")
    sp.add_argument("--ruleset")
    sp.add_argument("--include")
    sp.add_argument("--exclude")
    sp.add_argument("--secrets", action="store_true")
    sp.add_argument("--licenses", action="store_true")
    sp.add_argument("--deps", action="store_true")
    sp.add_argument("--sast", action="store_true")
    sp.set_defaults(handler=SecureGuard)

    # sbom
    sp = sub.add_parser("sbom")
    sp.add_argument("scope", nargs="?", default="repo")
    sp.add_argument("--out")
    sp.add_argument("--path")
    sp.set_defaults(handler=SBOM)

    # tbox audit (single combined)
    sp = sub.add_parser("tbox")
    sp.add_argument("action", nargs="?", default="audit")
    sp.add_argument("scope", nargs="?", default="repo")
    sp.add_argument("--fix", action="store_true")
    sp.add_argument("--path")
    sp.set_defaults(handler=TBoxAudit)

    # forge_zip
    sp = sub.add_parser("forge_zip")
    sp.add_argument("--source")
    sp.add_argument("--out")
    sp.add_argument("--path")
    sp.set_defaults(handler=ForgeZip)

    # release
    sp = sub.add_parser("release")
    sp.add_argument("scope", nargs="?", default="repo")
    sp.add_argument("--version")
    sp.add_argument("--channel")
    sp.add_argument("--notes")
    sp.add_argument("--path")
    sp.set_defaults(handler=Release)

    # stubs for remaining commands to keep the interface complete
    for name in ["bind","forge","naglize","vaulttime","codex-lock",
                 "cst++","hal","jctest","policy_enforcer","format","lint",
                 "test","awareness++","truth_analysis","777","index","vectors",
                 "fork.create","fork.validate","fork.collapse"]:
        sp = sub.add_parser(name)
        sp.add_argument("scope", nargs="?", default="repo")
        sp.add_argument("--path")
        sp.set_defaults(handler=WakeSyncStub)

    # macro runner
    sp = sub.add_parser(":macro")
    sp.add_argument("name")
    sp.add_argument("--args", nargs="*", default=[])
    sp.add_argument("--path")
    def macro_handler(args):
        macros = DEFAULT_MACROS.copy()
        name = args.name
        if name not in macros:
            print(f"[macro] not found: {name}", file=sys.stderr)
            return 1
        # prepare vars map from --args like k=v
        kv = {}
        for a in args.args:
            if "=" in a:
                k,v = a.split("=",1)
                kv[k]=v
        exit_code = 0
        for step in macros[name]:
            # recursive macro call support
            if step.startswith(":"):
                code = run_shell_like(f":macro {step}", cli_entrypoint)
                exit_code = exit_code or code
                continue
            # interpolate ${var}
            for k,v in kv.items():
                step = step.replace("${"+k+"}", v)
            code = run_shell_like(step, cli_entrypoint)
            exit_code = exit_code or code
        print(f"[macro] {name} exit={exit_code}")
        return exit_code
    sp.set_defaults(handler=macro_handler)

    return p

def cli_entrypoint(argv=None):
    argv = argv or sys.argv[1:]
    parser = build_parser()
    args = parser.parse_args(argv)
    # let stubs know their command name
    if hasattr(args, "handler") and args.handler == WakeSyncStub:
        args.command = parser.prog if not argv else argv[0]
    handler = args.handler(args) if callable(args.handler) else args.handler
    return handler.run() if hasattr(handler, "run") else handler(args)

if __name__ == "__main__":
    sys.exit(cli_entrypoint())
