# Prometheus Command & Macro Spec (Tier-1++)

## Command format
```
<verb> [target|scope] [--flags ...] [key=value ...]
```
- Idempotent unless noted.
- Pre/Post hooks: each command may call `pre::<verb>` / `post::<verb>`.
- Scope keywords: repo | project | module | file | all.
- Dry-run: add `--plan` to see actions.

---

## Core Lifecycle

### `wake [scope]`
- Purpose: bring systems/agents online; reload configs; register hooks.
- Inputs: `--agents=*` (HAL, VaultTime, Wardog, Phoenix, Hivemind, ControlNexus), `--safe`, `--force`
- Effects: starts required daemons; verifies health; mounts project manifests.
- Idempotency: yes (restarts only if unhealthy).

### `sync [scope]`
- Purpose: reconcile state: files, configs, manifests, indexes, embeddings.
- Inputs: `--pull`, `--push`, `--two-way` (default), `--index`, `--vectors`, `--ci`
- Effects: updates SBOM, search indexes, vector stores; normalizes line endings/perm.
- Idempotency: yes.

### `bind [thing]`
- Purpose: attach an asset (code, docs, agent, config) into Prometheus Runtime.
- Inputs: `thing` path or alias, `--as=<role>`, `--project=<name>`
- Effects: writes manifest, registers ownership, updates imports/routes.

### `forge [scope]`
- Purpose: build + package targets to Tier-1++ artifact.
- Inputs: `--zip|--tar|--dmg|--ipa|--docker`, `--release`, `--version=X.Y.Z`
- Effects: runs tests → hardening → SBOM → signs → bundles.
- Alias: `hal forge` (same pipeline, HAL-supervised).

### `naglize [scope]`
- Purpose: apply Adam’s defaults (quality bars, naming, structure).
- Inputs: `--strict` (fail on any deviation)
- Effects: refactors to canonical structure & style, updates docs/templates.

### `vaulttime [scope]`
- Purpose: license/sign/attest artifacts & docs.
- Inputs: `--owner=Adam`, `--license=<type>`, `--attest`, `--bill-of-materials`
- Effects: immutable PDFs, provenance, chain-of-custody, signature blocks.

### `codex-lock [scope]`
- Purpose: freeze logic/specs under Codex control.
- Inputs: `--reason=<text>`, `--unlock-token=<id>` (for future change)
- Effects: prevents drift; records change protocol; requires unlock to modify.

---

## Validation & Hardening

### `secure_guard [scope]`
- Purpose: single-file or tree security scanner (CLI/CI-ready).
- Inputs:  
  `--ruleset=default,strict,paranoid` · `--path=<file|dir>` · `--include=glob1,glob2` · `--exclude=glob` · `--secrets` · `--licenses` · `--deps` · `--sast` · `--sbom-link`  
- Checks:  
  Secrets (keys/tokens), high-risk regexes, unsafe APIs, weak crypto, OS injections, dependency CVEs, license conflicts, binary blobs, policy violations.  
- Outputs:  
  Machine JSON at `reports/secure_guard.json` and human summary at `reports/secure_guard.txt`. Exit codes: `0=clean`, `2=findings`, `3=error`.  
- Idempotency: yes.  
- Examples:  
  `secure_guard repo --path=. --ruleset=strict --secrets --deps --licenses`

### `policy_enforcer [scope]`
- Purpose: enforce configurable repository policies.
- Inputs: `--config=runtime/config/policy_config.json` · `--fail-on=warning,error` · `--report=reports/policy.json`
- Checks: required headers, NOTICE blocks, file naming, disallowed terms, binary-in-text, TODO/FIXME ceilings, required companions (`.manifest`, `.test`).  
- Idempotency: yes.  
- Example: `policy_enforcer all --fail-on=warning`

### `placeholder_gate [scope]`
- Purpose: block placeholders from entering release artifacts.
- Inputs: `--root=.` · `--out=reports/placeholder_report.json` · `--terms=PLACEHOLDER,STUB,LOREM,TBD,TODO,FIXME`
- Behavior: fails if any flagged term exists outside `sandbox/` or `examples/`.  
- Example: `placeholder_gate repo --root .`

### `sbom [scope]`
- Purpose: generate and validate Software Bill of Materials.
- Inputs: `--format=cyclonedx,spdx` · `--out=sbom.json` · `--deps` · `--lockfiles`
- Behavior: enumerates packages, hashes, licenses; links to `secure_guard` CVE scan.  
- Example: `sbom repo --format=cyclonedx --out=build/sbom.json`

### `repair_inits [scope]`
- Purpose: auto-create missing `__init__.py`, manifests, tests per policy.
- Inputs: `--write` (default read-only dry-run) · `--report=reports/repair_inits.json`
- Idempotency: yes—re-runs make no further changes.  
- Example: `repair_inits module --write`

### `tbox audit [scope]`
- Purpose: composite audit (structure, perms, runnability).
- Inputs: `--fix` · `--report=reports/tbox_audit.json`
- Flow: runs `repair_inits` → `placeholder_gate` → `policy_enforcer` → `secure_guard` → `sbom`.  
- Example: `tbox audit all --fix`

---

## Build & Packaging

### `forge [scope]`
- Purpose: build, harden, package, sign.
- Inputs:  
  Packaging: `--zip|--tar|--dmg|--ipa|--docker`  
  Release: `--release` · `--version=X.Y.Z` · `--changelog=CHANGELOG.md`  
  Hardening: `--with=tbox,secure_guard,cst++`  
  Signing: `--sign` · `--provenance`
- Outputs: artifact under `dist/` with SBOM + signatures.  
- Aliases: `hal forge` (HAL-supervised).  
- Example: `forge repo --zip --release --version=1.2.3 --with=tbox,cst++ --sign`

### `forge_zip`
- Purpose: opinionated zip bundler with self-heal scripts.
- Inputs: `--source=.` · `--out=dist/<name>.zip` · `--provenance`
- Behavior: injects `PROMETHEUS_STARTER.sh`, checksum, README, manifests.  
- Example: `forge_zip --source .`

---

## Runtime Intelligence

### `awareness++ [scope]`
- Purpose: bind Awareness model and validate project/state.
- Inputs: `--validate` · `--repair` · `--report=reports/awareness.json`
- Effects: updates `runtime/prometheus/docs/awareness_runtime_model.md`.  
- Example: `awareness++ project --validate`

### `truth_analysis [scope]`
- Purpose: run SkyWalk + CST bindpass + HAL review.
- Inputs: `--depth=full|quick` · `--report=reports/truth.json`
- Effects: detects unbound modules, missing vectors, drift; proposes binds.  
- Example: `truth_analysis all --depth=full`

### `777 [scope]`
- Purpose: 777 diagnostic mode (deep analysis, suspicion grading).
- Inputs: `--max` · `--report=reports/777.json`
- Behavior: ranks highest-risk findings first, emits concrete remediation.  
- Example: `777 repo --max`

---

## Fork Engine (Schrödinger)

### `fork.create [name]`
- Purpose: create a forward/lateral fork variant.
- Inputs: `--type=forward|lateral` · `--notes="..."`  
- Output: registers under `optimization_engine/schrodinger_forks/[name]/`.

### `fork.validate [name]`
- Purpose: run HAL + JC-Test + CST++ validation.
- Inputs: `--profiles=perf,accuracy,entropy` · `--report=reports/fork_[name].json`

### `fork.collapse [name]`
- Purpose: deterministically select superior fork.
- Inputs: `--metric=accuracy|perf|stability|composite`  
- Effects: promotes winner → Codex-lock; archives others to `/legacy/forks`.

---

## Data & Indexing

### `index [scope]`
- Purpose: rebuild code/doc index for search & RAG.
- Inputs: `--full` · `--incremental` · `--out=runtime/index/`
- Example: `index repo --full`

### `vectors [scope]`
- Purpose: embed and sync to vector store(s).
- Inputs: `--providers=local,pinecone,weaviate` · `--namespace=<project>`  
- Example: `vectors docs --providers=local --namespace=prometheus`

---

## Ownership & Licensing

### `vaulttime [scope]`
- Purpose: license/sign/attest (immutable).
- Inputs: `--owner=Adam` · `--license=Proprietary|Apache-2.0|MIT` · `--attest` · `--pdf`
- Outputs: `/licenses/`, `/attestations/`, signed PDFs.  
- Example: `vaulttime all --owner=Adam --license=Proprietary --attest`

### `codex-lock [scope]`
- Purpose: freeze critical logic/spec.
- Inputs: `--reason="..."` · `--unlock-token=<id>`
- Effects: change-control enforced at commit and forge time.

---

## Project Hygiene

### `format [scope]`
- Purpose: apply canonical formatting (code + docs).
- Inputs: `--lang=py,ts,swift,md` · `--write`
- Example: `format all --write`

### `lint [scope]`
- Purpose: multilanguage lint.
- Inputs: `--lang=py,ts,swift` · `--strict`
- Example: `lint repo --lang=py,ts --strict`

### `test [scope]`
- Purpose: run tests.
- Inputs: `--unit` · `--integration` · `--e2e` · `--report=reports/tests.xml`
- Example: `test all --unit --integration`

---

## Release Orchestration

### `release [scope]`
- Purpose: create a signed, versioned release.
- Inputs: `--version=X.Y.Z` · `--channel=alpha,beta,stable` · `--notes=CHANGELOG.md`
- Flow: `tbox audit` → `forge` → `vaulttime` → provenance manifest.  
- Example: `release repo --version=1.2.0 --channel=beta`

---

# Macro System

## Macro Syntax
```
:macro <name> [args...]      # invoke macro
:macro.define <name> <<EOF   # define multi-step macro
  <command 1>
  <command 2>
EOF
```
- Macros are idempotent unless a step explicitly mutates state beyond policy.
- Macros can call commands, other macros, and support `${arg}` interpolation.

## Canonical Macros

### `:bootstrap`
- Intent: initialize repo to Prometheus standard.
- Steps:  
  `wake repo --agents=* --safe`  
  `sync repo --two-way --index`  
  `repair_inits repo --write`  
  `format repo --write`  
  `lint repo --strict`

### `:hardening-pass`
- Intent: Tier-1++ hardening.
- Steps:  
  `tbox audit all --fix`  
  `secure_guard repo --ruleset=strict --secrets --deps --licenses --sast`  
  `policy_enforcer all --fail-on=warning`  
  `sbom repo --format=cyclonedx --out=build/sbom.json`  
  `vaulttime all --owner=Adam --license=Proprietary --attest`

### `:ship-beta`
- Intent: produce Beta build artifact.
- Args: `${version}`  
- Steps:  
  `:hardening-pass`  
  `test all --unit --integration`  
  `forge repo --zip --release --version=${version} --with=tbox,cst++ --sign`  
  `release repo --version=${version} --channel=beta --notes=CHANGELOG.md`

### `:truth-run`
- Intent: full truth analysis + awareness validation.
- Steps:  
  `truth_analysis all --depth=full --report=reports/truth.json`  
  `awareness++ all --validate --report=reports/awareness.json`  
  `index all --full`  
  `vectors docs --providers=local --namespace=prometheus`

### `:fork-cycle`
- Intent: create, validate, and collapse fork variants.
- Args: `${name}`  
- Steps:  
  `fork.create ${name} --type=forward`  
  `fork.validate ${name} --profiles=composite`  
  `fork.collapse ${name} --metric=composite`

### `:release-stable`
- Intent: cut a stable, signed release.
- Args: `${version}`  
- Steps:  
  `:hardening-pass`  
  `test all --unit --integration --e2e`  
  `forge repo --zip --release --version=${version} --with=tbox,cst++ --sign --provenance`  
  `vaulttime all --owner=Adam --license=Proprietary --attest --pdf`  
  `release repo --version=${version} --channel=stable --notes=CHANGELOG.md`

---

# Return Codes
- 0 success/clean
- 1 generic failure
- 2 findings/violations detected (non-zero but actionable)
- 3 configuration/runtime error
- 4 policy or codex lock violation
