# initialize_adam.sh - Snapshot for Adam Nagle
