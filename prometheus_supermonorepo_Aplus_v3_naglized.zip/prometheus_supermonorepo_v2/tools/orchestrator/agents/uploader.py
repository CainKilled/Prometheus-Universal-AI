import subprocess
from pathlib import Path
UPL = Path("tools/drive_uploader/drive_uploader.py").resolve()
class UploadAgent:
  def run(self, **kwargs):
    root = Path(kwargs["root"]).resolve()
    upload_path = Path(kwargs["upload_path"]).resolve()
    drive_root = kwargs["drive_root_name"]
    dest_subpath = kwargs["dest_subpath"]
    threads = str(kwargs["threads"])
    subprocess.check_call([
      "python", str(UPL),
      "--source", str(upload_path),
      "--drive-root-name", drive_root,
      "--dest-subpath", dest_subpath + "/artifacts",
      "--threads", threads
    ], cwd=str(root))
    return True
