#!/usr/bin/env bash
set -euo pipefail
VERSION="${VERSION:-}"
if [ -z "${VERSION}" ]; then
  echo "VERSION is required (e.g., VERSION=v1.0.0)"
  exit 2
fi

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
OUT_DIR="${ROOT}/dist/releases/${VERSION}"
[ -d "$OUT_DIR" ] || { echo "Release dir not found: $OUT_DIR"; exit 2; }

echo "[*] Sealing with VaultTime (requires VAULTTIME_KEY)"
SEAL_SCOPE=changed VAULTTIME_KEY="${VAULTTIME_KEY:?set VAULTTIME_KEY}" python "${ROOT}/tools/vaulttime_seal.py"

echo "[*] HMAC signing SHA256SUMS"
python - << 'PY'
import os, hmac, hashlib, base64, json
from pathlib import Path
ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / 'dist' / 'releases' / os.environ['VERSION']
key = os.environ['VAULTTIME_KEY'].encode('utf-8')
sums = (OUT / 'SHA256SUMS.txt').read_bytes()
sig = hmac.new(key, sums, hashlib.sha256).hexdigest()
(OUT / 'SHA256SUMS.txt.hmac').write_text(sig, encoding='utf-8')
print("Wrote SHA256SUMS.txt.hmac")
PY

if [ -n "${COSIGN_PRIVATE_KEY:-}" ]; then
  echo "[*] Cosign present; signing all artifacts with cosign"
  echo "$COSIGN_PRIVATE_KEY" | base64 -d > "${OUT_DIR}/cosign.key"
  for a in "${OUT_DIR}"/*; do
    [ -f "$a" ] || continue
    cosign sign-blob --key "${OUT_DIR}/cosign.key" "$a" --output-signature "$a.sig" ${COSIGN_PASSWORD:+--pass-env COSIGN_PASSWORD}
  done
fi

if [ -n "${GPG_PRIVATE_KEY:-}" ]; then
  echo "[*] GPG present; signing all artifacts with GPG"
  echo "$GPG_PRIVATE_KEY" | base64 -d | gpg --batch --import
  for a in "${OUT_DIR}"/*; do
    [ -f "$a" ] || continue
    gpg --batch --yes --pinentry-mode loopback ${GPG_PASSPHRASE:+--passphrase "$GPG_PASSPHRASE"} --armor --output "$a.asc" --detach-sign "$a"
  done
fi

echo "[*] Done signing."
