
#!/usr/bin/env python3
import argparse, sys, os, glob, subprocess, shutil
from pathlib import Path
from prometheus_core.orchestrator import load_profile, start_service, stop_service, wait_healthy
from prometheus_core.watcher import watch

ROOT = Path(__file__).resolve().parents[1]

def _run(cmd, cwd=None, env=None, check=False):
    e = os.environ.copy()
    if env: e.update(env)
    print(f"$ {cmd}   # cwd={cwd or ROOT}")
    proc = subprocess.run(cmd, cwd=str(cwd or ROOT), env=e, shell=True, text=True)
    if check and proc.returncode != 0:
        sys.exit(proc.returncode)
    return proc.returncode

# ---------- lifecycle ----------
def cmd_start(args):
    prof = load_profile(args.profile)
    for s in prof.services:
        print(f"[start] {s.name}")
        _run(s.command, cwd=ROOT / s.cwd, env=s.env)
        if args.wait:
            ok = wait_healthy(s, retries=10)
            print(f"  -> healthy={ok}")
    return 0

def cmd_stop(args):
    prof = load_profile(args.profile)
    for s in prof.services:
        print(f"[stop] {s.name}")
        # best-effort: if compose, down; else pkill
        if s.type == "compose":
            _run("docker compose down -v", cwd=ROOT / s.cwd)
        else:
            _run(f"pkill -f "{s.command}" || true")
    return 0

def cmd_watch(args):
    print(f"[watch] profile={args.profile}")
    watch(args.profile, backoff=args.interval)

# ---------- quality gates ----------
def cmd_lint(args):
    rc = 0
    # pre-commit if available
    rc |= _run("pre-commit run --all-files || true")
    # language-specific fallbacks
    if shutil.which("ruff"):
        rc |= _run("ruff check . || true")
        rc |= _run("ruff format --check . || true")
    if shutil.which("black"):
        rc |= _run("black --check . || true")
    if shutil.which("markdownlint"):
        rc |= _run("markdownlint **/*.md || true")
    if shutil.which("yamllint"):
        rc |= _run("yamllint . || true")
    if shutil.which("shellcheck"):
        rc |= _run("shellcheck -x $(git ls-files '*.sh') || true")
    if shutil.which("hadolint"):
        rc |= _run("hadolint $(git ls-files '**/Dockerfile') || true")
    # node: eslint if present
    for pkg in ROOT.rglob("package.json"):
        if (pkg.parent / "node_modules/.bin/eslint").exists() or shutil.which("eslint"):
            rc |= _run("npm run -s lint || npx --yes eslint . || true", cwd=pkg.parent)
    print(f"[lint] rc={rc}")
    return rc

def cmd_test(args):
    rc = 0
    # Python pytest where present
    for req in ROOT.rglob("requirements.txt"):
        if (req.parent / "tests").exists():
            rc |= _run("pytest -q || true", cwd=req.parent)
    # Swift tests
    for swift_pkg in ROOT.rglob("Package.swift"):
        if "clients/prometheus-swift" in str(swift_pkg) or "apps/prometheus-swift-server" in str(swift_pkg):
            rc |= _run("swift test || true", cwd=swift_pkg.parent)
    # Node tests
    for pkg in ROOT.rglob("package.json"):
        rc |= _run("npm test --silent || true", cwd=pkg.parent)
    print(f"[test] rc={rc}")
    return rc

def cmd_verify(args):
    return _run("python tools/verify_all.py", check=False)

# ---------- release & shipping ----------
def cmd_release(args):
    if not args.version:
        print("ERROR: --version is required, e.g. v1.2.3")
        return 2
    env = {"VERSION": args.version}
    return _run("make release", env=env)

def cmd_docker_publish(args):
    env = {
        "VERSION": args.version,
        "DOCKER_REGISTRIES": args.registries,
        "DOCKER_NAMESPACE": args.namespace,
        "PLATFORMS": args.platforms,
    }
    return _run("./tools/docker_publish.sh", env=env)

def cmd_helm_deploy(args):
    chart = Path(args.chart)
    if not chart.exists():
        print(f"Chart not found: {chart}")
        return 2
    ns = args.namespace
    rel = args.release
    # Helm values for image.* if provided
    set_flags = []
    if args.image_registry:   set_flags += [f'--set', f'image.registry={args.image_registry}']
    if args.image_namespace:  set_flags += [f'--set', f'image.namespace={args.image_namespace}']
    if args.image_version:    set_flags += [f'--set', f'image.version={args.image_version}']
    cmd = f"helm upgrade --install {rel} {chart} --namespace {ns} --create-namespace {' '.join(set_flags)}"
    return _run(cmd)

def main():
    p = argparse.ArgumentParser("proctl", description="Prometheus orchestrator & devops CLI")
    sub = p.add_subparsers(dest="cmd")

    # lifecycle
    p_start = sub.add_parser("start", help="Start services in a profile")
    p_start.add_argument("-p","--profile", required=True, help="path to orchestrator yml")
    p_start.add_argument("--wait", action="store_true")
    p_start.set_defaults(func=cmd_start)

    p_stop = sub.add_parser("stop", help="Stop services in a profile")
    p_stop.add_argument("-p","--profile", required=True)
    p_stop.set_defaults(func=cmd_stop)

    p_watch = sub.add_parser("watch", help="Self-healing watcher")
    p_watch.add_argument("-p","--profile", required=True)
    p_watch.add_argument("-i","--interval", type=int, default=5)
    p_watch.set_defaults(func=cmd_watch)

    # quality
    p_lint = sub.add_parser("lint", help="Run linters (pre-commit + language fallbacks)")
    p_lint.set_defaults(func=cmd_lint)

    p_test = sub.add_parser("test", help="Run tests across stacks")
    p_test.set_defaults(func=cmd_test)

    p_verify = sub.add_parser("verify", help="Run system integrity verification")
    p_verify.set_defaults(func=cmd_verify)

    # release & shipping
    p_rel = sub.add_parser("release", help="Build + sign release artifacts")
    p_rel.add_argument("--version", required=True, help="vX.Y.Z")
    p_rel.set_defaults(func=cmd_release)

    p_dp = sub.add_parser("docker-publish", help="Buildx multi-arch image push (all Dockerfiles)")
    p_dp.add_argument("--version", required=True)
    p_dp.add_argument("--registries", default="ghcr.io,docker.io")
    p_dp.add_argument("--namespace", required=True)
    p_dp.add_argument("--platforms", default="linux/amd64,linux/arm64")
    p_dp.set_defaults(func=cmd_docker_publish)

    p_helm = sub.add_parser("helm-deploy", help="Helm upgrade/install for a chart")
    p_helm.add_argument("--chart", required=True, help="path to chart dir")
    p_helm.add_argument("--namespace", required=True)
    p_helm.add_argument("--release", required=True)
    p_helm.add_argument("--image-registry", default=None)
    p_helm.add_argument("--image-namespace", default=None)
    p_helm.add_argument("--image-version", default=None)
    p_helm.set_defaults(func=cmd_helm_deploy)

    args = p.parse_args()
    if not hasattr(args, "func"):
        p.print_help(); return 2
    return args.func(args)

if __name__ == "__main__":
    sys.exit(main())
