
import time
from .orchestrator import start_service, stop_service, healthy, wait_healthy, load_profile

def watch(profile_path: str, backoff:int=5):
    prof = load_profile(profile_path)
    while True:
        for svc in prof.services:
            if not healthy(svc):
                start_service(svc)
                wait_healthy(svc)
        time.sleep(backoff)
