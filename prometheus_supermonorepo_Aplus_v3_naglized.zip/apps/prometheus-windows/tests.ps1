
# Simple import test
Import-Module -Force "$PSScriptRoot/Prometheus.Windows/Prometheus.Windows.psd1"
Write-Host "Module imported OK"
