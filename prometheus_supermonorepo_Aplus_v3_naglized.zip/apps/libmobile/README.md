> Prometheus Runtime — Codex-Locked (A+ v3)
> VaultTime Signed — 2025-08-31T11:36:24.438002Z


# libmobile (full-stack, idempotent)

- Backend: FastAPI + SQLite (or Postgres via DATABASE_URL)
- Frontend: static HTML + JS (Nginx)
- Infra: docker-compose

## Run locally
```bash
cd apps/libmobile/infra
docker compose up --build
# web on http://localhost:8080, api on http://localhost:8000
```
