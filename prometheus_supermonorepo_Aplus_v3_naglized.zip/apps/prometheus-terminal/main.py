
import os, asyncio, json, psutil, subprocess
from pathlib import Path
from textual.app import App, ComposeResult
from textual.widgets import Header, Footer, Static, Button, DataTable, Input
from textual.containers import Horizontal, Vertical

ROOT = Path(__file__).resolve().parents[2]  # repo root

def discover_projects():
    projects = []
    for p in ROOT.rglob("requirements.txt"):
        projects.append({"type":"python","path":str(p.parent)})
    for p in ROOT.rglob("package.json"):
        projects.append({"type":"node","path":str(p.parent)})
    for p in ROOT.rglob("docker-compose.y*ml"):
        projects.append({"type":"compose","path":str(p.parent)})
    for p in ROOT.rglob("Dockerfile"):
        projects.append({"type":"dockerfile","path":str(p.parent)})
    seen=set(); uniq=[]
    for pr in projects:
        key=(pr["type"],pr["path"])
        if key in seen: continue
        seen.add(key); uniq.append(pr)
    return uniq

class TermDash(App):
    CSS = """
    #stats {height:3;}
    #cmd {height:3;}
    """
    BINDINGS = [("q","quit","Quit"),("r","refresh","Refresh")]
    def compose(self) -> ComposeResult:
        yield Header(show_clock=True)
        yield Static("Prometheus Terminal — ops at your fingertips", id="title")
        yield Static("", id="stats")
        self.table = DataTable(zebra_stripes=True)
        self.table.add_columns("Index","Type","Path")
        for i,pr in enumerate(discover_projects()):
            self.table.add_row(str(i), pr["type"], pr["path"])
        yield self.table
        with Horizontal(id="cmd"):
            self.cmd = Input(placeholder="Type a shell command to run in selected project (e.g., make test)")
            yield self.cmd
            yield Button("Run", id="run")
        yield Footer()
    def on_mount(self):
        self.refresh_stats()
    def action_refresh(self):
        self.refresh_stats()
    def refresh_stats(self):
        mem = psutil.virtual_memory()
        cpu = psutil.cpu_percent(interval=None)
        self.query_one("#stats", Static).update(f"CPU: {cpu:.1f}%  |  RAM: {mem.percent:.1f}%  |  ROOT={ROOT}")
    async def on_button_pressed(self, event: Button.Pressed):
        if event.button.id != "run": return
        if not self.table.cursor_row is None:
            row = self.table.get_row(self.table.cursor_row)
            path = row[2]
        else:
            path = str(ROOT)
        cmd = self.cmd.value or "pwd && ls -la"
        self.push_screen(ExecScreen(path, cmd))

class ExecScreen(Static):
    DEFAULT_CSS = "height: 20;"
    def __init__(self, path:str, cmd:str):
        super().__init__()
        self.path=path; self.cmd=cmd
    def on_mount(self):
        self.update(f"$ cd {self.path} && {self.cmd}\n\n")
        self.run_cmd()
    def run_cmd(self):
        try:
            out = subprocess.check_output(self.cmd, shell=True, cwd=self.path, stderr=subprocess.STDOUT, text=True, executable="/bin/bash")
            self.update(self.renderable + out)
        except subprocess.CalledProcessError as e:
            self.update(self.renderable + e.output + f"\n[exit {e.returncode}]")

if __name__ == "__main__":
    TermDash().run()
