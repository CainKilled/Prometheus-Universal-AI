> Prometheus Runtime — Codex-Locked (A+ v3)
> VaultTime Signed — 2025-08-31T11:36:24.438002Z


# Prometheus Terminal (Linux TUI)
A Textual-based terminal dashboard to discover projects and run commands in-context.

## Run
```bash
python -m pip install -r apps/prometheus-terminal/requirements.txt
python apps/prometheus-terminal/main.py
```
