> Prometheus Runtime — Codex-Locked (A+ v3)
> VaultTime Signed — 2025-08-31T11:36:24.438002Z


# Prometheus ChatGPT (pluggable chat backend + minimal web)

- Provider modes:
  - `echo` (default) — no external calls
  - `openai` — requires `OPENAI_API_KEY` and optional `OPENAI_MODEL`

## Local
```bash
cd apps/prometheus-chatgpt/infra
docker compose up --build
# web: http://localhost:9090  api: http://localhost:9000/health
```
