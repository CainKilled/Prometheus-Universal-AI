
import XCTest
@testable import PrometheusSwift

final class PrometheusSwiftTests: XCTestCase {
    func testClientInit() throws {
        let url = URL(string: "http://localhost:8000")!
        let client = PrometheusClient(base: url)
        XCTAssertEqual(client.base.absoluteString, "http://localhost:8000")
    }
}
