
// swift-tools-version:5.9
import PackageDescription

let package = Package(
    name: "PrometheusSwift",
    platforms: [
        .macOS(.v13)
    ],
    products: [
        .library(name: "PrometheusSwift", targets: ["PrometheusSwift"]),
        .executable(name: "prometheus-cli", targets: ["PrometheusSwiftCLI"]),
    ],
    targets: [
        .target(name: "PrometheusSwift"),
        .executableTarget(name: "PrometheusSwiftCLI", dependencies: ["PrometheusSwift"]),
        .testTarget(name: "PrometheusSwiftTests", dependencies: ["PrometheusSwift"]),
    ]
)
