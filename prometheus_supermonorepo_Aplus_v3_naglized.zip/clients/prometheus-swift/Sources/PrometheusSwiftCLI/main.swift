
import Foundation
import PrometheusSwift

let base = URL(string: ProcessInfo.processInfo.environment["API_BASE"] ?? "http://localhost:8000")!
let client = PrometheusClient(base: base)
do {
    let status = try client.health()
    print("Health:", status)
    let notes = try client.listNotes()
    print("Notes:", notes)
} catch {
    fputs("Error: \(error)\n", stderr)
    exit(1)
}
