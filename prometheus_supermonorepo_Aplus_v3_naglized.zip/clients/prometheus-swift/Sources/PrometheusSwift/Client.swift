
import Foundation

public struct PrometheusClient {
    public let base: URL
    public init(base: URL) { self.base = base }

    public func health() throws -> String {
        let url = base.appendingPathComponent("health")
        let data = try Data(contentsOf: url)
        let js = try JSONSerialization.jsonObject(with: data) as? [String:Any]
        return js?["status"] as? String ?? "unknown"
    }

    public func listNotes() throws -> [[String:Any]] {
        let url = base.appendingPathComponent("v1/notes")
        let data = try Data(contentsOf: url)
        let js = try JSONSerialization.jsonObject(with: data) as? [[String:Any]]
        return js ?? []
    }
}
