#!/bin/bash
echo "Enter target IP or device:"
read TARGET
echo "[Hellgate] Breaching entry point to $TARGET..."
cd ~/wardog/hellgate
python3 hellgate.py --target $TARGET --brute --inject exploit_x