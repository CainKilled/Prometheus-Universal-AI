#!/bin/bash
echo "[Phoenix] Activating Wardog Cybersecurity Suite..."
cd ~/wardog
./phoenix_main.sh