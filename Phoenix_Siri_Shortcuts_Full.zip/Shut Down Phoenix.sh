#!/bin/bash
echo "[Phoenix] Shutting down systems safely..."
cd ~/wardog
./phoenix_shutdown.sh