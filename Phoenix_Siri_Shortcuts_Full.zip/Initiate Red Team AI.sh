#!/bin/bash
echo "Enter target IP or domain:"
read TARGET
echo "[Red Team AI] Engaging offensive recon on $TARGET..."
cd ~/wardog/red_team
python3 red_team_ai.py --target $TARGET --mode aggressive