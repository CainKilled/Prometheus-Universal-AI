#!/bin/bash
echo "[Phoenix] Gathering system status..."
cd ~/wardog
python3 status_report.py | say