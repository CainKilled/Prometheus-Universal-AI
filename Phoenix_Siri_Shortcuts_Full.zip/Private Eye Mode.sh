#!/bin/bash
echo "[Private Eye Mode] Initiating stealth surveillance..."
cd ~/wardog/surveillance
python3 private_eye.py --silent --log /logs/surveillance.log