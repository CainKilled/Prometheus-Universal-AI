#!/bin/bash
echo "[Voice Mode] Listening..."
cd ~/wardog/voice
python3 voice_mode.py --start