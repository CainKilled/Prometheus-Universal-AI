#!/bin/bash
echo "[Rollback] Reverting to last stable state..."
cd ~/wardog/recovery
./phoenix_rollback.sh --auto