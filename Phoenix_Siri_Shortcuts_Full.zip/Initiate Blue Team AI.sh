#!/bin/bash
echo "[Blue Team AI] Activating defense systems..."
cd ~/wardog/blue_team
python3 blue_team_ai.py --live-monitor