#!/bin/bash
echo "Enter primary target:"
read T1
echo "Enter secondary target:"
read T2
echo "Enter tertiary target:"
read T3
cd ~/wardog/law_of_three
python3 law_of_three.py --targets $T1 $T2 $T3 --analyze --exploit