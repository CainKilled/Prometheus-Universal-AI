#!/bin/bash
echo "[Purge] Securely erasing logs and traces..."
cd ~/wardog/logs
./log_purge_secure.sh --confirm