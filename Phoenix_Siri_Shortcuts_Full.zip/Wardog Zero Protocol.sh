#!/bin/bash
echo "[WARNING] Engaging Zero Protocol. Confirm with secret:"
read -s CONFIRM
if [ "$CONFIRM" == "orangeunicorn110" ]; then
    cd ~/wardog/emergency
    ./zero_protocol.sh --nuke
else
    echo "Authorization failed. Zero Protocol aborted."
fi