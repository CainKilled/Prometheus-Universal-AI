#!/bin/bash
echo "Enter your request for code generation:"
read REQUEST
cd ~/wardog/codegen
python3 ai_code_gen.py --input "$REQUEST"