#!/bin/bash
echo "[Phoenix Hivemind] Activating all units..."
cd ~/wardog/hivemind
python3 hivemind_unite.py --initiate