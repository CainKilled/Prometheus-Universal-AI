#!/bin/bash
echo "Enter recon target:"
read TARGET
cd ~/wardog/grey_team
python3 grey_team_ai_recon.py --target $TARGET --covert