#!/bin/bash
echo "[Cyberdefense] Activating perimeter lockdown..."
cd ~/wardog/security
./activate_perimeter.sh