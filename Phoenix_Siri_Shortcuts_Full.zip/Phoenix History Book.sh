#!/bin/bash
echo "Enter your entry or keyword to retrieve:"
read ENTRY
cd ~/wardog/history
python3 history_book_manager.py --entry "$ENTRY"