"""
Git Adapter
===========

This adapter provides basic Git operations for the DevSwarm
orchestrator. It uses the system ``git`` command to interact with
repositories. Supported actions include ``clone``, ``pull``,
``push``, ``status``, ``add``, ``commit`` and ``checkout``.  Each
task must specify an ``action``. Additional keys are used to
parameterize the command (e.g. ``repo_url``, ``dest``, ``message``,
``branch``).

If the ``git`` executable cannot be found or a command fails, the
adapter logs an error and returns a dictionary with an ``error``
description. Otherwise it returns the command's stdout and exit
status.  The adapter logs each step to help trace the operation.
"""

from __future__ import annotations

from typing import Dict, Any, Callable, List
import subprocess
import shutil
import os


class GitAdapter:
    """Adapter for basic Git operations using the system git CLI."""

    def _run_git(self, args: List[str], cwd: str | None, logger: Callable[[str], None]) -> Dict[str, Any]:
        """Run a git command and return its output and exit code.

        If git is not installed or the command fails to execute,
        returns a dictionary with an ``error`` key.
        """
        git_cmd = shutil.which("git")
        if not git_cmd:
            logger("GitAdapter: git command not found")
            return {"error": "git not installed"}
        cmd = [git_cmd] + args
        try:
            result = subprocess.run(
                cmd,
                cwd=cwd,
                stdout=subprocess.PIPE,
                stderr=subprocess.STDOUT,
                text=True,
                check=False,
            )
            logger(f"GitAdapter: ran {' '.join(cmd)} (exit={result.returncode})")
            return {"output": result.stdout, "exit_code": result.returncode}
        except Exception as exc:
            logger(f"GitAdapter: exception running {' '.join(cmd)}: {exc}")
            return {"error": str(exc)}

    def run(self, task: Dict[str, Any], logger: Callable[[str], None]) -> Dict[str, Any]:
        action = task.get("action")
        cwd = task.get("cwd")
        if not action:
            logger("GitAdapter: missing action")
            return {"error": "missing action"}

        # Normalize path
        if cwd:
            cwd = os.path.abspath(cwd)

        if action == "clone":
            repo_url = task.get("repo_url")
            dest = task.get("dest")
            if not repo_url:
                logger("GitAdapter: clone missing repo_url")
                return {"error": "clone missing repo_url"}
            args = ["clone", repo_url]
            if dest:
                args.append(dest)
            return self._run_git(args, cwd, logger)

        elif action == "pull":
            # Accept optional remote and branch
            remote = task.get("remote", "origin")
            branch = task.get("branch")
            args = ["pull", remote]
            if branch:
                args.append(branch)
            return self._run_git(args, cwd, logger)

        elif action == "push":
            remote = task.get("remote", "origin")
            branch = task.get("branch")
            args = ["push", remote]
            if branch:
                args.append(branch)
            return self._run_git(args, cwd, logger)

        elif action == "status":
            return self._run_git(["status", "--short"], cwd, logger)

        elif action == "add":
            paths = task.get("paths") or ["."]
            if isinstance(paths, str):
                paths = [paths]
            args = ["add"] + paths
            return self._run_git(args, cwd, logger)

        elif action == "commit":
            message = task.get("message")
            if not message:
                logger("GitAdapter: commit missing message")
                return {"error": "commit missing message"}
            args = ["commit", "-m", message]
            return self._run_git(args, cwd, logger)

        elif action == "checkout":
            branch = task.get("branch")
            create = task.get("create", False)
            if not branch:
                logger("GitAdapter: checkout missing branch")
                return {"error": "checkout missing branch"}
            args = ["checkout"]
            if create:
                args += ["-b", branch]
            else:
                args.append(branch)
            return self._run_git(args, cwd, logger)

        else:
            logger(f"GitAdapter: unknown action '{action}'")
            return {"error": f"unknown action {action}"}