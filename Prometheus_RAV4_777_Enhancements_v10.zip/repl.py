"""
Prometheus Interactive Shell
============================

This script launches a simple read–eval–print loop (REPL) for
interacting with the Prometheus kernel. Users can list plugins, run
plugins with parameters, execute flows and exit. It is intended as an
alternative to the unified CLI for rapid experimentation.

Commands:

    help
        Show available commands.
    list
        List available plugins.
    run <plugin_name> [key=value ...]
        Run a plugin with optional key=value pairs as runtime parameters.
    flow <flow_path> [ctxkey=value ...]
        Execute a wizard flow file with optional context variables.
    exit
        Exit the REPL.
"""

from __future__ import annotations

import json
import shlex
import sys
from typing import Dict, Any

from core.kernel import PrometheusKernel


def parse_args(args: list[str]) -> Dict[str, Any]:
    """Parse key=value arguments into a dictionary. Values beginning with
    '{' or '[' are parsed as JSON. Values containing '=' may be quoted.
    """
    params: Dict[str, Any] = {}
    for arg in args:
        if '=' not in arg:
            raise ValueError(f"Invalid argument '{arg}', expected key=value")
        key, val = arg.split('=', 1)
        val = val.strip()
        if val.startswith('{') or val.startswith('['):
            try:
                params[key] = json.loads(val)
                continue
            except json.JSONDecodeError:
                pass
        # remove surrounding quotes
        if (val.startswith('"') and val.endswith('"')) or (val.startswith("'") and val.endswith("'")):
            params[key] = val[1:-1]
        else:
            params[key] = val
    return params


def main() -> None:
    base_dir = '.'
    kernel = PrometheusKernel(base_dir)
    kernel.load_plugins()
    print("Prometheus REPL. Type 'help' for instructions.")
    while True:
        try:
            line = input('prometheus> ').strip()
        except (EOFError, KeyboardInterrupt):
            print()
            break
        if not line:
            continue
        parts = shlex.split(line)
        cmd = parts[0]
        if cmd == 'help':
            print("Available commands:")
            print("  help                 Show this help message")
            print("  list                 List available plugins")
            print("  run <plugin> [key=value ...]")
            print("  flow <flow_path> [ctxkey=value ...]")
            print("  exit                 Exit the REPL")
            continue
        if cmd == 'exit':
            break
        if cmd == 'list':
            metas = kernel.list_plugins()
            for m in metas:
                print(f"- {m.get('name')}: {m.get('description')}")
            continue
        if cmd == 'run':
            if len(parts) < 2:
                print("Usage: run <plugin_name> [key=value ...]")
                continue
            plugin_name = parts[1]
            args = parts[2:]
            try:
                params = parse_args(args)
                result = kernel.run_plugin(plugin_name, params)
                print(result)
            except Exception as exc:
                print(f"Error: {exc}")
            continue
        if cmd == 'flow':
            if len(parts) < 2:
                print("Usage: flow <flow_path> [ctxkey=value ...]")
                continue
            flow_path = parts[1]
            ctx_args = parts[2:]
            try:
                ctx = parse_args(ctx_args)
                kernel.run_flow(flow_path, ctx)
            except Exception as exc:
                print(f"Error: {exc}")
            continue
        print(f"Unknown command: {cmd}")


if __name__ == '__main__':
    main()