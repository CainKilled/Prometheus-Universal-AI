"""
iOS Plugin
==========

This plugin scaffolds integration with iOS devices using open‑source tools
like [libimobiledevice](https://libimobiledevice.org/) and Apple's
command‑line utilities. Unlike Android, iOS has no official ADB equivalent,
but libimobiledevice provides functions to manage devices, install apps,
retrieve logs, etc.

You can implement functions such as listing connected devices, installing
IPA files or managing provisioning profiles by invoking commands like
`idevice_id`, `ideviceinstaller` or `ideviceinfo`. See the README for more.
"""

# Prometheus Codex Lock v1
# This file is part of Prometheus RAV4 777 Enhancements. Do not edit manually.

from typing import Dict, Any
from plugins.api.plugin_base import Plugin


class IOSPlugin:
    def metadata(self) -> Dict[str, Any]:
        """
        Return metadata for this plugin. The description now notes that
        the plugin integrates with libimobiledevice tools to perform
        device management tasks. See ``activate`` for supported actions.
        """
        return {
            "name": "ios",
            "version": "1.0.0",
            "description": "Interact with iOS devices via libimobiledevice command‑line tools",
            "targets": ["mobile", "ios"],
        }

    def activate(self, runtime: Dict[str, Any]) -> None:
        """
        Execute an iOS device management action using libimobiledevice tools.

        Supported runtime keys:

            action (str): One of ``devices``, ``info``, ``install``, ``uninstall``.
                Defaults to ``devices``.
            udid (str): Device UDID. Optional; if omitted, the command
                applies to the default or only device.
            ipa (str): Path to an IPA file to install (for ``install``).
            bundle_id (str): Bundle identifier to uninstall (for ``uninstall``).
            log (callable): Optional logger.

        The plugin invokes ``idevice_id``, ``ideviceinfo`` and
        ``ideviceinstaller`` via ``subprocess``. It verifies that the
        executables exist using ``shutil.which`` before running them.
        """
        import subprocess
        import shutil
        logger = runtime.get("log", print)
        action = str(runtime.get("action", "devices")).lower()
        udid = runtime.get("udid")
        ipa_path = runtime.get("ipa")
        bundle_id = runtime.get("bundle_id")
        idevice_id = shutil.which("idevice_id")
        ideviceinfo = shutil.which("ideviceinfo")
        ideviceinstaller = shutil.which("ideviceinstaller")
        # Helper to run a command and log output
        def run_cmd(cmd: list[str]) -> None:
            try:
                logger(f"IOSPlugin: Running {' '.join(cmd)}")
                result = subprocess.run(cmd, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True)
                logger(result.stdout.rstrip())
                if result.returncode != 0:
                    logger(f"IOSPlugin: Command exited with code {result.returncode}")
            except Exception as exc:
                logger(f"IOSPlugin: Error executing {' '.join(cmd)}: {exc}")
        # List devices
        if action == "devices":
            if not idevice_id:
                logger("IOSPlugin: 'idevice_id' not found. Please install libimobiledevice.")
                return
            run_cmd([idevice_id, "-l"])
            return
        # Device info
        if action == "info":
            if not ideviceinfo:
                logger("IOSPlugin: 'ideviceinfo' not found. Please install libimobiledevice.")
                return
            cmd = [ideviceinfo]
            if udid:
                cmd.extend(["-u", str(udid)])
            run_cmd(cmd)
            return
        # Install IPA
        if action == "install":
            if not ideviceinstaller:
                logger("IOSPlugin: 'ideviceinstaller' not found. Please install libimobiledevice.")
                return
            if not ipa_path:
                logger("IOSPlugin: 'ipa' path must be provided for install action")
                return
            cmd = [ideviceinstaller]
            if udid:
                cmd.extend(["-u", str(udid)])
            cmd.extend(["-i", str(ipa_path)])
            run_cmd(cmd)
            return
        # Uninstall app
        if action == "uninstall":
            if not ideviceinstaller:
                logger("IOSPlugin: 'ideviceinstaller' not found. Please install libimobiledevice.")
                return
            if not bundle_id:
                logger("IOSPlugin: 'bundle_id' must be provided for uninstall action")
                return
            cmd = [ideviceinstaller]
            if udid:
                cmd.extend(["-u", str(udid)])
            cmd.extend(["-U", str(bundle_id)])
            run_cmd(cmd)
            return
        logger(f"IOSPlugin: Unknown action '{action}'. Supported actions: devices, info, install, uninstall.")


def get_plugin() -> Plugin:
    return IOSPlugin()  # type: ignore[return-value]