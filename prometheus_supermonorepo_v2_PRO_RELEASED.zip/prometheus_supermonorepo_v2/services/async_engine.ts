// Legacy entry kept for compatibility. Prefer services/prometheus_async_engine.ts
