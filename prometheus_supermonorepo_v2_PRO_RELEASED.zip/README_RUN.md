
## Releases and signing
Local:
```bash
export VAULTTIME_KEY="your-strong-secret"
export VERSION="v1.0.0"
make release
# Artifacts at dist/releases/$VERSION
```

GitHub Actions:
- Add repository secrets:
  - VAULTTIME_KEY (required)
  - COSIGN_PRIVATE_KEY (base64, optional) and COSIGN_PASSWORD (optional)
  - GPG_PRIVATE_KEY (base64, optional) and GPG_PASSPHRASE (optional)
- Push a tag v1.2.3 or run the Release workflow with version=v1.2.3.
