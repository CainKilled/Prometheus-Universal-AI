#!/usr/bin/env python3
import os, json, zipfile, hashlib, sys
from pathlib import Path
from datetime import datetime, timezone

BASE = Path(__file__).resolve().parents[1]
DIST = BASE / "dist" / "releases"
VERSION = os.environ.get("VERSION") or (sys.argv[1] if len(sys.argv) > 1 else datetime.now(timezone.utc).strftime("%Y%m%d%H%M%S"))

EXCLUDES = {'.git', '.venv', 'node_modules', 'dist', 'build', '__pycache__'}

def sha256_of(path: Path):
    import hashlib
    h = hashlib.sha256()
    with path.open('rb') as f:
        for chunk in iter(lambda: f.read(1024*1024), b''):
            h.update(chunk)
    return h.hexdigest()

def should_include(p: Path) -> bool:
    parts = set(p.parts)
    if parts & EXCLUDES:
        return False
    return True

def zipdir(root: Path, target_zip: Path, base_prefix: Path):
    with zipfile.ZipFile(target_zip, 'w', compression=zipfile.ZIP_DEFLATED) as z:
        for path in root.rglob("*"):
            if not path.is_file(): 
                continue
            if not should_include(path.relative_to(base_prefix)):
                continue
            arcname = path.relative_to(base_prefix)
            z.write(path, arcname.as_posix())

def detect_projects(root_dir: Path):
    entries = []
    for root, dirs, files in os.walk(root_dir):
        rp = Path(root)
        if rp == root_dir: 
            continue
        parts = rp.relative_to(root_dir).parts
        if any(p.startswith('.') for p in parts): 
            continue
        fset = set(files)
        features = []
        entry = None
        typ = None
        if "docker-compose.yml" in fset or "docker-compose.yaml" in fset:
            features.append("docker-compose"); typ = typ or "multi"; entry = entry or "docker"
        if "package.json" in fset:
            features.append("node"); typ = typ or "node"; entry = entry or "node"
        if "pyproject.toml" in fset or "requirements.txt" in fset or any(fn.endswith(".py") for fn in fset):
            features.append("python"); typ = typ or "python"; entry = entry or "python"
        if "Makefile" in fset:
            features.append("make"); typ = typ or "make"; entry = entry or "make"
        if "index.html" in fset and "package.json" not in fset:
            features.append("static_web"); typ = typ or "static"; entry = entry or "static"
        if features:
            entries.append({
                "path": str(rp.relative_to(root_dir)),
                "type": typ or "misc",
                "features": features,
                "entry_hint": entry or "misc"
            })
    uniq = {}
    for e in entries:
        uniq[e["path"]] = e
    return [uniq[k] for k in sorted(uniq.keys())]

def main():
    out_dir = DIST / VERSION
    out_dir.mkdir(parents=True, exist_ok=True)

    manifest = {
        "version": VERSION,
        "built_utc": datetime.now(timezone.utc).isoformat(),
        "artifacts": []
    }

    # 1) Full repo bundle
    full_zip = out_dir / f"prometheus_supermonorepo_{VERSION}.zip"
    zipdir(BASE, full_zip, BASE)
    manifest["artifacts"].append({"name": full_zip.name, "path": str(full_zip), "sha256": sha256_of(full_zip)})

    # 2) Per-project bundles
    projects = detect_projects(BASE)
    for proj in projects:
        pdir = BASE / proj["path"]
        name = proj["path"].replace('/', '_')
        zpath = out_dir / f"{name}_{VERSION}.zip"
        zipdir(pdir, zpath, pdir)
        manifest["artifacts"].append({"name": zpath.name, "path": str(zpath), "sha256": sha256_of(zpath), "project": proj})
    
    # 3) SHA256SUMS
    sums = out_dir / "SHA256SUMS.txt"
    with sums.open('w', encoding='utf-8') as f:
        for a in manifest["artifacts"]:
            f.write(f"{a['sha256']}  {a['name']}
")
    manifest["artifacts"].append({"name": sums.name, "path": str(sums), "sha256": sha256_of(sums)})

    # 4) Manifest
    mpath = out_dir / "RELEASE_MANIFEST.json"
    mpath.write_text(json.dumps(manifest, indent=2), encoding='utf-8')

    print(json.dumps({"out_dir": str(out_dir), "count": len(manifest["artifacts"])}, indent=2))

if __name__ == "__main__":
    main()
