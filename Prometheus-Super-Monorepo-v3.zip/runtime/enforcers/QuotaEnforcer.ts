const usage = new Map<string, { date: string; tokens: number }>();
const today = ()=>new Date().toISOString().slice(0,10);
export function checkAndCharge(userId: string, tier: string, budget: Record<string,{dailyBudgetTokens:number}>, tokens: number) {
  const key = `${userId}:${today()}`;
  let u = usage.get(key); if (!u) { u = { date: today(), tokens: 0 }; usage.set(key, u); }
  const limit = budget[tier]?.dailyBudgetTokens ?? 100000;
  if (u.tokens + tokens > limit) return { ok:false, reason:"budget-exceeded", used: u.tokens, limit };
  u.tokens += tokens; return { ok:true, used: u.tokens, limit };
}
