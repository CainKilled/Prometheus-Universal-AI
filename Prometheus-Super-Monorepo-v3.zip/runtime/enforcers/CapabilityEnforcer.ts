import type { Policy } from "../policy/PolicyEngine.js";
export function isCapAllowed(policy: Policy, cap: string, overrides?: string[]) {
  const deny = new Set(policy.caps.deny);
  const allow = new Set(policy.caps.allow);
  if (deny.has(cap)) return overrides?.includes(cap) || false;
  return allow.has(cap) || false;
}
