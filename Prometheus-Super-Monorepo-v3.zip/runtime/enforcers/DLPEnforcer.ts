import type { Policy } from "../policy/PolicyEngine.js";
export function scan(policy: Policy, text: string) {
  const hits: { name:string; match:string }[] = [];
  for (const p of policy.dlp.blockPatterns) {
    const re = new RegExp(p.re, "g");
    let m; while ((m = re.exec(text)) !== null) hits.push({ name: p.name, match: m[0] });
  }
  if (!hits.length) return { ok:true, text, hits: [] };
  if (policy.dlp.action === "block") return { ok:false, reason:"dlp-block", hits };
  let redacted = text; for (const h of hits) redacted = redacted.split(h.match).join(`[REDACTED:${h.name}]`);
  return { ok:true, text: redacted, hits };
}
