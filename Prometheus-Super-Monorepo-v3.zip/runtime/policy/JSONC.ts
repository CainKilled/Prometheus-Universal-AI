export function parseJSONC(str: string): any {
  const noComments = str
    .replace(/\/\*[\s\S]*?\*\//g, '')
    .replace(/(^|\s)\/\/.*$/gm, '');
  return JSON.parse(noComments);
}
