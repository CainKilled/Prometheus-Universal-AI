# Prometheus — Brand
- Name: Prometheus
- Owner: Adam Nagle
- Tone: Futurist, pragmatic, security-first
- Colors: #111, #0ff, #7ef
- Usage: Include NOTICE and LICENSE when redistributing.
