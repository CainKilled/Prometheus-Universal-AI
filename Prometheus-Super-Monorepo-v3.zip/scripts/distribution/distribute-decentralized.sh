#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/../.." && pwd)"
OUT="$ROOT/dist/decentralized"
rm -rf "$OUT"; mkdir -p "$OUT"
tar -czf "$OUT/prometheus-pack.tgz" policy/ runtime/ backend/ packages/ branding/ README.md LICENSE NOTICE
sha256sum "$OUT/prometheus-pack.tgz" | awk '{print $1}' > "$OUT/sha256.txt"
echo "{ \"name\": \"prometheus-pack\", \"algo\": \"sha256\", \"hash\": \"$(cat "$OUT/sha256.txt")\" }" > "$OUT/manifest.json"
echo "✅ Decentralized pack -> $OUT"
