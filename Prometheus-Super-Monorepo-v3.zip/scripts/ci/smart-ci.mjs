import { execSync } from "node:child_process";
const sh = (c)=>execSync(c, { stdio:"inherit", shell:"bash" });
try {
  sh("npm run verify");
  sh("npm run build");
  sh("npm run dist");
  console.log("✅ Smart CI OK");
} catch (e) { console.error("❌ CI failed", e?.message||e); process.exit(1); }
