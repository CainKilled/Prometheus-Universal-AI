#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
MAN="$ROOT/vaulttime/manifest.codex.json"
OUT="$ROOT/vaulttime/integrity.sha256"
DATE="$(date -u +%Y-%m-%dT%H:%M:%SZ)"
tmp="$(mktemp)"
jq --arg t "$DATE" '.integrity.generated_at=$t' "$MAN" > "$tmp" && mv "$tmp" "$MAN"
> "$OUT"
while IFS= read -r p; do
  path="$ROOT/$p"
  if [ -d "$path" ]; then
    (cd "$path" && find . -type f ! -path "*/node_modules/*" -print0 | sort -z | xargs -0 sha256sum) >> "$OUT"
  elif [ -f "$path" ]; then
    sha256sum "$path" >> "$OUT"
  fi
done < <(jq -r '.paths[]' "$MAN")
echo "VaultTime: integrity -> $OUT"
