export function isDangerEnabled() { return process.env.DANGER_LAB === "1"; }
export function guard() { if (!isDangerEnabled()) throw new Error("Danger Lab disabled"); }
