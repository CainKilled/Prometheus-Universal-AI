#!/usr/bin/env node
import { bindChat } from "./chat_bind.js";
const [,,cmd, arg] = process.argv;
if (cmd === "chat-bind" && arg) bindChat(arg);
else console.log("Usage: prom-ws chat-bind <chat.json>");
