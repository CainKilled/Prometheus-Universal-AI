# Security Policy
- Report vulnerabilities to owner email.
- Hardening: SAFE mode default, caps deny-by-default, DLP, quotas.
