import { build } from "esbuild";
export async function compileTS(entry: string, outfile: string) {
  await build({ entryPoints:[entry], bundle:true, platform:"node", outfile, sourcemap:true });
  return { ok:true, outfile };
}
