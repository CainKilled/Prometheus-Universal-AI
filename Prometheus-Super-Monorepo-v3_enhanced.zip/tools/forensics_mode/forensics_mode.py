#!/usr/bin/env python3
"""
Forensics Mode Toolkit (Prometheus Runtime)

Functions:
- Walk the repo and compute SHA-256 for every file
- Flag suspicious markers (TODO/FIXME/PLACEHOLDER/NotImplemented/etc.)
- Capture basic file metadata (size, mtime, mode)
- Produce a signed JSON report using HMAC-SHA256
- Optional: persist results into runtime/db/prometheus_runtime.db

Usage:
  python forensics_mode.py --root .. --out report.json --sign-key vault/forensics_key.txt --db runtime/db/prometheus_runtime.db
"""
import os, sys, json, re, hashlib, hmac, time, stat, sqlite3
from pathlib import Path
from datetime import datetime

PLACEHOLDER_PATTERNS = [
    r"\bTODO\b", r"\bFIXME\b", r"\bTBD\b", r"\bPLACEHOLDER\b", r"\bSTUB\b",
    r"lorem ipsum", r"not\s+implemented", r"NotImplementedError", r"pass\s*#?\s*placeholder",
    r"\bWIP\b", r"\bHACK\b"
]
PLACEHOLDER_RE = re.compile("|".join(PLACEHOLDER_PATTERNS), re.IGNORECASE)

def is_binary(p: Path) -> bool:
    try:
        with p.open('rb') as f:
            b = f.read(8192)
        if b'\0' in b:
            return True
        text_chars = bytearray({7,8,9,10,12,13,27} | set(range(0x20, 0x100)))
        nontext = b.translate(None, text_chars)
        return float(len(nontext)) / float(max(1, len(b))) > 0.30
    except Exception:
        return False

def sha256_file(p: Path) -> str:
    h = hashlib.sha256()
    with p.open('rb') as f:
        for chunk in iter(lambda: f.read(65536), b''):
            h.update(chunk)
    return h.hexdigest()

def load_sign_key(path: Path) -> bytes:
    path.parent.mkdir(parents=True, exist_ok=True)
    if not path.exists():
        key = hashlib.sha256(f"FORensicsKey:{time.time()}".encode()).digest()
        path.write_bytes(key)
        os.chmod(path, 0o600)
        return key
    return path.read_bytes()

def sign_blob(key: bytes, blob: bytes) -> str:
    return hmac.new(key, blob, hashlib.sha256).hexdigest()

def persist_db(db_path: Path, report: dict):
    db_path.parent.mkdir(parents=True, exist_ok=True)
    conn = sqlite3.connect(str(db_path))
    cur = conn.cursor()
    cur.execute("""
    CREATE TABLE IF NOT EXISTS forensic_runs (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        created_at TEXT NOT NULL,
        root TEXT NOT NULL,
        file_count INTEGER NOT NULL,
        placeholders INTEGER NOT NULL,
        signature TEXT NOT NULL
    )""")
    cur.execute("""
    CREATE TABLE IF NOT EXISTS forensic_files (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        run_id INTEGER NOT NULL,
        path TEXT NOT NULL,
        size INTEGER,
        mtime REAL,
        mode INTEGER,
        sha256 TEXT,
        binary INTEGER,
        has_placeholder INTEGER,
        FOREIGN KEY(run_id) REFERENCES forensic_runs(id)
    )""")
    conn.commit()

    cur.execute("INSERT INTO forensic_runs (created_at, root, file_count, placeholders, signature) VALUES (?,?,?,?,?)",
                (report['created_at'], report['root'], report['summary']['file_count'], report['summary']['placeholder_hits'], report['signature']))
    run_id = cur.lastrowid

    rows = [(run_id, f['path'], f.get('size'), f.get('mtime'), f.get('mode'), f.get('sha256'), 1 if f.get('binary') else 0, 1 if f.get('has_placeholder') else 0)
            for f in report['files']]
    cur.executemany("INSERT INTO forensic_files (run_id, path, size, mtime, mode, sha256, binary, has_placeholder) VALUES (?,?,?,?,?,?,?,?)", rows)
    conn.commit()
    conn.close()

def main(argv=None):
    import argparse
    ap = argparse.ArgumentParser()
    ap.add_argument('--root', type=str, default='..')
    ap.add_argument('--out', type=str, default='forensics_report.json')
    ap.add_argument('--sign-key', type=str, default='vault/forensics_key.txt')
    ap.add_argument('--db', type=str, default='runtime/db/prometheus_runtime.db')
    args = ap.parse_args(argv)

    root = Path(args.root).resolve()
    files = []
    placeholder_hits = 0
    for p in root.rglob('*'):
        if not p.is_file():
            continue
        rel = p.relative_to(root).as_posix()
        try:
            stati = p.stat()
            meta = {
                'path': rel,
                'size': stati.st_size,
                'mtime': stati.st_mtime,
                'mode': stat.S_IMODE(stati.st_mode),
                'binary': is_binary(p),
                'sha256': sha256_file(p),
                'has_placeholder': False
            }
            if not meta['binary']:
                try:
                    txt = p.read_text(errors='ignore')
                except Exception:
                    txt = ''
                if PLACEHOLDER_RE.search(txt or ''):
                    meta['has_placeholder'] = True
                    placeholder_hits += 1
            files.append(meta)
        except Exception:
            continue

    blob = {
        'created_at': datetime.utcnow().isoformat() + 'Z',
        'root': str(root),
        'summary': {
            'file_count': len(files),
            'placeholder_hits': placeholder_hits
        },
        'files': files
    }
    data = json.dumps(blob, ensure_ascii=False, sort_keys=True, indent=2).encode()

    key_path = (root / args.sign_key) if not Path(args.sign_key).is_absolute() else Path(args.sign_key)
    key = load_sign_key(key_path)
    sig = sign_blob(key, data)
    blob['signature'] = sig

    out_path = (root / args.out) if not Path(args.out).is_absolute() else Path(args.out)
    out_path.write_text(json.dumps(blob, ensure_ascii=False, sort_keys=True, indent=2))
    try:
        persist_db(Path(args.db) if Path(args.db).is_absolute() else (root / args.db), blob)
    except Exception as e:
        # DB persistence is optional
        pass
    print(f"Forensics report written to: {out_path}")
    print(f"Signature: {sig}")

if __name__ == '__main__':
    main()
