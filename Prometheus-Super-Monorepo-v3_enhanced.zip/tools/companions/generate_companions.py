#!/usr/bin/env python3
"""
Generate companion .manifest and .test files for primary source files.
Policy (compact pass):
- Target up to 200 candidate files by heuristics (code extensions, size>0)
- For each, create <file>.manifest (json) with sha256, lines, ts
- Create <file>.test (python) that asserts hash and presence on disk
- Record companion entry in runtime DB
"""
import os, json, hashlib, time, stat, sqlite3
from pathlib import Path

CODE_EXTS = {'.py','.sh','.js','.ts','.go','.rs','.c','.cpp','.java','.kt','.swift','.rb','.php','.lua','.yaml','.yml','.toml','.ini','.json','.sql','.md','.dockerfile'}

def sha256_file(p: Path) -> str:
    h = hashlib.sha256()
    with p.open('rb') as f:
        for chunk in iter(lambda: f.read(65536), b''):
            h.update(chunk)
    return h.hexdigest()

def main():
    root = Path(__file__).resolve().parents[2]  # repo root
    db_path = root / 'runtime' / 'db' / 'prometheus_runtime.db'
    db_path.parent.mkdir(parents=True, exist_ok=True)

    conn = sqlite3.connect(str(db_path))
    conn.execute("CREATE TABLE IF NOT EXISTS companions (id INTEGER PRIMARY KEY AUTOINCREMENT, path TEXT UNIQUE, manifest_hash TEXT NOT NULL, test_last_run TEXT, status TEXT NOT NULL DEFAULT 'unknown')")
    conn.commit()

    candidates = []
    for p in root.rglob('*'):
        if not p.is_file(): continue
        if p.suffix.lower() in CODE_EXTS and p.stat().st_size > 0:
            # ignore our own generated companions
            if p.name.endswith('.manifest') or p.name.endswith('.test'): 
                continue
            candidates.append(p)
    # Cap to 200 for this pass
    candidates = sorted(candidates, key=lambda x: (-x.stat().st_size, x.as_posix()))[:200]

    created = 0
    for p in candidates:
        rel = p.relative_to(root).as_posix()
        h = sha256_file(p)
        lines = 0
        try:
            lines = p.read_text(errors='ignore').count('\n') + 1
        except Exception:
            lines = None
        manifest = {
            'path': rel,
            'sha256': h,
            'lines': lines,
            'created_at': time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime())
        }
        mpath = root / f"{rel}.manifest"
        mpath.parent.mkdir(parents=True, exist_ok=True)
        mpath.write_text(json.dumps(manifest, indent=2, sort_keys=True))
        # test file
        tpath = root / f"{rel}.test"
        tpath.write_text(f"""#!/usr/bin/env python3
import json, hashlib
from pathlib import Path
def sha256_file(p: Path) -> str:
    h = hashlib.sha256()
    with p.open('rb') as f:
        for chunk in iter(lambda: f.read(65536), b''):
            h.update(chunk)
    return h.hexdigest()
root = Path(__file__).resolve().parents[0]
target = Path(root.as_posix().replace('.test',''))
manifest = json.loads(Path(str(target)+'.manifest').read_text())
assert target.exists(), f'File missing: {{target}}'
assert sha256_file(target) == manifest['sha256'], 'Hash mismatch'
print('OK:', target)
""")
        os.chmod(tpath, 0o755)
        # db record
        conn.execute("INSERT OR REPLACE INTO companions (path, manifest_hash, test_last_run, status) VALUES (?,?,NULL,'created')", (rel, h))
        created += 1
    conn.commit()
    conn.close()
    print(f"Created {created} companion pairs (.manifest + .test)")

if __name__ == '__main__':
    main()
