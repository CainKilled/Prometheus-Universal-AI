# Monetization
- Stripe (Subscriptions, Metered usage)
- Tier mapping: FreeWanderer → free; Apprentice→low-cost; Artificer→pro; Architect→business; Oracle→enterprise
- Respect regional tax rules and user consent.
