import * as functions from "firebase-functions";
import { z } from "zod";
import { loadPolicy } from "../../../runtime/policy/PolicyEngine.js";
import { isCapAllowed } from "../../../runtime/enforcers/CapabilityEnforcer.js";
import { checkAndCharge } from "../../../runtime/enforcers/QuotaEnforcer.js";
import { scan as dlpScan } from "../../../runtime/enforcers/DLPEnforcer.js";

const Req = z.object({
  payload: z.any(),
  caps: z.array(z.string()).default([]),
  capsOverride: z.array(z.string()).optional(),
  userTier: z.string().default("FreeWanderer"),
  estTokens: z.number().default(1000)
});

export const execute_with_policy = functions.https.onCall(async (data, ctx) => {
  const { payload, caps, capsOverride, userTier, estTokens } = Req.parse(data);
  if (!ctx.auth?.uid) throw new functions.https.HttpsError("unauthenticated","Sign in required");
  const policy = loadPolicy(process.cwd(), process.env.PROM_MODE);

  for (const c of caps) {
    if (!isCapAllowed(policy, c, capsOverride as any)) {
      throw new functions.https.HttpsError("permission-denied",`cap denied: ${c}`);
    }
  }

  const q = checkAndCharge(ctx.auth.uid, userTier, policy.tiers as any, estTokens);
  if (!q.ok) throw new functions.https.HttpsError("resource-exhausted","token budget exceeded");

  const text = typeof payload === "string" ? payload : JSON.stringify(payload);
  const dlp = dlpScan(policy, text);
  if (!dlp.ok) throw new functions.https.HttpsError("failed-precondition","DLP block");

  return { ok:true, echoed: dlp.text };
});
