import fs from "node:fs"; import path from "node:path";
function fail(m){ console.error("❌", m); process.exit(1); }
const base = path.resolve("policy/default.policy.jsonc");
if (!fs.existsSync(base)) fail("missing policy/default.policy.jsonc");
for (const m of ["SAFE","PROD","LAB","GODMODE","CINEMATIC"]) {
  const p = path.resolve(`policy/modes/${m}.policy.jsonc`);
  if (!fs.existsSync(p)) fail(`missing ${p}`);
}
console.log("✅ policy files exist");
