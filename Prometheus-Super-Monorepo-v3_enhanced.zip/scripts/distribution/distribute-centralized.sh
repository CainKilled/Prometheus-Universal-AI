#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/../.." && pwd)"
OUT="$ROOT/dist/centralized"
rm -rf "$OUT"; mkdir -p "$OUT"
echo "▶ Copy branding and build artifacts (no frontend in this pack)"
cp -R "$ROOT/branding" "$OUT/branding"
echo "✅ Centralized dist -> $OUT"
