# Prometheus Super Monorepo — v3
**Owner:** Adam Nagle • **Project:** Prometheus • **License:** Apache-2.0 • **VaultTime:** Enabled

This monorepo is **idempotent, modular, hardened, and automation-first**, with:
- **SmartConfig + HAL** (modes, tiers, threading)
- **Policies + Enforcers + SOPs + Audit**
- **Packages:** linux-terminal (guarded), compiler, testing, danger-lab, workspace (chat binder)
- **CI:** lint (CST), tests (JCTEST), build, dist, vault sign
- **Distribution:** centralized & decentralized scripts
- **Branding, Notices, Licensing, Monetization stubs**

## Quickstart
```bash
npm ci
npm run verify        # lint + tests + policy check
npm run build
npm run status        # HAL/Smart status
```

## Commands
- `npm run verify` → ESLint (CST) + Jest (JCTEST) + policy validation
- `npm run dist` → Build + centralized & decentralized packs
- `npm run vault` → VaultTime sign (integrity manifest)

Everything defaults to **SAFE** mode and **deny-by-default** for risky caps.
