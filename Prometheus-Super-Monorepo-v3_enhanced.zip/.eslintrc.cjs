/** ESLint for CST (code style test) */
module.exports = {
  root: true,
  parser: "@typescript-eslint/parser",
  plugins: ["@typescript-eslint"],
  extends: [
    "eslint:recommended",
    "plugin:@typescript-eslint/recommended"
  ],
  parserOptions: { ecmaVersion: "latest", sourceType: "module" },
  env: { node: true, es2022: true },
  ignorePatterns: ["**/dist/**","**/lib/**"],
  rules: {
    "@typescript-eslint/no-explicit-any": "off", // relax where pragmatic
    "no-unused-vars": "warn"
  }
};
