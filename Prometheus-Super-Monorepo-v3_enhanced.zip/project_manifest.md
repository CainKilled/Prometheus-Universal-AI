# Project Manifest

Canonical manifest for the Prometheus Runtime.
