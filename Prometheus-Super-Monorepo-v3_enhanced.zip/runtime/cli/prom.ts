#!/usr/bin/env node
import { HAL } from "../hal/HAL.js";
import { Smart, setMode, setProductTier, setGoogleTier } from "../smart.config.js";

const [,,cmd,...rest] = process.argv;
async function main(){
  if (!cmd || cmd==="status") { console.log({ mode: Smart.mode, tier: Smart.productTier, gcpTier: Smart.googleDevTier }); return; }
  if (cmd==="mode") { setMode(rest[0] as any); console.log("mode->", Smart.mode); return; }
  if (cmd==="tier") { setProductTier(rest[0] as any); console.log("tier->", Smart.productTier); return; }
  if (cmd==="gcp-tier") { setGoogleTier(rest[0] as any); console.log("gcpTier->", Smart.googleDevTier); return; }
  console.log("Commands: status | mode <SAFE|PROD|LAB|GODMODE|CINEMATIC> | tier <...> | gcp-tier <...>");
}
main().catch(e=>(console.error(e),process.exit(1)));
