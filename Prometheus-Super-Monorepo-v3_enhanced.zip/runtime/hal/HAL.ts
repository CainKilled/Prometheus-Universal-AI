import { Smart, setMode, setProductTier, setGoogleTier } from "../smart.config.js";
import { EventEmitter } from "events";
export const HALBus = new EventEmitter();
type Caps = "net.read"|"net.write"|"fs.read"|"fs.write"|"exec.shell"|"bleeding.edge";
export const HAL = {
  config: Smart,
  setMode, setProductTier, setGoogleTier,
  policy: {
    isAllowedCap(cap: Caps, overrides?: Caps[]) {
      const denied = new Set(Smart.safety.denyCaps);
      return !denied.has(cap) || (overrides?.includes(cap) ?? false);
    },
    canOverrideCaps(userTier: string) {
      const order = ["FreeWanderer","Apprentice","Artificer","Architect","Oracle"];
      return order.indexOf(userTier) >= order.indexOf(Smart.safety.allowOverridesMinTier);
    }
  },
  on: HALBus.on.bind(HALBus), emit: HALBus.emit.bind(HALBus)
};
