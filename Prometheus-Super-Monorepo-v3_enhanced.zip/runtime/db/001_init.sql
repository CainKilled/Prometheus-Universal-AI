
-- Prometheus Runtime DB Initialization
PRAGMA journal_mode=WAL;
CREATE TABLE IF NOT EXISTS forensic_runs (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    created_at TEXT NOT NULL,
    root TEXT NOT NULL,
    file_count INTEGER NOT NULL,
    placeholders INTEGER NOT NULL,
    signature TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS forensic_files (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    run_id INTEGER NOT NULL,
    path TEXT NOT NULL,
    size INTEGER,
    mtime REAL,
    mode INTEGER,
    sha256 TEXT,
    binary INTEGER,
    has_placeholder INTEGER,
    FOREIGN KEY(run_id) REFERENCES forensic_runs(id)
);
CREATE TABLE IF NOT EXISTS events (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    created_at TEXT NOT NULL,
    kind TEXT NOT NULL,
    scope TEXT NOT NULL,
    message TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS companions (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    path TEXT NOT NULL UNIQUE,
    manifest_hash TEXT NOT NULL,
    test_last_run TEXT,
    status TEXT NOT NULL DEFAULT 'unknown'
);
