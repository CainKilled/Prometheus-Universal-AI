export type Mode = "SAFE"|"PROD"|"LAB"|"GODMODE"|"CINEMATIC";
export type Threading = "single"|"threadpool"|"hyper";
export type ProductTier = "FreeWanderer"|"Apprentice"|"Artificer"|"Architect"|"Oracle";
export type GoogleDevTier = "Firebase-Spark"|"Firebase-Blaze"|"GCP-Individual"|"GCP-Startup"|"GCP-Enterprise";

export interface SmartConfig {
  mode: Mode;
  threading: Threading;
  productTier: ProductTier;
  googleDevTier: GoogleDevTier;
  safety: { denyCaps: string[]; allowOverridesMinTier: ProductTier; };
}

const denyBase = ["fs.write","exec.shell","net.write","bleeding.edge"];

export const Smart: SmartConfig = {
  mode: "SAFE",
  threading: "threadpool",
  productTier: "FreeWanderer",
  googleDevTier: "Firebase-Spark",
  safety: { denyCaps: denyBase, allowOverridesMinTier: "Architect" }
};

export function setMode(m: Mode) { Smart.mode = m; if (m==="GODMODE") Smart.threading="hyper"; }
export function setProductTier(t: ProductTier){ Smart.productTier = t; }
export function setGoogleTier(t: GoogleDevTier){ Smart.googleDevTier = t; }
