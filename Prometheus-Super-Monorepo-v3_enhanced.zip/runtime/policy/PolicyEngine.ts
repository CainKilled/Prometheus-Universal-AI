import fs from "fs";
import path from "path";
import { parseJSONC } from "./JSONC.js";

export type Policy = {
  version: string;
  caps: { deny: string[]; allow: string[] };
  tiers: Record<string, { canOverrideCaps: boolean; dailyBudgetTokens: number; }>;
  dlp: { blockPatterns: { name:string; re:string }[]; action: "block"|"redact" };
  retentionDays: number;
  secrets: { allowedSources: ("env"|"vault")[]; forbidHardcoded: boolean };
  distribution: { centralized: boolean; decentralized: boolean; contentAddressed: boolean };
  order: { preferences: ("local"|"edge"|"remote"|"global")[]; allowReorder: boolean };
};

const readJSONC = (p:string)=>parseJSONC(fs.readFileSync(p,"utf8"));

export function loadPolicy(rootDir = process.cwd(), modeOverride?: string): Policy {
  const base = path.resolve(rootDir, "policy/default.policy.jsonc");
  const defaultPolicy = readJSONC(base);
  const mode = modeOverride || process.env.PROM_MODE || "SAFE";
  const modePath = path.resolve(rootDir, `policy/modes/${mode}.policy.jsonc`);
  const modePolicy = fs.existsSync(modePath) ? readJSONC(modePath) : {};
  return { ...defaultPolicy, ...modePolicy } as Policy;
}
