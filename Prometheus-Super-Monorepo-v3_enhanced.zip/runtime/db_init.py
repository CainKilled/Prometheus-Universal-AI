#!/usr/bin/env python3
"""
SQLite DB bootstrapper for Prometheus Runtime.
Applies all *.sql migrations in runtime/db in lexical order.
"""
import sqlite3, os
from pathlib import Path

def apply_migrations(db_path: Path, mig_dir: Path):
    db_path.parent.mkdir(parents=True, exist_ok=True)
    conn = sqlite3.connect(str(db_path))
    try:
        for mig in sorted(mig_dir.glob("*.sql")):
            sql = mig.read_text()
            conn.executescript(sql)
        conn.commit()
    finally:
        conn.close()

if __name__ == '__main__':
    root = Path(__file__).resolve().parents[1]
    db_path = root / 'runtime' / 'db' / 'prometheus_runtime.db'
    mig_dir = root / 'runtime' / 'db'
    apply_migrations(db_path, mig_dir)
    print(f"DB prepared at {db_path}")
