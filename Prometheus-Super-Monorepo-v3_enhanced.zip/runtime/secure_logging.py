#!/usr/bin/env python3
import logging, os
from pathlib import Path

def init_logger(name: str = 'prometheus', level: int = logging.INFO):
    logdir = Path('runtime/logs')
    logdir.mkdir(parents=True, exist_ok=True)
    logfile = logdir / f'{name}.log'
    logger = logging.getLogger(name)
    logger.setLevel(level)
    if not logger.handlers:
        fh = logging.FileHandler(logfile, encoding='utf-8')
        fmt = logging.Formatter('%(asctime)s - %(levelname)s - %(message)s')
        fh.setFormatter(fmt)
        logger.addHandler(fh)
        sh = logging.StreamHandler()
        sh.setFormatter(fmt)
        logger.addHandler(sh)
    return logger
