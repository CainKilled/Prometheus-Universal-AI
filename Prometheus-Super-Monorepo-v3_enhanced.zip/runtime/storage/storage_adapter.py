#!/usr/bin/env python3
"""
Storage Adapter for Prometheus Runtime
- LocalFilesystem: save/load/list artifacts under runtime/storage/data
- SqliteBlobStore: store small artifacts inside the runtime DB (companions, manifests)
"""
import os, sqlite3, base64
from pathlib import Path
from typing import List, Optional, Tuple

class LocalFilesystem:
    def __init__(self, base: Path):
        self.base = base
        self.base.mkdir(parents=True, exist_ok=True)

    def write_bytes(self, rel: str, data: bytes) -> Path:
        p = self.base / rel
        p.parent.mkdir(parents=True, exist_ok=True)
        p.write_bytes(data)
        return p

    def read_bytes(self, rel: str) -> bytes:
        return (self.base / rel).read_bytes()

    def list(self, rel: str=".") -> List[Path]:
        base = (self.base / rel)
        return [p for p in base.rglob('*') if p.is_file()]

class SqliteBlobStore:
    def __init__(self, db_path: Path):
        self.db_path = db_path
        self._ensure()

    def _ensure(self):
        conn = sqlite3.connect(str(self.db_path))
        conn.execute("CREATE TABLE IF NOT EXISTS kv (k TEXT PRIMARY KEY, v BLOB NOT NULL)")
        conn.commit()
        conn.close()

    def put(self, key: str, data: bytes):
        conn = sqlite3.connect(str(self.db_path))
        conn.execute("INSERT OR REPLACE INTO kv (k, v) VALUES (?, ?)", (key, data))
        conn.commit()
        conn.close()

    def get(self, key: str) -> Optional[bytes]:
        conn = sqlite3.connect(str(self.db_path))
        cur = conn.execute("SELECT v FROM kv WHERE k=?", (key,))
        row = cur.fetchone()
        conn.close()
        return row[0] if row else None
