
# Prometheus Enhancement Pass (Compact)

This pass installs:
- **Forensics Mode**: repeatable, signed scans (hashes + placeholder flags) with optional DB persistence.
- **DB Bootstrap**: `runtime/db/001_init.sql` and `runtime/db_init.py` prepare `prometheus_runtime.db`.
- **Storage Adapters**: local filesystem + sqlite blob store for small artifacts.
- **Companion Generator**: creates `.manifest` and `.test` for priority files (cap 200 per pass).

## Run Order
1. `python runtime/db_init.py`
2. `python tools/forensics_mode/forensics_mode.py --root . --out forensics_report.json`
3. `python tools/companions/generate_companions.py`
