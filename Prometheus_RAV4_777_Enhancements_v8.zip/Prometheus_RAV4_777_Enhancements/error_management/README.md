# Error Management 777 Engine

The *Smart Error Management 777 Engine* centralises error classification and
handling across the Prometheus environment. By assigning each error to a
category (transient, permanent, configuration, security or unknown) and
dispatching to registered handlers, the engine encourages consistent,
context‑aware responses to faults.

## Core concepts

1. **ErrorCategory** – Enum of high‑level categories used to classify
   exceptions. Extend `ErrorManager.classify()` to classify additional
   exceptions.
2. **ErrorEvent** – Data structure containing the error message, category,
   timestamp, original exception and optional context.
3. **ErrorManager** – Registry of handlers. It supports registering
   handlers per category or per exception type. If no handler is
   registered, it falls back to printing the error.

### Using the engine

```python
from error_management.engine import ErrorManager

err_mgr = ErrorManager()

# Register a handler for configuration errors
def handle_config(event):
    # e.g. prompt the user to fix configuration
    print(f"CONFIG ERROR: {event.message}")

err_mgr.register_category_handler(ErrorCategory.CONFIGURATION, handle_config)

try:
    with open("missing.yaml") as f:
        pass
except Exception as exc:
    err_mgr.handle("Failed to open configuration", exc)
```

This will classify `FileNotFoundError` as a configuration error and invoke
the registered handler.

The engine is intentionally simple; complex strategies like retries,
backoff or circuit breakers can be implemented by registering custom
handlers.