"""
Browser Plugin
==============

This plugin serves as a bridge between the Prometheus ecosystem and web
browsers. Its primary purpose is to expose a unified API for launching,
controlling and communicating with browsers (e.g. Chrome, Firefox, Edge) in
a platform‑agnostic way. The actual browser control logic should be
implemented using trusted open‑source projects such as
[Selenium](https://www.selenium.dev/) or [Playwright](https://playwright.dev/).
This scaffold provides only metadata and a stub activation method.
"""

# Prometheus Codex Lock v1
# This file is part of Prometheus RAV4 777 Enhancements. Do not edit manually.

from typing import Dict, Any
from plugins.api.plugin_base import Plugin


class BrowserPlugin:
    """
    Concrete browser integration plugin.

    This implementation uses Python’s built‑in `webbrowser` module to open
    a URL in the user’s default browser. If opening the browser fails or
    a graphical browser is unavailable, it falls back to a CLI mode using
    `urllib.request` to fetch the page and print its first few lines.

    A URL should be provided in the runtime context under the key `url`. If
    no URL is provided, the plugin opens a default page (`about:blank`).
    """

    def metadata(self) -> Dict[str, Any]:
        return {
            "name": "browser",
            "version": "1.0.0",
            "description": "Open URLs using the standard library webbrowser module with CLI fallback.",
            "targets": ["browser"],
        }

    def activate(self, runtime: Dict[str, Any]) -> None:
        import webbrowser
        import urllib.request
        from urllib.error import URLError

        logger = runtime.get("log", print)
        url = runtime.get("url", "about:blank")
        logger(f"Opening URL: {url}")
        try:
            # Attempt to open in graphical browser. `webbrowser.open` returns
            # True if the browser could be launched【185359879585831†L56-L63】.
            ok = webbrowser.open(url, new=2)
            if ok:
                logger("Browser opened successfully")
                return
        except webbrowser.Error as exc:
            logger(f"webbrowser error: {exc}")
        # Fallback: fetch and print the first 500 bytes of the page via HTTP
        try:
            with urllib.request.urlopen(url) as response:
                content = response.read(500).decode("utf-8", errors="replace")
                logger("CLI Fallback: showing first 500 bytes of page:\n" + content)
        except URLError as exc:
            logger(f"Failed to fetch URL in CLI fallback: {exc}")


def get_plugin() -> Plugin:
    return BrowserPlugin()  # type: ignore[return-value]