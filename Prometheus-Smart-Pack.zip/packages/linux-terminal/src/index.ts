import { spawn } from "child_process";
import { HAL } from "../../runtime/hal/HAL.js";

export function runCommand(cmd: string, args: string[] = [], opts: { cwd?: string } = {}) {
  if (!HAL.policy.isAllowedCap("exec.shell")) throw new Error("exec.shell not allowed (SAFE by default)");
  return new Promise((resolve, reject)=>{
    const p = spawn(cmd, args, { cwd: opts.cwd, shell: false });
    let out = "", err = "";
    p.stdout.on("data", d => out += String(d));
    p.stderr.on("data", d => err += String(d));
    p.on("close", code => code===0 ? resolve({ code, out }) : reject(new Error(err||`exit ${code}`)));
  });
}
