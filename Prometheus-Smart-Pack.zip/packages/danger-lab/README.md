# Danger Lab (OFF by default)
- Enables experimental features when `DANGER_LAB=1` env var is set.
- Never enable in production without review.
