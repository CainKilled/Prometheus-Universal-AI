// Minimal test harness using Node's assert
import assert from "node:assert";
try {
  assert.equal(1+1, 2);
  console.log("OK basic math");
  process.exit(0);
} catch (e) {
  console.error("Test failed", e);
  process.exit(1);
}
