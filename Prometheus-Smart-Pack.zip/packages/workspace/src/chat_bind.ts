/**
 * Bind chat histories to Prometheus project.
 * Usage: node dist/index.js chat-bind path/to/chat.json
 * Expected input: [{ id, timestamp, role, content }, ...]
 * Output: writes normalized NDJSON to database/chat/ bound to project "Prometheus".
 */
import fs from "fs";
import path from "path";

export function bindChat(file: string) {
  const raw = JSON.parse(fs.readFileSync(file, "utf8"));
  const outDir = path.resolve(process.cwd(), "database/chat");
  fs.mkdirSync(outDir, { recursive: true });
  const out = path.join(outDir, "prometheus.ndjson");
  const fd = fs.openSync(out, "a");
  for (const m of raw) {
    const rec = { project: "Prometheus", id: m.id, ts: m.timestamp, role: m.role, content: m.content };
    fs.writeSync(fd, JSON.stringify(rec) + "\n");
  }
  fs.closeSync(fd);
  console.log("Chat bound ->", out);
}
