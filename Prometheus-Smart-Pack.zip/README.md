# Prometheus Developer’s Guide — Smart Pack
This is a minimal, idempotent scaffold including:
- runtime smart config + HAL
- multithreading pool
- backend execute function
- packages: linux-terminal, compiler, testing, danger-lab, workspace

## Quick start
```bash
npm i --workspaces
npm run build
node runtime/cli/prom.ts status
```
