import * as functions from "firebase-functions";
import { z } from "zod";
import { GlobalPool } from "../../../runtime/concurrency/SmartPool.js";
import { HAL } from "../../../runtime/hal/HAL.js";

const Req = z.object({ payload: z.any(), capsOverride: z.array(z.string()).optional(), userTier: z.string().default("FreeWanderer") });

export const execute = functions.https.onCall(async (data, ctx) => {
  const { payload, capsOverride, userTier } = Req.parse(data);
  if (!ctx.auth?.uid) throw new functions.https.HttpsError("unauthenticated","Sign in required");
  if (capsOverride && !HAL.policy.canOverrideCaps(userTier)) throw new functions.https.HttpsError("permission-denied","Tier insufficient");
  const out = await GlobalPool.submit(String(Date.now()), payload);
  return { ok: true, out };
});
