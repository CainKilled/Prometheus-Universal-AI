export type Mode = "SAFE"|"PROD"|"LAB"|"GODMODE"|"CINEMATIC";
export type Threading = "single"|"threadpool"|"hyper";
export type ProductTier = "FreeWanderer"|"Apprentice"|"Artificer"|"Architect"|"Oracle";
export type GoogleDevTier = "Firebase-Spark"|"Firebase-Blaze"|"GCP-Individual"|"GCP-Startup"|"GCP-Enterprise";

export interface SmartConfig {
  mode: Mode;
  threading: Threading;
  productTier: ProductTier;
  googleDevTier: GoogleDevTier;
  safety: { denyCaps: string[]; allowOverridesMinTier: ProductTier; };
  uiux: { style: "Dashboard"|"Game"|"Futurist"|"Cinematic"; cinematicFpsCap: number; enableVoice: boolean; };
}

const denyBase = ["fs.write","exec.shell","net.write","bleeding.edge"];

export const Smart: SmartConfig = {
  mode: "SAFE",
  threading: "threadpool",
  productTier: "FreeWanderer",
  googleDevTier: "Firebase-Spark",
  safety: { denyCaps: denyBase, allowOverridesMinTier: "Architect" },
  uiux: { style:"Dashboard", cinematicFpsCap:60, enableVoice:false }
};

export function setMode(m: Mode) {
  Smart.mode = m;
  if (m === "GODMODE") Smart.threading = "hyper";
  if (m === "CINEMATIC") Smart.uiux.cinematicFpsCap = 90;
}
export function setProductTier(t: ProductTier){ Smart.productTier = t; }
export function setGoogleTier(t: GoogleDevTier){ Smart.googleDevTier = t; }
