#!/usr/bin/env node
import { HAL } from "../hal/HAL.js";
import { setMode, setProductTier, setGoogleTier, Smart } from "../smart.config.js";
import { GlobalPool } from "../concurrency/SmartPool.js";

const [,,cmd,...rest] = process.argv;
async function main(){
  if (!cmd || cmd==="status") { console.log({ mode: Smart.mode, tier: Smart.productTier, gcpTier: Smart.googleDevTier }); return; }
  if (cmd==="mode") { setMode(rest[0] as any); console.log("mode->", Smart.mode); return; }
  if (cmd==="tier") { setProductTier(rest[0] as any); console.log("tier->", Smart.productTier); return; }
  if (cmd==="gcp-tier") { setGoogleTier(rest[0] as any); console.log("gcpTier->", Smart.googleDevTier); return; }
  if (cmd==="run") { const out = await GlobalPool.submit(String(Date.now()), { msg: rest.join(" ")||"hello" }); console.log(out); return; }
  console.log("Commands: status | mode <SAFE|PROD|LAB|GODMODE|CINEMATIC> | tier <...> | gcp-tier <...> | run <text>");
}
main().catch(e=>(console.error(e),process.exit(1)));
