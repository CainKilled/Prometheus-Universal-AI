#!/usr/bin/env bash
# Test script for the steganography engine

python - <<'PY'
import os
import tempfile
from PIL import Image
import sys
sys.path.append('Prometheus_RAV4_777_Enhancements')
from engines.steganography_engine import scan_file_for_steganography

def embed_message(img, message: bytes):
    # Embed the message into the LSBs of the image pixels
    pixels = list(img.getdata())
    bits = []
    for byte in message:
        for i in range(8):
            bits.append((byte >> (7 - i)) & 1)
    # Pad bits to multiple of 3 to align with RGB channels
    while len(bits) % 3 != 0:
        bits.append(0)
    new_pixels = []
    bit_idx = 0
    for (r, g, b) in pixels:
        if bit_idx < len(bits):
            r = (r & ~1) | bits[bit_idx]
            g = (g & ~1) | bits[bit_idx + 1]
            b = (b & ~1) | bits[bit_idx + 2]
            bit_idx += 3
        new_pixels.append((r, g, b))
    img.putdata(new_pixels)
    return img

with tempfile.TemporaryDirectory() as tmpdir:
    # Create a clean image
    clean = Image.new('RGB', (10, 10), color=(255, 255, 255))
    clean_path = os.path.join(tmpdir, 'clean.png')
    clean.save(clean_path)
    res = scan_file_for_steganography(clean_path)
    assert not res["hidden"], 'Clean image falsely reported hidden data'

    # Embed message into another image
    secret_img = Image.new('RGB', (10, 10), color=(255, 255, 255))
    msg = b'STEGO:HELLO'
    embed_message(secret_img, msg)
    secret_path = os.path.join(tmpdir, 'secret.png')
    secret_img.save(secret_path)
    res = scan_file_for_steganography(secret_path)
    assert res["hidden"] and res["message"].startswith('HELLO'), 'Hidden message not detected or incorrect'
print("steganography_engine OK")
PY