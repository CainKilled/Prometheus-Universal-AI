#!/usr/bin/env bash
# Test script for the bughunting engine

python - <<'PY'
import os
import tempfile
import sys
sys.path.append('Prometheus_RAV4_777_Enhancements')
from engines.bughunting_engine import scan_codebase

with tempfile.TemporaryDirectory() as tmpdir:
    code = """
def safe():
    print('hello')

def unsafe():
    eval('2+2')
    import os, subprocess
    os.system('ls')
    subprocess.Popen(['ls'], shell=True)
"""
    sample_file = os.path.join(tmpdir, 'bad.py')
    with open(sample_file, 'w', encoding='utf-8') as f:
        f.write(code)
    findings = scan_codebase(tmpdir)
    assert any('eval' in f['snippet'] for f in findings), 'eval not detected'
    assert any('os.system' in f['snippet'] for f in findings), 'os.system not detected'
    assert any('subprocess.Popen' in f['snippet'] for f in findings), 'Popen not detected'
    print('bughunting_engine OK')
PY