"""
AutoCascade Engine
=================

The AutoCascade engine introspects the Prometheus monorepo to discover
new tools and automatically generates thin engine and plugin wrappers
for them.  By creating these wrappers, tools become first‑class
components within the framework: they can be invoked via the plugin
manager, scheduled by DevSwarm tasks and integrated into wizard flows
and CI/CD pipelines.  The goal of AutoCascade is to reduce manual
plumbing and make it easy for the system to "build itself" when
developers add new modules under ``tools``.

Usage:

    from engines.autocascade_engine import AutoCascadeEngine
    engine = AutoCascadeEngine(base_dir="/path/to/prometheus")
    created = engine.ensure_wrappers()
    print(f"Created wrappers for: {created}")

The engine is idempotent: running ``ensure_wrappers()`` repeatedly will
only generate wrappers for tools that don't already have them.  Each
generated engine exposes a ``run`` method that can call any public
callable in the underlying tool module.  Each generated plugin
exposes a simple interface expecting ``function``, ``args`` and
``kwargs`` in the runtime dictionary.

Developed and maintained by Adam Henry Nagle.  Contact:
603‑384‑8949, cainkilledabrl@icloud.com, nagleadam75@gmail.com.
"""

from __future__ import annotations

import inspect
import importlib
import json
import os
from pathlib import Path
from typing import List, Dict, Any, Optional


class AutoCascadeEngine:
    """Discover tools and generate engine/plugin wrappers for them.

    Parameters
    ----------
    base_dir: str
        The root of the Prometheus monorepo (directory containing
        ``tools``, ``engines``, ``plugins`` etc.).  If omitted,
        defaults to the current working directory.
    log: callable, optional
        A logging function used to report progress; defaults to ``print``.
    """

    def __init__(self, base_dir: Optional[str] = None, log: Optional[Any] = None) -> None:
        self.base_dir = base_dir or os.getcwd()
        self.log = log or (lambda *args, **kwargs: None)

    def scan_tools(self) -> List[str]:
        """Return a list of tool module names discovered under the tools directory."""
        tools_dir = Path(self.base_dir) / "tools"
        modules: List[str] = []
        for entry in tools_dir.iterdir():
            if entry.is_file() and entry.suffix == ".py" and entry.name != "__init__.py":
                modules.append(entry.stem)
        return modules

    def ensure_wrappers(self) -> List[str]:
        """Generate engine and plugin wrappers for any tool lacking them.

        Returns
        -------
        List[str]
            A list of tool names for which wrappers were created.
        """
        created: List[str] = []
        tools = self.scan_tools()
        gen_engines_dir = Path(self.base_dir) / "engines" / "autocascade_generated"
        gen_plugins_dir = Path(self.base_dir) / "plugins" / "targets" / "autocascade_generated"
        gen_engines_dir.mkdir(parents=True, exist_ok=True)
        gen_plugins_dir.mkdir(parents=True, exist_ok=True)
        for mod_name in tools:
            engine_path = gen_engines_dir / f"{mod_name}_engine.py"
            plugin_path = gen_plugins_dir / f"{mod_name}_plugin.py"
            # Skip generating for the autocascade engine itself or existing wrappers
            if mod_name == "autocascade_engine":
                continue
            if engine_path.exists() or plugin_path.exists():
                continue
            try:
                module = importlib.import_module(f"tools.{mod_name}")
            except Exception as exc:
                self.log(f"AutoCascade: failed to import tools.{mod_name}: {exc}")
                continue
            functions = [name for name, obj in inspect.getmembers(module) if callable(obj) and not name.startswith("_")]
            # Generate engine file content
            engine_code = self._render_engine(mod_name)
            plugin_code = self._render_plugin(mod_name, functions)
            engine_path.write_text(engine_code, encoding="utf-8")
            plugin_path.write_text(plugin_code, encoding="utf-8")
            # Write manifest files
            self._write_manifest(engine_path)
            self._write_manifest(plugin_path)
            # Write simple test scripts
            self._write_test(engine_path, mod_name)
            self._write_test(plugin_path, mod_name, plugin=True)
            created.append(mod_name)
            self.log(f"AutoCascade: generated wrappers for tool '{mod_name}'")
        return created

    def _render_engine(self, mod_name: str) -> str:
        """Return Python source code for a generated engine wrapping a tool module."""
        return f""""""
Auto‑generated Engine for tool {mod_name}
========================================

This engine was created by the AutoCascade engine.  It provides a
generic interface to call functions defined in the tool module
``tools.{mod_name}``.  Functions are dispatched by name, and any
positional or keyword arguments are forwarded directly.

Developed and maintained by Adam Henry Nagle.  Contact:
603‑384‑8949, cainkilledabrl@icloud.com, nagleadam75@gmail.com.
""""""

from __future__ import annotations

import importlib
from typing import Any


class {mod_name.capitalize()}Engine:
    """Call functions from ``tools.{mod_name}`` dynamically."""
    def __init__(self) -> None:
        self._module = importlib.import_module('tools.{mod_name}')

    def run(self, function: str, *args: Any, **kwargs: Any) -> Any:
        """Execute ``function`` defined in the tool module.

        Parameters
        ----------
        function: str
            Name of the function in the tool module to call.
        args: Any
            Positional arguments forwarded to the function.
        kwargs: Any
            Keyword arguments forwarded to the function.

        Returns
        -------
        Any
            The result of the function call.
        """
        if not hasattr(self._module, function):
            raise AttributeError(f"tools.{mod_name} has no function '{function}'")
        func = getattr(self._module, function)
        return func(*args, **kwargs)


__all__ = ['{mod_name.capitalize()}Engine']
"""

    def _render_plugin(self, mod_name: str, functions: List[str]) -> str:
        """Return Python source code for a generated plugin wrapping a tool module."""
        # Build a docstring listing available functions
        funcs_list = "\n".join(f"  * ``{fn}``" for fn in functions) or "  (no public functions found)"
        return f""""""
Auto‑generated Plugin for tool {mod_name}
=======================================

This plugin was created automatically by the AutoCascade engine.  It
wraps the corresponding engine (``{mod_name.capitalize()}Engine``) and
exposes a simple interface via runtime parameters.  The plugin
accepts the following keys in the runtime dictionary:

``function``: name of the function to call (required)
``args``: list of positional arguments (optional)
``kwargs``: dictionary of keyword arguments (optional)

Available functions discovered in ``tools.{mod_name}``:
{funcs_list}

Developed and maintained by Adam Henry Nagle.  Contact:
603‑384‑8949, cainkilledabrl@icloud.com, nagleadam75@gmail.com.
""""""

from __future__ import annotations

from typing import Dict, Any
from plugins.api.plugin_base import Plugin
from engines.autocascade_generated.{mod_name}_engine import {mod_name.capitalize()}Engine


class {mod_name.capitalize()}Plugin:
    """Automatically generated plugin wrapper for ``tools.{mod_name}``."""
    def metadata(self) -> Dict[str, Any]:
        return {{
            "name": "{mod_name}",
            "version": "1.0.0",
            "description": "Auto‑generated plugin for tools.{mod_name}",
            "targets": ["tools", "{mod_name}"],
        }}

    def activate(self, runtime: Dict[str, Any]) -> None:
        logger = runtime.get("log", print)
        func_name: str = runtime.get("function")
        args = runtime.get("args", [])
        kwargs = runtime.get("kwargs", {{}})
        if not func_name:
            logger("Missing required parameter: function")
            return
        engine = {mod_name.capitalize()}Engine()
        try:
            result = engine.run(func_name, *args, **kwargs)
            logger(result)
        except Exception as exc:
            logger(f"Error running function {{func_name}}: {{exc}}")


def get_plugin() -> Plugin:
    return {mod_name.capitalize()}Plugin()  # type: ignore[return-value]
"""

    def _write_manifest(self, file_path: Path) -> None:
        """Create a simple manifest file for a generated module."""
        import hashlib
        sha = hashlib.sha256(file_path.read_bytes()).hexdigest()
        manifest = {
            "file": str(file_path.relative_to(Path(self.base_dir))),
            "sha256": sha,
            "created_utc": __import__('datetime').datetime.utcnow().strftime('%Y-%m-%dT%H:%M:%SZ'),
            "codex_lock": True,
            "vaulttime_seal": True,
        }
        manifest_path = file_path.with_suffix(file_path.suffix + ".manifest.json")
        manifest_path.write_text(json.dumps(manifest, indent=2), encoding="utf-8")

    def _write_test(self, file_path: Path, mod_name: str, plugin: bool = False) -> None:
        """Write a basic test script for a generated engine or plugin."""
        test_path = file_path.with_suffix(file_path.suffix + ".test.sh")
        # Determine import path and call
        rel = file_path.relative_to(Path(self.base_dir))
        # Build test code
        if plugin:
            # Test plugin metadata
            test_code = f"""#!/usr/bin/env bash
python - <<'PY'
import sys
sys.path.append('{self.base_dir}')
from plugins.autocascade_generated.{mod_name}_plugin import get_plugin
plugin = get_plugin()
meta = plugin.metadata()
assert meta['name'] == '{mod_name}'
print('{mod_name}_plugin OK')
PY
"""
        else:
            test_code = f"""#!/usr/bin/env bash
python - <<'PY'
import sys
sys.path.append('{self.base_dir}')
from engines.autocascade_generated.{mod_name}_engine import {mod_name.capitalize()}Engine
engine = {mod_name.capitalize()}Engine()
# ensure the engine has a run method
assert hasattr(engine, 'run')
print('{mod_name}_engine OK')
PY
"""
        test_path.write_text(test_code, encoding="utf-8")