#!/usr/bin/env bash
set -euo pipefail
python -m py_compile "engines/asset_engine.py"
echo "[OK] asset_engine.py"