"""
Profile Manager for libmobiledevice GUI
--------------------------------------

This module provides a simple profile manager used by the
``libmobiledevice_gui`` package.  It is responsible for creating,
loading and verifying a user profile consisting of a username and a
hashed password.  Profiles are stored in JSON format on disk in a
location relative to the package directory.  Passwords are hashed
using SHA‑256 to avoid storing clear‑text credentials.  If no profile
exists the manager can create a new one.  When verifying a password
the provided plain text string is hashed and compared against the
stored digest.

This class can be used independently of the GUI to manage user
credentials for any tools that require authentication.

Developed and maintained by Adam Henry Nagle.  Contact:
603‑384‑8949, cainkilledabrl@icloud.com, nagleadam75@gmail.com.
"""

from __future__ import annotations

import json
import hashlib
from pathlib import Path
from typing import Optional, Dict, Any


class ProfileManager:
    """Manage user profiles for the libmobiledevice GUI.

    A profile consists of a username and a hashed password.  Profiles are
    stored in a JSON file at ``profile.json`` within the package's
    directory.  The manager provides methods to check if a profile
    exists, create a new profile, load an existing profile, and verify
    provided credentials against the stored password hash.
    """

    def __init__(self, base_dir: Optional[str] = None) -> None:
        # Determine where profile data should be stored.  If base_dir is
        # provided use that, otherwise default to this file's directory.
        if base_dir is None:
            self.base_path = Path(__file__).resolve().parent
        else:
            self.base_path = Path(base_dir)
        self.profile_path = self.base_path / "profile.json"

    def profile_exists(self) -> bool:
        """Return True if the profile file exists and contains a username."""
        if not self.profile_path.exists():
            return False
        try:
            data = json.loads(self.profile_path.read_text(encoding="utf-8"))
            return bool(data.get("username"))
        except Exception:
            # If the file is malformed, treat as non‑existent
            return False

    def create_profile(self, username: str, password: str) -> None:
        """Create a new profile with the given username and password.

        The password is hashed with SHA‑256 before being stored.  If a
        profile already exists it will be overwritten.
        """
        digest = hashlib.sha256(password.encode("utf-8")).hexdigest()
        data = {
            "username": username,
            "password_hash": digest,
        }
        self.profile_path.write_text(json.dumps(data, indent=2), encoding="utf-8")

    def load_profile(self) -> Optional[Dict[str, Any]]:
        """Load and return the stored profile if it exists, else None."""
        if not self.profile_exists():
            return None
        try:
            return json.loads(self.profile_path.read_text(encoding="utf-8"))
        except Exception:
            return None

    def verify_password(self, password: str) -> bool:
        """Check if the provided password matches the stored profile hash."""
        profile = self.load_profile()
        if not profile:
            return False
        digest = hashlib.sha256(password.encode("utf-8")).hexdigest()
        return digest == profile.get("password_hash")