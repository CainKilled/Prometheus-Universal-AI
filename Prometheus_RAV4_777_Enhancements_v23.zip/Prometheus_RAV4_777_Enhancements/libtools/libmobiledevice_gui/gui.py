"""
libmobiledevice GUI Application
-------------------------------

This module implements a simple Tkinter‑based graphical interface
around common ``libimobiledevice`` tools.  It is designed to work
together with the ``ProfileManager`` so that users must register a
username and password on first launch.  After logging in the
application presents a main window containing buttons to perform
typical device management tasks such as listing connected devices and
retrieving device information.  The output of these commands is
displayed in a scrollable text area so users can see the results of
their actions.

NOTE: This GUI is intended as a lightweight front‑end and does not
expose the full capabilities of libimobiledevice.  To perform more
advanced operations such as backup, restore or app installation the
``libmobiledevice`` command line tools should be used directly.  In
future iterations this GUI could be extended to cover additional
commands.

Developed and maintained by Adam Henry Nagle.  Contact:
603‑384‑8949, cainkilledabrl@icloud.com, nagleadam75@gmail.com.
"""

from __future__ import annotations

import os
import subprocess
import tkinter as tk
from tkinter import simpledialog, messagebox, scrolledtext
from typing import Optional

from .profile_manager import ProfileManager


class LibMobileDeviceGUI:
    """Main application class for the libmobiledevice GUI."""

    def __init__(self, profile_manager: Optional[ProfileManager] = None) -> None:
        self.pm = profile_manager or ProfileManager()
        self.root = tk.Tk()
        self.root.title("libmobiledevice GUI")
        self.root.geometry("600x400")
        # Create text output area
        self.text_area = scrolledtext.ScrolledText(self.root, wrap=tk.WORD, height=15)
        self.text_area.pack(fill=tk.BOTH, expand=True, padx=10, pady=10)
        # Create buttons frame
        btn_frame = tk.Frame(self.root)
        btn_frame.pack(fill=tk.X, padx=10, pady=5)
        tk.Button(btn_frame, text="List Devices", command=self.list_devices).pack(side=tk.LEFT, padx=5)
        tk.Button(btn_frame, text="Device Info", command=self.device_info).pack(side=tk.LEFT, padx=5)
        tk.Button(btn_frame, text="Exit", command=self.root.quit).pack(side=tk.RIGHT, padx=5)
        # Show login or registration dialog
        self.ensure_profile_and_login()

    # ------------------------------------------------------------------
    # Profile handling
    # ------------------------------------------------------------------
    def ensure_profile_and_login(self) -> None:
        """Ensure a profile exists and prompt the user to authenticate."""
        # If no profile exists ask to create one
        if not self.pm.profile_exists():
            messagebox.showinfo("Registration", "No profile found. Please create one.")
            self.register_user()
        # Now prompt for password
        for _ in range(3):  # Allow up to 3 attempts
            pwd = simpledialog.askstring("Login", "Enter your password:", show="*")
            if pwd is None:
                # User cancelled
                self.root.quit()
                return
            if self.pm.verify_password(pwd):
                username = self.pm.load_profile().get("username", "")
                self.root.title(f"libmobiledevice GUI – {username}")
                return
            messagebox.showerror("Error", "Incorrect password. Try again.")
        messagebox.showerror("Failed", "Too many incorrect attempts.")
        self.root.quit()

    def register_user(self) -> None:
        """Prompt the user to register a new profile."""
        while True:
            username = simpledialog.askstring("Registration", "Choose a username:")
            if username is None or username.strip() == "":
                messagebox.showwarning("Invalid", "Username cannot be empty.")
                continue
            pwd = simpledialog.askstring("Registration", "Choose a password:", show="*")
            if pwd is None or pwd == "":
                messagebox.showwarning("Invalid", "Password cannot be empty.")
                continue
            self.pm.create_profile(username.strip(), pwd)
            messagebox.showinfo("Saved", "Profile created successfully. Please log in.")
            break

    # ------------------------------------------------------------------
    # Command execution helpers
    # ------------------------------------------------------------------
    def run_command(self, cmd: list[str]) -> str:
        """Run a command and return its output or error message."""
        try:
            proc = subprocess.run(cmd, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True)
            return proc.stdout.strip()
        except FileNotFoundError:
            return f"Command not found: {' '.join(cmd)}"
        except Exception as e:
            return f"Error running {' '.join(cmd)}: {e}"

    def append_output(self, text: str) -> None:
        """Append a line of text to the output area."""
        self.text_area.insert(tk.END, text + "\n")
        self.text_area.see(tk.END)

    # ------------------------------------------------------------------
    # Device operations
    # ------------------------------------------------------------------
    def list_devices(self) -> None:
        """List connected devices using idevice_id -l."""
        self.append_output("Listing devices...")
        output = self.run_command(["idevice_id", "-l"])
        if not output:
            output = "No devices found or idevice_id not installed."
        self.append_output(output)

    def device_info(self) -> None:
        """Prompt for UDID and display device information."""
        udid = simpledialog.askstring("Device Info", "Enter device UDID (leave blank to list first device):")
        if udid is None:
            return
        udid = udid.strip()
        cmd = ["ideviceinfo"]
        if udid:
            cmd.extend(["-u", udid])
        self.append_output(f"Fetching info for device {udid or '[default]'}...")
        output = self.run_command(cmd)
        self.append_output(output)

    # ------------------------------------------------------------------
    # Application entry point
    # ------------------------------------------------------------------
    def run(self) -> None:
        """Start the Tkinter main loop."""
        self.root.mainloop()


def main() -> None:
    gui = LibMobileDeviceGUI()
    gui.run()


if __name__ == "__main__":
    main()