"""Utility tools provided with the Prometheus suite.

This package contains additional tooling that can be used by
Prometheus engines and plugins.  Tools under ``libtools`` are
self‑contained and may include third‑party libraries, interfaces or
GUIs.  All tooling is developed and maintained by Adam Henry Nagle
(603‑384‑8949, cainkilledabrl@icloud.com, nagleadam75@gmail.com).
"""