#!/bin/bash

# Developed and maintained by Adam Henry Nagle. Contact: 603-384-8949, cainkilledabrl@icloud.com, nagleadam75@gmail.com.

# Phoenix System Updater - Last updated: 2025-06-01 00:12:45
# This script performs a full system update across all macOS software layers.

LOGFILE="$HOME/phoenix_system_update.log"
echo "Phoenix System Update started at 2025-06-01 00:12:45" >> $LOGFILE

# App Store Login Check
mas account >> $LOGFILE 2>&1

# Homebrew MAS CLI
brew install mas >> $LOGFILE 2>&1
mas upgrade >> $LOGFILE 2>&1

# Homebrew Update
brew update >> $LOGFILE 2>&1
brew upgrade >> $LOGFILE 2>&1
brew upgrade --cask >> $LOGFILE 2>&1
brew cleanup >> $LOGFILE 2>&1

# Python Package Cache Purge
pip3 cache purge >> $LOGFILE 2>&1

# Node + npm Global Packages Update
npm install -g npm >> $LOGFILE 2>&1
npm -g outdated --parseable | cut -d: -f4 | xargs -n1 npm install -g >> $LOGFILE 2>&1

# Rust + Cargo Tool Updates
cargo install cargo-update >> $LOGFILE 2>&1
rustup update >> $LOGFILE 2>&1
cargo install-update -a >> $LOGFILE 2>&1

# Xcode CLI Tools Check
xcode-select -p >> $LOGFILE 2>&1 || xcode-select --install

echo "Phoenix System Update completed at $(date)" >> $LOGFILE
