"""
Helper Swarms
=============

This module provides basic implementations of helper agent swarms for
handling low‑, middle‑ and upper‑tier tasks. Each swarm maintains a
queue of tasks and uses a simple scheduler to execute them at
approximate times. Tasks are defined by a name, an interval in
seconds and a callable action. Schedulers are deliberately simple and
intended to be replaced by more sophisticated cron or APScheduler‑like
components in the future.

Developers can extend these classes to add persistence, concurrency
controls or custom scheduling logic. The base API remains small and
idempotent so that tasks can be rerun safely.

Developed and maintained by Adam Henry Nagle. Contact: 603-384-8949,
cainkilledabrl@icloud.com, nagleadam75@gmail.com.
"""

from __future__ import annotations

import threading
import time
from dataclasses import dataclass, field
from typing import Callable, Dict, List, Optional


@dataclass
class Task:
    """Represents a scheduled task with a name and callable action."""

    name: str
    interval: float
    action: Callable[[], None]
    last_run: float = field(default_factory=lambda: 0.0)

    def should_run(self, now: float) -> bool:
        """Return True if the task should run at the given time."""
        return (now - self.last_run) >= self.interval

    def run(self) -> None:
        """Execute the task's action and update last_run."""
        try:
            self.action()
        finally:
            self.last_run = time.time()


class BaseHelperSwarm:
    """
    Base class for helper swarms. Subclasses implement specific task
    registration and priority behaviour. The swarm runs tasks in a
    background thread. Tasks may be added at runtime via
    `register_task`.
    """

    def __init__(self, name: str) -> None:
        self.name = name
        self.tasks: Dict[str, Task] = {}
        self._running = False
        self._thread: Optional[threading.Thread] = None
        # Default sleep between checks; subclasses may adjust
        self.poll_interval: float = 1.0

    def register_task(self, task: Task) -> None:
        """Add a task to the swarm, overwriting any existing task with the same name."""
        self.tasks[task.name] = task

    def start(self) -> None:
        """Start the scheduler thread if not already running."""
        if not self._running:
            self._running = True
            self._thread = threading.Thread(target=self._run_loop, daemon=True)
            self._thread.start()

    def stop(self) -> None:
        """Signal the scheduler thread to stop."""
        self._running = False
        if self._thread:
            self._thread.join(timeout=5.0)

    def _run_loop(self) -> None:
        """Internal loop that checks and executes tasks."""
        while self._running:
            now = time.time()
            for task in list(self.tasks.values()):
                if task.should_run(now):
                    try:
                        task.run()
                    except Exception as exc:
                        # Individual task errors should not stop the swarm.
                        print(f"{self.name}: Error running task {task.name}: {exc}")
            time.sleep(self.poll_interval)

    def list_tasks(self) -> List[str]:
        """Return the names of registered tasks."""
        return list(self.tasks.keys())


class LowEndSwarm(BaseHelperSwarm):
    """Swarm for low‑end tasks like housekeeping, backups and status checks."""

    def __init__(self) -> None:
        super().__init__(name="LowEndSwarm")
        # Low‑end tasks poll frequently but perform lightweight work
        self.poll_interval = 1.0


class MidEndSwarm(BaseHelperSwarm):
    """Swarm for medium complexity tasks such as compiling, testing or packaging."""

    def __init__(self) -> None:
        super().__init__(name="MidEndSwarm")
        self.poll_interval = 2.0


class HighEndSwarm(BaseHelperSwarm):
    """Swarm for high‑end tasks like deployments, analytics or heavy data processing."""

    def __init__(self) -> None:
        super().__init__(name="HighEndSwarm")
        # High‑end tasks may be expensive; poll less frequently
        self.poll_interval = 5.0


# Reader and writer swarms ---------------------------------------------------

class ReaderSwarm(BaseHelperSwarm):
    """Swarm for reading operations such as analysis, summarisation and scanning.

    These tasks typically inspect existing artefacts without producing new
    files.  Examples include vulnerability scanning, documentation
    extraction and dataset summarisation.  Reader swarms poll at a
    moderate frequency as they are often invoked on demand.
    """

    def __init__(self) -> None:
        super().__init__(name="ReaderSwarm")
        self.poll_interval = 2.0


class WriterSwarm(BaseHelperSwarm):
    """Swarm for writing operations such as code generation and report writing.

    Writer tasks create or modify artefacts.  They may rely on
    results produced by reader tasks.  Writers run less frequently
    than readers to avoid conflicts and to give readers time to
    prepare context.
    """

    def __init__(self) -> None:
        super().__init__(name="WriterSwarm")
        self.poll_interval = 3.0
