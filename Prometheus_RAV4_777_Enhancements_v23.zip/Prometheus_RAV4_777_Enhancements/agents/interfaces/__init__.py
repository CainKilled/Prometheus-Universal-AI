"""
Prometheus Interfaces Package
=============================

This package exposes interface modules for interacting with the Prometheus
Infinity runtime. These modules provide CLI and programmatic entry points
into various subsystems, including the Control Nexus and any future user
interfaces. To add your own interface, create a new module in this
directory and ensure it is imported in this package's ``__all__``.

Developer: Adam Henry Nagle
Phone: 6033848949
Emails: cainkilledabrl@icloud.com, nagleadam75@gmail.com
"""

__all__ = [
    "control_nexus_v3",
]