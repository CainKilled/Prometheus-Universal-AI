"""
Agents Package
==============

This package defines helper swarms and agent constructs that operate
within the Prometheus ecosystem. Agents encapsulate tasks of varying
complexity and priority and execute them via pluggable schedulers.

The goal of these classes is to provide a unified interface for
automated background jobs across the system. They are used by the
HyperHiveMind devswarm to offload work to helper processes and will
evolve over time as new roles and behaviours are introduced.

Developed and maintained by Adam Henry Nagle. Contact: 603-384-8949,
cainkilledabrl@icloud.com, nagleadam75@gmail.com.
"""
