"""
Tool Builder Plugin
===================

This plugin generates new plugin scaffolds programmatically. It enables the
Prometheus ecosystem to extend itself by creating new plugins on demand.
Provide the following keys in the runtime context when activating the
plugin:

* `plugin_name` – name of the new plugin (snake_case)
* `category` – primary category under `plugins/targets` (e.g. `tools`,
  `browser`, etc.)
* `description` – human‑readable description for the plugin (optional)

On activation the plugin will create a directory tree under
`plugins/targets/<category>/<plugin_name>` with a `plugin.py` scaffold based
on the builtin template. The new plugin will be ready for further
implementation.
"""

# Prometheus Codex Lock v1
# This file is part of Prometheus RAV4 777 Enhancements. Do not edit manually.

import os
from pathlib import Path
from typing import Dict, Any
from plugins.api.plugin_base import Plugin


TEMPLATE = """"""  # Not used, kept for compatibility



class ToolBuilderPlugin:
    def metadata(self) -> Dict[str, Any]:
        return {
            "name": "tool_builder",
            "version": "0.1.0",
            "description": "Generate new plugin scaffolds programmatically",
            "targets": ["tool", "builder"],
        }

    def _render_template(self, name: str, description: str, category: str) -> str:
        """
        Render a Python plugin scaffold for the given name and description.

        This method builds a full Python module as a string. The generated
        plugin contains a descriptive module‑level docstring, a codex lock
        header, imports, a plugin class with appropriate metadata, and an
        `activate` method stub. The class name is derived from the plugin
        name by converting snake_case to CamelCase and appending ``Plugin``.

        Parameters
        ----------
        name : str
            The snake_case name of the plugin (e.g. ``my_feature``).
        description : str
            Human‑readable description of what the plugin does. Quotes will
            automatically be escaped.
        category : str
            The primary category under ``plugins/targets`` where the plugin
            lives (e.g. ``terminal``, ``editor``).

        Returns
        -------
        str
            A complete Python source file ready to be written to ``plugin.py``.
        """
        # Convert plugin name to a CamelCase class name
        class_name = ''.join(part.capitalize() for part in name.split('_')) + 'Plugin'
        # Escape double quotes in the description
        safe_desc = description.replace('"', '\\"') if description else ""
        # Determine a human‑friendly title for the module docstring
        title = ' '.join(part.capitalize() for part in name.split('_')) + ' Plugin'
        # Compose the module docstring. Use triple quotes to avoid accidental escapes.
        docstring = (
            f"\"\"\"\n{title}\n{'=' * len(title)}\n\n"
            f"{safe_desc if safe_desc else 'No description provided.'}\n\n"
            f"This plugin was generated automatically by the ToolBuilderPlugin. "
            f"Edit the activate() method to provide real functionality.\n"
            "\"\"\""
        )
        # Compose the class definition. We include metadata and a stubbed activate().
        class_def = f"\n\nfrom typing import Dict, Any\nfrom plugins.api.plugin_base import Plugin\n\n\n" \
            f"class {class_name}:\n" \
            f"    def metadata(self) -> Dict[str, Any]:\n" \
            f"        return {{\n" \
            f"            \"name\": \"{name}\",\n" \
            f"            \"version\": \"0.1.0\",\n" \
            f"            \"description\": \"{safe_desc if safe_desc else 'No description provided.'}\",\n" \
            f"            \"targets\": [\"{category}\"]\n" \
            f"        }}\n\n" \
            f"    def activate(self, runtime: Dict[str, Any]) -> None:\n" \
            f"        \"\"\"\n" \
            f"        Entry point for the {name} plugin. The runtime dict may contain\n" \
            f"        keys specific to the plugin. Implement your plugin logic here.\n" \
            f"        \"\"\"\n" \
            f"        logger = runtime.get(\"log\", print)\n" \
            f"        logger(f'{class_name}: activated with runtime context {{runtime}}')\n"\
            
        # Compose the get_plugin() factory function
        factory = (
            "\n\n" +
            "def get_plugin() -> Plugin:\n" +
            f"    return {class_name}()  # type: ignore[return-value]\n"
        )
        # Concatenate all pieces into a single module
        return f"{docstring}{class_def}{factory}"

    def activate(self, runtime: Dict[str, Any]) -> None:
        logger = runtime.get("log", print)
        base_dir = Path(runtime.get("base_dir", "."))
        plugin_name = runtime.get("plugin_name")
        category = runtime.get("category")
        description = runtime.get("description", "No description provided")
        if not plugin_name or not category:
            logger("ToolBuilderPlugin: 'plugin_name' and 'category' must be provided in runtime")
            return
        # Determine target path
        target_dir = base_dir / "plugins" / "targets" / category / plugin_name
        target_dir.mkdir(parents=True, exist_ok=True)
        # Create plugin scaffold
        plugin_content = self._render_template(plugin_name, description, category)
        plugin_file = target_dir / "plugin.py"
        if plugin_file.exists():
            logger(f"Plugin file {plugin_file} already exists. Skipping generation.")
            return
        with plugin_file.open("w", encoding="utf-8") as f:
            f.write(plugin_content)
        logger(f"Generated new plugin scaffold at {plugin_file}")


def get_plugin() -> Plugin:
    return ToolBuilderPlugin()  # type: ignore[return-value]