"""
Anaconda Plugin
===============

This plugin scaffolds integration with Anaconda environments. It can
create or activate conda environments, install dependencies specified in
Prometheus manifests and launch notebooks or IDEs within the conda context.
Use the ``conda`` command‑line interface (``conda create``, ``conda env create``,
``conda run``) for implementation. Consider using Python’s ``subprocess``
module or the ``conda`` API (if available).

Developed and maintained by Adam Henry Nagle. Contact: 603‑384‑8949,
cainkilledabrl@icloud.com, nagleadam75@gmail.com.
"""

# Prometheus Codex Lock v1
# This file is part of Prometheus RAV4 777 Enhancements. Do not edit manually.

from typing import Dict, Any
from plugins.api.plugin_base import Plugin


class AnacondaPlugin:
    def metadata(self) -> Dict[str, Any]:
        """
        Return metadata about this plugin. The version has been bumped and
        the description updated to indicate that it provides a working
        integration with conda for managing environments and packages.
        """
        return {
            "name": "anaconda",
            "version": "1.0.0",
            "description": "Manage Anaconda/Conda environments and packages",
            "targets": ["notebook", "conda"],
        }

    def activate(self, runtime: Dict[str, Any]) -> None:
        """
        Execute conda commands to manage environments.

        Supported runtime keys:

            action (str): One of ``create``, ``install``, ``remove_env``, ``uninstall``, ``list_envs``.
                ``create`` creates a new environment; ``install`` installs packages
                into an environment; ``remove_env`` removes an entire environment;
                ``uninstall`` removes packages from an environment; ``list_envs``
                lists existing environments. Defaults to ``list_envs``.
            env_name (str): Name of the conda environment to operate on.
            packages (list[str]): List of packages to install or uninstall.
            environment_file (str): Path to an environment.yml file to create
                an environment from. Only used for ``create``.
            log (callable): Optional logger.

        The plugin calls the ``conda`` CLI via ``subprocess`` and logs
        output. If conda is not available, a message is logged.
        """
        import subprocess
        import shutil
        import os
        logger = runtime.get("log", print)
        action = str(runtime.get("action", "list_envs")).lower()
        env_name = runtime.get("env_name")
        packages = runtime.get("packages", [])
        env_file = runtime.get("environment_file")
        conda = shutil.which("conda")
        if not conda:
            logger("AnacondaPlugin: 'conda' executable not found. Please install Anaconda or Miniconda.")
            return
        def run_cmd(cmd: list[str], cwd: str | None = None) -> None:
            try:
                logger(f"AnacondaPlugin: Running {' '.join(cmd)}")
                result = subprocess.run(cmd, cwd=cwd, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True)
                logger(result.stdout.rstrip())
                if result.returncode != 0:
                    logger(f"AnacondaPlugin: Command exited with code {result.returncode}")
            except Exception as exc:
                logger(f"AnacondaPlugin: Error executing {' '.join(cmd)}: {exc}")
        # Determine action
        if action == "create":
            if not env_name:
                logger("AnacondaPlugin: 'env_name' must be provided for create action")
                return
            if env_file:
                # conda env create -n NAME -f environment.yml
                cmd = [conda, "env", "create", "-n", env_name, "-f", env_file]
            else:
                # conda create -y -n NAME packages...
                cmd = [conda, "create", "-y", "-n", env_name] + [str(p) for p in packages]
            run_cmd(cmd)
        elif action == "install":
            if not env_name or not packages:
                logger("AnacondaPlugin: 'env_name' and 'packages' are required for install action")
                return
            cmd = [conda, "install", "-y", "-n", env_name] + [str(p) for p in packages]
            run_cmd(cmd)
        elif action == "remove_env":
            if not env_name:
                logger("AnacondaPlugin: 'env_name' must be provided for remove_env action")
                return
            cmd = [conda, "env", "remove", "-y", "-n", env_name]
            run_cmd(cmd)
        elif action == "uninstall":
            if not env_name or not packages:
                logger("AnacondaPlugin: 'env_name' and 'packages' are required for uninstall action")
                return
            cmd = [conda, "remove", "-y", "-n", env_name] + [str(p) for p in packages]
            run_cmd(cmd)
        elif action == "list_envs":
            # conda env list
            cmd = [conda, "env", "list"]
            run_cmd(cmd)
        else:
            logger(f"AnacondaPlugin: Unknown action '{action}'. Supported actions: create, install, remove_env, uninstall, list_envs.")


def get_plugin() -> Plugin:
    return AnacondaPlugin()  # type: ignore[return-value]