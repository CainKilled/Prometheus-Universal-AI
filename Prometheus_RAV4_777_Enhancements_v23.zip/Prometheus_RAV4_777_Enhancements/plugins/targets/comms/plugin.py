"""
Comms Plugin
============

This plugin exposes a simple interface for internal and external
communications via the ``CommsEngine``.  It supports three primary
operations selected by the ``type`` runtime parameter:

* ``internal-send`` – enqueue a message on the internal queue (requires ``message``)
* ``internal-receive`` – dequeue and return a message if one is available
* ``http`` – send an HTTP POST request to a URL with a JSON payload

Additional runtime parameters:

``url``: Target URL for HTTP requests.
``payload``: JSON‑serialisable payload for HTTP requests.
``message``: Arbitrary data to enqueue for internal messaging.

The plugin returns results via the ``log`` function supplied in the
runtime.  For HTTP requests, the JSON response or error is logged.

Developed and maintained by Adam Henry Nagle.  Contact:
603‑384‑8949, cainkilledabrl@icloud.com, nagleadam75@gmail.com.
"""

# Prometheus Codex Lock v1
# This file is part of Prometheus RAV4 777 Enhancements. Do not edit manually.

from typing import Dict, Any
from plugins.api.plugin_base import Plugin

from engines.comms_engine import CommsEngine


class CommsPlugin:
    """Internal/external communications interface."""

    def metadata(self) -> Dict[str, Any]:
        return {
            "name": "comms",
            "version": "1.0.0",
            "description": "Send messages internally or externally using CommsEngine.",
            "targets": ["comms"],
        }

    def activate(self, runtime: Dict[str, Any]) -> None:
        logger = runtime.get("log", print)
        comms_type = runtime.get("type", "internal-send")
        engine = CommsEngine()
        if comms_type == "internal-send":
            message = runtime.get("message")
            engine.send_internal(message)
            logger(f"Message enqueued: {message}")
        elif comms_type == "internal-receive":
            msg = engine.receive_internal()
            logger(f"Received message: {msg}")
        elif comms_type == "http":
            url = runtime.get("url")
            payload = runtime.get("payload")
            result = engine.send_http(url, payload)
            logger(f"HTTP response: {result}")
        else:
            logger(f"Unknown comms type: {comms_type}")


def get_plugin() -> Plugin:
    return CommsPlugin()  # type: ignore[return-value]