"""
Docker Adapter
==============

This adapter wraps the system ``docker`` CLI to perform common
container operations. Supported actions include ``build``, ``run``,
``stop``, ``rm``, ``pull``, ``push`` and ``images``. Each task
specifies an ``action`` and additional parameters as needed:

* ``build`` requires a ``path`` to the context directory and an
  optional ``tag`` for the resulting image.
* ``run`` needs an ``image`` name and may include ``name`` for the
  container, ``detached`` (bool) and a list of ``ports`` (e.g.
  ``["80:80"]``).
* ``stop`` and ``rm`` expect a ``container`` ID or name.
* ``pull`` and ``push`` use the ``image`` field.
* ``images`` lists local images.

If the Docker CLI is unavailable or the command fails, an error is
returned. Otherwise the adapter returns the combined output and exit
code. Logging is used to trace operations.
"""

from __future__ import annotations

from typing import Dict, Any, Callable, List
import subprocess
import shutil


class DockerAdapter:
    """Adapter for executing docker commands via the CLI."""

    def _run_docker(self, args: List[str], logger: Callable[[str], None]) -> Dict[str, Any]:
        docker_cmd = shutil.which("docker")
        if not docker_cmd:
            logger("DockerAdapter: docker command not found")
            return {"error": "docker not installed"}
        cmd = [docker_cmd] + args
        try:
            result = subprocess.run(
                cmd,
                stdout=subprocess.PIPE,
                stderr=subprocess.STDOUT,
                text=True,
                check=False,
            )
            logger(f"DockerAdapter: ran {' '.join(cmd)} (exit={result.returncode})")
            return {"output": result.stdout, "exit_code": result.returncode}
        except Exception as exc:
            logger(f"DockerAdapter: exception running {' '.join(cmd)}: {exc}")
            return {"error": str(exc)}

    def run(self, task: Dict[str, Any], logger: Callable[[str], None]) -> Dict[str, Any]:
        action = task.get("action")
        if not action:
            logger("DockerAdapter: missing action")
            return {"error": "missing action"}

        if action == "build":
            path = task.get("path")
            tag = task.get("tag")
            if not path:
                logger("DockerAdapter: build missing path")
                return {"error": "build missing path"}
            args = ["build", path]
            if tag:
                args += ["-t", tag]
            return self._run_docker(args, logger)

        elif action == "run":
            image = task.get("image")
            if not image:
                logger("DockerAdapter: run missing image")
                return {"error": "run missing image"}
            args = ["run"]
            if task.get("detached"):
                args.append("-d")
            name = task.get("name")
            if name:
                args += ["--name", name]
            ports = task.get("ports")
            if ports:
                for mapping in ports:
                    args += ["-p", mapping]
            cmd_args = task.get("cmd_args") or []
            args.append(image)
            if isinstance(cmd_args, str):
                args += cmd_args.split()
            elif isinstance(cmd_args, list):
                args += cmd_args
            return self._run_docker(args, logger)

        elif action == "stop":
            container = task.get("container")
            if not container:
                logger("DockerAdapter: stop missing container")
                return {"error": "stop missing container"}
            return self._run_docker(["stop", container], logger)

        elif action == "rm":
            container = task.get("container")
            if not container:
                logger("DockerAdapter: rm missing container")
                return {"error": "rm missing container"}
            return self._run_docker(["rm", container], logger)

        elif action == "pull":
            image = task.get("image")
            if not image:
                logger("DockerAdapter: pull missing image")
                return {"error": "pull missing image"}
            return self._run_docker(["pull", image], logger)

        elif action == "push":
            image = task.get("image")
            if not image:
                logger("DockerAdapter: push missing image")
                return {"error": "push missing image"}
            return self._run_docker(["push", image], logger)

        elif action == "images":
            return self._run_docker(["images"], logger)

        else:
            logger(f"DockerAdapter: unknown action '{action}'")
            return {"error": f"unknown action {action}"}