"""
SOPs Package
============

This package provides facilities for parsing and running standard
operating procedures (SOPs) written in Markdown with optional
frontmatter metadata. A SOP comprises a sequence of notes or shell
commands prefaced by ``$``. When executed, shell commands are run
via ``subprocess`` and results are collected. Notes are returned as
informational messages. SOPs enable documentation and automation of
repetitive operational tasks.

Developed and maintained by Adam Henry Nagle. Contact: 603‑384‑8949,
cainkilledabrl@icloud.com, nagleadam75@gmail.com.
"""

from .loader import parse_sop, run_sop  # noqa: F401