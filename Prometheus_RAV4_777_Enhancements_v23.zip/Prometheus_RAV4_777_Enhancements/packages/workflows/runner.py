"""
Workflow Runner
===============

This module defines a utility for executing declarative workflows
described in JSON or YAML. Each workflow consists of a list of steps.
Steps may be of kind ``shell``, which runs a shell command, or kind
``plugin``, which calls a Prometheus plugin via the kernel API. The
runner returns a list of results containing exit codes and outputs.

Developed and maintained by Adam Henry Nagle. Contact: 603-384-8949,
cainkilledabrl@icloud.com, nagleadam75@gmail.com.
"""

import json
import subprocess
import shlex
from pathlib import Path
from typing import Dict, Any, List, Callable

try:
    import yaml  # type: ignore
except Exception:
    yaml = None  # type: ignore


def _load(path: Path) -> Dict[str, Any]:
    text = path.read_text(encoding="utf-8")
    if path.suffix.lower() in (".yml", ".yaml"):
        if yaml is None:
            raise RuntimeError("PyYAML is not installed for YAML workflows")
        return yaml.safe_load(text)
    return json.loads(text)


def run_workflow(base_dir: str, file: str, kernel: Any = None,
                 logger: Callable[[str], None] = print) -> Dict[str, Any]:
    """Execute a workflow specification.

    Args:
        base_dir: Root of the repository.
        file: Relative path to the workflow specification.
        kernel: Kernel object implementing run_plugin() for plugin steps.
        logger: Function used to log messages.
    Returns:
        A dictionary containing success flag and results list.
    """
    wf_path = Path(base_dir) / file
    spec = _load(wf_path)
    steps: List[Dict[str, Any]] = spec.get("steps", [])
    results: List[Dict[str, Any]] = []
    for idx, step in enumerate(steps, start=1):
        kind = step.get("kind", "shell")
        if kind == "shell":
            cmd = step.get("run")
            if cmd is None:
                results.append({"error": "missing command in shell step"})
                continue
            logger(f"[Workflow] step {idx}: shell {cmd}")
            use_shell = step.get("shell", True)
            try:
                proc = subprocess.run(cmd if use_shell else shlex.split(cmd),
                                      capture_output=True, text=True, shell=use_shell)
                results.append({"rc": proc.returncode, "out": proc.stdout, "err": proc.stderr})
            except Exception as exc:
                results.append({"error": str(exc)})
        elif kind == "plugin":
            if kernel is None:
                results.append({"error": "kernel is required for plugin steps"})
                continue
            plugin_name = step.get("plugin")
            params = step.get("params", {})
            logger(f"[Workflow] step {idx}: plugin {plugin_name}")
            try:
                res = kernel.run_plugin(plugin_name, params)
                results.append(res if isinstance(res, dict) else {"result": res})
            except Exception as exc:
                results.append({"error": str(exc)})
        else:
            results.append({"error": f"unknown step kind {kind}"})
    success = all((r.get("rc", 0) == 0) for r in results if "rc" in r)
    success = success and all("error" not in r for r in results)
    return {"ok": success, "results": results}
