"""
Prometheus Packages
===================

This top‑level package bundles utilities for merkle trees, datasets,
workflows, standard operating procedures (SOPs) and rules in the
Prometheus ecosystem. These modules provide reusable building blocks
for constructing higher‑level automation in the monorepo.

Developed and maintained by Adam Henry Nagle. Contact: 603-384-8949,
cainkilledabrl@icloud.com, nagleadam75@gmail.com.
"""

from . import merkle, datasets, workflows, sops, rules  # noqa: F401
