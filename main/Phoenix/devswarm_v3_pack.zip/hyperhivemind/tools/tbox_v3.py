import os, json, hashlib, glob
from pathlib import Path

REQUIRED = [
  "pyproject.toml", "README.md",
  "hyperhivemind/config.py",
  "hyperhivemind/cli.py",
  "hyperhivemind/validators.py",
  "hyperhivemind/fork_engine.py",
  "hyperhivemind/johari_loop.py",
  "hyperhivemind/godmode.py",
  "hyperhivemind/swarm/manager.py",
  "hyperhivemind/swarm/agents/spawner.py",
  "hyperhivemind/swarm/agents/validator.py",
  "hyperhivemind/swarm/agents/integrator.py",
  "hyperhivemind/swarm/agents/reporter.py",
  "hyperhivemind/swarm/agents/executor.py",
  "hyperhivemind/generators/usecase_gen.py"
]

def sha256(path:str)->str:
  h = hashlib.sha256()
  with open(path,"rb") as f:
    for chunk in iter(lambda: f.read(65536), b""):
      h.update(chunk)
  return h.hexdigest()

def run(base:str)->dict:
  base = Path(base)
  missing = [p for p in REQUIRED if not (base/p).exists()]
  usecases = sorted(glob.glob(str(base / "usecases" / "*.json")))
  status = "OK" if not missing and len(usecases) >= 1 else "ISSUES"
  # compute checksums of core files
  core = {}
  for p in REQUIRED:
    fp = base / p
    if fp.exists():
      core[p] = sha256(fp.as_posix())
  return {
    "status": status,
    "missing": missing,
    "core_checksums": core,
    "usecase_count": len(usecases)
  }