import random
from .models import ForkResult

class SchrodingerForkEngine:
    def __init__(self, forward:int=3, lateral:int=3, seed:int=1337):
        self.forward = max(1, forward)
        self.lateral = max(1, lateral)
        self.rng = random.Random(seed)

    def _score(self, base: float, idx: int, total: int) -> float:
        # 3+ refactor: tighter jitter for determinism, bounded 0..1
        jitter = self.rng.uniform(-0.05, 0.05)
        return max(0.0, min(1.0, base + (idx/total)*0.25 + jitter))

    def propose(self):
        forks = []
        for i in range(1, self.forward+1):
            forks.append(ForkResult(name=f"forward-{i}", score=self._score(0.55, i, self.forward)))
        for i in range(1, self.lateral+1):
            forks.append(ForkResult(name=f"lateral-{i}", score=self._score(0.45, i, self.lateral)))
        return forks

    def collapse(self, forks):
        return max(forks, key=lambda f: f.score)