import os, json
from datetime import datetime
from pathlib import Path
from typing import Dict, Any

def vaulttime_now() -> str:
    return datetime.utcnow().isoformat(timespec="milliseconds") + "Z"

def vaulttime_validate(ts: str) -> bool:
    try:
        datetime.fromisoformat(ts.replace("Z", "+00:00"))
        return True
    except Exception:
        return False

class CodexLock:
    def __init__(self, path: str):
        self.path = path
        self.held = False
    def acquire(self) -> bool:
        if os.path.exists(self.path):
            return False
        Path(self.path).write_text(json.dumps({"ts": vaulttime_now()}))
        self.held = True
        return True
    def release(self):
        if self.held and os.path.exists(self.path):
            os.remove(self.path)
        self.held = False
    def __enter__(self):
        if not self.acquire():
            raise RuntimeError("codex lock busy")
        return self
    def __exit__(self, a,b,c):
        self.release()

def hal_validate_manifest(m: Dict[str, Any]) -> Dict[str, Any]:
    req = ["task_id","owner","scope","category","description"]
    missing = [k for k in req if not str(m.get(k,"")).strip()]
    errors = []
    if missing: errors.append("missing:" + ",".join(missing))
    p = m.get("priority",5)
    if not isinstance(p,int) or p<1 or p>10:
        errors.append("priority out of range 1..10")
    return {"ok": not errors, "errors": errors}

def tbox_verify_artifacts(dirpath: str) -> Dict[str, Any]:
    must = ["result.json","metrics.json"]
    found, missing, empty = [], [], []
    for f in must:
        p = Path(dirpath) / f
        if not p.exists():
            missing.append(f)
        else:
            if p.stat().st_size < 2: empty.append(f)
            else: found.append(f)
    return {"ok": (not missing and not empty), "found": found, "missing": missing, "empty": empty}