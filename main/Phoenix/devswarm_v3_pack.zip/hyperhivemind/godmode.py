import functools, json, time, os
from .config import load_config

def godmode(fn):
    cfg = load_config()
    log_path = os.path.join(cfg.logs_dir, "godmode.log")
    @functools.wraps(fn)
    def w(*a, **k):
        t0 = time.time()
        with open(log_path,"a",encoding="utf-8") as f:
            f.write(json.dumps({"enter": fn.__name__, "t": t0})+"\n")
        try:
            r = fn(*a, **k)
            t1 = time.time()
            with open(log_path,"a",encoding="utf-8") as f:
                f.write(json.dumps({"exit": fn.__name__, "ms": int((t1-t0)*1000)})+"\n")
            return r
        except Exception as e:
            t1 = time.time()
            with open(log_path,"a",encoding="utf-8") as f:
                f.write(json.dumps({"error": fn.__name__, "e": str(e), "ms": int((t1-t0)*1000)})+"\n")
            raise
    return w