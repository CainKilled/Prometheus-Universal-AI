from http.server import BaseHTTPRequestHandler, HTTPServer
import json, os
from .config import load_config

def run_server(host, port):
    cfg = load_config()
    class H(BaseHTTPRequestHandler):
        def _h(self, code=200, ctype="application/json"):
            self.send_response(code); self.send_header("Content-Type", ctype); self.end_headers()
        def log_message(self, *a, **k): return
        def do_GET(self):
            if self.path == "/healthz":
                self._h(200, "text/plain; charset=utf-8"); self.wfile.write(b"ok"); return
            if self.path == "/status":
                try:
                    payload = json.loads(open(cfg.state_path,"r",encoding="utf-8").read())
                except Exception:
                    payload = {"status":"IDLE"}
                self._h(200, "application/json; charset=utf-8")
                self.wfile.write(json.dumps(payload, indent=2).encode())
                return
            self._h(404, "application/json; charset=utf-8"); self.wfile.write(b'{"error":"not found"}')
    httpd = HTTPServer((host, port), H)
    print(f"[DevSwarm v3] http://{host}:{port} • /healthz • /status")
    try: httpd.serve_forever()
    except KeyboardInterrupt: pass
    finally: httpd.server_close()