class JohariLoop:
    def __init__(self, passes:int=3):
        self.passes = max(1, passes)
        self.history = []

    def run(self, detect, fix):
        for i in range(1, self.passes+1):
            issues = detect()
            self.history.append({"pass": i, "issues": issues})
            if issues.get("ok"):
                return {"ok": True, "passes": i, "history": self.history}
            self.history[-1]["fix"] = fix(issues)
        return {"ok": False, "passes": self.passes, "history": self.history}