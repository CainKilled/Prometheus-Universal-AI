import json
from pathlib import Path
from ..config import load_config
from ..models import TaskManifest
from ..validators import CodexLock, hal_validate_manifest, tbox_verify_artifacts, vaulttime_now
from ..fork_engine import SchrodingerForkEngine
from ..johari_loop import JohariLoop
from ..godmode import godmode
from .agents.spawner import SpawnerAgent
from .agents.validator import ValidatorAgent
from .agents.integrator import IntegratorAgent
from .agents.reporter import ReporterAgent
from .agents.executor import SubtaskExecutor

class SwarmManager:
    def __init__(self, manifest: TaskManifest):
        self.cfg = load_config()
        self.manifest = manifest
        self.state_path = Path(self.cfg.state_path)

    def _state(self, status: str, extra=None):
        payload = {"ts": vaulttime_now(), "status": status, "manifest": self.manifest.__dict__}
        if extra: payload.update(extra)
        self.state_path.write_text(json.dumps(payload, indent=2))

    @godmode
    def execute(self):
        with CodexLock(self.cfg.codex_lock_path):
            hal = hal_validate_manifest(self.manifest.__dict__)
            if not hal["ok"]:
                self._state("HAL_FAILED", {"hal": hal})
                return {"ok": False, "error": "HAL failed", "hal": hal}
            self._state("INIT")

            forks = SchrodingerForkEngine(self.cfg.forks_forward, self.cfg.forks_lateral).propose()
            best = sorted(forks, key=lambda f: f.score, reverse=True)[:2]

            out_dir = Path(self.cfg.build_dir) / self.manifest.task_id
            out_dir.mkdir(parents=True, exist_ok=True)
            exe = SubtaskExecutor()

            def detect():
                return tbox_verify_artifacts(str(out_dir))

            def fix(issues):
                # integrate default structure then re-run executor on best forks
                IntegratorAgent().integrate(str(out_dir), self.manifest.__dict__)
                for f in best: exe.run(self.manifest, f, out_dir)
                return {"attempted": [f.name for f in best]}

            result = JohariLoop(self.cfg.johari_passes).run(detect, fix)
            final = tbox_verify_artifacts(str(out_dir))
            status = "DONE" if final["ok"] else "FAILED"
            self._state(status, {"final": final, "johari": result, "best": [b.name for b in best]})
            ReporterAgent().send(self.manifest.__dict__, status, {"final": final})
            return {"ok": final["ok"], "status": status, "final": final}