import time, uuid
from ...models import AgentReport
from ...godmode import godmode

class ReporterAgent:
    def __init__(self):
        self.id = str(uuid.uuid4())
        self.role = "Reporter"
    @godmode
    def send(self, manifest: dict, status: str, details: dict) -> AgentReport:
        time.sleep(0.003)
        return AgentReport(agent_id=self.id, role=self.role, status=status, details=details)