import uuid, time
from ...models import AgentReport
from ...godmode import godmode

class SpawnerAgent:
    def __init__(self):
        self.id = str(uuid.uuid4())
        self.role = "Spawner"
    @godmode
    def spawn(self, role: str) -> AgentReport:
        time.sleep(0.005)
        return AgentReport(agent_id=self.id, role=self.role, status=f"spawned:{role}")