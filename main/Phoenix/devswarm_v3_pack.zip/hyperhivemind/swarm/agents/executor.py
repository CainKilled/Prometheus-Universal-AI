import uuid, time, json, hashlib
from pathlib import Path
from ...models import AgentReport
from ...godmode import godmode
from ...validators import vaulttime_now

class SubtaskExecutor:
    def __init__(self):
        self.id = str(uuid.uuid4())
        self.role = "SubtaskExecutor"
    @godmode
    def run(self, manifest, fork, out_dir):
        h = hashlib.sha256(fork.name.encode()).hexdigest()[:12]
        payload = {"task_id": manifest.task_id, "fork": fork.name, "hash": h, "ts": vaulttime_now()}
        out = Path(out_dir)
        (out/"result.json").write_text(json.dumps(payload, indent=2))
        (out/"metrics.json").write_text(json.dumps({"score": fork.score}, indent=2))
        time.sleep(0.003)
        return AgentReport(agent_id=self.id, role=self.role, status="DONE", details=payload)