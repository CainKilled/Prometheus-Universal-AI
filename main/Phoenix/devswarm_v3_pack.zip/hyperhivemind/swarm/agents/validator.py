import time, uuid
from ...models import AgentReport
from ...validators import hal_validate_manifest, tbox_verify_artifacts
from ...godmode import godmode

class ValidatorAgent:
    def __init__(self):
        self.id = str(uuid.uuid4())
        self.role = "Validator"
    @godmode
    def validate(self, manifest: dict, dirpath: str) -> AgentReport:
        time.sleep(0.005)
        hal = hal_validate_manifest(manifest)
        tbox = tbox_verify_artifacts(dirpath)
        status = "OK" if hal["ok"] and tbox["ok"] else "ISSUES"
        return AgentReport(agent_id=self.id, role=self.role, status=status, details={"hal": hal, "tbox": tbox})