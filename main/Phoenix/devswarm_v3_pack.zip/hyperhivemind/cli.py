import argparse, json, os, glob
from pathlib import Path
from .models import TaskManifest
from .swarm.manager import SwarmManager
from .server import run_server
from .tools import tbox_v3

def _load_task(path:str)->TaskManifest:
    return TaskManifest(**json.loads(Path(path).read_text()))

def main():
    p = argparse.ArgumentParser(description="HyperHiveMind DevSwarm CLI (v3)")
    s = p.add_subparsers(dest="cmd", required=True)

    r = s.add_parser("run")
    r.add_argument("--task")
    r.add_argument("--queue")

    sv = s.add_parser("serve")
    sv.add_argument("--host", default="127.0.0.1")
    sv.add_argument("--port", type=int, default=8787)

    tb = s.add_parser("tbox")
    tb.add_argument("--base", default=".")

    a = p.parse_args()

    if a.cmd == "run":
        tasks = []
        if a.task: tasks.append(a.task)
        if a.queue: tasks.extend(sorted(glob.glob(os.path.join(a.queue, "*.json"))))
        if not tasks:
            print("No tasks found.")
            return 1
        exitc = 0
        for t in tasks:
            res = SwarmManager(_load_task(t)).execute()
            if not res.get("ok"): exitc = 2
        return exitc

    if a.cmd == "serve":
        run_server(a.host, a.port)
        return 0

    if a.cmd == "tbox":
        report = tbox_v3.run(a.base)
        print(json.dumps(report, indent=2))
        # also write to logs
        Path(a.base, "logs").mkdir(parents=True, exist_ok=True)
        Path(a.base, "logs", "TBOX_V3_REPORT.json").write_text(json.dumps(report, indent=2))
        return 0