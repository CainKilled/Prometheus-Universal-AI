from dataclasses import dataclass
from pathlib import Path

@dataclass
class DevSwarmConfig:
    state_path: str = "state/state.json"
    logs_dir: str = "logs"
    build_dir: str = "build"
    queue_dir: str = "usecases"
    codex_lock_path: str = ".codex.lock"
    forks_forward: int = 3
    forks_lateral: int = 3
    johari_passes: int = 3

def ensure_dirs(cfg: DevSwarmConfig):
    Path(cfg.logs_dir).mkdir(parents=True, exist_ok=True)
    Path(cfg.build_dir).mkdir(parents=True, exist_ok=True)
    Path(cfg.queue_dir).mkdir(parents=True, exist_ok=True)
    Path(Path(cfg.state_path).parent).mkdir(parents=True, exist_ok=True)

def load_config() -> DevSwarmConfig:
    cfg = DevSwarmConfig()
    ensure_dirs(cfg)
    return cfg