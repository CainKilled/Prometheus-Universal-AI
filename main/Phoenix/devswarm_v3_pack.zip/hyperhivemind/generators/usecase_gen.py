import argparse, json
from pathlib import Path

CATEGORIES = ["DEV","SEC","OPS","UX","EDGE"]

def gen_case(i:int)->dict:
    cat = CATEGORIES[i % len(CATEGORIES)]
    rid = f"usecase_{i:04d}"
    return {
        "task_id": rid,
        "owner": "Adam Henry Nagle",
        "scope": "Prometheus Infinity",
        "category": cat,
        "description": f"Auto-generated {cat} scenario {i}",
        "priority": (i % 10) + 1,
        "constraints": {"deterministic": True, "max_runtime_ms": 250}
    }

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--count", type=int, default=1000)
    ap.add_argument("--out", default="usecases")
    a = ap.parse_args()
    Path(a.out).mkdir(parents=True, exist_ok=True)
    for i in range(1, a.count+1):
        (Path(a.out)/f"usecase_{i:04d}.json").write_text(json.dumps(gen_case(i), indent=2))
    print(f"Generated {a.count} use cases in {a.out}")

if __name__ == "__main__":
    main()