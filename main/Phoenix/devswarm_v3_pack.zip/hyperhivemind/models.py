from dataclasses import dataclass, field
from typing import List, Dict, Any

@dataclass
class TaskManifest:
    task_id: str
    owner: str
    scope: str
    category: str
    description: str
    priority: int = 5
    constraints: Dict[str, Any] = field(default_factory=dict)

@dataclass
class AgentReport:
    agent_id: str
    role: str
    status: str
    details: Dict[str, Any] = field(default_factory=dict)

@dataclass
class ForkResult:
    name: str
    score: float
    artifacts: List[str] = field(default_factory=list)
    notes: str = ""