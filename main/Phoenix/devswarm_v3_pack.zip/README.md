# HyperHiveMind DevSwarm — v3
Tier-1++ swarm engine with:
- TBOX v3 self-checks (artifacts, structure, determinism)
- 3+ refactor (CLI UX, deterministic forks, stronger validation)
- 5Q gate (purpose, scope, risk, resources, go/no-go)

## Quickstart
```bash
pip install -e .
python -m hyperhivemind.generators.usecase_gen --count 1000 --out usecases
devswarm run --queue usecases
devswarm serve --host 127.0.0.1 --port 8787
devswarm tbox --base .
```