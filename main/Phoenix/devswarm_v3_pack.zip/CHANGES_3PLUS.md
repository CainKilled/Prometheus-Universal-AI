# 3+ Refactor (v3)
1) Deterministic fork engine (tighter jitter, bounded scoring) for reproducible collapses.
2) Stronger validations (HAL priority bounds; CodexLock; TBOX artifacts enforced in Johari fix).
3) UX improvements: `devswarm tbox --base .` subcommand; clearer server output and logs.