# VaultTime Certificate
**Bundle:** onboarding_bundle_v1  
**Owner:** Adam Henry Nagle <cainkilledabel@icloud.com>  
**License:** VaultTime-Private-v1  
**Created:** 2025-08-21T18:27:32Z

## Codex Aggregate
```
e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855
```

## Signature
Algorithm: RSA-4096-SHA256
Fingerprint: 8850c5add4093cfac6349ad073323cb65372df0c4274006af585859dbbdc41c5

Signature (base64):
```
XdqQJ5XxiKCzQNQiu11SfROb/WILH05eoVGEjNn1RUCSKsG9cpXuHnD3Ni8FvNehLWgQnD4F7UxmUQIJjtqI6zsfzjq8ETyn52gX5KAjcIewOQSh8Bx4DkvqosPT9ierEE2Yd2kTPHKI/gu3r3sViPqCe+0iWOzHvwqQamm7Cno5FfGucZbj11gECqiuFmJkUkXedzkJ3ytOyjo9YhZQcyYqPrYEi3hohDkrhQjVikCAfF2tiemHVm98Lp2pHaQcAiIV1vHtPKE95V8tTUef5FjpI0XGPPvtJwCK84t6Pk4uVgFW+yZU3uFgXyLf8tgeMZyl/uai2ELiHJv3V+LaWy7ZJNGQDIfhPlVGymn0u/2Kv69/VBTy4Mo6KVE6GAZgGIBoUoSv1oxCPOffj+1URCeTyRYFQBpZx641zSz4qMWqDPESj3L8eH974wk27Defenyju7pkBpgGwj5jiG9qfk22BNplgEoPLQ3fA3tgYxd3WqWr8oHqhRaRr535DhxdrnMBFIoVX7SwVsIzjiQGbDwHzsfi7xhepHCgvM7qmTOA3b+goMGCW3NSQ8hXeTNoiiJVE63jhXSA4VfwxFNT3UBa2/Owv2HPHsBljVLH7YBveOkdvQWJZFn8Bp1rGO5x0+zuXHJWpa07xvT0p2M/Wx+raiOcqIS9c+KDAU5haXo=
```

## Verify (OpenSSL)
```bash
python3 onboarding_bundle_v1/scripts/hal_hardener.py
openssl dgst -sha256 -verify vaulttime/public_key.pem -signature <(base64 -d vaulttime/signature.b64) vaulttime/signing_blob.json
```
