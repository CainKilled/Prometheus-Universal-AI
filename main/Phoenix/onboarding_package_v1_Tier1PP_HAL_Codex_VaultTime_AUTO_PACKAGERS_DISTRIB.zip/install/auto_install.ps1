Param()
$ErrorActionPreference = 'Stop'
function Log($m){ Write-Host "[auto-install] $m" }

# Paths
$ROOT = Split-Path -Parent (Split-Path -Parent $MyInvocation.MyCommand.Path)

# Ensure Python
if (-not (Get-Command python -ErrorAction SilentlyContinue)) {
  if (Get-Command winget -ErrorAction SilentlyContinue) {
    Log "Installing Python via winget..."
    winget install -e --id Python.Python.3 || Write-Warning "Winget install may require interaction."
  } else {
    Write-Warning "Python not found and winget unavailable. Please install Python 3."
  }
}

$PY = (Get-Command python -ErrorAction SilentlyContinue) ? "python" : "py"

# Venv
& $PY -m venv "$ROOT\.venv"
& "$ROOT\.venv\Scripts\Activate.ps1"

# Requirements
if (Test-Path "$ROOT\requirements.txt") {
  & pip install --upgrade pip
  & pip install -r "$ROOT\requirements.txt"
}

# HAL Hardener / TBOX guard
if (Test-Path "$ROOT\onboarding_bundle_v1\scripts\hal_hardener.py") {
  & $PY "$ROOT\onboarding_bundle_v1\scripts\hal_hardener.py"
}
if (Test-Path "$ROOT\onboarding_bundle_v1\scripts\tbox_v3_guard.py") {
  & $PY "$ROOT\onboarding_bundle_v1\scripts\tbox_v3_guard.py"
}

# Forge hardened zip
$forge = "$ROOT\onboarding_bundle_v1\scripts\forge_zip.sh"
if (Test-Path $forge) {
  bash $forge "$ROOT\forge_out.zip"
  Log "Forge complete: $ROOT\forge_out.zip"
}

Log "Auto-install complete."
