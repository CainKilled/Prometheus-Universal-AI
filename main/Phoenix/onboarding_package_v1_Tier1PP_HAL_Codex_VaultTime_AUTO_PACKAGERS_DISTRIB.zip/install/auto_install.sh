#!/usr/bin/env bash
set -euo pipefail

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
log(){ echo "[auto-install] $*"; }

detect_os() {
  unameOut="$(uname -s || true)"
  case "${unameOut}" in
      Linux*)     OS=Linux;;
      Darwin*)    OS=Mac;;
      CYGWIN*|MINGW*|MSYS*) OS=Windows;;
      *)          OS=Unknown;;
  esac
  echo "$OS"
}

ensure_tool() {
  local t="$1" ; if command -v "$t" >/dev/null 2>&1; then return 0; fi
  local OS="$(detect_os)"
  if [[ "$OS" == "Mac" ]]; then
    if ! command -v brew >/dev/null 2>&1; then
      log "Homebrew not found. Installing..."; /bin/bash -c "$(curl -fsSL https://raw.githubusercontent.com/Homebrew/install/HEAD/install.sh)"
    fi
    brew install "$t" || true
  elif [[ "$OS" == "Linux" ]]; then
    if command -v apt >/dev/null 2>&1; then sudo apt update && sudo apt install -y "$t" || true
    elif command -v dnf >/dev/null 2>&1; then sudo dnf install -y "$t" || true
    elif command -v yum >/dev/null 2>&1; then sudo yum install -y "$t" || true
    fi
  else
    log "Skipping ensure_tool for $t on $OS"
  fi
}

main() {
  OS="$(detect_os)"
  log "Detected OS: $OS"

  # Core prerequisites
  ensure_tool python3
  ensure_tool git

  # Python venv
  if command -v python3 >/dev/null 2>&1; then PY=python3; else PY=python; fi
  "$PY" -m venv "$ROOT/.venv"
  source "$ROOT/.venv/bin/activate" || true
  if [[ -f "$ROOT/requirements.txt" ]]; then pip install --upgrade pip && pip install -r "$ROOT/requirements.txt"; fi

  # HAL hardener + TBOX guard (if present)
  if [[ -f "$ROOT/onboarding_bundle_v1/scripts/hal_hardener.py" ]]; then
    "$PY" "$ROOT/onboarding_bundle_v1/scripts/hal_hardener.py"
  fi
  if [[ -f "$ROOT/onboarding_bundle_v1/scripts/tbox_v3_guard.py" ]]; then
    "$PY" "$ROOT/onboarding_bundle_v1/scripts/tbox_v3_guard.py"
  fi

  # Forge hardened zip (if forge script exists)
  if [[ -f "$ROOT/onboarding_bundle_v1/scripts/forge_zip.sh" ]]; then
    "$ROOT/onboarding_bundle_v1/scripts/forge_zip.sh" "$ROOT/forge_out.zip"
    log "Forge complete: $ROOT/forge_out.zip"
  fi

  log "Auto-install complete."
}

main "$@"
