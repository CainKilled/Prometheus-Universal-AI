#!/usr/bin/env bash
set -euo pipefail
python3 onboarding_bundle_v1/scripts/tbox_v3_guard.py
