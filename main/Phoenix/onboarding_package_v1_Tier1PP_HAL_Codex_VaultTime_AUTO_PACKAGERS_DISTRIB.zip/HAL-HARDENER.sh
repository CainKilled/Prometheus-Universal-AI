#!/usr/bin/env bash
set -euo pipefail
python3 onboarding_bundle_v1/scripts/hal_hardener.py
