#!/usr/bin/env bash
set -euo pipefail
# Produce SHA256 sums for common artifacts into top-level files
shopt -s globstar nullglob
for ext in exe pkg dmg run deb rpm zip; do
  for f in **/*.$ext; do
    sha256sum "$f" >> "SHA256SUMS.$ext.txt"
  done
done
