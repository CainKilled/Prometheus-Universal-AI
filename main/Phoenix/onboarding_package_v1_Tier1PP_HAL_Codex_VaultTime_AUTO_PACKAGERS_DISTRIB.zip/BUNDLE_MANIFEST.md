# BUNDLE_MANIFEST (itemized)
Generated: 2025-08-21T19:21:26Z

| Path | Size (bytes) |
|---|---|
| `.github/workflows/release-distribute.yml` | 4642 |
| `.github/workflows/windows-ci-test.yml` | 1017 |
| `.github/workflows/winget-submit.yml` | 854 |
| `BUNDLE_MANIFEST.md` | 1045 |
| `HAL-HARDENER.sh` | 91 |
| `PROMETHEUS_STARTER.ps1` | 133 |
| `PROMETHEUS_STARTER.sh` | 142 |
| `TBOX-GUARD.sh` | 92 |
| `codex/AGGREGATE_SHA256.txt` | 65 |
| `codex/manifest.json` | 399 |
| `install/auto_install.ps1` | 1359 |
| `install/auto_install.sh` | 2105 |
| `packagers/homebrew/prometheus-phoenix.rb` | 629 |
| `packagers/homebrew/update_formula.sh` | 498 |
| `packagers/linux/build_deb.sh` | 543 |
| `packagers/linux/build_makeself.sh` | 509 |
| `packagers/linux/build_rpm.sh` | 543 |
| `packagers/macos/build_dmg.sh` | 430 |
| `packagers/macos/build_pkg.sh` | 681 |
| `packagers/windows/inno/build_inno.bat` | 210 |
| `packagers/windows/inno/prometheus.iss` | 1236 |
| `packagers/windows/nsis/build_nsis.bat` | 141 |
| `packagers/windows/nsis/prometheus.nsi` | 732 |
| `packagers/windows/sfx/build_sfx.bat` | 362 |
| `packagers/windows/sfx/config.txt` | 303 |
| `packagers/winget/manifests/AdamHenryNagle/PrometheusPhoenix/1.0.0/PrometheusPhoenix.installer.yaml` | 588 |
| `packagers/winget/manifests/AdamHenryNagle/PrometheusPhoenix/1.0.0/PrometheusPhoenix.locale.en-US.yaml` | 488 |
| `packagers/winget/manifests/AdamHenryNagle/PrometheusPhoenix/1.0.0/PrometheusPhoenix.yaml` | 229 |
| `scripts/release_checksums.sh` | 253 |
| `start.bat` | 127 |
| `vaulttime/VaultTime_CERTIFICATE.md` | 1329 |
| `vaulttime/manifest.json` | 1302 |
| `vaulttime/public_key.pem` | 800 |
| `vaulttime/signature.b64` | 684 |
| `vaulttime/signing_blob.json` | 417 |
| `vaulttime/verify_signature.sh` | 447 |
