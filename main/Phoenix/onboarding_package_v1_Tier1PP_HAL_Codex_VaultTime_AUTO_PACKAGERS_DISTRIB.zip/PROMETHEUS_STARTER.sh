#!/usr/bin/env bash
# Prometheus Starter (Unix/macOS)
DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
exec "$DIR/install/auto_install.sh"
