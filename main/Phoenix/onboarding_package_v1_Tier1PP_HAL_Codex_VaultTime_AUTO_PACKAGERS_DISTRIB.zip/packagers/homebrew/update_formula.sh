#!/usr/bin/env bash
# Update formula SHA256 from a release file URL
set -euo pipefail
FORMULA=${1:-packagers/homebrew/prometheus-phoenix.rb}
ASSET_URL=${2:-}
if [[ -z "$ASSET_URL" ]]; then
  echo "Usage: $0 <formula.rb> <asset_url>"
  exit 1
fi
TMP=$(mktemp)
curl -L "$ASSET_URL" -o "$TMP"
SUM=$(shasum -a 256 "$TMP" | awk '{print $1}')
sed -i'' -e "s|^  url ".*"|  url "$ASSET_URL"|g" "$FORMULA"
sed -i'' -e "s|^  sha256 ".*"|  sha256 "$SUM"|g" "$FORMULA"
echo "Updated $FORMULA with sha256=$SUM"
