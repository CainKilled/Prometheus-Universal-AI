#!/usr/bin/env bash
set -euo pipefail
# Build macOS .pkg using pkgbuild + productbuild
# Refs: pkgbuild(1), productbuild(1)

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/../.." && pwd)"
PAYLOAD="$PWD/payload_root"
PKGID="com.prometheus.phoenixmastercodex"
VERSION="1.0.0"
COMP_PKG="phoenixmastercodex.component.pkg"
PRODUCT_PKG="PhoenixMasterCodex.pkg"

rm -rf "$PAYLOAD"
mkdir -p "$PAYLOAD/Applications/PhoenixMasterCodex"
rsync -a "$ROOT/" "$PAYLOAD/Applications/PhoenixMasterCodex/" --exclude 'packagers' || true

pkgbuild --root "$PAYLOAD" --identifier "$PKGID" --version "$VERSION" "$COMP_PKG"
productbuild --package "$COMP_PKG" "$PRODUCT_PKG"
echo "[macOS] Built $PRODUCT_PKG"
