#!/usr/bin/env bash
set -euo pipefail
# Build a simple DMG via hdiutil
NAME="PhoenixMasterCodex"
DMG="${NAME}.dmg"
SRCROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/../.." && pwd)"
STAGE="$(pwd)/dmg_stage"
rm -rf "$STAGE" "$DMG"
mkdir -p "$STAGE/${NAME}"
rsync -a "$SRCROOT/" "$STAGE/${NAME}/" --exclude 'packagers' || true
hdiutil create -volname "$NAME" -srcfolder "$STAGE/${NAME}" -ov -format UDZO "$DMG"
echo "[macOS] Built $DMG"
