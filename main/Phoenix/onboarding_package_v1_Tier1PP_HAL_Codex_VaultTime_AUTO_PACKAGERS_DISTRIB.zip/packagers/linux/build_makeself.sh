#!/usr/bin/env bash
set -euo pipefail
# Build a self-extracting .run using makeself
# Requires: makeself.sh (https://github.com/megastep/makeself)
ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/../.." && pwd)"
STAGE="$(pwd)/payload"
OUT="PhoenixMasterCodex.run"
rm -rf "$STAGE" "$OUT"
mkdir -p "$STAGE"
rsync -a "$ROOT_DIR/" "$STAGE/" --exclude 'packagers' || true
# Run starter after extraction
makeself.sh "$STAGE" "$OUT" "Phoenix Master Codex Installer" "./PROMETHEUS_STARTER.sh"
echo "[Linux] Built $OUT"
