#!/usr/bin/env bash
set -euo pipefail
which fpm >/dev/null 2>&1 || { echo "fpm not installed"; exit 0; }
APP="prometheus-phoenix"
VERSION=${VERSION:-1.0.0}
BUILDROOT="$(pwd)/.pkgroot"
OUTDIR="$(pwd)/output"
rm -rf "$BUILDROOT"
mkdir -p "$BUILDROOT/opt/$APP"
rsync -a --exclude 'output/' --exclude '.git/' --exclude '.github/' ./ "$BUILDROOT/opt/$APP/"
mkdir -p "$OUTDIR"
fpm -s dir -t deb -n "$APP" -v "$VERSION" --license "Proprietary" --description "Phoenix Master Codex vInfinity" --prefix / -C "$BUILDROOT" .
mv ./*.deb "$OUTDIR/" || true
