# Prometheus Starter (Windows PowerShell)
$here = Split-Path -Parent $MyInvocation.MyCommand.Path
& "$here\install\auto_install.ps1"
