# Prometheus Network — Platinum Edition

**Owner:** Adam Henry Nagle · **Contact:** cainkilledabel@icloud.com · **Phone:** (603) 384-8949

This is the authoritative platinum bundle. Use `./hal_forge` to orchestrate and `./forge_zip.sh` to package.
