
import argparse, json, pathlib, time
ap=argparse.ArgumentParser(); ap.add_argument('--root',required=True); ap.add_argument('--out',required=True)
a=ap.parse_args(); root=pathlib.Path(a.root).resolve()
comps=[{'bom-ref':p.relative_to(root).as_posix(),'type':'file','name':p.name,'version':'1.0.0'}
       for p in sorted(root.rglob('*')) if p.is_file() and '.backups' not in p.parts]
sbom={'bomFormat':'CycloneDX','specVersion':'1.5','version':1,'metadata':{'timestamp':time.strftime('%Y-%m-%dT%H:%M:%SZ')},'components':comps}
pathlib.Path(a.out).write_text(json.dumps(sbom,indent=2)); print('OK:',a.out)
