export default function Dashboard(){ return <div>Control Nexus</div> }
