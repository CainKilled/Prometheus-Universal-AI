#!/usr/bin/env bash
set -euo pipefail

ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
OUT_DIR="$ROOT_DIR/.backups"
NAME="prometheus_network_platinum_20250818-224227"
ZIP="$OUT_DIR/$NAME.zip"
SIG="$OUT_DIR/$NAME.zip.sig"
mkdir -p "$OUT_DIR"
python3 "$ROOT_DIR/scripts/integrity.py" --root "$ROOT_DIR" --out "$ROOT_DIR/MANIFEST.integrity.json"
python3 "$ROOT_DIR/scripts/sbom_generate.py" --root "$ROOT_DIR" --out "$ROOT_DIR/SBOM.cycdx.json"
cd "$ROOT_DIR/.."
zip -qr "$ZIP" "$(basename "$ROOT_DIR")"
python3 - <<'PY'
import hashlib, pathlib
p=pathlib.Path("/mnt/data/PROMETHEUS_NETWORK_PLATINUM/.backups/prometheus_network_platinum_20250818-224227.zip");h=hashlib.sha256();h.update(p.read_bytes());pathlib.Path("/mnt/data/PROMETHEUS_NETWORK_PLATINUM/.backups/prometheus_network_platinum_20250818-224227.zip.sig").write_text(h.hexdigest()+"  "+p.name+"\n");print(h.hexdigest())
PY
