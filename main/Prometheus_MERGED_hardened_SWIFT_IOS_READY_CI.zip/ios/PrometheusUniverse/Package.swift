// swift-tools-version: 5.9
import PackageDescription

let package = Package(
    name: "PrometheusUniverseModules",
    platforms: [
        .iOS(.v16)
    ],
    products: [
        .library(name: "AutoUnpackKit", targets: ["AutoUnpackKit"]),
        .library(name: "AutoIgniter", targets: ["AutoIgniter"]),
        .library(name: "PrometheusSwiftEngine", targets: ["PrometheusSwiftEngine"]),
        .library(name: "PrometheusCompilerEngine", targets: ["PrometheusCompilerEngine"])
    ],
    dependencies: [
        .package(url: "https://github.com/weichsel/ZIPFoundation", from: "0.9.0")
    ],
    targets: [
        .target(name: "AutoUnpackKit", dependencies: [.product(name: "ZIPFoundation", package: "ZIPFoundation")], path: "Sources/AutoUnpackKit"),
        .target(name: "AutoIgniter", dependencies: ["AutoUnpackKit"], path: "Sources/AutoIgniter"),
        .target(name: "PrometheusSwiftEngine", dependencies: [], path: "Sources/PrometheusSwiftEngine"),
        .target(name: "PrometheusCompilerEngine", dependencies: [], path: "Sources/PrometheusCompilerEngine")
    ]
)
