// AutoIgniter.swift
import Foundation
import Combine

public final class AutoIgniter: NSObject, ObservableObject {
    @Published public var statusMessage: String = "Ready"
    @Published public var lastBootstrapSummary: String? = nil

    private let firstLaunchKey = "prometheus.firstLaunchComplete"

    @MainActor
    public func bootstrapOnFirstLaunch() async {
        if !UserDefaults.standard.bool(forKey: firstLaunchKey) {
            await runBootstrap(tag: "First Launch")
            UserDefaults.standard.set(true, forKey: firstLaunchKey)
        } else {
            statusMessage = "App initialized"
        }
    }

    @MainActor
    public func forceBootstrap() async {
        await runBootstrap(tag: "Manual Trigger")
    }

    @MainActor
    private func runBootstrap(tag: String) async {
        statusMessage = "Bootstrapping… (\(tag))"
        do {
            let dest = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask).first!
                .appendingPathComponent("PrometheusUniverse/bootstrap", isDirectory: true)

            let summary = try AutoUnpackManager.shared.unpackBundledZip(named: "prometheus_payload", to: dest)

            let human = "Extracted \(summary.fileCount) files (\(summary.bytesTotal) bytes) to \(summary.extractedTo.path)"
            lastBootstrapSummary = human
            statusMessage = "✅ Bootstrap complete"
        } catch {
            statusMessage = "❌ Bootstrap failed: \(error)"
        }
    }
}
