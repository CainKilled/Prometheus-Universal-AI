// AutoUnpackManager.swift
import Foundation
import ZIPFoundation

public enum AutoUnpackError: Error {
    case resourceNotFound
    case unzipFailed
}

public struct AutoUnpackSummary: Codable {
    public let extractedTo: URL
    public let fileCount: Int
    public let bytesTotal: Int64
    public let timestamp: Date
}

public final class AutoUnpackManager {
    public static let shared = AutoUnpackManager()

    private init() {}

    public func unpackBundledZip(named resourceName: String,
                                 to directory: URL) throws -> AutoUnpackSummary {
        let bundle = Bundle.main
        guard let zipUrl = bundle.url(forResource: resourceName, withExtension: "zip") else {
            throw AutoUnpackError.resourceNotFound
        }

        try FileManager.default.createDirectory(at: directory, withIntermediateDirectories: true)

        // Unzip using ZIPFoundation
        guard let archive = Archive(url: zipUrl, accessMode: .read) else {
            throw AutoUnpackError.unzipFailed
        }

        var count = 0
        var totalBytes: Int64 = 0
        for entry in archive {
            let destURL = directory.appendingPathComponent(entry.path)
            try FileManager.default.createDirectory(at: destURL.deletingLastPathComponent(), withIntermediateDirectories: true)
            _ = try archive.extract(entry, to: destURL)
            count += 1
            totalBytes += Int64(entry.uncompressedSize)
        }
        return AutoUnpackSummary(extractedTo: directory, fileCount: count, bytesTotal: totalBytes, timestamp: Date())
    }
}
