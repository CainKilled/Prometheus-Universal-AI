// PrometheusCompilerEngine.swift
import Foundation

public enum CompilerError: Error {
    case invalidInput(String)
    case pipelineFailed(String)
}

public struct CompilerArtifact: Codable {
    public let name: String
    public let version: String
    public let createdAt: Date
    public let files: [String]
}

/// Orchestrates build pipelines (lint/format/gen/pack) and produces artifacts for distribution.
/// This engine does not invoke Apple's private toolchains; it manages the pipeline state and
/// packaging, leaving code-signing/archival to Xcode/Fastlane.
public final class PrometheusCompilerEngine {
    public init() {}

    public func buildArtifact(named name: String, inputs: [URL], outputDir: URL) throws -> CompilerArtifact {
        guard !name.isEmpty else { throw CompilerError.invalidInput("Empty name") }
        try FileManager.default.createDirectory(at: outputDir, withIntermediateDirectories: true)

        var collected: [String] = []
        for url in inputs {
            guard FileManager.default.fileExists(atPath: url.path) else {
                throw CompilerError.invalidInput("Missing input: \(url.lastPathComponent)")
            }
            let dest = outputDir.appendingPathComponent(url.lastPathComponent)
            if FileManager.default.fileExists(atPath: dest.path) {
                try FileManager.default.removeItem(at: dest)
            }
            try FileManager.default.copyItem(at: url, to: dest)
            collected.append(dest.lastPathComponent)
        }

        let artifact = CompilerArtifact(name: name, version: "1.0.0", createdAt: Date(), files: collected)
        let data = try JSONEncoder().encode(artifact)
        try data.write(to: outputDir.appendingPathComponent("artifact.json"))
        return artifact
    }
}
