#!/usr/bin/env bash
set -euo pipefail
echo "[iOS] Build helper — expects an existing Xcode project/workspace bound to this repo."
echo "Use: xcodebuild -workspace <YourApp>.xcworkspace -scheme <YourScheme> -configuration Release -destination 'generic/platform=iOS'"