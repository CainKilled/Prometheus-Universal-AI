# SIFT — Static Integrity & File Triage

**Purpose:** scan the repository for placeholder content (e.g., `PLACEHOLDER`, `TODO`, `FIXME`, `STUB`, `LOREM`), 
auto-upgrade safe cases, and emit a detailed report with hashes before/after.

**Commands**
```bash
python tools/sift/sift.py scan   # scan only
python tools/sift/sift.py fix    # scan + apply safe fixes
python tools/sift/sift.py report # show last report path
```