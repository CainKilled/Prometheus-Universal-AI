#!/usr/bin/env python3
import argparse, json, sys
from pathlib import Path
from sift_scan_fix import scan_repo, fix_repo

def main():
    ap = argparse.ArgumentParser(prog="sift", description="Static Integrity & File Triage")
    ap.add_argument("cmd", choices=["scan","fix","report"], help="Action to perform")
    ap.add_argument("--root", default=".", help="Root of repo")
    ap.add_argument("--report", default="tools/sift/reports/sift_report.json", help="Report path")
    args = ap.parse_args()

    root = Path(args.root).resolve()
    rep = Path(args.report).resolve()
    rep.parent.mkdir(parents=True, exist_ok=True)

    if args.cmd in ("scan","fix"):
        records = scan_repo(root)
        fixed = []
        if args.cmd == "fix":
            fixed = fix_repo(root, records)

        payload = {
            "root": str(root),
            "cmd": args.cmd,
            "total_hits": sum(r.get("count",0) for r in records),
            "records": records,
            "fixed": fixed,
        }
        rep.write_text(json.dumps(payload, indent=2))
        print(str(rep))
    elif args.cmd == "report":
        print(str(rep))

if __name__ == "__main__":
    main()