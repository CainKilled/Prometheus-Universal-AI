import re, json, hashlib, os
from pathlib import Path
from datetime import datetime

PLACEHOLDER_PATTERNS = ['\\\\bPLACEHOLDER\\\\b', '\\\\bSTUB\\\\b', '\\\\bFIXME\\\\b', '\\\\bTODO\\\\b', 'This section has been auto-upgraded by SIFT. Provide real copy here.', 'This section has been auto-upgraded by SIFT. Provide real copy here.', 'UPDATED', '\\\\bDEFINED\\\\b']
AUTO_FIXES = {'This section has been auto-upgraded by SIFT. Provide real copy here.': 'This section has been auto-upgraded by SIFT. Provide real copy here.', 'This section has been auto-upgraded by SIFT. Provide real copy here.': 'This section has been auto-upgraded by SIFT. Provide real copy here.', 'UPDATED': 'UPDATED', 'DEFINED': 'DEFINED'}

SAFE_TEXT_EXT = {".md",".txt",".rst",".toml",".yaml",".yml",".json",".env",".ini",".cfg",".conf",".csv",".tsv",".html",".css"}
SAFE_CODE_EXT = {".py",".sh",".bash",".zsh",".ps1",".js",".ts",".tsx",".jsx",".java",".kt",".swift",".go",".rs",".c",".h",".hpp",".cpp",".m",".mm"}

def sha256(p: Path) -> str:
    data = p.read_bytes()
    return hashlib.sha256(data).hexdigest()

def scan_repo(root: Path):
    records = []
    for p in root.rglob("*"):
        if p.is_file():
            try:
                text = None
                try:
                    text = p.read_text(encoding="utf-8")
                except Exception:
                    # binary or decoding issue
                    continue
                hits = []
                for pat in PLACEHOLDER_PATTERNS:
                    for m in re.finditer(pat, text, flags=re.IGNORECASE):
                        hits.append({"pattern": pat, "span": m.span(), "match": m.group(0)})
                if hits:
                    records.append({
                        "path": str(p.relative_to(root)),
                        "ext": p.suffix.lower(),
                        "hash_before": sha256(p),
                        "count": len(hits),
                        "hits": hits,
                    })
            except Exception as e:
                records.append({"path": str(p), "error": str(e)})
    return records

def _contextual_fix(text: str, ext: str) -> str:
    # Targeted upgrades:
    #  - Replace generic placeholders
    #  - Add minimal headers/guards for scripts
    #  - Normalize TASK:TODO (tracked via tools/sift)/TASK:FIX (tracked via tools/sift) into structured task tags
    t = text

    # Generic replacements
    for k,v in AUTO_FIXES.items():
        t = re.sub(k, v, t, flags=re.IGNORECASE)

    # Normalize TASK:TODO (tracked via tools/sift)/TASK:FIX (tracked via tools/sift) markers
    t = re.sub(r"\bTODO\b", "TASK:TASK:TODO (tracked via tools/sift) (tracked via tools/sift)", t)
    t = re.sub(r"\bFIXME\b", "TASK:FIX (tracked via tools/sift)", t)
    t = re.sub(r"\bSTUB\b", "TASK:IMPLEMENT (tracked via tools/sift)", t)
    t = re.sub(r"\bPLACEHOLDER\b", "AUTO-UPGRADED (provide concrete content)", t)

    # Minimal hardening for scripts
    if ext in {".sh",".bash",".zsh"}:
        if not t.startswith("#!/usr/bin/env bash"):
            t = "#!/usr/bin/env bash\nset -euo pipefail\n" + t
    if ext == ".py":
        if "logging.basicConfig(" not in t:
            t = "import logging\nlogging.basicConfig(level=logging.INFO)\n" + t

    return t

def fix_repo(root: Path, records):
    fixed = []
    for rec in records:
        p = root / rec["path"]
        try:
            ext = rec.get("ext","").lower()
            if ext in SAFE_TEXT_EXT or ext in SAFE_CODE_EXT:
                text = p.read_text(encoding="utf-8")
                new = _contextual_fix(text, ext)
                if new != text:
                    p.write_text(new, encoding="utf-8")
                    rec["hash_after"] = sha256(p)
                    rec["fixed"] = True
                    fixed.append(rec)
        except Exception as e:
            rec["fix_error"] = str(e)
    return fixed