# CI Build & TestFlight Upload (No Mac Needed)

This repo is configured to build in the **cloud** and ship to **TestFlight** using GitHub Actions + Fastlane.

## What you need (doable from iPhone Safari)

1. **Apple Developer Account** (enrolled).
2. **App Store Connect** app record named `PrometheusUniverse` (create it in App Store Connect).
3. A **private Git repo** (GitHub) containing this project.
4. A **private Match repo** to store signing files (also GitHub; can be empty to start).

## Secrets to add in your GitHub repo

Add these in *Settings → Secrets and variables → Actions → New repository secret*:

- `APP_STORE_CONNECT_API_KEY_JSON` — JSON for your ASC API key, like:
  ```json
  {
    "key_id": "ABC123XYZ",
    "issuer_id": "00000000-0000-0000-0000-000000000000",
    "key": "-----BEGIN PRIVATE KEY-----\n...\n-----END PRIVATE KEY-----"
  }
  ```
- `MATCH_GIT_URL` — SSH/HTTPS URL of your private match repo (e.g., `git@github.com:you/ios-signing.git`)
- `MATCH_PASSWORD` — a passphrase you choose for encrypting signing assets
- `IOS_SIGNING_KEYCHAIN_PASSWORD` — any random string (used by fastlane to unlock a temp keychain on CI)

## First run

1. Commit & push to `main` (or trigger **Actions → iOS Beta (TestFlight) → Run workflow**).
2. The workflow will:
   - `xcodegen generate` to create the Xcode project
   - Install fastlane gems
   - Use Fastlane to create/download certificates & profiles (via `match`)
   - Build the app
   - Upload to TestFlight

> This flow works **without** a local Mac. All signing material is created and stored by CI.

## Where to edit app IDs

- `ios/PrometheusUniverse/project.yml` → `bundleIdPrefix` and target `PRODUCT_BUNDLE_IDENTIFIER`  
- `fastlane/Appfile` → set your Apple ID/team IDs

