# Prometheus iOS Testing (Overview)

This folder contains a Swift Package scaffold for shared iOS logic. 
To test on-device:
1. Create an Xcode iOS app target and add this package as a local dependency.
2. Use your Apple Developer account to enable signing.
3. Build and run on your iPhone via Xcode, or distribute via TestFlight.

Automation helpers live under `tools/ios/` in the repo (build scripts, fastlane templates).