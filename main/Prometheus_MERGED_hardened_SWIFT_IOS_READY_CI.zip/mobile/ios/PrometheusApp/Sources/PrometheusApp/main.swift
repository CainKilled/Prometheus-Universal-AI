import Foundation
// Minimal CLI-style entrypoint for Swift Package build (server/utility mode).
// For actual iOS app (Xcode project), this package provides shared logic.

print("[PrometheusApp] Bootstrap OK — shared logic ready.")