#!/usr/bin/env python3
import argparse, json, re, sys
from pathlib import Path

placeholder_re = re.compile(r"\b(PLACEHOLDER|TODO|STUB|FIXME|LOREM|TBD|WIP)\b", re.I)

def is_text_file(path: Path, max_bytes=2048) -> bool:
    try:
        with open(path, "rb") as f:
            chunk = f.read(max_bytes)
        if b"\x00" in chunk:
            return False
        printable = sum(1 for b in chunk if (32 <= b <= 126) or b in b"\r\n\t")
        return printable / max(1,len(chunk)) > 0.8
    except Exception:
        return False

def main(root: Path, fix: bool=False):
    py_errors = []
    json_errors = []
    placeholders = []
    for p in root.rglob("*"):
        if not p.is_file(): 
            continue
        if p.suffix.lower()==".py":
            try:
                compile(p.read_text(errors="ignore"), str(p), "exec")
            except Exception as e:
                py_errors.append({"file": str(p), "error": str(e)})
        if p.suffix.lower()==".json":
            try:
                data = json.load(open(p, "r", errors="ignore"))
                if fix:
                    open(p, "w").write(json.dumps(data, indent=2)+"\n")
            except Exception as e:
                json_errors.append({"file": str(p), "error": str(e)})
        if is_text_file(p):
            try:
                txt = p.read_text(errors="ignore")
                for m in placeholder_re.finditer(txt):
                    placeholders.append({"file": str(p), "match": m.group(0)})
            except Exception:
                pass
    report = {"py_errors": py_errors, "json_errors": json_errors, "placeholders": placeholders}
    print(json.dumps(report, indent=2))
    return 0 if not py_errors and not json_errors else 1

if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--root", default=str(Path(__file__).resolve().parents[1]))
    ap.add_argument("--fix", action="store_true")
    args = ap.parse_args()
    sys.exit(main(Path(args.root), fix=args.fix))
