# Init for Code_Generator
