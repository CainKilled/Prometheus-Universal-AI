# Init for Sentinal_AI
