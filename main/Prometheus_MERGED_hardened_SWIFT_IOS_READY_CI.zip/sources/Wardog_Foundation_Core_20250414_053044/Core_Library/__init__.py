# Init for Core_Library
