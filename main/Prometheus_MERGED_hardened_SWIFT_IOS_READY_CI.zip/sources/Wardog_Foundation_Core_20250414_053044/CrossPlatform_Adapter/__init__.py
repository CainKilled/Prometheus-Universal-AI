# Init for CrossPlatform_Adapter
