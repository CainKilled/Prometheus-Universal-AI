# Init for SecureComms
