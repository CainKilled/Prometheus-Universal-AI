# Init for Mutt_AI
