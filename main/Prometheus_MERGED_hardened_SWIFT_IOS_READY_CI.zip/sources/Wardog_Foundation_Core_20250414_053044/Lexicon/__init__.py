# Init for Lexicon
