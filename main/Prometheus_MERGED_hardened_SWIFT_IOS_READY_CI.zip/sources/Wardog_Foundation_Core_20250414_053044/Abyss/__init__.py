# Init for Abyss
