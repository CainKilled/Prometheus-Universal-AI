# Init for RedTeam_AI
