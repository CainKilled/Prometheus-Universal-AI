# Init for Nagles_Retribution
