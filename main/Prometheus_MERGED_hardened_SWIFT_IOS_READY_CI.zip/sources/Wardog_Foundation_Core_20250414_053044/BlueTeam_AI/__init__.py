# Init for BlueTeam_AI
