# Init for LogCenter
