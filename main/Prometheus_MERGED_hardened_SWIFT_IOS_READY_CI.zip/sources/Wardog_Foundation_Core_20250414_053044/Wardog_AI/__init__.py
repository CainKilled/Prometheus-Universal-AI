# Init for Wardog_AI
