# Init for GreyTeam_AI
