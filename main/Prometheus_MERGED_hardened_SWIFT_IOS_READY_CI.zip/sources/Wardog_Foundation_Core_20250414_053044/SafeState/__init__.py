# Init for SafeState
