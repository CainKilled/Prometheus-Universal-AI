# Init for Wardog_Utils
