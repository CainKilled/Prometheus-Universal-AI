# Init for Singularity
