# Init for Encryption_Core
