### Viral System
Runs botnet-style media deployment via automation/viral_infiltrator.py