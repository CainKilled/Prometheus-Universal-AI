import React from 'react';
import { SafeAreaView, Text, StyleSheet } from 'react-native';
import AIEngine from './components/AIEngine';
import CyberSecurity from './components/CyberSecurity';
import AppGenerator from './components/AppGenerator';

export default function App() {
  return (
    <SafeAreaView style={styles.container}>
      <Text style={styles.header}>Phoenix: A Wardog Revolution</Text>
      <AIEngine />
      <CyberSecurity />
      <AppGenerator />
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, alignItems: 'center', justifyContent: 'center', padding: 20 },
  header: { fontSize: 24, fontWeight: 'bold' }
});
