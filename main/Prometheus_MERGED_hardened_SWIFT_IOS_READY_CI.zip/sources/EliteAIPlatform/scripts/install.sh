#!/bin/bash
echo "Installing dependencies..."
pip install -r ../backend/requirements.txt
echo "Starting platform..."
python ../backend/main.py
