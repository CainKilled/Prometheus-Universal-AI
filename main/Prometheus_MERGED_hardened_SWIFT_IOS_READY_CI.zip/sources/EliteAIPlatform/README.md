# Elite AI Cyber Platform

## Overview
An elite AI-powered platform with a web-based UI, voice intelligence, customizable modules, and real-time local/cloud sync.

## Features
- Web UI (React)
- Local & cloud sync
- AI without API keys
- Voice interaction
- Full customization
- Cross-platform support

## Installation
Run `scripts/install.sh` (Linux/macOS) or `scripts/install.bat` (Windows).

## Run
Start with `python backend/main.py` or use the web UI at `localhost:8000`.
