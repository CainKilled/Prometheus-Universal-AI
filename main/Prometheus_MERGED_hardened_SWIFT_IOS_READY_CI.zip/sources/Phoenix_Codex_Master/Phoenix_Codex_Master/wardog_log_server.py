from flask import Flask, jsonify, request
from flask_cors import CORS
import wardog_logger

PHOENIX_SECRET = "orangeunicorn110"

app = Flask(__name__)
CORS(app)

@app.route('/api/logs/stream', methods=['GET'])
def stream_logs():
    device = request.args.get('device')
    user = request.args.get('user')
    auth = request.args.get('auth')

    if auth != PHOENIX_SECRET:
        return jsonify({"error": "Unauthorized"}), 403

    logs = wardog_logger.get_logs(device, user)
    return jsonify(logs), 200

if __name__ == "__main__":
    app.run(host='0.0.0.0', port=5000)
