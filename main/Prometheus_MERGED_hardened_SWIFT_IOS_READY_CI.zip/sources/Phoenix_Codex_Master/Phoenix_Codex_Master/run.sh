#!/bin/sh
echo "[Phoenix] Initializing Codex Master..."
pip3 install -r requirements.txt
python3 wardog_log_server.py
