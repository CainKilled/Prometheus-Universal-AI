from datetime import datetime

def get_logs(device, user):
    return {
        "user": user,
        "device": device,
        "timestamp": datetime.utcnow().isoformat(),
        "events": [
            {
                "type": "login",
                "status": "success",
                "source": "Scriptable",
                "ip": "192.168.1.105",
                "timestamp": datetime.utcnow().isoformat()
            },
            {
                "type": "scan",
                "tool": "Phoenix Red Team AI",
                "target": "external_network",
                "status": "no threats",
                "timestamp": datetime.utcnow().isoformat()
            },
            {
                "type": "heartbeat",
                "status": "active",
                "module": "Wardog AI Defense System",
                "timestamp": datetime.utcnow().isoformat()
            }
        ]
    }
