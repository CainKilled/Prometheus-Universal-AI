# Phoenix Codex Master v-Infinity
This is the official log server package for Wardog + Phoenix Codex integration.

## Instructions

1. Extract:
   ```bash
   tar -xvzf Phoenix_Codex_Master.tar.gz
   cd Phoenix_Codex_Master
   ```

2. Run:
   ```bash
   ./run.sh
   ```

3. Access via Scriptable:
   ```
   http://<your-ip>:5000/api/logs/stream?device=iphone13&user=adam&auth=orangeunicorn110
   ```

- Fully editable
- No expiration
- Cross-platform (iSH, Linux, macOS, Windows WSL)
- Safe to copy, email, modify
