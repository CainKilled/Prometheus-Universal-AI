import React, { useState } from 'react';

const DiagnosisTool = () => {
    const [file, setFile] = useState(null);
    const [result, setResult] = useState(null);

    const handleFileUpload = (e) => setFile(e.target.files[0]);

    const submitPhoto = async () => {
        try {
            const formData = new FormData();
            formData.append("file", file);
            formData.append("user_id", 1); // Static for demo

            const response = await fetch("http://localhost:8000/diagnose/?user_id=1", {
                method: "POST",
                body: formData,
            });

            const data = await response.json();
            setResult(data);
        } catch (error) {
            alert("An error occurred: " + error.message);
        }
    };

    return (
        <div>
            <h1>Nagle's Photo Dr.</h1>
            <input type="file" onChange={handleFileUpload} />
            <button onClick={submitPhoto}>Diagnose</button>
            {result && (
                <div>
                    <h2>Diagnosis</h2>
                    <pre>{JSON.stringify(result, null, 2)}</pre>
                </div>
            )}
        </div>
    );
};

export default DiagnosisTool;
