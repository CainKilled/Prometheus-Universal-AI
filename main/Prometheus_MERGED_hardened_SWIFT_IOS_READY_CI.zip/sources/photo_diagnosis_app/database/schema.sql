CREATE TABLE users (
    id SERIAL PRIMARY KEY,
    username VARCHAR(50) NOT NULL,
    email VARCHAR(100) UNIQUE NOT NULL,
    subscription_tier VARCHAR(20) DEFAULT 'Free'
);

CREATE TABLE growth_journal (
    id SERIAL PRIMARY KEY,
    user_id INT REFERENCES users(id),
    date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    photo_path TEXT,
    notes TEXT
);

CREATE TABLE diagnoses (
    id SERIAL PRIMARY KEY,
    user_id INT REFERENCES users(id),
    photo_path TEXT,
    diagnosis TEXT,
    confidence FLOAT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
