from fastapi import FastAPI, File, UploadFile, HTTPException
from tensorflow.lite.python.interpreter import Interpreter
from database import DatabaseConnection
import numpy as np
from PIL import Image
import io
import uvicorn

app = FastAPI()
db = DatabaseConnection()

def preprocess_image(image_bytes):
    image = Image.open(io.BytesIO(image_bytes)).convert("RGB")
    image = image.resize((224, 224))
    image_array = np.array(image, dtype=np.float32) / 255.0
    image_array = np.expand_dims(image_array, axis=0)
    return image_array

def map_predictions_to_issues(predictions):
    return {"issue": "Nutrient Deficiency", "confidence": float(predictions[0][0])}

@app.post("/diagnose/")
async def diagnose_photo(user_id: int, file: UploadFile = File(...)):
    try:
        image_bytes = await file.read()
        image = preprocess_image(image_bytes)

        interpreter = Interpreter(model_path="model/model.tflite")
        interpreter.allocate_tensors()

        input_details = interpreter.get_input_details()
        output_details = interpreter.get_output_details()

        interpreter.set_tensor(input_details[0]['index'], image)
        interpreter.invoke()

        predictions = interpreter.get_tensor(output_details[0]['index'])
        diagnosis = map_predictions_to_issues(predictions)

        db.execute(
            """
            INSERT INTO diagnoses (user_id, photo_path, diagnosis, confidence)
            VALUES (:user_id, :photo_path, :diagnosis, :confidence)
            """,
            {
                "user_id": user_id,
                "photo_path": file.filename,
                "diagnosis": diagnosis["issue"],
                "confidence": diagnosis["confidence"],
            },
        )

        return {"diagnosis": diagnosis, "confidence": predictions.tolist()}

    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

if __name__ == "__main__":
    uvicorn.run(app, host="0.0.0.0", port=8000)
