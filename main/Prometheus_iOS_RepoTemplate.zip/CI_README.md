# CI Build & TestFlight Upload (No Mac Needed)

This repo is wired to build in the **cloud** and ship to **TestFlight** using GitHub Actions + Fastlane.
You can operate it from mobile Safari.

## Required Secrets

- `APP_STORE_CONNECT_API_KEY_JSON` — JSON for your ASC API key.
- `MATCH_GIT_URL` — private repo URL to store signing assets (Fastlane Match).
- `MATCH_PASSWORD` — passphrase to encrypt signing assets.
- `IOS_SIGNING_KEYCHAIN_PASSWORD` — arbitrary string for the CI keychain.

## Workflows

- **Retarget (Bundle ID & Name)** → Adjusts bundle ID, name, and team in files.
- **Create ASC App** → Uses Fastlane `produce` to create the app record in App Store Connect.
- **iOS Beta (TestFlight)** → Builds the app and uploads to TestFlight using Fastlane `beta`.

## Bitrise Option

Alternatively, use `bitrise.yml` with your Bitrise project. Add secrets and run the pipeline which mirrors the Actions flow.
