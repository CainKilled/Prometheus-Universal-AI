# Prometheus iOS Starter (Template)

A forkable/template repository that builds and ships an iOS app to **TestFlight** entirely in the cloud (no Mac required),
and auto-bootstraps your Prometheus payload on first launch.

## Features
- SwiftUI app with **Auto-Igniter** + **AutoUnpackKit**
- **XcodeGen** project spec
- **Fastlane** lanes (`create_app`, `setup_match`, `beta`, `build_local`)
- **GitHub Actions** workflows:
  - `asc-create-app.yml` → creates the App Store Connect app record via API (Fastlane `produce`)
  - `ios-beta.yml` → builds and uploads to TestFlight
  - `retarget.yml` → retargets Bundle ID / App Name programmatically
- **Bitrise** pipeline (`bitrise.yml`) as an alternative CI
- Ready to be marked as a **Template Repository** on GitHub (Settings → Template repository)

## Quick Start
1. Click **Use this template** (or fork).
2. In your repo, add Actions secrets (Settings → Secrets → Actions):
   - `APP_STORE_CONNECT_API_KEY_JSON`
   - `MATCH_GIT_URL`
   - `MATCH_PASSWORD`
   - `IOS_SIGNING_KEYCHAIN_PASSWORD`
3. Run **Actions → Retarget (Bundle ID & Name)** to set your `BUNDLE_ID`, `APP_NAME`, `TEAM_ID`, etc.
4. Run **Actions → Create ASC App** to create the app record.
5. Run **Actions → iOS Beta (TestFlight)** to build and upload.

See `CI_README.md` for details.
