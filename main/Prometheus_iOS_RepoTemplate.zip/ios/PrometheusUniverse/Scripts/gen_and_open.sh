#!/usr/bin/env bash
set -euo pipefail
# iOS Helper Script (macOS host): generate Xcode project & open it
cd "$(dirname "$0")"
if ! command -v xcodegen >/dev/null 2>&1; then
  echo "Please install XcodeGen: brew install xcodegen" >&2
  exit 1
fi
xcodegen generate
open PrometheusUniverse.xcodeproj
