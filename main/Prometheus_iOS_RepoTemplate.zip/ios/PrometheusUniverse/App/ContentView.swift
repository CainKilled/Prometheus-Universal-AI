// ContentView.swift
import SwiftUI

struct ContentView: View {
    @EnvironmentObject var igniter: AutoIgniter

    var body: some View {
        VStack(spacing: 16) {
            Text("Prometheus Universe")
                .font(.system(size: 28, weight: .bold, design: .rounded))
            Text(igniter.statusMessage)
                .font(.system(size: 16, weight: .regular, design: .rounded))
                .multilineTextAlignment(.center)
                .padding(.horizontal)

            if let last = igniter.lastBootstrapSummary {
                VStack(alignment: .leading, spacing: 8) {
                    Text("Last Bootstrap:")
                        .font(.headline)
                    Text(last)
                        .font(.footnote)
                        .foregroundColor(.secondary)
                        .textSelection(.enabled)
                }.padding()
            }

            Button("Run Bootstrap Again") {
                Task { await igniter.forceBootstrap() }
            }
            .buttonStyle(.borderedProminent)
        }
        .padding()
    }
}
