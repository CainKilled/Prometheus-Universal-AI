
# Ownership

**Product Owner & Lead Developer**: *Adam Nagle*  
- Email: cainkilledabel@icloud.com, nagleadam75@gmail.com  
- Phone: 603-384-8949

This repository and all integrated tooling (proctl, orchestrators, CI/CD, charts, clients) are developed as a marketable product owned by Adam Nagle.
