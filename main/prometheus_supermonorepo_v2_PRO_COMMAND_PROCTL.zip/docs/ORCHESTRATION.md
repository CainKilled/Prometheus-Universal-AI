
# Orchestration & Self-healing

Use `tools/proctl.py` to start/stop/watch profiles defined in `orchestrators/*.yml`.

## Examples
```bash
./start.sh libmobile
./start.sh chatgpt
./start.sh terminal
./start.sh swiftserver

./stop.sh libmobile
```

## Self-healing
Enable the watcher as a user service:
```bash
make services-install
systemctl --user enable --now prometheus-proctl@libmobile.service
journalctl --user -u prometheus-proctl@libmobile.service -f
```
