
import Foundation
import Network

// Simple HTTP server using NWListener (no external deps).
// Endpoints: /health, /echo?msg=..., /time

let port: UInt16 = UInt16(ProcessInfo.processInfo.environment["PORT"].flatMap { UInt16($0) } ?? 8088)
let params = NWParameters.tcp
let listener = try NWListener(using: params, on: NWEndpoint.Port(rawValue: port)!)

func httpResponse(_ body: String, status: String = "200 OK") -> Data {
    let b = body.data(using: .utf8)!
    let headers = "HTTP/1.1 \(status)\r\nContent-Type: application/json\r\nContent-Length: \(b.count)\r\nConnection: close\r\n\r\n"
    var out = Data(headers.utf8)
    out.append(b)
    return out
}

listener.newConnectionHandler = { conn in
    conn.start(queue: .global())
    conn.receive(minimumIncompleteLength: 1, maximumLength: 65536) { data, _, _, _ in
        guard let data = data, let req = String(data: data, encoding: .utf8) else { conn.cancel(); return }
        let first = req.split(separator: "\n").first ?? ""
        let parts = first.split(separator: " ")
        let path = parts.count > 1 ? String(parts[1]) : "/"
        let query = URLComponents(string: "http://x\(path)")?.queryItems ?? []
        let qs = Dictionary(uniqueKeysWithValues: query.map { ($0.name, $0.value ?? "") })
        var body = "{}"
        if path.hasPrefix("/health") {
            body = "{\"status\":\"ok\",\"port\":\(port)}"
        } else if path.hasPrefix("/time") {
            body = "{\"utc\":\"\(ISO8601DateFormatter().string(from: Date()))\"}"
        } else if path.hasPrefix("/echo") {
            let msg = qs["msg"] ?? ""
            body = "{\"echo\":\"\(msg)\"}"
        } else {
            body = "{\"error\":\"not found\",\"path\":\"\(path)\"}"
        }
        let res = httpResponse(body)
        conn.send(content: res, completion: .contentProcessed { _ in conn.cancel() })
    }
}
print("PrometheusSwiftServer listening on :\(port)")
listener.start(queue: .global())
dispatchMain()
