
import XCTest
final class ServerTests: XCTestCase {
    func testDummy() throws {
        XCTAssertTrue(true)
    }
}
