
# Prometheus Swift Server (self-contained)

Minimal Swift-based HTTP server (no external deps) exposing:
- `/health` — status
- `/time` — current UTC
- `/echo?msg=hello` — echoes a message

## Run
```bash
cd apps/prometheus-swift-server
swift build && swift test
PORT=8088 swift run prometheus-swift-server
# or
cd apps/prometheus-swift-server/infra && docker compose up --build
```
