
# Prometheus Terminal (Linux TUI)
A Textual-based terminal dashboard to discover projects and run commands in-context.

## Run
```bash
python -m pip install -r apps/prometheus-terminal/requirements.txt
python apps/prometheus-terminal/main.py
```
