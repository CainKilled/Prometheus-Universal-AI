
import os
os.environ["CHAT_PROVIDER"]="echo"
from fastapi.testclient import TestClient
import app
client = TestClient(app.app)
def test_chat():
    r = client.post("/api/chat", json={"messages":[{"role":"user","content":"hello"}]})
    assert r.status_code == 200
    assert "ECHO" in r.json()["content"]
