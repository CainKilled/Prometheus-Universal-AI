
import os, json, typing, httpx
from fastapi import FastAPI, HTTPException
from pydantic import BaseModel

CHAT_PROVIDER = os.getenv("CHAT_PROVIDER","echo").lower()
OPENAI_API_KEY = os.getenv("OPENAI_API_KEY")
OPENAI_MODEL = os.getenv("OPENAI_MODEL","gpt-4o-mini")
OPENAI_BASE = os.getenv("OPENAI_BASE","https://api.openai.com/v1")

class Msg(BaseModel):
    role: str
    content: str

class ChatRequest(BaseModel):
    messages: typing.List[Msg]

class ChatResponse(BaseModel):
    content: str

app = FastAPI(title="Prometheus Chat API")

@app.get("/health")
def health():
    return {"status":"ok","provider":CHAT_PROVIDER}

@app.post("/api/chat", response_model=ChatResponse)
def chat(req: ChatRequest):
    if CHAT_PROVIDER == "echo":
        reply = "\n".join([f"{m.role}: {m.content}" for m in req.messages])
        return ChatResponse(content=f"ECHO:\n{reply}")
    elif CHAT_PROVIDER == "openai":
        if not OPENAI_API_KEY:
            raise HTTPException(status_code=400, detail="OPENAI_API_KEY missing")
        # minimal create call; no streaming
        body = {"model": OPENAI_MODEL, "messages":[m.model_dump() for m in req.messages]}
        headers = {"Authorization": f"Bearer {OPENAI_API_KEY}"}
        with httpx.Client(timeout=60.0) as client:
            r = client.post(f"{OPENAI_BASE}/chat/completions", headers=headers, json=body)
            if r.status_code != 200:
                raise HTTPException(status_code=r.status_code, detail=r.text)
            content = r.json()["choices"][0]["message"]["content"]
            return ChatResponse(content=content)
    else:
        raise HTTPException(status_code=400, detail=f"Unsupported provider: {CHAT_PROVIDER}")
