
from fastapi.testclient import TestClient
import app

client = TestClient(app.app)

def test_health():
    r = client.get("/health")
    assert r.status_code == 200
    assert r.json()["status"] == "ok"

def test_notes_crud():
    r = client.post("/v1/notes", json={"text": "hello"})
    assert r.status_code == 200
    nid = r.json()["id"]
    r = client.get("/v1/notes")
    assert r.status_code == 200
    assert any(n["id"] == nid and n["text"] == "hello" for n in r.json())
