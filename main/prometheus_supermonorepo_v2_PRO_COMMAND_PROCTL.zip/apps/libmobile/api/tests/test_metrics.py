
from fastapi.testclient import TestClient
import app

client = TestClient(app.app)

def test_metrics():
    r = client.get("/metrics")
    assert r.status_code == 200
    assert "python_gc_objects_collected_total" in r.text or "process_cpu_seconds_total" in r.text
