
function Get-ServiceSafe {
  param([string]$Name)
  try { return Get-Service -Name $Name -ErrorAction Stop } catch { return $null }
}

function Install-PrometheusService {
  param(
    [string]$RepoPath = "$HOME\prometheus_supermonorepo_v2_PRO",
    [int]$ProjectIndex = 0
  )
  $svcName = "PrometheusLauncher$ProjectIndex"
  $cmd = "powershell -NoProfile -ExecutionPolicy Bypass -File `"$RepoPath\start.ps1`" $ProjectIndex"
  $svc = Get-ServiceSafe -Name $svcName
  if ($null -eq $svc) {
    sc.exe create $svcName binPath= "cmd /c $cmd" start= auto | Out-Null
    Write-Host "Created service $svcName (auto-start)."
  } else {
    sc.exe config $svcName start= auto | Out-Null
    # Attempt to update binPath if changed
    sc.exe config $svcName binPath= "cmd /c $cmd" | Out-Null
    Write-Host "Updated service $svcName configuration."
  }
}

function Start-PrometheusService { param([int]$ProjectIndex = 0)
  $svcName = "PrometheusLauncher$ProjectIndex"
  $svc = Get-ServiceSafe -Name $svcName
  if ($null -eq $svc) { throw "Service $svcName not installed. Run Install-PrometheusService first." }
  if ($svc.Status -ne "Running") { Start-Service -Name $svcName }
  Write-Host "Service $svcName is Running."
}

function Enable-PrometheusAutostart { param([int]$ProjectIndex = 0)
  $svcName = "PrometheusLauncher$ProjectIndex"
  sc.exe config $svcName start= auto | Out-Null
  Write-Host "Enabled autostart for $svcName."
}

function Uninstall-PrometheusService { param([int]$ProjectIndex = 0)
  $svcName = "PrometheusLauncher$ProjectIndex"
  $svc = Get-ServiceSafe -Name $svcName
  if ($null -ne $svc) {
    if ($svc.Status -eq "Running") { Stop-Service -Name $svcName -Force }
    sc.exe delete $svcName | Out-Null
    Write-Host "Removed service $svcName."
  } else {
    Write-Host "Service $svcName not present. Nothing to remove."
  }
}
