
## What & Why
- ...

## Checklist
- [ ] Tests added/updated
- [ ] CI green
- [ ] Security review (if sensitive)
- [ ] Docs updated

## Screenshots / Notes
