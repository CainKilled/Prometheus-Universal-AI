
# PrometheusSwift

Swift Package with a simple client for the libmobile API and a CLI.

## Build
```bash
cd clients/prometheus-swift
swift build
swift test
API_BASE=http://localhost:8000 swift run prometheus-cli
```
