
import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;

const String apiBase = String.fromEnvironment('API_BASE', defaultValue: 'http://localhost:8000');

void main() => runApp(const MyApp());

class MyApp extends StatelessWidget {
  const MyApp({super.key});
  @override
  Widget build(BuildContext context) {
    return MaterialApp(title: 'libmobile', home: NotesPage());
  }
}

class NotesPage extends StatefulWidget {
  @override
  State<NotesPage> createState() => _NotesPageState();
}

class _NotesPageState extends State<NotesPage> {
  final _controller = TextEditingController();
  List<dynamic> notes = [];
  String status = 'checking...';

  @override
  void initState() {
    super.initState();
    _health();
    _load();
  }

  Future<void> _health() async {
    try {
      final r = await http.get(Uri.parse('$apiBase/health'));
      setState(() => status = r.statusCode == 200 ? 'ok' : 'down');
    } catch (_) { setState(() => status = 'down'); }
  }

  Future<void> _load() async {
    final r = await http.get(Uri.parse('$apiBase/v1/notes'));
    setState(() => notes = json.decode(r.body));
  }

  Future<void> _add() async {
    final t = _controller.text;
    if (t.isEmpty) return;
    await http.post(Uri.parse('$apiBase/v1/notes'),
        headers: {'Content-Type':'application/json'},
        body: json.encode({'text': t}));
    _controller.clear();
    _load();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('libmobile ($apiBase) — '), actions: [Text(status)]),
      body: Column(children: [
        Row(children: [
          Expanded(child: TextField(controller: _controller, decoration: const InputDecoration(hintText: 'note'))),
          IconButton(icon: const Icon(Icons.add), onPressed: _add)
        ]),
        Expanded(child: ListView(children: [ for (var n in notes) ListTile(title: Text('${n["id"]}: ${n["text"]}')) ]))
      ]),
    );
  }
}
