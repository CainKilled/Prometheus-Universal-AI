
import os, yaml, time, signal
from dataclasses import asdict
from .models import Service, Profile, HealthCheck
from .utils import run, tcp_check, http_check

def load_profile(path: str) -> Profile:
    with open(path, 'r', encoding='utf-8') as f:
        y = yaml.safe_load(f)
    services = []
    for s in y.get('services', []):
        hc = s.get('health', {}) or {}
        services.append(Service(
            name=s['name'],
            type=s['type'],
            cwd=s['cwd'],
            command=s['command'],
            env=s.get('env',{}) or {},
            health=HealthCheck(**hc),
            autorestart=bool(s.get('autorestart', True))
        ))
    return Profile(name=y.get('name','default'), services=services)

def start_service(svc: Service):
    if svc.type == "compose":
        return run("docker compose up -d", cwd=svc.cwd, env=svc.env)
    elif svc.type in ("python","node","shell","swift","docker"):
        # non-daemonized; rely on systemd/launchd or 'watch' to keep alive
        return run(svc.command, cwd=svc.cwd, env=svc.env)
    else:
        return run(svc.command, cwd=svc.cwd, env=svc.env)

def stop_service(svc: Service):
    if svc.type == "compose":
        return run("docker compose down -v", cwd=svc.cwd, env=svc.env)
    # best-effort stop: try pkill by cwd
    return run(f"pkill -f '{svc.command}' || true")

def healthy(svc: Service) -> bool:
    hc = svc.health
    if hc.type == "none":
        return True
    if hc.type == "http" and hc.url:
        return http_check(hc.url, timeout=hc.timeout)
    if hc.type == "tcp" and hc.port:
        return tcp_check("127.0.0.1", hc.port, timeout=hc.timeout)
    if hc.type == "process" and hc.process:
        out = run(f"pgrep -f '{hc.process}'")
        return out.returncode == 0
    return False

def wait_healthy(svc: Service, retries=None):
    r = retries or svc.health.retries
    for _ in range(r):
        if healthy(svc): return True
        time.sleep(svc.health.interval)
    return healthy(svc)
