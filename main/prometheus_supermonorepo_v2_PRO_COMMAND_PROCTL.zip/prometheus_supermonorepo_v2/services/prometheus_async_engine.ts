// services/prometheus_async_engine.ts
// Prometheus-bound Async Engine (Web Worker + Fallback)
export interface RunOptions {
    timeoutMs?: number;
    signal?: AbortSignal;
    onProgress?: (progress: { checked: number; elapsedMs: number }) => void;
}
export interface EngineResult {
    result: number;
    runtime: "web-worker" | "fallback";
}
let _workerUrl: string | null = null;
function buildWorkerUrl(): string {
    if (_workerUrl) return _workerUrl;
    const source = `
        (function(){
            function findNthPrime(n){
                let primes = [];
                let candidate = 2;
                let checked = 0;
                function isPrime(k){
                    for(let i=0;i<primes.length;i++){
                        let p = primes[i];
                        if(p*p > k) break;
                        if(k % p === 0) return false;
                    }
                    return true;
                }
                while(primes.length < n){
                    if(isPrime(candidate)) primes.push(candidate);
                    candidate = candidate === 2 ? 3 : candidate+2;
                    checked++;
                    if(checked % 10000 === 0){
                        self.postMessage({type:"progress", checked});
                    }
                }
                return primes[n-1];
            }
            self.onmessage = (ev)=>{
                try {
                    const n = ev.data.n;
                    const result = findNthPrime(n);
                    self.postMessage({type:"result", result});
                } catch(err){
                    self.postMessage({type:"error", message: err && err.message ? err.message : String(err)});
                }
            };
        })();
    `;
    const blob = new Blob([source], { type: "application/javascript" });
    _workerUrl = URL.createObjectURL(blob);
    return _workerUrl;
}
function cleanupWorker(worker: Worker) {
    try { worker.terminate(); } catch {}
    if (_workerUrl) {
        URL.revokeObjectURL(_workerUrl);
        _workerUrl = null;
    }
}
function validateInput(n: number) {
    if (!Number.isFinite(n) || n <= 0 || !Number.isInteger(n)) {
        throw new Error("n must be a positive integer");
    }
    if (n > 5_000_000) {
        throw new Error("n too large for this engine configuration");
    }
}
export async function runAsyncCalculation(n: number, opts: RunOptions = {}): Promise<EngineResult> {
    validateInput(n);
    const { timeoutMs, signal, onProgress } = opts;
    if (typeof Worker === "undefined") {
        return { result: nthPrimeFallback(n, onProgress, signal), runtime: "fallback" };
    }
    const worker = new Worker(buildWorkerUrl());
    return new Promise<EngineResult>((resolve, reject) => {
        let timeoutId: any;
        const start = (typeof performance !== "undefined" && performance.now) ? performance.now() : Date.now();
        if (timeoutMs && timeoutMs > 0) {
            timeoutId = setTimeout(() => {
                cleanupWorker(worker);
                reject(new Error("Timed out"));
            }, timeoutMs);
        }
        if (signal) {
            const abortHandler = () => {
                cleanupWorker(worker);
                reject(new DOMException("Aborted", "AbortError"));
            };
            signal.addEventListener("abort", abortHandler, { once: true });
        }
        worker.onmessage = (ev) => {
            const msg = ev.data;
            if (msg?.type === "progress" && onProgress) {
                const now = (typeof performance !== "undefined" && performance.now) ? performance.now() : Date.now();
                onProgress({ checked: msg.checked, elapsedMs: now - start });
                return;
            }
            if (msg?.type === "result") {
                if (timeoutId) clearTimeout(timeoutId);
                cleanupWorker(worker);
                resolve({ result: msg.result, runtime: "web-worker" });
                return;
            }
            if (msg?.type === "error") {
                if (timeoutId) clearTimeout(timeoutId);
                cleanupWorker(worker);
                reject(new Error(String(msg.message || "Worker error")));
                return;
            }
        };
        worker.onerror = (err) => {
            if (timeoutId) clearTimeout(timeoutId);
            cleanupWorker(worker);
            reject(err);
        };
        worker.postMessage({ n });
    });
}
// Fallback (cooperative yielding not available here; keep it simple)
function nthPrimeFallback(n: number, onProgress?: RunOptions["onProgress"], signal?: AbortSignal): number {
    const primes: number[] = [];
    let candidate = 2;
    let checked = 0;
    while (primes.length < n) {
        if (signal?.aborted) throw new DOMException("Aborted", "AbortError");
        if (isPrime(candidate, primes)) primes.push(candidate);
        candidate = candidate === 2 ? 3 : candidate + 2;
        checked++;
        if (checked % 10000 === 0 && onProgress) {
            const now = (typeof performance !== "undefined" && performance.now) ? performance.now() : Date.now();
            onProgress({ checked, elapsedMs: now });
        }
    }
    return primes[n - 1];
}
function isPrime(k: number, primes: number[]): boolean {
    for (let i=0;i<primes.length;i++){
        const p = primes[i];
        if (p * p > k) break;
        if (k % p === 0) return false;
    }
    return true;
}
