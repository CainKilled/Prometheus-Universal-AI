import hashlib, json, os, stat
from pathlib import Path
from datetime import datetime, timezone
ISO = "%Y-%m-%dT%H:%M:%SZ"
def sha256_file(p: Path) -> str:
  h = hashlib.sha256()
  with p.open("rb") as f:
    for chunk in iter(lambda: f.read(1024*1024), b""):
      h.update(chunk)
  return h.hexdigest()
def walk_manifest(root: Path):
  items = []
  for p in sorted(root.rglob("*")):
    if p.is_file():
      rel = p.relative_to(root).as_posix()
      items.append({"path": rel, "size": p.stat().st_size, "sha256": sha256_file(p)})
  return {"generated_at": datetime.now(timezone.utc).strftime(ISO), "root": root.name, "items": items}
class CodexAgent:
  def run(self, **kwargs):
    name = kwargs["name"]
    root = Path(kwargs["root"]).resolve()
    artifact = kwargs.get("artifact")
    target_roots = [root]
    if artifact:
      ap = Path(artifact).resolve()
      if ap.exists(): target_roots.append(ap.parent)
    for tr in target_roots:
      if not tr.exists(): continue
      manifest = walk_manifest(tr)
      (tr / ".manifest.json").write_text(json.dumps(manifest, indent=2), encoding="utf-8")
      lock = {
        "name": name, "root": tr.as_posix(),
        "generated_at": datetime.now(timezone.utc).strftime(ISO),
        "root_sha256": sha256_file(tr / ".manifest.json"),
        "policy": {"immutable_companions": True, "drift_tolerance": 0.0, "tier": "Tier-1++"}
      }
      (tr / ".codex.lock.json").write_text(json.dumps(lock, indent=2), encoding="utf-8")
      test_sh = tr / ".manifest.test.sh"
      test_sh.write_text("""#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")" && pwd)"
python3 - <<'PY'
import json, hashlib, pathlib, sys, os
root = pathlib.Path(ROOT).resolve()
m = json.loads((root/".manifest.json").read_text())
ok = True
for it in m["items"]:
    p = root / it["path"]
    if not p.exists():
        print("MISSING:", it["path"]); ok=False; continue
    h=hashlib.sha256()
    with p.open("rb") as f:
        for chunk in iter(lambda:f.read(1024*1024), b""):
            h.update(chunk)
    if h.hexdigest()!=it["sha256"]:
        print("MISMATCH:", it["path"]); ok=False
if not ok: sys.exit(1)
print("OK")
PY
""", encoding="utf-8")
      os.chmod(str(test_sh), os.stat(str(test_sh)).st_mode | stat.S_IEXEC)
    return True
