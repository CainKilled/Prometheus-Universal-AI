
## Releases and signing
Local:
```bash
export VAULTTIME_KEY="your-strong-secret"
export VERSION="v1.0.0"
make release
# Artifacts at dist/releases/$VERSION
```

GitHub Actions:
- Add repository secrets:
  - VAULTTIME_KEY (required)
  - COSIGN_PRIVATE_KEY (base64, optional) and COSIGN_PASSWORD (optional)
  - GPG_PRIVATE_KEY (base64, optional) and GPG_PASSPHRASE (optional)
- Push a tag v1.2.3 or run the Release workflow with version=v1.2.3.


## Docker publishing
Local (build & push all Dockerfiles):
```bash
export VERSION=v1.0.0
export DOCKER_REGISTRY=ghcr.io
export DOCKER_NAMESPACE=<your-gh-username-or-org>
./tools/docker_publish.sh
```

GitHub:
- Push a tag (`v*`) or dispatch **Docker Publish** workflow.
- Ensure repository has `packages: write` permission (default for GHCR via GITHUB_TOKEN).
- Optional: set `COSIGN_PRIVATE_KEY`/`COSIGN_PASSWORD` secrets to sign images.

## libmobile app
```bash
# Compose
cd apps/libmobile/infra
docker compose up --build

# API health
curl http://localhost:8000/health

# Web UI
open http://localhost:8080   # or start your browser
```


## Armada ops
- **Docker (multi-registry):**
  - Secrets for Docker Hub in GitHub: `DOCKERHUB_USERNAME`, `DOCKERHUB_TOKEN`
  - Local: `DOCKER_REGISTRIES=ghcr.io,docker.io DOCKER_NAMESPACE=<ns> VERSION=v1.0.0 ./tools/docker_publish.sh`
- **Kubernetes (Helm):**
  - Set `KUBECONFIG_BASE64` secret. Run CD workflow `CD - libmobile k8s` with `version` matching your image tag.
- **SBOM & Security:**
  - `sbom.yml` produces SPDX SBOM, `security-scan` runs Grype. Results uploaded as artifacts.
- **SLSA provenance:**
  - `slsa-provenance.yml` attaches provenance when Release workflow completes.

## Mobile clients
- Flutter client: `clients/libmobile/flutter` (see README)
- React Native (Expo): `clients/libmobile/react-native` (see README)


## Prometheus Linux Terminal
```bash
python -m pip install -r apps/prometheus-terminal/requirements.txt
python apps/prometheus-terminal/main.py
```

## Prometheus ChatGPT
```bash
# local echo mode (no external calls)
cd apps/prometheus-chatgpt/infra
docker compose up --build
# Web: http://localhost:9090  API: http://localhost:9000/health

# OpenAI mode
export CHAT_PROVIDER=openai
export OPENAI_API_KEY=sk-...
export OPENAI_MODEL=gpt-4o-mini
cd apps/prometheus-chatgpt/infra && docker compose up --build
```

## Prometheus Windows
- PowerShell module under `apps/prometheus-windows/Prometheus.Windows`
- See README for service install/management.
```powershell
Import-Module .\apps\prometheus-windows\Prometheus.Windows\Prometheus.Windows.psd1
Install-PrometheusService -RepoPath "$env:USERPROFILE\prometheus_supermonorepo_v2_PRO" -ProjectIndex 0
Start-PrometheusService -ProjectIndex 0
```

## Prometheus Swift
```bash
cd clients/prometheus-swift
swift build && swift test
API_BASE=http://localhost:8000 swift run prometheus-cli
```


## proctl: extended commands
```bash
# Lint / Test / Verify
python tools/proctl.py lint
python tools/proctl.py test
python tools/proctl.py verify

# Release
python tools/proctl.py release --version v1.2.3

# Docker publish
python tools/proctl.py docker-publish --version v1.2.3 --namespace <ns> --registries ghcr.io,docker.io --platforms linux/amd64,linux/arm64

# Helm deploy (libmobile chart example)
python tools/proctl.py helm-deploy --chart apps/libmobile/helm/libmobile --namespace libmobile --release libmobile --image-registry ghcr.io --image-namespace <ns> --image-version v1.2.3
```
