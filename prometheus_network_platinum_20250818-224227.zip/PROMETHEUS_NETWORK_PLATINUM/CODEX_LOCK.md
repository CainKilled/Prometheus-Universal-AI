# Codex Lock
Immutable manifest + integrity controls.
