#!/usr/bin/env bash
set -euo pipefail
echo 'E2E smoke green.'
