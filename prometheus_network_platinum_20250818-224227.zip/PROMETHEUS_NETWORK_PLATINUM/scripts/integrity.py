
import argparse, json, hashlib, pathlib, time
def sha(p):
    h=hashlib.sha256()
    with open(p,'rb') as f:
        for b in iter(lambda:f.read(1<<20), b''): h.update(b)
    return h.hexdigest()
ap=argparse.ArgumentParser(); ap.add_argument('--root',required=True); ap.add_argument('--out',required=True)
a=ap.parse_args(); root=pathlib.Path(a.root).resolve()
manifest={'generated_at':time.strftime('%Y-%m-%dT%H:%M:%SZ'), 'algorithm':'SHA-256','files':[]}
for p in sorted(root.rglob('*')):
    if p.is_file() and '.backups' not in p.parts:
        manifest['files'].append({'path':p.relative_to(root).as_posix(),'sha256':sha(p),'size':p.stat().st_size})
pathlib.Path(a.out).write_text(json.dumps(manifest,indent=2)); print('OK:',a.out)
