"""
Prometheus OS Helpers
=====================

This module contains simple helper functions that abstract over the
operating system. It is **not** a full operating system; rather it
provides utilities for file management, process execution and basic
network requests. These helpers are used by the Prometheus Kernel and
other modules to perform common tasks in a consistent way.

Functions included:

* ``run_command`` – Run a shell command and return its output and exit code.
* ``list_dir`` – List files and directories within a given path.
* ``read_file`` – Read the contents of a text file.
* ``write_file`` – Write text content to a file, creating parent
  directories as needed.
* ``http_get`` – Perform a simple HTTP GET request using urllib.

These functions wrap built‑in Python modules and capture exceptions,
returning error messages instead of raising.

Developed and maintained by Adam Henry Nagle. Contact: 603‑384‑8949,
cainkilledabrl@icloud.com, nagleadam75@gmail.com.
"""

from __future__ import annotations

import os
import subprocess
import urllib.request
from pathlib import Path
from typing import Tuple, List, Dict, Any


def run_command(cmd: List[str] | str, cwd: str | None = None, shell: bool = False) -> Dict[str, Any]:
    """Execute a command and return a dict with output and exit code.

    Args:
        cmd: The command to run. Can be a list of arguments or a string
            when ``shell=True``.
        cwd: The working directory to run the command in.
        shell: Whether to execute through the shell. Defaults to False.

    Returns:
        A dict with keys ``output`` (str) and ``exit_code`` (int). If
        an exception occurs, ``error`` will contain the exception message.
    """
    try:
        result = subprocess.run(cmd, cwd=cwd, shell=shell, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True)
        return {"output": result.stdout, "exit_code": result.returncode}
    except Exception as exc:
        return {"error": str(exc), "exit_code": -1, "output": ""}


def list_dir(path: str | Path) -> Dict[str, Any]:
    """List the contents of a directory. Returns names sorted alphabetically.
    If the directory does not exist, ``error`` will be set.
    """
    try:
        p = Path(path)
        if not p.exists() or not p.is_dir():
            return {"error": f"{path} is not a directory"}
        return {"items": sorted([item.name for item in p.iterdir()])}
    except Exception as exc:
        return {"error": str(exc)}


def read_file(path: str | Path) -> Dict[str, Any]:
    """Read a text file. Returns a dict with ``content`` or ``error``.
    """
    try:
        p = Path(path)
        with p.open('r', encoding='utf-8') as f:
            content = f.read()
        return {"content": content}
    except Exception as exc:
        return {"error": str(exc)}


def write_file(path: str | Path, content: str) -> Dict[str, Any]:
    """Write text content to a file, creating parent directories as needed.
    Returns a dict with ``ok`` set to True on success or ``error`` on failure.
    """
    try:
        p = Path(path)
        p.parent.mkdir(parents=True, exist_ok=True)
        with p.open('w', encoding='utf-8') as f:
            f.write(content)
        return {"ok": True}
    except Exception as exc:
        return {"error": str(exc)}


def http_get(url: str, timeout: int = 10) -> Dict[str, Any]:
    """Perform a simple HTTP GET request. Returns dict with ``body`` or ``error``.
    Uses urllib.request to avoid external dependencies.
    """
    try:
        with urllib.request.urlopen(url, timeout=timeout) as response:
            body = response.read().decode('utf-8', errors='ignore')
        return {"body": body, "status": 200}
    except Exception as exc:
        return {"error": str(exc)}


def copy_file(src: str | Path, dst: str | Path) -> Dict[str, Any]:
    """Copy a file from ``src`` to ``dst``. Returns ok/error status."""
    import shutil
    try:
        shutil.copy2(src, dst)
        return {"ok": True}
    except Exception as exc:
        return {"error": str(exc)}


def move_file(src: str | Path, dst: str | Path) -> Dict[str, Any]:
    """Move a file or directory from ``src`` to ``dst``. Returns ok/error status."""
    import shutil
    try:
        shutil.move(src, dst)
        return {"ok": True}
    except Exception as exc:
        return {"error": str(exc)}


def delete(path: str | Path) -> Dict[str, Any]:
    """Delete a file or directory. Directories are removed recursively."""
    import shutil
    p = Path(path)
    try:
        if p.is_dir():
            shutil.rmtree(p)
        else:
            p.unlink()
        return {"ok": True}
    except Exception as exc:
        return {"error": str(exc)}


def disk_usage(path: str | Path = '/') -> Dict[str, Any]:
    """Return disk usage statistics for the given path."""
    import shutil
    try:
        total, used, free = shutil.disk_usage(str(path))
        return {"total": total, "used": used, "free": free}
    except Exception as exc:
        return {"error": str(exc)}


def process_list() -> Dict[str, Any]:
    """Return a list of running processes (pid and command)."""
    try:
        result = subprocess.run(['ps', '-eo', 'pid,comm'], stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True)
        lines = result.stdout.strip().split('\n')[1:]  # Skip header
        procs = []
        for line in lines:
            parts = line.strip().split(None, 1)
            if len(parts) == 2:
                pid, cmd = parts
                procs.append({'pid': int(pid), 'command': cmd})
        return {"processes": procs}
    except Exception as exc:
        return {"error": str(exc)}


def get_env(var: str) -> Dict[str, Any]:
    """Get an environment variable. Returns {'value': value} or {'error': ...}."""
    try:
        return {"value": os.environ.get(var)}
    except Exception as exc:
        return {"error": str(exc)}


def set_env(var: str, value: str) -> Dict[str, Any]:
    """Set an environment variable. Returns {'old_value': old_value} on success or error."""
    try:
        old = os.environ.get(var)
        os.environ[var] = value
        return {"old_value": old}
    except Exception as exc:
        return {"error": str(exc)}


def http_post(url: str, data: Any, headers: Dict[str, str] | None = None, timeout: int = 10) -> Dict[str, Any]:
    """Perform a simple HTTP POST request with JSON body."""
    try:
        import json as _json
        payload = _json.dumps(data).encode('utf-8')
        req = urllib.request.Request(url, data=payload, headers=headers or {'Content-Type': 'application/json'}, method='POST')
        with urllib.request.urlopen(req, timeout=timeout) as response:
            body = response.read().decode('utf-8', errors='ignore')
        return {"body": body, "status": 200}
    except Exception as exc:
        return {"error": str(exc)}
