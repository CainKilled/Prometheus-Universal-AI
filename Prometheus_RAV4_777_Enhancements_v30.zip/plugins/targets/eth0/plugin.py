"""
Ethernet Plugin
===============

Expose the Eth0 engine for basic wired network operations.  Supported
actions include ``status``, ``info``, ``enable`` and ``disable``.
See :mod:`engines.eth0_engine` for details.

Developed and maintained by Adam Henry Nagle.  Contact: 603‑384‑8949,
cainkilledabrl@icloud.com, nagleadam75@gmail.com.
"""

from __future__ import annotations

from typing import Dict, Any

from engines.eth0_engine import Eth0Engine
from plugins.api.plugin_base import Plugin


class Eth0Plugin:
    def metadata(self) -> Dict[str, Any]:
        return {
            'name': 'eth0',
            'version': '0.1.0',
            'description': 'Manage the eth0 network interface.',
            'targets': ['network'],
        }

    def activate(self, runtime: Dict[str, Any]) -> Dict[str, Any] | None:
        engine = Eth0Engine()
        return engine.run(runtime)


def get_plugin() -> Plugin:
    return Eth0Plugin()  # type: ignore[return-value]