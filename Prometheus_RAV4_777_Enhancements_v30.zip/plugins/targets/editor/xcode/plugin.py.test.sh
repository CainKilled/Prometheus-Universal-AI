#!/bin/bash
python -c "import plugins.targets.editor.xcode.plugin; print('plugin OK')"
