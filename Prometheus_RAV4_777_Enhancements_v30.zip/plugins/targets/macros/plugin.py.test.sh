#!/usr/bin/env bash
# Test script for MacrosPlugin

python - <<'PY'
import sys
import os
sys.path.append('Prometheus_RAV4_777_Enhancements')
from plugins.targets.macros.plugin import get_plugin
from engines.macros_engine import MacrosEngine

plugin = get_plugin()
assert plugin.metadata()['name'] == 'macros'

# Ensure macros directory exists and create a sample macro for testing
base_dir = 'Prometheus_RAV4_777_Enhancements'
macros_dir = os.path.join(base_dir, 'macros')
os.makedirs(macros_dir, exist_ok=True)
sample_macro_path = os.path.join(macros_dir, 'test_macro.json')
with open(sample_macro_path, 'w', encoding='utf-8') as f:
    f.write('{"name": "test_macro", "steps": [{"type": "shell", "cmd": "echo test macro"}]}')

# List macros
result = plugin.activate({'action': 'list', 'log': lambda *args, **kwargs: None})
assert 'test_macro' in result['macros']

# Run macro using dummy kernel
res = plugin.activate({'action': 'run', 'name': 'test_macro', 'log': lambda *a, **k: None})
assert res['ok'] is True
print("macros plugin OK")
PY