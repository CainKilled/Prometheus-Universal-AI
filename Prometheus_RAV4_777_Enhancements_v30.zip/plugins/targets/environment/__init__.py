"""
Environment plugin package
-------------------------

This package contains the environment plugin for the Prometheus
runtime. The plugin exposes the environment engine through the
plugin manager, allowing users to list environment definitions,
inspect them and scaffold new projects from templates.

Developed and maintained by Adam Henry Nagle. Contact: 603‑384‑8949,
cainkilledabrl@icloud.com, nagleadam75@gmail.com.
"""