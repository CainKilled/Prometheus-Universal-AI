#!/bin/bash
# Smoke test for theme plugin
python - <<'PY'
import sys
sys.path.insert(0, 'Prometheus_RAV4_777_Enhancements')
from plugins.targets.theme.plugin import get_plugin
p = get_plugin()
assert p.metadata()['name'] == 'theme'
print('theme plugin OK')
PY