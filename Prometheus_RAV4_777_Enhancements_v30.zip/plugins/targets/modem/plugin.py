"""
Modem Plugin
============

Expose the Modem engine to query and control modems.  Supported
actions are ``info``, ``connect``, ``disconnect`` and ``status``.
See :mod:`engines.modem_engine` for details.

Developed and maintained by Adam Henry Nagle.  Contact: 603‑384‑8949,
cainkilledabrl@icloud.com, nagleadam75@gmail.com.
"""

from __future__ import annotations

from typing import Dict, Any

from engines.modem_engine import ModemEngine
from plugins.api.plugin_base import Plugin


class ModemPlugin:
    def metadata(self) -> Dict[str, Any]:
        return {
            'name': 'modem',
            'version': '0.1.0',
            'description': 'Query and control cellular modems (stub).',
            'targets': ['network'],
        }

    def activate(self, runtime: Dict[str, Any]) -> Dict[str, Any] | None:
        engine = ModemEngine()
        return engine.run(runtime)


def get_plugin() -> Plugin:
    return ModemPlugin()  # type: ignore[return-value]