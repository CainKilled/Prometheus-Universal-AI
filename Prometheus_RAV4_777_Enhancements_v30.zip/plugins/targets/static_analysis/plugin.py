"""
Static Analysis Plugin
======================

This plugin exposes the Static Analysis engine to the Prometheus runtime.
It checks Python files for syntax errors and risky patterns such as
``eval``, ``exec``, ``os.system`` and the use of ``subprocess`` with
``shell=True``.  Users can customise the patterns to search for by
supplying a comma‑separated list in the runtime parameters.

Runtime parameters:

``root`` (str)
    Directory to scan.  Defaults to the current working directory.
``patterns`` (str)
    Optional comma‑separated patterns to search for.  Defaults to the
    engine’s built‑in list.
``log`` (callable)
    Optional logger for status messages.  Defaults to ``print``.

Developed and maintained by Adam Henry Nagle.  Contact: 603‑384‑8949,
cainkilledabrl@icloud.com, nagleadam75@gmail.com.
"""

from __future__ import annotations

from typing import Dict, Any

from engines.static_analysis_engine import StaticAnalysisEngine
from plugins.api.plugin_base import Plugin


class StaticAnalysisPlugin:
    def metadata(self) -> Dict[str, Any]:
        return {
            'name': 'static_analysis',
            'version': '0.1.0',
            'description': 'Run lightweight static analysis on Python files.',
            'targets': ['quality', 'maintenance'],
        }

    def activate(self, runtime: Dict[str, Any]) -> Dict[str, Any] | None:
        root = runtime.get('root')
        patterns_raw = runtime.get('patterns')
        log = runtime.get('log', print)
        patterns = None
        if patterns_raw:
            # split by comma and strip whitespace
            patterns = [p.strip() for p in patterns_raw.split(',') if p.strip()]
        engine = StaticAnalysisEngine()
        return engine.run({'root': root, 'patterns': patterns, 'log': log})


def get_plugin() -> Plugin:
    return StaticAnalysisPlugin()  # type: ignore[return-value]