#!/usr/bin/env bash
# Test script for ModesPlugin

python - <<'PY'
import sys
sys.path.append('Prometheus_RAV4_777_Enhancements')
from plugins.targets.modes.plugin import get_plugin

plugin = get_plugin()
assert plugin.metadata()['name'] == 'modes'
# List modes
result = plugin.activate({'action': 'list', 'log': lambda *args, **kwargs: None})
assert 'developer' in result
# Set mode and get
plugin.activate({'action': 'set', 'mode': 'developer', 'log': lambda *args, **kwargs: None})
res = plugin.activate({'action': 'get', 'log': lambda *args, **kwargs: None})
assert res['mode'] == 'developer'
print("modes plugin OK")
PY