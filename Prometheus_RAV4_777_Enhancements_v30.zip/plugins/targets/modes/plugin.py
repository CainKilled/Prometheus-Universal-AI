"""
Modes Plugin
============

This plugin exposes a simple interface to manage and query the
Prometheus runtime's operating mode.  It wraps the
``ModesEngine`` to list available modes, retrieve the current mode,
or set a new one.  Use this plugin to switch between contexts such as
``developer``, ``designer`` or ``engineer`` to change how the system
behaves.

Runtime parameters:

    action (str): One of ``list``, ``get`` or ``set``.  Defaults to ``get``.
    mode (str):   Mode name when ``action`` is ``set``.
    log (callable): Optional logger for status messages.

Example:

    # List all modes
    kernel.run_plugin('modes', {'action': 'list'})
    # Set mode to designer
    kernel.run_plugin('modes', {'action': 'set', 'mode': 'designer'})
    # Get current mode
    kernel.run_plugin('modes', {'action': 'get'})

Developed and maintained by Adam Henry Nagle.  Contact: 603‑384‑8949,
cainkilledabrl@icloud.com, nagleadam75@gmail.com.
"""

from __future__ import annotations

from typing import Any, Dict

from engines.modes_engine import ModesEngine
from plugins.api.plugin_base import Plugin


class ModesPlugin:
    def metadata(self) -> Dict[str, Any]:
        return {
            'name': 'modes',
            'version': '0.1.0',
            'description': 'Manage the runtime operating mode (developer, designer, etc.)',
            'targets': ['core'],
        }

    def activate(self, runtime: Dict[str, Any]) -> Dict[str, Any] | None:
        action: str = runtime.get('action', 'get').lower()
        mode = runtime.get('mode')
        log = runtime.get('log', print)
        engine = ModesEngine()
        if action == 'list':
            modes = engine.list_modes()
            log(f"Available modes: {', '.join(modes.keys())}")
            return modes
        if action == 'get':
            current = engine.get_mode()
            log(f"Current mode: {current}")
            return {'mode': current}
        if action == 'set':
            if not mode:
                log("ModesPlugin: 'mode' parameter is required for set action")
                return {'error': "'mode' is required"}
            try:
                engine.set_mode(mode)
                log(f"Mode set to {mode}")
                return {'mode': mode}
            except ValueError as exc:
                log(f"ModesPlugin: {exc}")
                return {'error': str(exc)}
        log(f"ModesPlugin: Unknown action '{action}'")
        return {'error': f"Unknown action '{action}'"}


def get_plugin() -> Plugin:
    return ModesPlugin()  # type: ignore[return-value]