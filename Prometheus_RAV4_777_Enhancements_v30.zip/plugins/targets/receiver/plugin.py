"""
Receiver Plugin
===============

Expose the Receiver engine for listening to incoming TCP connections.
Supported actions are ``start``, ``stop`` and ``status``.  See
:mod:`engines.receiver_engine` for details.

Developed and maintained by Adam Henry Nagle.  Contact: 603‑384‑8949,
cainkilledabrl@icloud.com, nagleadam75@gmail.com.
"""

from __future__ import annotations

from typing import Dict, Any

from engines.receiver_engine import ReceiverEngine
from plugins.api.plugin_base import Plugin


class ReceiverPlugin:
    def __init__(self) -> None:
        # Keep a single engine instance to preserve listener state across calls
        self.engine = ReceiverEngine()

    def metadata(self) -> Dict[str, Any]:
        return {
            'name': 'receiver',
            'version': '0.1.0',
            'description': 'Start and stop a TCP receiver.',
            'targets': ['network'],
        }

    def activate(self, runtime: Dict[str, Any]) -> Dict[str, Any] | None:
        return self.engine.run(runtime)


def get_plugin() -> Plugin:
    return ReceiverPlugin()  # type: ignore[return-value]