#!/bin/bash
python -c "import plugins.targets.external.plugin; print('plugin OK')"
