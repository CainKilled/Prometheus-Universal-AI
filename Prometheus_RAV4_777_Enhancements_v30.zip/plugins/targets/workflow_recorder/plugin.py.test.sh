#!/usr/bin/env bash
# Test script for workflow recorder plugin
set -e
cd "$(dirname "$0")/../../.."  # navigate to project root

PYTHONPATH=. python3 - <<'PY'
from plugins.targets.workflow_recorder.plugin import WorkflowRecorderPlugin
import os, json, time

plugin = WorkflowRecorderPlugin()
runtime = {"task_name": "plugin_test", "actions": ["stepA", "stepB"], "root": "."}
result = plugin.activate(runtime)
assert result["status"] == "ok"
record_path = result["record_file"]
assert os.path.isfile(record_path), f"Plugin did not create record file {record_path}"
with open(record_path, 'r', encoding='utf-8') as f:
    data = json.load(f)
assert data['task_name'] == 'plugin_test'
assert data['actions'] == ["stepA", "stepB"]
print('workflow_recorder plugin test passed')
PY