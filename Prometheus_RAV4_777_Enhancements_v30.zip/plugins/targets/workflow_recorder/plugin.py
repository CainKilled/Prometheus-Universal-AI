"""
Workflow Recorder Plugin
=======================

This plugin provides access to the :class:`~engines.workflow_recorder_engine.WorkflowRecorderEngine`
through the Prometheus runtime.  It allows callers to record a named task and
its associated actions to disk for later automation.  Actions should be passed
as JSON‑serialisable objects (strings, dictionaries, lists, etc.).  The plugin
returns the relative path to the newly created record file.

The plugin expects the following keys in the ``runtime`` dictionary passed
by the plugin manager:

``task_name``
    A string naming the task being recorded.
``actions``
    A list of actions representing the steps taken during the task.
``root``
    (Optional) The base directory of the repository.  Defaults to ``.``.

Developer
---------

Authored by Adam Henry Nagle.  Contact: cainkilledabrl@icloud.com,
nagleadam75@gmail.com, phone 603‑384‑8949.
"""

from __future__ import annotations

from typing import Any, Dict

from engines.workflow_recorder_engine import WorkflowRecorderEngine


class WorkflowRecorderPlugin:
    """Plugin wrapper around :class:`WorkflowRecorderEngine`.

    This plugin simply instantiates the engine and forwards the call to
    :meth:`WorkflowRecorderEngine.run`.  It exposes a small number of metadata
    attributes used by the plugin manager to register and describe the plugin.
    """

    name = "workflow_recorder"
    version = "0.1.0"
    description = "Record workflows (task actions) to JSON files."

    def activate(self, runtime: Dict[str, Any]) -> Dict[str, Any]:
        """Entry point called by the plugin manager.

        Parameters
        ----------
        runtime: Dict[str, Any]
            A dictionary containing runtime parameters.  Expected keys are
            ``task_name`` (str), ``actions`` (list) and optional ``root`` (str).

        Returns
        -------
        Dict[str, Any]
            Result from :meth:`WorkflowRecorderEngine.run`.
        """
        task_name = runtime.get("task_name")
        actions = runtime.get("actions", [])
        base_dir = runtime.get("root", ".")
        engine = WorkflowRecorderEngine(base_dir=base_dir)
        return engine.run(task_name=task_name, actions=actions, runtime=runtime)


def get_plugin() -> WorkflowRecorderPlugin:
    """Factory function used by the plugin manager to retrieve the plugin class."""
    return WorkflowRecorderPlugin()