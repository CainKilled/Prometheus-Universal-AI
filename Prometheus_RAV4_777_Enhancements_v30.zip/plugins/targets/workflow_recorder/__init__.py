"""Workflow recorder plugin package.

This package exposes the workflow recorder plugin, which allows tasks to be
recorded into JSON files for later automation.  See `plugin.py` for the
implementation details.

Owned and maintained by Adam Henry Nagle (cainkilledabrl@icloud.com, nagleadam75@gmail.com).
"""

from .plugin import get_plugin  # noqa: F401