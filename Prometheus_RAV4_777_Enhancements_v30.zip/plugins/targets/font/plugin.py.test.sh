#!/bin/bash
# Smoke test for font plugin
python - <<'PY'
import sys
sys.path.insert(0, 'Prometheus_RAV4_777_Enhancements')
from plugins.targets.font.plugin import get_plugin
p = get_plugin()
assert p.metadata()['name'] == 'font'
print('font plugin OK')
PY