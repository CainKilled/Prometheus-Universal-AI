"""
Font Plugin
===========

This plugin wraps the Font engine allowing users to list available font
files packaged with the application.  At present it scans the
``webapp/assets/fonts`` directory for TrueType and OpenType fonts.

Runtime parameters:

``root`` (str)
    Optional root directory.  Defaults to the current working directory.
``log`` (callable)
    Optional logger for status messages.  Defaults to ``print``.

Developed and maintained by Adam Henry Nagle.  Contact: 603‑384‑8949,
cainkilledabrl@icloud.com, nagleadam75@gmail.com.
"""

from __future__ import annotations

from typing import Dict, Any

from engines.font_engine import FontEngine
from plugins.api.plugin_base import Plugin


class FontPlugin:
    def metadata(self) -> Dict[str, Any]:
        return {
            'name': 'font',
            'version': '0.1.0',
            'description': 'List bundled font files.',
            'targets': ['ui'],
        }

    def activate(self, runtime: Dict[str, Any]) -> Dict[str, Any] | None:
        root = runtime.get('root')
        log = runtime.get('log', print)
        engine = FontEngine()
        return engine.run({'root': root, 'log': log})


def get_plugin() -> Plugin:
    return FontPlugin()  # type: ignore[return-value]