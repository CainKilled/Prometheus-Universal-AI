"""
Shader Plugin
=============

Expose the Shader engine to validate and stub compile GLSL/HLSL
shaders.  Supported actions are ``validate``, ``compile`` and
``run``.  See :mod:`engines.shader_engine` for details.

Developed and maintained by Adam Henry Nagle.  Contact: 603‑384‑8949,
cainkilledabrl@icloud.com, nagleadam75@gmail.com.
"""

from __future__ import annotations

from typing import Dict, Any

from engines.shader_engine import ShaderEngine
from plugins.api.plugin_base import Plugin


class ShaderPlugin:
    def metadata(self) -> Dict[str, Any]:
        return {
            'name': 'shader',
            'version': '0.1.0',
            'description': 'Validate and stub compile shader code.',
            'targets': ['graphics'],
        }

    def activate(self, runtime: Dict[str, Any]) -> Dict[str, Any] | None:
        engine = ShaderEngine()
        return engine.run(runtime)


def get_plugin() -> Plugin:
    return ShaderPlugin()  # type: ignore[return-value]