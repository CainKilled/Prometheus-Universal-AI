#!/bin/bash
python -c "import plugins.targets.swarm.plugin; print('plugin OK')"
