"""
Manifest Generator Plugin
=========================

This plugin exposes the Manifest & Test Generator engine to the Prometheus
runtime.  It allows users to automatically create missing manifest and test
files for engines and plugins across the project.  This helps maintain
consistency and reduces manual bookkeeping when adding new modules.

Runtime parameters:

``kind`` (str)
    Optional filter for what to generate.  Accepted values are
    ``engines``, ``plugins`` and ``all`` (default).  When set to
    ``engines`` only engine modules are processed; when ``plugins`` only
    plugin modules are processed.
``root`` (str)
    The root directory to scan.  Defaults to the current working directory.
``log`` (callable)
    Optional logger for status messages.  Defaults to ``print``.

Developed and maintained by Adam Henry Nagle.  Contact: 603‑384‑8949,
cainkilledabrl@icloud.com, nagleadam75@gmail.com.
"""

from __future__ import annotations

from typing import Dict, Any

from engines.manifest_engine import ManifestEngine
from plugins.api.plugin_base import Plugin


class ManifestPlugin:
    def metadata(self) -> Dict[str, Any]:
        return {
            'name': 'manifest',
            'version': '0.1.0',
            'description': 'Generate missing manifest and test files for engines and plugins.',
            'targets': ['build', 'maintenance'],
        }

    def activate(self, runtime: Dict[str, Any]) -> Dict[str, Any] | None:
        kind = runtime.get('kind', 'all')
        root = runtime.get('root')
        log = runtime.get('log', print)
        engine = ManifestEngine()
        return engine.run({'kind': kind, 'root': root, 'log': log})


def get_plugin() -> Plugin:
    return ManifestPlugin()  # type: ignore[return-value]