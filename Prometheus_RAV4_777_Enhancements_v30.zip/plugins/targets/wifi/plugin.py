"""
Wi‑Fi Plugin
============

Expose the Wi‑Fi engine for scanning networks and managing
connections.  Supported actions include ``scan``, ``connect``,
``disconnect`` and ``status``.  See :mod:`engines.wifi_engine` for
details.

Developed and maintained by Adam Henry Nagle.  Contact: 603‑384‑8949,
cainkilledabrl@icloud.com, nagleadam75@gmail.com.
"""

from __future__ import annotations

from typing import Dict, Any

from engines.wifi_engine import WifiEngine
from plugins.api.plugin_base import Plugin


class WifiPlugin:
    def metadata(self) -> Dict[str, Any]:
        return {
            'name': 'wifi',
            'version': '0.1.0',
            'description': 'Scan and manage Wi‑Fi networks.',
            'targets': ['network'],
        }

    def activate(self, runtime: Dict[str, Any]) -> Dict[str, Any] | None:
        engine = WifiEngine()
        return engine.run(runtime)


def get_plugin() -> Plugin:
    return WifiPlugin()  # type: ignore[return-value]