#!/bin/bash
python -c "import plugins.targets.databases.sql.plugin; print('plugin OK')"
