#!/bin/bash
python -c "import plugins.targets.mobile.android.plugin; print('plugin OK')"
