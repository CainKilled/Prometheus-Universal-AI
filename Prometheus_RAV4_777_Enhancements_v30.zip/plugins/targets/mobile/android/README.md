# Android Plugin

This directory contains a fully functional plugin for integrating Android
devices and development tools with the Prometheus environment. It wraps
common Android CLI utilities and exposes a simple interface for listing
devices, installing and uninstalling APKs, running shell commands,
rebooting and flashing partitions.

To use the plugin effectively you should install and configure the
following open‑source projects:

* **ADB (Android Debug Bridge)** – Command‑line tool for communicating
  with Android devices. See the official Android documentation for
  installation instructions.
* **Fastboot** – Low‑level tool for flashing bootloaders and firmware.
* **Magisk** – Root solution for customizing Android, if device rooting is
  required. Use responsibly and be aware of warranty implications.

Once these tools are installed, the plugin will automatically locate
them via `shutil.which()` and call them using `subprocess.run()`. No
further modification of `plugin.py` is required. See `plugin.py` for
details.

Supported actions:

* `devices` – List connected devices (`adb devices`).
* `install` – Install an APK to a device (requires `apk` path).
* `uninstall` – Uninstall a package (`package` name required).
* `shell` – Run a shell command on the device (`command` string required).
* `reboot` – Reboot the device.
* `flash` – Flash an image to a partition via Fastboot (`img` and
  `partition` required).
* `magisk` – Run a Magisk CLI command (`magisk_cmd` required).

See the main README for an overview of the plugin system.

## About the Developer

This plugin and accompanying documentation were created by **Adam Henry Nagle**.  
For consulting, support or inquiries, you can reach Adam at:

- **Phone**: 603‑384‑8949  
- **Email**: cainkilledabrl@icloud.com  
- **Email**: nagleadam75@gmail.com