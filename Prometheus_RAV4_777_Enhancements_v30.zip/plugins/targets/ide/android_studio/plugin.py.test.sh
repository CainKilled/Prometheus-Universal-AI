#!/bin/bash
python -c "import plugins.targets.ide.android_studio.plugin; print('plugin OK')"
