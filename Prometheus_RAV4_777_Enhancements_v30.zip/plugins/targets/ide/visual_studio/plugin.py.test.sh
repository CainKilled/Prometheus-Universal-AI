#!/bin/bash
python -c "import plugins.targets.ide.visual_studio.plugin; print('plugin OK')"
