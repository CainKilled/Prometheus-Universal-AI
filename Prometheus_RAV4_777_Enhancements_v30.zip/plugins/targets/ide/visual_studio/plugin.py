"""
Visual Studio Plugin
====================

This plugin scaffolds integration with Microsoft Visual Studio and the
associated MSBuild toolchain. To implement bridging, use the
`devenv` command on Windows to open solutions or build projects, or call
`msbuild` from any platform to compile generated code. The plugin could
also generate `.sln` and `.vcxproj` files based on Prometheus specs.

Developed and maintained by Adam Henry Nagle. Contact: 603‑384‑8949,
cainkilledabrl@icloud.com, nagleadam75@gmail.com.
"""

# Prometheus Codex Lock v1
# This file is part of Prometheus RAV4 777 Enhancements. Do not edit manually.

from typing import Dict, Any
from plugins.api.plugin_base import Plugin


class VisualStudioPlugin:
    def metadata(self) -> Dict[str, Any]:
        """
        Return metadata describing this plugin. The description has been
        updated to reflect that this plugin now calls into the MSBuild and
        Visual Studio command line tools to build, clean or open solutions.
        """
        return {
            "name": "visual_studio",
            "version": "1.0.0",
            "description": "Integration with Microsoft Visual Studio and MSBuild toolchain",
            "targets": ["ide", "visual_studio"],
        }

    def activate(self, runtime: Dict[str, Any]) -> None:
        """
        Execute an action using Visual Studio or MSBuild.

        Supported runtime keys:

            action (str): One of ``build``, ``clean``, ``rebuild``, ``test`` or ``open``.
                Defaults to ``build``.
            solution (str): Path to the .sln file to act upon.
            project (str): Path to a specific project file (.csproj, .vcxproj) for msbuild.
            configuration (str): Build configuration, e.g. ``Debug`` or ``Release`` (default: ``Debug``).
            platform (str): Target platform, e.g. ``Any CPU``, ``x64`` (default: ``Any CPU``).
            log (callable): Optional logger callable.

        The plugin prefers MSBuild if available. On Windows, it falls
        back to ``devenv`` for opening a solution or performing build
        actions. On non‑Windows systems where Visual Studio is unavailable,
        the plugin will attempt to locate ``dotnet`` to build .NET
        solutions or projects.
        """
        import subprocess
        import shutil
        import os
        logger = runtime.get("log", print)
        action = str(runtime.get("action", "build")).lower()
        sln = runtime.get("solution")
        project = runtime.get("project")
        configuration = runtime.get("configuration", "Debug")
        platform = runtime.get("platform", "Any CPU")
        # Helper to execute a command
        def run_cmd(cmd: list[str], cwd: str | None = None) -> None:
            try:
                logger(f"VisualStudioPlugin: Running {' '.join(cmd)}")
                result = subprocess.run(cmd, cwd=cwd, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True)
                logger(result.stdout.rstrip())
                if result.returncode != 0:
                    logger(f"VisualStudioPlugin: Command exited with code {result.returncode}")
            except Exception as exc:
                logger(f"VisualStudioPlugin: Error executing {' '.join(cmd)}: {exc}")
        # Choose MSBuild executable
        msbuild = shutil.which("msbuild")
        devenv = shutil.which("devenv")
        dotnet = shutil.which("dotnet")
        # Determine target file
        target = sln or project
        if not target and action != "open":
            logger("VisualStudioPlugin: Either 'solution' or 'project' must be provided")
            return
        # Normalise path for logging
        if target:
            target_path = os.path.abspath(str(target))
        else:
            target_path = None
        # Opening solution in IDE
        if action == "open":
            if not sln:
                logger("VisualStudioPlugin: 'solution' must be provided for open action")
                return
            if devenv:
                run_cmd([devenv, target_path])
            elif dotnet:
                # dotnet cannot open solutions; just print message
                logger("VisualStudioPlugin: Visual Studio executable not found. Can't open solution.")
            else:
                logger("VisualStudioPlugin: No compatible IDE found to open the solution")
            return
        # Build/clean/test using available tool
        build_args = []
        if msbuild:
            # Use msbuild on the solution or project
            cmd = [msbuild, target_path]
            # Determine MSBuild target based on action
            if action == "clean":
                build_args.append("/t:Clean")
            elif action == "rebuild":
                build_args.append("/t:Rebuild")
            elif action == "test":
                build_args.append("/t:Test")
            # Append configuration and platform
            build_args.append(f"/p:Configuration={configuration}")
            build_args.append(f"/p:Platform={platform}")
            cmd.extend(build_args)
            run_cmd(cmd)
        elif devenv:
            # Fallback to devenv for build/clean actions on Windows
            cmd = [devenv, target_path]
            if action == "clean":
                cmd.extend(["/Clean", configuration])
            elif action == "rebuild":
                cmd.extend(["/Rebuild", configuration])
            elif action == "test":
                # Visual Studio does not provide a generic /Test switch; note to user
                logger("VisualStudioPlugin: 'test' not supported via devenv. Use msbuild or dotnet if available.")
                return
            else:  # build
                cmd.extend(["/Build", configuration])
            run_cmd(cmd)
        elif dotnet and target_path and target_path.endswith(('.sln', '.csproj')):
            # Use dotnet build for .NET solutions/projects on cross-platform
            cmd = [dotnet, action if action in {"build", "clean"} else "build", target_path]
            if configuration:
                cmd.extend(["-c", configuration])
            run_cmd(cmd)
        else:
            logger("VisualStudioPlugin: No suitable build tool found (msbuild, devenv, dotnet)")


def get_plugin() -> Plugin:
    return VisualStudioPlugin()  # type: ignore[return-value]