#!/bin/bash
python -c "import plugins.targets.cicd.plugin; print('plugin OK')"
