"""
PyDev Elite Plugin
==================

This plugin integrates the standalone ``pydev_elite_suite.py`` application
into the Prometheus ecosystem.  When activated, the plugin will attempt
to launch the Python development suite as a separate process using the
current Python interpreter.  It logs success or failure to the runtime
logger.  The plugin accepts an optional ``script_path`` in the runtime
context; if provided, this path will be executed instead of the default
``pydev_elite_suite.py`` located in the root of the Prometheus project.

**Note:** Launching the GUI or web components of PyDev Elite may fail
in headless environments.  The plugin handles any exceptions and
reports them via the logger instead of raising.

Developed and maintained by Adam Henry Nagle. Contact: 603‑384‑8949,
cainkilledabrl@icloud.com, nagleadam75@gmail.com.
"""

# Prometheus Codex Lock v1
# This file is part of Prometheus RAV4 777 Enhancements. Do not edit manually.

from typing import Dict, Any
from plugins.api.plugin_base import Plugin
import subprocess
import sys
import os


class PyDevElitePlugin:
    """Concrete plugin to launch the PyDev Elite development suite."""

    def metadata(self) -> Dict[str, Any]:
        return {
            "name": "pydev_elite",
            "version": "1.0.0",
            "description": (
                "Launch the PyDev Elite development environment (GUI/web) "
                "as a subprocess."
            ),
            "targets": ["ide", "dev_suite"],
        }

    def activate(self, runtime: Dict[str, Any]) -> None:
        logger = runtime.get("log", print)
        root = runtime.get("root", os.getcwd())
        script_path = runtime.get("script_path")
        if script_path is None:
            # fall back to the bundled script in the tools directory if present
            default = os.path.join(root, "pydev_elite_suite.py")
            script_path = default
        logger(f"PyDev Elite Plugin: launching script at {script_path}")
        try:
            subprocess.Popen([sys.executable, script_path], cwd=root)
            logger("PyDev Elite launched successfully")
        except Exception as exc:
            logger(f"PyDev Elite launch failed: {exc}")


def get_plugin() -> Plugin:
    """Entry point for the plugin manager.  Return a plugin instance."""
    return PyDevElitePlugin()  # type: ignore[return-value]
