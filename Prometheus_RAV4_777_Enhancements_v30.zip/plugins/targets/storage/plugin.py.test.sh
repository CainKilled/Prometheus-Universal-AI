#!/bin/bash
python -c "import plugins.targets.storage.plugin; print('plugin OK')"
