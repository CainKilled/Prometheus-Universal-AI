"""
Prometheus Unified Command Line Interface
========================================

This script provides a single entry point for interacting with the
Prometheus RAV4 777 enhancements monorepo. It discovers available
plugins, allows users to list and run them, executes declarative
wizard flows, and supports generating new plugin scaffolds via the
tool builder. It also exposes commands for working with templates and
initiating CI/CD pipelines.

Usage:
    python cli.py list
        List all available plugins.

    python cli.py run <plugin> [--key=value ...]
        Run a plugin by name with arbitrary runtime parameters.
        Parameters are passed as key=value pairs; values are treated
        as strings or JSON if they start with ``{"` or ``[``.

    python cli.py flow <flow_file> [--ctxkey=value ...]
        Execute a wizard flow JSON file. Context variables provided
        via ``--ctxkey`` are merged into each step's parameters.

    python cli.py create-plugin --name=my_plugin --category=editor --description="My plugin"
        Generate a new plugin scaffold using the ToolBuilderPlugin.

    python cli.py template list
        List available templates.

    python cli.py template create --from=path/to/project --name=my_template
        Create a template from an existing project.

    python cli.py template generate --name=my_template --out=path/to/output [--var.key=value ...]
        Generate a project skeleton from a template, substituting variables.

    python cli.py cicd --step="echo Hello" --step="pytest -q"
        Run a simple CI/CD pipeline by executing multiple shell steps.

This CLI is intentionally simple; for more complex workflows you can
use the Python API directly or integrate into your own applications.
"""

from __future__ import annotations

import argparse
import json
import os
import sys
from typing import Any, Dict, List, Optional

from plugins.manager import discover_plugins
from plugins.api.plugin_base import Plugin
from plugins.targets.wizard.plugin import WizardPlugin
from plugins.targets.tool_builder.plugin import ToolBuilderPlugin
from plugins.targets.cicd.plugin import CICDPlugin  # type: ignore
from templates.template_db import list_templates, add_template, get_template, delete_template
from templates.builder import generate_from_template, create_template_from_project


def parse_key_values(pairs: List[str]) -> Dict[str, Any]:
    """Parse key=value pairs into a dictionary. Values starting with
    ``{``, ``[``, or ``"`` are parsed as JSON; otherwise they remain strings.
    """
    data: Dict[str, Any] = {}
    for pair in pairs:
        if "=" not in pair:
            raise ValueError(f"Invalid parameter '{pair}', expected key=value")
        key, value = pair.split("=", 1)
        value = value.strip()
        if value.startswith("{") or value.startswith("["):
            try:
                data[key] = json.loads(value)
                continue
            except json.JSONDecodeError:
                pass  # fall back to string
        # Also treat quoted values as strings without quotes
        if (value.startswith("\"") and value.endswith("\"")) or (value.startswith("'") and value.endswith("'")):
            data[key] = value[1:-1]
        else:
            data[key] = value
    return data


def list_plugins(base_dir: str) -> None:
    """Discover and print all plugin names and descriptions."""
    metas = discover_plugins(base_dir)
    print("Available plugins:")
    for meta in metas:
        name = meta.get("name")
        description = meta.get("description", "")
        targets = ", ".join(meta.get("targets", []))
        print(f"- {name} ({targets}): {description}")


def run_plugin(base_dir: str, plugin_name: str, params: Dict[str, Any]) -> None:
    """Load and run a plugin by name with the given parameters."""
    metas = discover_plugins(base_dir)
    target_meta: Optional[Dict[str, Any]] = None
    for meta in metas:
        if meta.get("name") == plugin_name:
            target_meta = meta
            break
    if not target_meta:
        print(f"Plugin '{plugin_name}' not found.")
        return
    plugin_path = os.path.join(base_dir, target_meta.get("path"))
    # Dynamically import plugin module
    try:
        import importlib.util
        spec = importlib.util.spec_from_file_location(f"cli_dyn_{plugin_name}", plugin_path)
        if not spec or not spec.loader:
            raise ImportError(f"Cannot load spec for {plugin_name}")
        mod = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(mod)  # type: ignore[call-arg]
        plugin: Plugin = mod.get_plugin()  # type: ignore[attr-defined]
    except Exception as exc:
        print(f"Failed to import plugin '{plugin_name}': {exc}")
        return
    # Add base_dir to params for relative path resolution
    params = dict(params)
    params.setdefault("log", print)
    params.setdefault("base_dir", base_dir)
    try:
        plugin.activate(params)  # type: ignore[misc]
    except Exception as exc:
        print(f"Error running plugin '{plugin_name}': {exc}")


def run_flow(base_dir: str, flow_file: str, context: Dict[str, Any]) -> None:
    """Execute a wizard flow JSON file via the WizardPlugin."""
    wiz = WizardPlugin()
    runtime: Dict[str, Any] = {
        "root": base_dir,
        "flow": flow_file,
        "ctx": context,
        "log": print,
    }
    wiz.activate(runtime)


def create_plugin(base_dir: str, name: str, category: str, description: str) -> None:
    """Generate a new plugin using the ToolBuilderPlugin."""
    builder = ToolBuilderPlugin()
    runtime = {
        "base_dir": base_dir,
        "plugin_name": name,
        "category": category,
        "description": description,
        "log": print,
    }
    builder.activate(runtime)


def run_cicd(base_dir: str, steps: List[str]) -> None:
    """Run a CI/CD pipeline using the CICDPlugin."""
    cicd = CICDPlugin()  # type: ignore[call-arg]
    runtime = {
        "steps": steps,
        "log": print,
    }
    cicd.activate(runtime)  # type: ignore[misc]


def handle_template(base_dir: str, args: argparse.Namespace) -> None:
    """Handle template-related commands."""
    if args.subcommand == "list":
        names = list_templates()
        print("Templates:")
        for n in names:
            print(f"- {n}")
    elif args.subcommand == "create":
        source = args.source
        name = args.name
        overwrite = args.overwrite
        try:
            create_template_from_project(source, name, overwrite=overwrite)
            print(f"Created template '{name}' from {source}")
        except Exception as exc:
            print(f"Error creating template: {exc}")
    elif args.subcommand == "generate":
        tmpl_name = args.name
        out_dir = args.out
        variables = parse_key_values(args.vars or [])
        try:
            generate_from_template(tmpl_name, out_dir, variables)
            print(f"Generated project from template '{tmpl_name}' into {out_dir}")
        except Exception as exc:
            print(f"Error generating project: {exc}")


def main() -> None:
    base_dir = os.path.dirname(os.path.abspath(__file__))
    parser = argparse.ArgumentParser(description="Prometheus RAV4 777 CLI")
    subparsers = parser.add_subparsers(dest="command")
    # list
    subparsers.add_parser("list", help="List available plugins")
    # run
    run_parser = subparsers.add_parser("run", help="Run a plugin by name")
    run_parser.add_argument("plugin", help="Plugin name to run")
    run_parser.add_argument("params", nargs="*", help="key=value pairs to pass to the plugin")
    # flow
    flow_parser = subparsers.add_parser("flow", help="Run a wizard flow JSON file")
    flow_parser.add_argument("flow_file", help="Path to flow JSON file relative to repo root")
    flow_parser.add_argument("ctx", nargs="*", help="key=value pairs for flow context")
    # create-plugin
    cp_parser = subparsers.add_parser("create-plugin", help="Generate a new plugin scaffold")
    cp_parser.add_argument("--name", required=True, help="Name of the plugin to create (snake_case)")
    cp_parser.add_argument("--category", required=True, help="Category under plugins/targets")
    cp_parser.add_argument("--description", default="Generated plugin", help="Description for the plugin")
    # template subcommands
    tmpl_parser = subparsers.add_parser("template", help="Manage templates")
    tmpl_sub = tmpl_parser.add_subparsers(dest="subcommand", required=True)
    tmpl_sub.add_parser("list", help="List available templates")
    tmpl_create = tmpl_sub.add_parser("create", help="Create a template from a project directory")
    tmpl_create.add_argument("--from", dest="source", required=True, help="Source project directory")
    tmpl_create.add_argument("--name", required=True, help="Template name")
    tmpl_create.add_argument("--overwrite", action="store_true", help="Overwrite if template exists")
    tmpl_gen = tmpl_sub.add_parser("generate", help="Generate a project from a template")
    tmpl_gen.add_argument("--name", required=True, help="Template name")
    tmpl_gen.add_argument("--out", required=True, help="Output directory")
    tmpl_gen.add_argument("--var", dest="vars", action="append", help="Variable substitution (key=value)")
    # cicd
    cicd_parser = subparsers.add_parser("cicd", help="Run a simple CI/CD pipeline")
    cicd_parser.add_argument("--step", dest="steps", action="append", required=True, help="Shell command to execute")
    args = parser.parse_args()
    if args.command == "list":
        list_plugins(base_dir)
    elif args.command == "run":
        params = parse_key_values(args.params)
        run_plugin(base_dir, args.plugin, params)
    elif args.command == "flow":
        ctx = parse_key_values(args.ctx)
        run_flow(base_dir, args.flow_file, ctx)
    elif args.command == "create-plugin":
        create_plugin(base_dir, args.name, args.category, args.description)
    elif args.command == "template":
        handle_template(base_dir, args)
    elif args.command == "cicd":
        run_cicd(base_dir, args.steps)
    else:
        parser.print_help()


if __name__ == "__main__":
    main()