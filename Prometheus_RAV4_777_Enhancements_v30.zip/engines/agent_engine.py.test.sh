#!/bin/bash
python -c "import engines.agent_engine; print('agent_engine OK')"
