#!/bin/bash
# Smoke test for networking_engine
python - <<'PY'
import sys
sys.path.insert(0, 'Prometheus_RAV4_777_Enhancements')
from engines.networking_engine import NetworkingEngine
engine = NetworkingEngine()
assert engine.metadata()['name'] == 'networking'
print('networking_engine OK')
PY