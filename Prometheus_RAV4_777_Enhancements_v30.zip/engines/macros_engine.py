"""
Macros Engine
=============

This engine loads and executes macros defined in JSON files.  A macro
is a named sequence of steps, each of which can either be a shell
command or a call to another plugin.  Macro files should live in the
``macros`` directory under the project root.  Each file must contain
a dictionary with the keys ``name`` and ``steps``.  Steps are
executed in order; shell steps run a command via ``subprocess``, and
plugin steps call into the Prometheus plugin system via the provided
kernel.  The engine returns a list of results for each step along
with a flag indicating whether all steps succeeded.

Macro file format:

```
{
  "name": "hello_world",
  "description": "A simple macro example",
  "steps": [
    {"type": "shell", "cmd": "echo Hello"},
    {"type": "plugin", "plugin": "terminal", "params": {"command": "echo World"}}
  ]
}
```

Developed and maintained by Adam Henry Nagle.  Contact:
603‑384‑8949, cainkilledabrl@icloud.com, nagleadam75@gmail.com.
"""

from __future__ import annotations

import json
import subprocess
import shlex
from pathlib import Path
from typing import Any, Dict, List, Tuple, Optional


class MacrosEngine:
    """Load and execute macros defined in JSON files."""

    def __init__(self, base_dir: Optional[str] = None) -> None:
        if base_dir is None:
            self.base_dir = Path(__file__).resolve().parent
        else:
            self.base_dir = Path(base_dir)
        # Macros are stored in a 'macros' directory relative to base_dir
        self.macros_dir = self.base_dir.parent / "macros"
        self.macros_dir.mkdir(exist_ok=True)

    def list_macros(self) -> List[str]:
        """Return a list of macro names (file stems) present in the macros dir."""
        return [p.stem for p in self.macros_dir.glob("*.json")]

    def load_macro(self, name: str) -> Dict[str, Any]:
        """Load a macro definition by name."""
        path = self.macros_dir / f"{name}.json"
        if not path.exists():
            raise FileNotFoundError(f"Macro file not found: {path}")
        with path.open("r", encoding="utf-8") as f:
            return json.load(f)

    def run_macro(self, name: str, kernel: Any, logger: Any = print) -> Dict[str, Any]:
        """Execute a macro by name using the provided kernel for plugin steps."""
        definition = self.load_macro(name)
        results: List[Dict[str, Any]] = []
        ok = True
        for step in definition.get("steps", []):
            stype = step.get("type")
            if stype == "shell":
                cmd = step.get("cmd")
                if not cmd:
                    results.append({"error": "shell step missing cmd"})
                    ok = False
                    continue
                try:
                    proc = subprocess.run(
                        cmd if step.get("shell", True) else shlex.split(cmd),
                        capture_output=True,
                        text=True,
                        shell=step.get("shell", True),
                    )
                    results.append({"rc": proc.returncode, "out": proc.stdout, "err": proc.stderr})
                    if proc.returncode != 0:
                        ok = False
                except Exception as exc:
                    results.append({"error": str(exc)})
                    ok = False
            elif stype == "plugin":
                plugin_name = step.get("plugin")
                params = step.get("params", {})
                if not plugin_name:
                    results.append({"error": "plugin step missing plugin name"})
                    ok = False
                    continue
                try:
                    res = kernel.run_plugin(plugin_name, params)
                    results.append(res)
                    if isinstance(res, dict) and res.get("error"):
                        ok = False
                except Exception as exc:
                    results.append({"error": str(exc)})
                    ok = False
            else:
                results.append({"error": f"unknown step type {stype}"})
                ok = False
        return {"ok": ok, "results": results}