"""
Utilities Engine
=================

The Utilities Engine offers a collection of basic file and system
operations that may be used throughout the project.  These include
reading and writing text files, copying and moving files, deleting
files or directories and retrieving disk usage statistics.  While
Python’s standard library exposes these functions already, wrapping them
in an engine ensures consistent logging and error handling and makes
them available through the plugin system.

Runtime parameters
------------------

``action`` (str)
    The operation to perform.  Supported actions include:

    * ``read``: Read and return the contents of a text file.  Requires
      ``path``.
    * ``write``: Write text to a file.  Requires ``path`` and ``content``.
    * ``copy``: Copy a file from ``src`` to ``dst``.
    * ``move``: Move a file from ``src`` to ``dst``.
    * ``delete``: Delete a file or directory at ``path``.
    * ``disk_usage``: Return free/used disk space information.

``root`` (str)
    Optional base path used for relative ``path``, ``src`` and ``dst`` values.

Developed and maintained by Adam Henry Nagle.  Contact: 603‑384‑8949,
cainkilledabrl@icloud.com, nagleadam75@gmail.com.
"""

from __future__ import annotations

from pathlib import Path
from typing import Dict, Any
import os
import shutil
import json


class UtilitiesEngine:
    """Engine providing basic file and system utilities."""

    def metadata(self) -> Dict[str, Any]:
        return {
            "name": "utilities",
            "version": "0.1.0",
            "description": "Perform simple file and system operations (read, write, copy, move, delete, disk usage).",
        }

    def run(self, task: Dict[str, Any]) -> Dict[str, Any]:
        action = task.get('action')
        root = Path(task.get('root', os.getcwd())).resolve()
        log = task.get('log', print)
        if not action:
            return {'error': "'action' parameter required"}
        action = action.lower()
        try:
            if action == 'read':
                path = task.get('path')
                if not path:
                    return {'error': "'path' required for read"}
                p = (root / path).resolve() if not os.path.isabs(path) else Path(path)
                content = p.read_text(encoding='utf-8')
                return {'content': content}
            if action == 'write':
                path = task.get('path')
                content = task.get('content', '')
                if not path:
                    return {'error': "'path' required for write"}
                p = (root / path).resolve() if not os.path.isabs(path) else Path(path)
                p.parent.mkdir(parents=True, exist_ok=True)
                p.write_text(content, encoding='utf-8')
                return {'ok': True}
            if action == 'copy':
                src = task.get('src')
                dst = task.get('dst')
                if not src or not dst:
                    return {'error': "'src' and 'dst' required for copy"}
                s = (root / src).resolve() if not os.path.isabs(src) else Path(src)
                d = (root / dst).resolve() if not os.path.isabs(dst) else Path(dst)
                d.parent.mkdir(parents=True, exist_ok=True)
                shutil.copy2(s, d)
                return {'ok': True}
                
            if action == 'move':
                src = task.get('src')
                dst = task.get('dst')
                if not src or not dst:
                    return {'error': "'src' and 'dst' required for move"}
                s = (root / src).resolve() if not os.path.isabs(src) else Path(src)
                d = (root / dst).resolve() if not os.path.isabs(dst) else Path(dst)
                d.parent.mkdir(parents=True, exist_ok=True)
                shutil.move(s, d)
                return {'ok': True}
            if action == 'delete':
                path = task.get('path')
                if not path:
                    return {'error': "'path' required for delete"}
                p = (root / path).resolve() if not os.path.isabs(path) else Path(path)
                if p.is_dir():
                    shutil.rmtree(p)
                else:
                    p.unlink()
                return {'ok': True}
            if action == 'disk_usage':
                usage = shutil.disk_usage(str(root))
                return {'total': usage.total, 'used': usage.used, 'free': usage.free}
            return {'error': f"Unknown action '{action}'"}
        except Exception as exc:
            log(f"UtilitiesEngine: {exc}")
            return {'error': str(exc)}


def get_engine() -> UtilitiesEngine:
    return UtilitiesEngine()