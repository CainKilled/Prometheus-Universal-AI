#!/bin/bash
# Smoke test for router_engine
python - <<'PY'
import sys
sys.path.insert(0, 'Prometheus_RAV4_777_Enhancements')
from engines.router_engine import RouterEngine
engine = RouterEngine()
assert engine.metadata()['name'] == 'router'
print('router_engine OK')
PY