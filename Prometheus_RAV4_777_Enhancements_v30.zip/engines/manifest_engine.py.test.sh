#!/bin/bash
# Smoke test for manifest_engine
python - <<'PY'
import sys
sys.path.insert(0, 'Prometheus_RAV4_777_Enhancements')
from engines.manifest_engine import ManifestEngine
engine = ManifestEngine()
res = engine.metadata()
assert 'name' in res and res['name'] == 'manifest_generator'
print('manifest_engine OK')
PY