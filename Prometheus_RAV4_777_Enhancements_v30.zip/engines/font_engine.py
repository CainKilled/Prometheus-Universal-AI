"""
Font Engine
===========

The Font Engine lists available font resources that can be used in
applications and templates.  It scans the ``webapp/assets/fonts``
directory for TrueType (``.ttf``) and OpenType (``.otf``) fonts and
returns their names.  Future versions could integrate system font
discovery, but this implementation focuses on bundled assets to
maintain portability.

Runtime parameters
------------------

``root`` (str)
    Optional root directory for resolution.  Defaults to current working
    directory.
``log`` (callable)
    Optional logger for status messages.  Defaults to ``print``.

Developed and maintained by Adam Henry Nagle.  Contact: 603‑384‑8949,
cainkilledabrl@icloud.com, nagleadam75@gmail.com.
"""

from __future__ import annotations

from pathlib import Path
from typing import Dict, Any, List
import os


class FontEngine:
    """Engine for listing bundled font files."""

    def metadata(self) -> Dict[str, Any]:
        return {
            "name": "font",
            "version": "0.1.0",
            "description": "List font files under webapp/assets/fonts.",
        }

    def run(self, task: Dict[str, Any]) -> Dict[str, Any]:
        root = Path(task.get('root', os.getcwd())).resolve()
        log = task.get('log', print)
        fonts_dir = root / 'webapp' / 'assets' / 'fonts'
        names: List[str] = []
        if fonts_dir.is_dir():
            for p in fonts_dir.iterdir():
                if p.suffix.lower() in ['.ttf', '.otf']:
                    names.append(p.name)
        log(f"FontEngine: Found {len(names)} fonts")
        return {'fonts': names}


def get_engine() -> FontEngine:
    return FontEngine()