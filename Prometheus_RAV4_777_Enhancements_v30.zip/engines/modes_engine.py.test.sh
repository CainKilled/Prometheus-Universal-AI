#!/bin/bash
python -c "import engines.modes_engine; print('modes_engine OK')"
