#!/bin/bash
# Smoke test for modem_engine
python - <<'PY'
import sys
sys.path.insert(0, 'Prometheus_RAV4_777_Enhancements')
from engines.modem_engine import ModemEngine
engine = ModemEngine()
assert engine.metadata()['name'] == 'modem'
print('modem_engine OK')
PY