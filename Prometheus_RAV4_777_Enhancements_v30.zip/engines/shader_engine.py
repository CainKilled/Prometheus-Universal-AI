"""
Shader Engine
=============

This engine manages generic shader compilation and validation tasks for
graphics applications.  It provides a consistent interface for
processing GLSL/HLSL shader source code.  In this environment, we
cannot compile shaders for a real GPU, so the engine performs basic
syntax checks and returns stubbed results.

Runtime parameters
------------------

``action`` (str)
    Operation to perform.  Supported actions:

    * ``validate`` – Check that a shader file exists and is non‑empty.
    * ``compile`` – Stub compile that returns a hash of the source.
    * ``run`` – Stub run that returns a simulated output.

``source`` (str)
    Path to a shader source file (GLSL/HLSL).  Required for
    ``validate`` and ``compile`` actions.
``log`` (callable)
    Optional logger for status messages.  Defaults to ``print``.

Developed and maintained by Adam Henry Nagle.  Contact: 603‑384‑8949,
cainkilledabrl@icloud.com, nagleadam75@gmail.com.
"""

from __future__ import annotations

from pathlib import Path
from typing import Dict, Any
import hashlib


class ShaderEngine:
    """Engine for validating and stub compiling shader code."""

    def metadata(self) -> Dict[str, Any]:
        return {
            'name': 'shader',
            'version': '0.1.0',
            'description': 'Validate and stub compile GLSL/HLSL shaders.',
        }

    def run(self, runtime: Dict[str, Any]) -> Dict[str, Any]:
        action = (runtime.get('action') or 'validate').lower()
        log = runtime.get('log', print)
        source = runtime.get('source')
        if action in {'validate', 'compile'} and not source:
            return {'error': "'source' parameter required"}
        if action == 'validate':
            path = Path(source)
            if not path.exists():
                return {'valid': False, 'error': f'Source file {source} does not exist'}
            if path.stat().st_size == 0:
                return {'valid': False, 'error': 'Source file is empty'}
            return {'valid': True}
        if action == 'compile':
            path = Path(source)
            if not path.exists():
                return {'error': f'Source file {source} does not exist'}
            code = path.read_text(encoding='utf-8')
            digest = hashlib.sha256(code.encode('utf-8')).hexdigest()
            return {'compiled': True, 'digest': digest}
        if action == 'run':
            # A stub run: return a simple message
            return {'output': 'Shader executed (stub)'}
        return {'error': f"Unknown action '{action}'"}


def get_engine() -> ShaderEngine:
    return ShaderEngine()