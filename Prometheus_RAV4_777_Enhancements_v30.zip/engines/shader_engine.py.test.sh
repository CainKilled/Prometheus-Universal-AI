#!/bin/bash
# Smoke test for shader_engine
python - <<'PY'
import sys
sys.path.insert(0, 'Prometheus_RAV4_777_Enhancements')
from engines.shader_engine import ShaderEngine
engine = ShaderEngine()
assert engine.metadata()['name'] == 'shader'
print('shader_engine OK')
PY