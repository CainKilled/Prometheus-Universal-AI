#!/bin/bash
# Smoke test for static_analysis_engine
python - <<'PY'
import sys
sys.path.insert(0, 'Prometheus_RAV4_777_Enhancements')
from engines.static_analysis_engine import StaticAnalysisEngine
engine = StaticAnalysisEngine()
res = engine.metadata()
assert res['name'] == 'static_analysis'
print('static_analysis_engine OK')
PY