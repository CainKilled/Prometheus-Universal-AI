#!/bin/bash
# Smoke test for utilities_engine
python - <<'PY'
import sys
sys.path.insert(0, 'Prometheus_RAV4_777_Enhancements')
from engines.utilities_engine import UtilitiesEngine
engine = UtilitiesEngine()
assert engine.metadata()['name'] == 'utilities'
print('utilities_engine OK')
PY