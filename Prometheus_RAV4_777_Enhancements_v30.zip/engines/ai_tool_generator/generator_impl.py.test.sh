#!/bin/bash
python -c "import engines.ai_tool_generator.generator_impl; print('generator_impl OK')"
