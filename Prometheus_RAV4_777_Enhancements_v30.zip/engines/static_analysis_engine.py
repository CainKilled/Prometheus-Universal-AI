"""
Static Analysis Engine
======================

This engine performs lightweight static analysis on Python source files to
identify potential issues.  It compiles modules to catch syntax errors and
searches for common risky patterns such as uses of ``eval`` or ``exec``.
Future enhancements could integrate external tools like ``flake8`` or
``pylint``, but this implementation avoids external dependencies and works
solely with the Python standard library.

Runtime parameters
------------------

``root`` (str)
    Directory to scan.  Defaults to the current working directory.
``patterns`` (list[str])
    A list of string patterns to search for within each Python file.  The
    default patterns look for calls to ``eval`` and ``exec`` and uses of
    ``os.system`` or ``subprocess.Popen`` with ``shell=True``.
``log`` (callable)
    Optional logger for status messages.  Defaults to ``print``.

Developed and maintained by Adam Henry Nagle.  Contact: 603‑384‑8949,
cainkilledabrl@icloud.com, nagleadam75@gmail.com.
"""

from __future__ import annotations

from pathlib import Path
import py_compile
import os
from typing import Dict, Any, List


class StaticAnalysisEngine:
    """Engine for simple static analysis of Python files."""

    DEFAULT_PATTERNS = [
        'eval(', 'exec(', 'os.system(', 'subprocess.Popen(', 'shell=True'
    ]

    def metadata(self) -> Dict[str, Any]:
        return {
            "name": "static_analysis",
            "version": "0.1.0",
            "description": "Perform basic static analysis and syntax checking on Python files.",
        }

    def run(self, task: Dict[str, Any]) -> Dict[str, Any]:
        root = Path(task.get('root', os.getcwd())).resolve()
        patterns: List[str] = task.get('patterns', self.DEFAULT_PATTERNS)
        log = task.get('log', print)
        issues: List[Dict[str, Any]] = []
        for py_file in root.rglob('*.py'):
            # Skip files in virtual envs or caches
            if any(part in py_file.parts for part in ['__pycache__', '.venv', '.git']):
                continue
            try:
                py_compile.compile(str(py_file), doraise=True)
            except py_compile.PyCompileError as exc:
                issues.append({'file': str(py_file), 'type': 'syntax', 'message': str(exc)})
                continue
            # Search for patterns
            try:
                source = py_file.read_text(errors='ignore')
            except Exception:
                continue
            for pattern in patterns:
                if pattern in source:
                    line_no = next((i+1 for i, line in enumerate(source.splitlines()) if pattern in line), 0)
                    issues.append({'file': str(py_file), 'type': 'pattern', 'pattern': pattern, 'line': line_no})
        if issues:
            log(f"StaticAnalysisEngine: Found {len(issues)} issues")
        return {'ok': not issues, 'issues': issues}


def get_engine() -> StaticAnalysisEngine:
    return StaticAnalysisEngine()