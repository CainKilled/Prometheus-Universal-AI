#!/bin/bash
# Smoke test for sender_engine
python - <<'PY'
import sys
sys.path.insert(0, 'Prometheus_RAV4_777_Enhancements')
from engines.sender_engine import SenderEngine
engine = SenderEngine()
assert engine.metadata()['name'] == 'sender'
print('sender_engine OK')
PY