#!/usr/bin/env bash
# Test script for workflow_recorder_engine
# This script verifies that the engine can record a simple workflow and writes
# a record file in the expected directory.

set -e
cd "$(dirname "$0")/.."  # Navigate to project root

PYTHONPATH=. python3 - <<'PY'
from engines.workflow_recorder_engine import WorkflowRecorderEngine
import os, json, time

engine = WorkflowRecorderEngine(base_dir='.')
result = engine.run(task_name='test_task', actions=['step1','step2'])
record_path = result['record_file']
assert result['status'] == 'ok', 'Status should be ok'
assert os.path.isfile(record_path), f'Record file {record_path} not found'
with open(record_path, 'r', encoding='utf-8') as f:
    data = json.load(f)
assert data['task_name'] == 'test_task', 'Task name mismatch'
assert data['actions'] == ['step1','step2'], 'Actions mismatch'
print('workflow_recorder_engine test passed')
PY