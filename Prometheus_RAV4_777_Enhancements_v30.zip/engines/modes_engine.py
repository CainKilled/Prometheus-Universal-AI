"""
Modes Engine
============

The modes engine manages high‑level operating modes for the Prometheus
runtime.  A mode is a named context that can be used to configure
plugins, helper swarms or engines differently depending on the user's
intent.  For example, a ``developer`` mode might enable verbose
logging and debugging tools, whereas a ``designer`` mode could
activate UI prototyping plugins.  Modes are persisted across sessions
in a simple JSON file located under the engine's directory.

The engine exposes methods to list available modes, get the current
mode, and set a new mode.  It also defines a default set of
predefined modes; additional modes can be added at runtime by passing
an ``available_modes`` dictionary when constructing the engine.

Developed and maintained by Adam Henry Nagle.  Contact:
603‑384‑8949, cainkilledabrl@icloud.com, nagleadam75@gmail.com.
"""

from __future__ import annotations

import json
from pathlib import Path
from typing import Dict, List, Optional


class ModesEngine:
    """Manage global modes for the Prometheus runtime."""

    DEFAULT_MODES: Dict[str, str] = {
        "developer": "Enable developer tools and verbose logging",
        "designer": "Activate design helpers and preview UI components",
        "engineer": "Focus on build systems and dependency management",
        "asset": "Manage assets like images, sounds and other resources",
        "resource": "Explore and summarize project resources",
        "architect": "Summarize high‑level project structure",
        "idea_to_app": "Automate idea to application workflows",
    }

    def __init__(self, base_dir: Optional[str] = None, available_modes: Optional[Dict[str, str]] = None) -> None:
        # Determine where to persist the current mode
        if base_dir is None:
            self.base_dir = Path(__file__).resolve().parent
        else:
            self.base_dir = Path(base_dir)
        self.state_file = self.base_dir / "modes_state.json"
        # Merge default modes with any additional provided modes
        self.available_modes: Dict[str, str] = dict(self.DEFAULT_MODES)
        if available_modes:
            self.available_modes.update(available_modes)

    def list_modes(self) -> Dict[str, str]:
        """Return a dictionary of available mode names to descriptions."""
        return dict(self.available_modes)

    def get_mode(self) -> str:
        """Return the currently active mode.  If none is set, return 'developer'."""
        if self.state_file.exists():
            try:
                data = json.loads(self.state_file.read_text(encoding="utf-8"))
                mode = data.get("mode")
                if mode in self.available_modes:
                    return mode
            except Exception:
                pass
        return "developer"

    def set_mode(self, mode: str) -> None:
        """Persist the selected mode.  Raises ValueError if unknown."""
        if mode not in self.available_modes:
            raise ValueError(f"Unknown mode '{mode}'. Available modes: {list(self.available_modes)}")
        data = {"mode": mode}
        self.state_file.write_text(json.dumps(data), encoding="utf-8")