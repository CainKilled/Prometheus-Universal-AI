#!/bin/bash
python -c "import engines.huggingface_engine; print('huggingface_engine OK')"
