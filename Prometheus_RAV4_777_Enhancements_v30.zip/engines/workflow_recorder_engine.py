"""
Workflow Recorder Engine
========================

This engine provides a simple API for capturing and persisting the sequence of
steps (``actions``) that constitute a task.  Recorded workflows are written
to JSON files under ``data/workflows`` in the repository.  Each record is
timestamped and uniquely named so that multiple invocations for the same task
can coexist.  Downstream tooling can introspect these records to automate
repeated tasks, generate documentation, or feed into higher‑level orchestration
layers.

The engine is idempotent and safe to invoke repeatedly.  If the output
directory does not exist, it will be created on demand.  All records include
the task name, the list of actions (which may be arbitrary nested structures)
and the time of recording.

Developer
---------

This file is owned and maintained by Adam Henry Nagle (cainkilledabrl@icloud.com,
nagleadam75@gmail.com, phone 603‑384‑8949).  All modifications should preserve
the overall intent of capturing workflows for later reuse and automation.
"""

from __future__ import annotations

import json
import time
from pathlib import Path
from typing import Any, Dict, List, Optional


class WorkflowRecorderEngine:
    """Engine for recording task workflows to disk.

    Parameters
    ----------
    base_dir: str
        The base directory of the repository.  Relative paths for output will
        be resolved against this directory.
    workflows_dir: str
        Subdirectory under ``base_dir`` where workflow records should be
        persisted.  Defaults to ``"data/workflows"``.
    """

    def __init__(self, base_dir: str = ".", workflows_dir: str = "data/workflows") -> None:
        self.base_dir = Path(base_dir)
        self.workflows_dir = self.base_dir / workflows_dir
        # Ensure the workflows directory exists
        self.workflows_dir.mkdir(parents=True, exist_ok=True)

    def run(self, task_name: str, actions: List[Any], runtime: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
        """Record a task and its actions to a JSON file.

        Parameters
        ----------
        task_name: str
            A name describing the task being recorded (e.g. ``"build_project"``).
        actions: List[Any]
            A list of actions representing the steps taken during the task.  Actions
            may be arbitrary JSON‑serialisable structures such as strings, dicts
            or nested lists.
        runtime: Optional[Dict[str, Any]]
            Additional metadata passed by the plugin system at runtime.  Unused
            here but accepted for future compatibility.

        Returns
        -------
        Dict[str, Any]
            A dictionary containing the path to the record file and a status
            indicator.
        """
        # Prepare the record
        record = {
            "task_name": task_name,
            "actions": actions,
            "timestamp": time.time(),
        }
        # Compose an output filename: task name, timestamp
        ts = int(record["timestamp"])
        safe_name = task_name.replace(" ", "_").replace("/", "_")
        filename = f"{safe_name}_{ts}.json"
        file_path = self.workflows_dir / filename
        # Persist the record
        with file_path.open("w", encoding="utf-8") as f:
            json.dump(record, f, indent=2)
        # Return a reference to the record
        return {
            "status": "ok",
            "record_file": str(file_path.relative_to(self.base_dir)),
        }
