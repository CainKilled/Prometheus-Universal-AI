#!/bin/bash
# Smoke test for wifi_engine
python - <<'PY'
import sys
sys.path.insert(0, 'Prometheus_RAV4_777_Enhancements')
from engines.wifi_engine import WifiEngine
engine = WifiEngine()
assert engine.metadata()['name'] == 'wifi'
print('wifi_engine OK')
PY