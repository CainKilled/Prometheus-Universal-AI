#!/bin/bash
# Smoke test for firewall_engine
python - <<'PY'
import sys
sys.path.insert(0, 'Prometheus_RAV4_777_Enhancements')
from engines.firewall_engine import FirewallEngine
engine = FirewallEngine()
assert engine.metadata()['name'] == 'firewall'
print('firewall_engine OK')
PY