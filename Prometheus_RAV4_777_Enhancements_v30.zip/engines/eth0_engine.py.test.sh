#!/bin/bash
# Smoke test for eth0_engine
python - <<'PY'
import sys
sys.path.insert(0, 'Prometheus_RAV4_777_Enhancements')
from engines.eth0_engine import Eth0Engine
engine = Eth0Engine()
assert engine.metadata()['name'] == 'eth0'
print('eth0_engine OK')
PY