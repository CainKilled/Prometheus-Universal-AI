#!/usr/bin/env bash
# Test script for alias_tool

python - <<'PY'
import sys
sys.path.append('Prometheus_RAV4_777_Enhancements')
from tools.alias_tool import add_alias, list_aliases, remove_alias

add_alias('lsdev_test', 'ios', {'action': 'devices'})
aliases = list_aliases()
assert 'lsdev_test' in aliases
assert aliases['lsdev_test']['plugin'] == 'ios'
remove_alias('lsdev_test')
assert 'lsdev_test' not in list_aliases()
print('alias tool OK')
PY