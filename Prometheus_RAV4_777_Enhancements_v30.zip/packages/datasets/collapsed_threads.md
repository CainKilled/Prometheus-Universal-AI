# 🧠 Collapsed Threads Report

## thread_001
- **Type:** stubbed module
- **Origin:** 2025-07-10
- **Status:** ✅ resolved
- **Bound To:** `/truth_tree/modules/starfield_engine.ts`
- **Codex-Locked:** 🔒 Yes

## thread_002
- **Type:** placeholder policy
- **Origin:** 2025-07-12
- **Status:** ✅ resolved
- **Bound To:** `/truth_tree/policies/governance_policy.md`
- **Codex-Locked:** 🔒 Yes

## thread_003
- **Type:** dangling AI capsule spec
- **Origin:** 2025-07-14
- **Status:** ✅ resolved
- **Bound To:** `/truth_tree/capsules/ide_spec.ts`
- **Codex-Locked:** 🔒 Yes

## thread_004
- **Type:** unfinished script
- **Origin:** 2025-07-15
- **Status:** ✅ resolved
- **Bound To:** `/truth_tree/scripts/forge_all.sh`
- **Codex-Locked:** 🔒 Yes

## thread_005
- **Type:** disconnected memory logic
- **Origin:** 2025-07-19
- **Status:** ✅ resolved
- **Bound To:** `/runtime/prometheus/memory/chain_sync_engine.py`
- **Codex-Locked:** 🔒 Yes

