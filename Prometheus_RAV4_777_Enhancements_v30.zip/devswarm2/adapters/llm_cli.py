"""
LLM CLI Adapter
================

This adapter simulates interaction with a language model via a command
line interface. It is intended as a placeholder demonstrating how to
integrate external processes into the devswarm. In the absence of a
real LLM CLI, it simply echoes or transforms the prompt. If a
``command`` key is provided in the task, the adapter will attempt to
execute it as a shell command and return its output.
"""

from typing import Dict, Any, Callable
import subprocess
import shlex


class LLMCLIAdapter:
    def run(self, task: Dict[str, Any], logger: Callable[[str], None]) -> Dict[str, Any]:
        prompt = task.get("prompt", "")
        command = task.get("command")
        if command:
            try:
                args = shlex.split(command)
                result = subprocess.run(args, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True)
                logger(f"LLMCLIAdapter: Ran command '{command}', exit={result.returncode}")
                return {"output": result.stdout, "exit_code": result.returncode}
            except Exception as exc:
                logger(f"LLMCLIAdapter: Error running command '{command}': {exc}")
                return {"error": str(exc)}
        # Default behaviour: reverse the prompt string
        logger(f"LLMCLIAdapter: Received prompt: {prompt}")
        response = prompt[::-1]
        logger(f"LLMCLIAdapter: Responding with reversed prompt")
        return {"response": response}