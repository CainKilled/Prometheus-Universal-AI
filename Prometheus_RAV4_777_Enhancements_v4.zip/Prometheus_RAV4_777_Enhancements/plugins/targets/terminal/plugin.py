"""
Terminal Plugin
===============

This plugin provides a hook to integrate terminal emulators (e.g. GNOME
Terminal, iTerm2, Windows Terminal) with the Prometheus ecosystem. It can
be used to launch shells in the context of generated projects, run build
commands or monitor logs. Implementors should use operating system tools
and terminal emulator APIs to open new tabs, split panes or send commands.
"""

# Prometheus Codex Lock v1
# This file is part of Prometheus RAV4 777 Enhancements. Do not edit manually.

from typing import Dict, Any
import os
from plugins.api.plugin_base import Plugin


class TerminalPlugin:
    def metadata(self) -> Dict[str, Any]:
        return {
            "name": "terminal",
            "version": "0.1.0",
            "description": "Bridge for interacting with terminal emulators",
            "targets": ["terminal"],
        }

    def activate(self, runtime: Dict[str, Any]) -> None:
        """
        Launch a shell or execute a command in a subprocess.

        This implementation provides a simple CLI integration by running
        commands using Python's ``subprocess`` module. If the runtime
        dictionary contains a ``command`` key, it will execute that
        command in the specified working directory (``cwd``). Otherwise
        it will open an interactive shell. The output of the command is
        streamed back to the caller via the provided logger.

        Runtime keys:
            command (str or list): The command to run. If omitted,
                an interactive shell is started.
            cwd (str): Working directory to execute the command in.
            shell (bool): Whether to run the command through the shell.
        """
        import subprocess
        import shlex

        logger = runtime.get("log", print)
        command = runtime.get("command")
        cwd = runtime.get("cwd", None)
        use_shell = runtime.get("shell", True)
        try:
            if command is None:
                # Open an interactive shell
                logger("Starting interactive shell. Type exit or Ctrl-D to quit.")
                proc = subprocess.Popen(
                    os.environ.get("SHELL", "/bin/sh"),
                    cwd=cwd,
                    shell=True,
                    text=True
                )
                proc.communicate()
                logger("Shell session ended.")
                return
            # If command is a string and shell=False, split it into args
            if not use_shell and isinstance(command, str):
                command_args = shlex.split(command)
            else:
                command_args = command
            logger(f"Running command: {command} (shell={use_shell}, cwd={cwd})")
            proc = subprocess.Popen(
                command_args,
                cwd=cwd,
                shell=use_shell,
                stdout=subprocess.PIPE,
                stderr=subprocess.STDOUT,
                text=True
            )
            # Stream output to logger
            for line in proc.stdout:
                logger(line.rstrip())
            return_code = proc.wait()
            logger(f"Command exited with code {return_code}")
        except FileNotFoundError:
            logger(f"Command not found: {command}")
        except Exception as e:
            logger(f"Error running command {command}: {e}")


def get_plugin() -> Plugin:
    return TerminalPlugin()  # type: ignore[return-value]