#!/usr/bin/env python3
import argparse, re, json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
IOS = ROOT / "ios" / "PrometheusUniverse"

def replace_in_file(path: Path, repls: dict):
    txt = path.read_text(encoding="utf-8")
    for k, v in repls.items():
        txt = re.sub(k, v, txt)
    path.write_text(txt, encoding="utf-8")

def main():
    p = argparse.ArgumentParser()
    p.add_argument("--bundle-id", required=True)
    p.add_argument("--app-name", required=True)
    p.add_argument("--team-id")
    p.add_argument("--team-name")
    args = p.parse_args()

    # project.yml replacements
    proj = IOS / "project.yml"
    repls = {
        r"bundleIdPrefix: .*": f"bundleIdPrefix: {args.bundle_id.rsplit('.', 1)[0]}",
        r"PRODUCT_BUNDLE_IDENTIFIER: .*": f"PRODUCT_BUNDLE_IDENTIFIER: {args.bundle_id}",
        r"PRODUCT_NAME: .*": f"PRODUCT_NAME: {args.app_name}",
    }
    replace_in_file(proj, repls)

    # Info.plist sanity (name shows as product, fine)

    # Fastlane/Appfile placeholders (if present)
    appfile = IOS / "fastlane" / "Appfile"
    if appfile.exists():
        repls2 = {}
        if args.team_id:
            repls2[r'team_id\(".*"\)']: f'team_id("{args.team_id}")'
        if repls2:
            replace_in_file(appfile, repls2)

    readme = IOS / "README_iOS.md"
    replace_in_file(readme, {r"com\.adamnagle\.prometheus\.universe": args.bundle_id})

    print("Retarget complete:", args.bundle_id, "/", args.app_name)

if __name__ == "__main__":
    main()
