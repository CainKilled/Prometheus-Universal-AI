# Secrets Templates

Add these as **GitHub Actions Secrets** on your repository:

- `APP_STORE_CONNECT_API_KEY_JSON` → paste the content of `APP_STORE_CONNECT_API_KEY_JSON.example.json` with your real values
- `MATCH_GIT_URL` → e.g., `git@github.com:YOURUSER/ios-signing.git`
- `MATCH_PASSWORD` → a passphrase you choose
- `IOS_SIGNING_KEYCHAIN_PASSWORD` → any random string
