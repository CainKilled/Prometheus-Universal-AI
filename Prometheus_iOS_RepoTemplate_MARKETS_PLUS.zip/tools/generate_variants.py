#!/usr/bin/env python3
import json, itertools, shutil, yaml, sys, re
from pathlib import Path
from datetime import datetime

ROOT = Path(__file__).resolve().parents[1]
IOS = ROOT / "ios" / "PrometheusUniverse"

def load_manifest():
    mp = ROOT / "tools" / "market_paths.json"
    return json.loads(mp.read_text(encoding="utf-8"))

def write_yaml(path: Path, data):
    with open(path, "w", encoding="utf-8") as f:
        yaml.dump(data, f, sort_keys=False)

def sanitize(s):  # For scheme names
    return re.sub(r'[^A-Za-z0-9_.+-]', '-', s)

def aps_env_for(env: str) -> str:
    return "production" if env.lower() == "prod" else "development"

def group_id(bundle_id: str) -> str:
    return f"group.{bundle_id}"

def ensure_dir(p: Path):
    p.parent.mkdir(parents=True, exist_ok=True)
    return p

def create_entitlements(path: Path, caps: list, env: str, bundle_id: str):
    ent = {
        "com.apple.security.network.client": True
    }
    if "Push" in caps:
        ent["aps-environment"] = aps_env_for(env)
    if "AppGroups" in caps:
        ent["com.apple.security.application-groups"] = [group_id(bundle_id)]
    # write
    ensure_dir(path).write_text(json.dumps(ent, indent=2), encoding="utf-8")

def plist_background_modes(path: Path, caps: list):
    modes = []
    if "BackgroundModes" in caps:
        modes = ["fetch", "processing", "remote-notification"]
    # produce a minimal Info.plist fragment (Xcode uses base file; this is full file for simplicity)
    contents = f"""<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0"><dict>
  <key>CFBundleDevelopmentRegion</key><string>en</string>
  <key>CFBundlePackageType</key><string>APPL</string>
  <key>UIBackgroundModes</key>
  <array>
    {''.join(f'<string>{m}</string>' for m in modes)}
  </array>
</dict></plist>
"""
    ensure_dir(path).write_text(contents, encoding="utf-8")

def main():
    mp = load_manifest()
    envs = mp["environments"]
    caps_all = mp["capabilities"]
    dists = mp["distributions"]

    base = yaml.safe_load((IOS / "project.yml").read_text(encoding="utf-8"))
    targets = base.get("targets", {})
    base_target = targets.get("PrometheusUniverse")

    new_targets = {}
    schemes = []

    # Extract base bundle identifier prefix from settings or fallback
    base_bundle = base_target.get("settings", {}).get("base", {}).get("PRODUCT_BUNDLE_IDENTIFIER", "com.example.prometheus")

    # Iterate all combinations
    for env in envs:
        for r in range(len(caps_all)+1):
            for caps_subset in itertools.combinations(caps_all, r):
                caps = list(caps_subset)
                for dist in dists:
                    caps_tag = "None" if not caps else "+".join(sorted(caps))
                    suffix = f"-{env}-{dist}-{caps_tag}"
                    tname = "PrometheusUniverse" + suffix

                    # Deep copy target
                    t = json.loads(json.dumps(base_target))
                    base_settings = t.setdefault("settings", {}).setdefault("base", {})
                    # Product name & bundle id per variant
                    base_settings["PRODUCT_NAME"] = tname
                    variant_bundle = base_bundle  # retarget workflow will set final bundle id
                    base_settings["PRODUCT_BUNDLE_IDENTIFIER"] = base_bundle

                    # Create entitlements per target
                    ent_path = IOS / "Entitlements" / f"{tname}.entitlements"
                    create_entitlements(ent_path, caps, env, base_bundle)
                    t["entitlements"] = f"Entitlements/{tname}.entitlements"

                    # Background modes Info (optional override)
                    if "BackgroundModes" in caps:
                        info_override = IOS / "InfoOverrides" / f"{tname}.plist"
                        plist_background_modes(info_override, caps)
                        t["settings"]["base"]["INFOPLIST_FILE"] = str(info_override.relative_to(IOS))

                    # Optional extensions
                    # NSE
                    ext_targets = []
                    if "NotificationsExt" in caps:
                        nse_name = tname + ".NSE"
                        nse = {
                            "type": "app-extension",
                            "platform": "iOS",
                            "sources": ["Extensions/PrometheusNSE"],
                            "settings": {"base": {"INFOPLIST_FILE": "Extensions/PrometheusNSE/Info.plist"}},
                            "settingsGroups": []
                        }
                        nse_settings = nse.setdefault("settings", {}).setdefault("base", {})
                        nse_settings["PRODUCT_BUNDLE_IDENTIFIER"] = base_bundle + ".nse"
                        ext_targets.append((nse_name, nse))
                        # App target dependency
                        t.setdefault("dependencies", []).append({"target": nse_name})

                    # Widgets
                    if "Widgets" in caps:
                        w_name = tname + ".Widgets"
                        w = {
                            "type": "app-extension",
                            "platform": "iOS",
                            "sources": ["Extensions/PrometheusWidgets"],
                            "settings": {"base": {"INFOPLIST_FILE": "Extensions/PrometheusWidgets/Info.plist"}},
                            "settingsGroups": []
                        }
                        w_settings = w.setdefault("settings", {}).setdefault("base", {})
                        w_settings["PRODUCT_BUNDLE_IDENTIFIER"] = base_bundle + ".widgets"
                        ext_targets.append((w_name, w))
                        t.setdefault("dependencies", []).append({"target": w_name})

                    # Register targets
                    new_targets[tname] = t
                    for (en, edef) in ext_targets:
                        new_targets[en] = edef

                    schemes.append({"name": tname, "buildAction": {"targets": [tname]}})

    base["targets"] = {"PrometheusUniverse": base_target, **new_targets}
    base["schemes"] = schemes

    out = IOS / "project.generated.yml"
    write_yaml(out, base)
    print(f"[A+] Generated {len(new_targets)} targets and {len(schemes)} schemes at {out}.")

if __name__ == "__main__":
    try:
        import yaml  # type: ignore
    except Exception:
        print("Please `pip3 install pyyaml` on the host before running.", file=sys.stderr)
        sys.exit(1)
    main()
