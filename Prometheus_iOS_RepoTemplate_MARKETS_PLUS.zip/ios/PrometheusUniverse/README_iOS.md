# Prometheus Universe (iOS)

This folder is a ready-to-generate Xcode project (via **XcodeGen**) with Swift packages:
- `AutoUnpackKit` – Unzips `Resources/prometheus_payload.zip` to Documents on first launch
- `AutoIgniter` – First‑launch detection & bootstrap orchestration
- `PrometheusSwiftEngine` – Safe on‑device source evaluator/transformer (no arbitrary exec)
- `PrometheusCompilerEngine` – Artifact pipeline orchestrator (packaging, not code‑signing)

## Build (macOS + Xcode)

1. Install Xcode 15+ and [XcodeGen](https://github.com/yonaskolb/XcodeGen):  
   `brew install xcodegen`
2. From this folder:  
   `xcodegen generate`
3. Open `PrometheusUniverse.xcodeproj` in Xcode.
4. Set the Signing Team for the `PrometheusUniverse` target.
5. Build & run on your iPhone (iOS 16+). On first launch, the app unpacks `Resources/prometheus_payload.zip`.

## TestFlight (Fastlane)

- Edit `fastlane/Appfile` with your Apple IDs/Team IDs.
- `bundle install` then `bundle exec fastlane beta` to build & upload to TestFlight.

## Notes

- iOS does **not** allow auto‑executing installers from the Files app for security reasons.  
  The supported path is: build/run via Xcode, AltStore, or TestFlight. This app auto‑bootstraps its payload on first launch.
- You can replace `Resources/prometheus_payload.zip` with your monorepo snapshot or other assets.
