// PrometheusUniverseApp.swift
// Part of Prometheus Universe (iOS)
import SwiftUI

@main
struct PrometheusUniverseApp: App {
    @StateObject private var igniter = AutoIgniter()

    var body: some Scene {
        WindowGroup {
            ContentView()
                .environmentObject(igniter)
                .task {
                    await igniter.bootstrapOnFirstLaunch()
                }
        }
    }
}
