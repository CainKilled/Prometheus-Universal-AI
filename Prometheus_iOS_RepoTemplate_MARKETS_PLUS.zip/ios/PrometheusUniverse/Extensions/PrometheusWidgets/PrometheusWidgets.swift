// PrometheusWidgets.swift
import WidgetKit
import SwiftUI

struct PrometheusEntry: TimelineEntry {
    let date: Date
}

struct PrometheusProvider: TimelineProvider {
    func placeholder(in context: Context) -> PrometheusEntry { PrometheusEntry(date: Date()) }
    func getSnapshot(in context: Context, completion: @escaping (PrometheusEntry) -> ()) { completion(PrometheusEntry(date: Date())) }
    func getTimeline(in context: Context, completion: @escaping (Timeline<PrometheusEntry>) -> ()) {
        completion(Timeline(entries: [PrometheusEntry(date: Date())], policy: .after(Date().addingTimeInterval(900))))
    }
}

struct PrometheusWidgetEntryView : View {
    var entry: PrometheusProvider.Entry
    var body: some View {
        Text("Prometheus")
    }
}

@main
struct PrometheusWidget: Widget {
    let kind: String = "PrometheusWidget"
    var body: some WidgetConfiguration {
        StaticConfiguration(kind: kind, provider: PrometheusProvider()) { entry in
            PrometheusWidgetEntryView(entry: entry)
        }
        .configurationDisplayName("Prometheus")
        .description("Quick status.")
        .supportedFamilies([.systemSmall, .systemMedium])
    }
}
