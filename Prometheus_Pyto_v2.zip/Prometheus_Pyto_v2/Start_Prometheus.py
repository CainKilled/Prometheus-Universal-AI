#!/usr/bin/env python3
import os, sys, pathlib
BASE = pathlib.Path(__file__).resolve().parent
if str(BASE) not in sys.path:
    sys.path.insert(0, str(BASE))

from prometheus_pyto.runtime import boot_and_enter_cli

if __name__ == "__main__":
    boot_and_enter_cli(embed_requested=True)
