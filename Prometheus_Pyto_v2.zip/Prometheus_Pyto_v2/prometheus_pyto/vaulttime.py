import hashlib, pathlib
from .utils import now, write_json
from .config import RUNTIME_DIR

VT_DIR = RUNTIME_DIR/"vaulttime"

def ensure():
    VT_DIR.mkdir(parents=True, exist_ok=True)

def seal(path: pathlib.Path):
    ensure()
    sha = hashlib.sha256(path.read_bytes()).hexdigest()
    rec = {"ts": now(), "file": str(path), "sha256": sha}
    write_json(VT_DIR/(path.name+".seal.json"), rec)
    return rec
