from .vaulttime import seal
from .config import SLOTS_DIR
import pathlib

def task_seal(args):
    path = pathlib.Path(args.get("path",""))
    if not path.exists():
        return {"error":"not_found", "path": str(path)}
    return {"sealed": seal(path)}

def task_list_slots(args):
    return {"slots":[p.name for p in SLOTS_DIR.glob("*") if p.is_dir()]}

def task_bind_slot(args):
    name = args.get("name","slot0")
    target = args.get("target","")
    p = SLOTS_DIR/name
    p.mkdir(parents=True, exist_ok=True)
    cfg = p/"slot.target"
    cfg.write_text(target, encoding="utf-8")
    return {"slot": name, "target": target}

REGISTRY = {
    "seal": task_seal,
    "list_slots": task_list_slots,
    "bind_slot": task_bind_slot,
}
