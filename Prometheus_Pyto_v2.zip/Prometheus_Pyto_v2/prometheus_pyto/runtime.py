from .config import ensure_structure, RUNTIME_DIR, LOG_DIR, CONFIG_DIR, load
from .logger import get_logger
from .control_nexus_cli import open_cli
from .validators import run_all

logger = get_logger("runtime")

BANNER = "Prometheus Pyto Embedded Runtime v2"

def boot_and_enter_cli(embed_requested=False):
    print(BANNER)
    ensure_structure()
    cfg = load()
    results = run_all(RUNTIME_DIR)
    for name, ok, msg in results:
        logger.info("Check %s: %s - %s", name, "OK" if ok else "FAIL", msg)
    if embed_requested:
        logger.info("Embed mode requested")
    print("Runtime ready. Entering Control Nexus CLI.")
    open_cli()
