import os, json, pathlib
BASE_DIR = pathlib.Path(__file__).resolve().parents[1]
RUNTIME_DIR = BASE_DIR / "runtime"
LOG_DIR = RUNTIME_DIR / "logs"
CONFIG_DIR = RUNTIME_DIR / "config"
HAL_DIR = RUNTIME_DIR / "hal"
IPC_INBOX = RUNTIME_DIR / "ipc" / "inbox"
IPC_OUTBOX = RUNTIME_DIR / "ipc" / "outbox"
SLOTS_DIR = RUNTIME_DIR / "slots"

CONFIG_FILE = CONFIG_DIR / "prometheus_pyto.json"
DEFAULTS = {
    "version": "2.0.0",
    "log_level": "INFO",
    "strict_mode": True,
    "allow_network": False,
    "embed_mode": True,
    "slot_default": "slot0"
}

def ensure_structure():
    for p in [RUNTIME_DIR, LOG_DIR, CONFIG_DIR, HAL_DIR, IPC_INBOX, IPC_OUTBOX, SLOTS_DIR]:
        p.mkdir(parents=True, exist_ok=True)

def load():
    ensure_structure()
    if CONFIG_FILE.exists():
        try:
            return json.loads(CONFIG_FILE.read_text(encoding="utf-8"))
        except Exception:
            pass
    save(DEFAULTS)
    return DEFAULTS.copy()

def save(cfg: dict):
    ensure_structure()
    CONFIG_FILE.write_text(json.dumps(cfg, indent=2), encoding="utf-8")
    return cfg
