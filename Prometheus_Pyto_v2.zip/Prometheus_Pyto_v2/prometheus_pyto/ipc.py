import json, pathlib, uuid, traceback
from .config import IPC_INBOX, IPC_OUTBOX
from .utils import now

def pull_tasks():
    IPC_INBOX.mkdir(parents=True, exist_ok=True)
    for p in sorted(IPC_INBOX.glob("*.json")):
        try:
            data = json.loads(p.read_text(encoding="utf-8"))
            yield p, data
        except Exception:
            yield p, {"error":"invalid_json", "content": p.read_text(encoding='utf-8', errors='ignore')}

def write_result(task_id: str, result: dict):
    out = IPC_OUTBOX / f"{task_id}.result.json"
    result["ts"] = now()
    out.write_text(json.dumps(result, indent=2), encoding="utf-8")
    return out

def process_with(registry: dict):
    processed = []
    for p, task in pull_tasks():
        tid = task.get("id") or str(uuid.uuid4())
        try:
            name = task.get("task")
            handler = registry.get(name)
            if not handler:
                write_result(tid, {"error":"unknown_task", "task": name})
            else:
                res = handler(task.get("args", {}))
                write_result(tid, {"ok": True, "data": res})
        except Exception as e:
            write_result(tid, {"ok": False, "error": str(e), "trace": traceback.format_exc()})
        finally:
            try: p.unlink()
            except Exception: pass
        processed.append(tid)
    return processed
