import uuid
from .config import HAL_DIR
from .utils import write_json, now

def emit_handshake(mode="pyto-embedded"):
    data = {
        "id": str(uuid.uuid4()),
        "ts": now(),
        "mode": mode,
        "status": "ready",
        "capabilities": ["ipc","control_nexus_adapter","vaulttime_local","no_network_default"]
    }
    write_json(HAL_DIR/"handshake.json", data)
    return data

def emit_health(status="ok", details=None):
    write_json(HAL_DIR/"health.json", {"ts": now(), "status": status, "details": details or {}})
