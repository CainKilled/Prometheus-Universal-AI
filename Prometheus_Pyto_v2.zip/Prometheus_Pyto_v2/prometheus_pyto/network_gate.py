from .config import load
def network_allowed():
    return bool(load().get("allow_network", False))
