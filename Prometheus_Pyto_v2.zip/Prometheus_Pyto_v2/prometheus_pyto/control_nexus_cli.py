from .logger import get_logger
from .validators import run_all
from .config import RUNTIME_DIR, LOG_DIR, CONFIG_DIR, HAL_DIR, load, save
from .hal_bridge import emit_handshake, emit_health
from .ipc import process_with
from .control_nexus_adapter import REGISTRY

logger = get_logger("control_nexus")

MENU = {
    "1": "Run diagnostics",
    "2": "Emit HAL handshake",
    "3": "Process IPC inbox tasks",
    "4": "Toggle allow_network",
    "5": "Tail last 80 log lines",
    "6": "Exit",
}

def tail(n=80):
    p = LOG_DIR/"prometheus_pyto.log"
    if not p.exists(): return ["<no log yet>"]
    return p.read_text(encoding="utf-8", errors="ignore").splitlines()[-n:]

def open_cli():
    cfg = load()
    while True:
        print("\n=== Control Nexus CLI (Pyto Embedded) ===")
        for k,v in MENU.items():
            print(f"[{k}] {v}")
        c = input("Select: ").strip()
        if c == "1":
            res = run_all(RUNTIME_DIR)
            for k,ok,msg in res:
                print(f"{k}: {'OK' if ok else 'FAIL'} — {msg}")
            emit_health("ok", {"checks": res})
            logger.info("Diagnostics run")
        elif c == "2":
            hs = emit_handshake()
            print("Handshake emitted:", hs)
        elif c == "3":
            ids = process_with(REGISTRY)
            print("Processed tasks:", ids)
        elif c == "4":
            cfg["allow_network"] = not cfg.get("allow_network", False)
            save(cfg); print("allow_network:", cfg["allow_network"])
        elif c == "5":
            for ln in tail(): print(ln)
        elif c == "6":
            print("Exiting.")
            break
        else:
            print("Invalid.")
