import sys, pathlib

def check_python(min_major=3, min_minor=10):
    v = sys.version_info
    ok = (v.major, v.minor) >= (min_major, min_minor)
    return ok, f"{v.major}.{v.minor}.{v.micro}"

def check_paths(*paths):
    res = []
    for p in paths:
        try:
            path = pathlib.Path(p); path.mkdir(parents=True, exist_ok=True)
            t = path/".w"
            t.write_text("ok", encoding="utf-8"); t.unlink()
            res.append((str(path), True, "rw"))
        except Exception as e:
            res.append((str(p), False, str(e)))
    return res

def run_all(runtime_dir):
    ok, ver = check_python()
    results = [("python", ok, ver)]
    results += check_paths(runtime_dir, runtime_dir/"logs", runtime_dir/"config")
    return results
