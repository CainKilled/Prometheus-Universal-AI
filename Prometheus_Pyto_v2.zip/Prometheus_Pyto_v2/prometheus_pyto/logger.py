import logging, logging.handlers
from .config import LOG_DIR, load

def get_logger(name="prometheus_pyto"):
    cfg = load()
    LOG_DIR.mkdir(parents=True, exist_ok=True)
    log_path = LOG_DIR / "prometheus_pyto.log"

    logger = logging.getLogger(name)
    logger.setLevel(getattr(logging, cfg.get("log_level","INFO")))

    if not logger.handlers:
        fh = logging.handlers.RotatingFileHandler(str(log_path), maxBytes=1024*1024, backupCount=5)
        sh = logging.StreamHandler()
        fmt = logging.Formatter("%(asctime)s | %(levelname)s | %(name)s | %(message)s")
        fh.setFormatter(fmt); sh.setFormatter(fmt)
        logger.addHandler(fh); logger.addHandler(sh)
    return logger
