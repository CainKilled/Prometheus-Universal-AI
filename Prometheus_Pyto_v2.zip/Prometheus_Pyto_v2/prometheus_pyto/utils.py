import time, pathlib, json

def now():
    return time.strftime("%Y-%m-%d %H:%M:%S")

def write_json(path: pathlib.Path, data: dict):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(data, indent=2), encoding="utf-8")
