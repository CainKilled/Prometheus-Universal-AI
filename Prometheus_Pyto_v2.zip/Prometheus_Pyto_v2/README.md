# Prometheus Pyto v2 — Embedded Mode

This package runs **inside Pyto** but is **embedded into the Prometheus Runtime** via filesystem IPC,
Config sync, and Control Nexus adapters. It is safe to run on-device without network.

Key integrations:
- **HAL Bridge** — deterministic hooks to Prometheus HAL.
- **VaultTime Adapter** — local cryptographic manifests, seal/stamp actions.
- **Control Nexus Adapter** — exposes Pyto runtime controls as Prometheus tasks.
- **IPC (inbox/outbox)** — drop JSON tasks into `./runtime/ipc/inbox` and read results from `./runtime/ipc/outbox`.
- **Slots** — mount points for Prometheus projects. Point a slot to a repo path and it becomes addressable by CLI.

Quick start (Pyto):
1. Place `Prometheus_Pyto_v2` in Pyto's Documents.
2. Open `Start_Prometheus.py` and Run.
3. Choose "Bind to Prometheus" to emit the embed-ready handshake file under `./runtime/hal/handshake.json`.
