#!/usr/bin/env python3
import os, zipfile, pathlib
ROOT = pathlib.Path(__file__).resolve().parents[1]
OUT = ROOT.parent / (ROOT.name + ".zip")
def zipdir(path, ziph):
    for base, _, files in os.walk(path):
        for f in files:
            full = os.path.join(base, f)
            rel = os.path.relpath(full, os.path.dirname(path))
            ziph.write(full, arcname=rel)
with zipfile.ZipFile(OUT, "w", zipfile.ZIP_DEFLATED) as z:
    zipdir(str(ROOT), z)
print("Wrote", OUT)
