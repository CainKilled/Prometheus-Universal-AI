#!/usr/bin/env python3
import os, json, time, hashlib, pathlib

ROOT = pathlib.Path(__file__).resolve().parent
RUNTIME = ROOT / "runtime"
for p in [RUNTIME, RUNTIME/"logs", RUNTIME/"config", RUNTIME/"ipc"/"inbox", RUNTIME/"ipc"/"outbox", RUNTIME/"slots", RUNTIME/"hal"]:
    p.mkdir(parents=True, exist_ok=True)

def sha256(p):
    h = hashlib.sha256()
    with open(p, "rb") as f:
        while True:
            b = f.read(8192)
            if not b:
                break
            h.update(b)
    return h.hexdigest()

COMP = ROOT/"companions"
COMP.mkdir(exist_ok=True)

def write_companion(path: pathlib.Path):
    rel = path.relative_to(ROOT)
    data = {
        "file": str(rel),
        "sha256": sha256(path),
        "generated": time.strftime("%Y-%m-%d %H:%M:%S"),
        "policy": "Prometheus Companion File Immutability Protocol v1",
    }
    (COMP/(rel.name+".manifest.json")).write_text(json.dumps(data, indent=2), encoding="utf-8")
    test_code = f"""#!/usr/bin/env python3
import json, hashlib, pathlib
ROOT = pathlib.Path(__file__).resolve().parents[1]
T = ROOT/'{rel.as_posix()}'
M = ROOT/'companions'/'{rel.name}.manifest.json'
def h(p):
    x = hashlib.sha256()
    with open(p, 'rb') as f:
        while True:
            b = f.read(8192)
            if not b: break
            x.update(b)
    return x.hexdigest()
m = json.loads(M.read_text(encoding='utf-8'))
cur = h(T)
assert cur == m['sha256'], f"Hash mismatch for {rel.as_posix()}"
print("OK", {rel.name!r}, cur)
"""
    (COMP/(rel.name+".test.py")).write_text(test_code, encoding="utf-8")

for py in (ROOT/"prometheus_pyto").rglob("*.py"):
    write_companion(py)

print("Install complete.")
