#!/usr/bin/env python3
import json, hashlib, pathlib
ROOT = pathlib.Path(__file__).resolve().parents[1]
T = ROOT/'prometheus_pyto/validators.py'
M = ROOT/'companions'/'validators.py.manifest.json'
def h(p):
    x = hashlib.sha256()
    with open(p, 'rb') as f:
        while True:
            b = f.read(8192)
            if not b: break
            x.update(b)
    return x.hexdigest()
m = json.loads(M.read_text(encoding='utf-8'))
cur = h(T)
assert cur == m['sha256'], f"Hash mismatch for prometheus_pyto/validators.py"
print("OK", 'validators.py', cur)
