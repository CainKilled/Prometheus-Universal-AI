"""
Developer Engine
================

This engine provides developer‑centric insights for a project.  It can
calculate basic statistics such as the number of files, total lines of
code and a breakdown by file extension. These metrics help assess
project size and composition. The engine expects a runtime task
dictionary with an optional ``root`` key pointing to the directory to
analyze (default is the current working directory) and an optional
``lang`` hint which is currently unused but reserved for future
language‑specific analyses.
"""

from __future__ import annotations

from typing import Dict, Any
from pathlib import Path
import os


class DeveloperEngine:
    def metadata(self) -> Dict[str, Any]:
        return {
            "name": "developer",
            "version": "1.0.0",
            "description": "Analyze code statistics such as file counts and line counts."
        }

    def run(self, task: Dict[str, Any]) -> Dict[str, Any]:
        root = Path(task.get("root", os.getcwd()))
        lang = task.get("lang", "any")
        stats: Dict[str, Any] = {"files": 0, "lines": 0, "extensions": {}}
        for p in root.rglob("*"):
            if p.is_file() and not any(part in p.parts for part in [".git", "__pycache__"]):
                stats["files"] += 1
                try:
                    cnt = p.read_text(errors="ignore").count("\n")
                except Exception:
                    cnt = 0
                stats["lines"] += cnt
                ext = p.suffix or "NOEXT"
                stats["extensions"][ext] = stats["extensions"].get(ext, 0) + 1
        return {"ok": True, "stats": stats}


def get_engine() -> DeveloperEngine:
    return DeveloperEngine()