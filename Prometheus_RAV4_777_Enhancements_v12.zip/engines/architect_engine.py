"""
Architect Engine
================

The Architect Engine summarises the high‑level structure of the
Prometheus monorepo. It counts plugins, engines, templates and
provides a brief overview of the top‑level directories. The runtime
task accepts an optional ``root`` key pointing to the repository
root. If omitted, it uses the current working directory. This engine
helps developers understand the overall architecture and component
distribution.
"""

from __future__ import annotations

from typing import Dict, Any
from pathlib import Path
import os


class ArchitectEngine:
    def metadata(self) -> Dict[str, Any]:
        return {
            "name": "architect",
            "version": "1.0.0",
            "description": "Summarise the monorepo's high‑level structure: counts of plugins, engines and templates."
        }

    def run(self, task: Dict[str, Any]) -> Dict[str, Any]:
        root = Path(task.get("root", os.getcwd()))
        counts = {"plugins": 0, "engines": 0, "templates": 0, "dirs": []}
        # Count plugins (targets directories with plugin.py)
        plugins_dir = root / "plugins" / "targets"
        if plugins_dir.exists():
            for p in plugins_dir.rglob("plugin.py"):
                counts["plugins"] += 1
        # Count engines
        engines_dir = root / "engines"
        if engines_dir.exists():
            for p in engines_dir.glob("*_engine.py"):
                counts["engines"] += 1
        # Count templates
        templates_dir = root / "templates"
        if templates_dir.exists():
            for p in templates_dir.rglob("*.json"):
                counts["templates"] += 1
        # List top‑level directories
        for item in root.iterdir():
            if item.is_dir() and not item.name.startswith('.'):
                counts["dirs"].append(item.name)
        return {"ok": True, "summary": counts}


def get_engine() -> ArchitectEngine:
    return ArchitectEngine()