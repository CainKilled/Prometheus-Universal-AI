"""
Asset Engine
============

The Asset Engine manages static resources within a project. It can
enumerate files considered assets (images, CSS, JS, HTML, fonts) and
copy them to a destination directory if requested. The runtime task
should include ``root`` (path to search) and may include ``out`` to
indicate where to copy assets. Without ``out`` only a listing is
returned. Copying preserves relative paths under ``root``.
"""

from __future__ import annotations

from typing import Dict, Any, List
from pathlib import Path
import os
import shutil


class AssetEngine:
    def metadata(self) -> Dict[str, Any]:
        return {
            "name": "asset",
            "version": "1.0.0",
            "description": "List and optionally copy static asset files (images, CSS, JS, HTML, fonts)."
        }

    ASSET_EXTS = {'.png', '.jpg', '.jpeg', '.gif', '.svg', '.css', '.js', '.html', '.htm', '.woff', '.woff2', '.ttf'}

    def run(self, task: Dict[str, Any]) -> Dict[str, Any]:
        root = Path(task.get("root", os.getcwd()))
        out = task.get("out")
        found: List[str] = []
        for p in root.rglob("*"):
            if p.is_file() and p.suffix.lower() in self.ASSET_EXTS:
                found.append(str(p))
        if out:
            dest = Path(out)
            dest.mkdir(parents=True, exist_ok=True)
            for f in found:
                src = Path(f)
                rel = src.relative_to(root)
                target = dest / rel
                target.parent.mkdir(parents=True, exist_ok=True)
                try:
                    shutil.copy2(src, target)
                except Exception:
                    continue
            return {"ok": True, "copied": len(found)}
        return {"ok": True, "assets": found}


def get_engine() -> AssetEngine:
    return AssetEngine()