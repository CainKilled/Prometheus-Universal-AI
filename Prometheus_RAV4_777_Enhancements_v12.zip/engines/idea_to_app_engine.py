"""
Idea To App Engine
===================

This engine provides a bridge into the Prometheus monorepo builder. It
takes a plain language idea and produces a runnable project using the
built‑in build CLI. The runtime task must include ``idea`` (the
description of the desired application), ``name`` (project name) and
``kind`` (one of ``webapp`` or ``cli``). You may optionally specify
``root`` to locate the repository base and ``out`` to choose an output
directory (defaults to ``./output``). The engine runs the builder
script synchronously and returns the command's output and exit code.
"""

from __future__ import annotations

from typing import Dict, Any
from pathlib import Path
import subprocess
import shlex
import os


class IdeaToAppEngine:
    def metadata(self) -> Dict[str, Any]:
        return {
            "name": "idea_to_app",
            "version": "1.0.0",
            "description": "Generate a runnable project from an idea via the monorepo builder."
        }

    def run(self, task: Dict[str, Any]) -> Dict[str, Any]:
        idea = task.get("idea")
        name = task.get("name")
        kind = task.get("kind", "webapp")
        root = Path(task.get("root", os.getcwd()))
        out = task.get("out", None)
        if not idea or not name:
            return {"error": "'idea' and 'name' parameters are required"}
        builder = root / "bin" / "pm_build"
        if not builder.exists():
            return {"error": f"Builder not found at {builder}"}
        cmd = [str(builder), "build", "--idea", idea, "--name", name, "--kind", kind]
        if out:
            cmd += ["--out", out]
        try:
            result = subprocess.run(cmd, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True)
            return {"ok": result.returncode == 0, "exit_code": result.returncode, "output": result.stdout}
        except Exception as exc:
            return {"error": str(exc)}


def get_engine() -> IdeaToAppEngine:
    return IdeaToAppEngine()