"""
MongoDB Plugin
==============

This plugin acts as a scaffold for integrating MongoDB with the Prometheus
environment. When fully implemented, it could create, query and manage
MongoDB databases used by generated projects. To implement actual
functionality, install [pymongo](https://pymongo.readthedocs.io/) or use
the `mongo` command‑line client. The plugin should read connection
parameters from the runtime or configuration files.
"""

# Prometheus Codex Lock v1
# This file is part of Prometheus RAV4 777 Enhancements. Do not edit manually.

from typing import Dict, Any
from plugins.api.plugin_base import Plugin


class MongoPlugin:
    def metadata(self) -> Dict[str, Any]:
        return {
            "name": "mongo",
            "version": "0.1.0",
            "description": "MongoDB integration scaffold",
            "targets": ["database", "mongo"],
        }

    def activate(self, runtime: Dict[str, Any]) -> None:
        """
        Connect to MongoDB and perform basic operations.

        This implementation uses ``pymongo`` if available. Provide the
        following keys in the runtime dictionary to control behaviour:

            uri (str): MongoDB connection URI. Defaults to ``mongodb://localhost:27017``.
            database (str): Name of the database to operate on.
            collection (str): Name of the collection (for insert/find actions).
            action (str): One of ``list_databases``, ``list_collections``, ``insert_one`` or ``find``.
            document (dict): Document to insert (required for ``insert_one``).
            query (dict): Query for ``find`` (defaults to empty dict).

        Results or errors are printed via the provided logger.
        """
        logger = runtime.get("log", print)
        uri = runtime.get("uri", "mongodb://localhost:27017")
        db_name = runtime.get("database")
        coll_name = runtime.get("collection")
        action = runtime.get("action", "list_databases")
        try:
            from pymongo import MongoClient
            client = MongoClient(uri)
            logger(f"Connected to MongoDB at {uri}")
            if action == "list_databases":
                logger("Databases:")
                for db in client.list_database_names():
                    logger(f"- {db}")
            elif action == "list_collections":
                if not db_name:
                    logger("Database name is required for list_collections action")
                else:
                    db = client[db_name]
                    logger(f"Collections in {db_name}:")
                    for coll in db.list_collection_names():
                        logger(f"- {coll}")
            elif action == "insert_one":
                if not (db_name and coll_name):
                    logger("Both database and collection names are required for insert_one action")
                else:
                    document = runtime.get("document", {})
                    db = client[db_name]
                    result = db[coll_name].insert_one(document)
                    logger(f"Inserted document with id {result.inserted_id}")
            elif action == "find":
                if not (db_name and coll_name):
                    logger("Both database and collection names are required for find action")
                else:
                    query = runtime.get("query", {})
                    db = client[db_name]
                    cursor = db[coll_name].find(query)
                    for doc in cursor:
                        logger(str(doc))
            else:
                logger(f"Unknown action: {action}")
        except ImportError:
            logger("pymongo is not installed. Please install it to use MongoDB functionality.")
        except Exception as exc:
            logger(f"MongoDB error: {exc}")


def get_plugin() -> Plugin:
    return MongoPlugin()  # type: ignore[return-value]