"""
VS Code Plugin
===============

This plugin serves as a gateway to integrate Visual Studio Code with the
Prometheus environment. It provides metadata describing the integration and
a stub activation method. To implement actual functionality, use the
[Visual Studio Code API](https://code.visualstudio.com/api) and
[language server protocols](https://microsoft.github.io/language-server-protocol/).
For example, you could launch VS Code via the command line and open
generated projects automatically.
"""

# Prometheus Codex Lock v1
# This file is part of Prometheus RAV4 777 Enhancements. Do not edit manually.

from typing import Dict, Any
from plugins.api.plugin_base import Plugin


class VSCodePlugin:
    def metadata(self) -> Dict[str, Any]:
        return {
            "name": "vscode",
            "version": "0.1.0",
            "description": "Integration scaffold for Visual Studio Code",
            "targets": ["editor", "ide"],
        }

    def activate(self, runtime: Dict[str, Any]) -> None:
        """
        Launch Visual Studio Code and open a specified path.

        This implementation uses the ``code`` command line tool to start VS Code.
        If ``code`` is not available on the system PATH, a message is logged.
        Provide the following keys in the runtime dict:

            path (str): directory or file to open in VS Code. Defaults to the
                current working directory.
        """
        import subprocess
        import os
        logger = runtime.get("log", print)
        path = runtime.get("path", os.getcwd())
        # Determine which command to use. 'code' is the standard CLI for VS Code.
        command = ["code", path]
        try:
            logger(f"Launching VS Code for path: {path}")
            result = subprocess.run(command, check=False, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True)
            if result.returncode != 0:
                logger(f"VS Code command returned non‑zero exit code: {result.returncode}\n{result.stdout}")
            else:
                logger("VS Code launched successfully (exit code 0)")
        except FileNotFoundError:
            logger("The 'code' CLI was not found on the system PATH. Ensure that VS Code is installed and the command is available.")
        except Exception as exc:
            logger(f"Error launching VS Code: {exc}")


def get_plugin() -> Plugin:
    return VSCodePlugin()  # type: ignore[return-value]