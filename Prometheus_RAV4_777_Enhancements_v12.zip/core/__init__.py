"""
Core modules for the Prometheus RAV4 777 Enhancements.

The ``core`` package contains foundational components that tie the
plugin system together at a higher level. The ``kernel`` module defines
the runtime environment (event loop, plugin registry, task dispatch)
while ``os.py`` houses miscellaneous operating system helpers that
provide a unified interface for process execution, file system
interaction and simple networking. These modules are designed to be
extensible and are intentionally kept light so that you can drop in
additional functionality as needed.
"""
