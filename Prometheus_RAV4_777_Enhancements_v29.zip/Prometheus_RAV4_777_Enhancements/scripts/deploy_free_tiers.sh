#!/usr/bin/env bash
#
# Deploy Prometheus RAV4 777 Enhancements to various free‑tier cloud providers.
#
# This script automates typical deployment tasks for AWS SageMaker,
# Firebase Hosting, Google Cloud Functions and Cloudflare Workers.
# It relies on the corresponding command‑line tools (aws, firebase,
# gcloud and wrangler) being installed and configured with valid
# credentials for a free‑tier account.
#
# Developed and maintained by Adam Henry Nagle. Contact:
#   Phone: 603‑384‑8949
#   Emails: cainkilledabrl@icloud.com, nagleadam75@gmail.com
#
# Usage:
#   ./deploy_free_tiers.sh <target> [options]
#
# Targets:
#   sagemaker  – Uploads a zipped copy of the repository to S3 and registers a
#                SageMaker model. Requires --bucket, --model, --region, --role.
#   firebase   – Deploys static web assets to Firebase Hosting. Requires --project.
#   gcloud     – Deploys a Cloud Function using gcloud. Requires --project,
#                optional --region.
#   cloudflare – Publishes a Cloudflare Worker. Requires --name, --account-id,
#                --api-token.
#
# The script performs idempotent checks where possible (e.g. skipping
# bucket creation if it already exists). It is safe to re‑run.

set -euo pipefail

if [ $# -lt 1 ]; then
  cat <<'USAGE'
Usage: deploy_free_tiers.sh <target> [options]

Targets:
  sagemaker  Deploy to AWS SageMaker (requires awscli configured)
  firebase   Deploy to Firebase Hosting (requires firebase-tools)
  gcloud     Deploy to Google Cloud Functions (requires gcloud CLI)
  cloudflare Deploy to Cloudflare Workers (requires wrangler)

For more details on each target, run with the desired target followed
by --help.
USAGE
  exit 1
fi

TARGET=$1
shift

function deploy_sagemaker() {
  local BUCKET=""
  local MODEL=""
  local REGION=""
  local ROLE=""
  while [ $# -gt 0 ]; do
    case "$1" in
      --bucket) BUCKET=$2; shift 2;;
      --model)  MODEL=$2;  shift 2;;
      --region) REGION=$2; shift 2;;
      --role)   ROLE=$2;   shift 2;;
      --help)
        echo "Usage: deploy_free_tiers.sh sagemaker --bucket <s3-bucket> --model <model-name> --region <aws-region> --role <sagemaker-exec-role-arn>"
        return 0;;
      *)
        echo "Unknown option for sagemaker: $1"
        return 1;;
    esac
  done
  if [[ -z "$BUCKET" || -z "$MODEL" || -z "$REGION" || -z "$ROLE" ]]; then
    echo "Missing required options. Run with --help for usage."
    return 1
  fi
  echo "[SageMaker] Checking bucket $BUCKET..."
  if aws s3api head-bucket --bucket "$BUCKET" >/dev/null 2>&1; then
    echo "[SageMaker] Bucket exists."
  else
    echo "[SageMaker] Creating bucket $BUCKET in region $REGION..."
    aws s3api create-bucket --bucket "$BUCKET" --region "$REGION" \
      --create-bucket-configuration LocationConstraint="$REGION"
  fi
  local ARCHIVE="/tmp/${MODEL}_code.zip"
  echo "[SageMaker] Packaging repository into $ARCHIVE..."
  (cd "$(dirname "$0")/.." && zip -qr "$ARCHIVE" . -x '*.git*' -x '*/__pycache__/*')
  echo "[SageMaker] Uploading archive to s3://$BUCKET/$MODEL.zip..."
  aws s3 cp "$ARCHIVE" "s3://$BUCKET/$MODEL.zip"
  echo "[SageMaker] Registering model $MODEL..."
  aws sagemaker create-model --model-name "$MODEL" \
    --primary-container Image=123456789012.dkr.ecr."$REGION".amazonaws.com/sagemaker-scikit-learn:0.23-1-cpu-py3 \
    --execution-role-arn "$ROLE" \
    --model-data-url "s3://$BUCKET/$MODEL.zip" \
    --region "$REGION"
  echo "[SageMaker] Deployment complete."
}

function deploy_firebase() {
  local PROJECT=""
  while [ $# -gt 0 ]; do
    case "$1" in
      --project) PROJECT=$2; shift 2;;
      --help)
        echo "Usage: deploy_free_tiers.sh firebase --project <firebase-project-id>"
        return 0;;
      *)
        echo "Unknown option for firebase: $1"
        return 1;;
    esac
  done
  if [[ -z "$PROJECT" ]]; then
    echo "Firebase project ID is required. Use --project."
    return 1
  fi
  echo "[Firebase] Using project $PROJECT..."
  firebase use "$PROJECT" || firebase use --add "$PROJECT"
  if [ ! -f firebase.json ]; then
    echo "[Firebase] Creating firebase.json..."
    cat > firebase.json <<EOF
{
  "hosting": {
    "public": "public",
    "ignore": ["firebase.json", "**/.*", "**/node_modules/**"]
  }
}
EOF
    mkdir -p public
    echo "<!DOCTYPE html><html><body><h1>Prometheus RAV4 777</h1></body></html>" > public/index.html
  fi
  echo "[Firebase] Deploying to Firebase Hosting..."
  firebase deploy --only hosting --project "$PROJECT"
}

function deploy_gcloud() {
  local PROJECT=""
  local REGION="us-central1"
  while [ $# -gt 0 ]; do
    case "$1" in
      --project) PROJECT=$2; shift 2;;
      --region)  REGION=$2; shift 2;;
      --help)
        echo "Usage: deploy_free_tiers.sh gcloud --project <gcp-project> [--region <region>]"
        return 0;;
      *)
        echo "Unknown option for gcloud: $1"
        return 1;;
    esac
  done
  if [[ -z "$PROJECT" ]]; then
    echo "GCloud project ID is required. Use --project."
    return 1
  fi
  echo "[GCloud] Setting project to $PROJECT..."
  gcloud config set project "$PROJECT"
  gcloud services enable cloudfunctions.googleapis.com
  if [ ! -f main.py ]; then
    cat > main.py <<'EOF'
def handler(request):
    return "Hello from Prometheus RAV4 777!"
EOF
  fi
  if [ ! -f requirements.txt ]; then
    echo "# Add any Python dependencies here" > requirements.txt
  fi
  echo "[GCloud] Deploying Cloud Function..."
  gcloud functions deploy prometheus_rav4_777 --entry-point handler --runtime python39 \
    --trigger-http --allow-unauthenticated --region "$REGION"
}

function deploy_cloudflare() {
  local NAME=""
  local ACCOUNT=""
  local TOKEN=""
  while [ $# -gt 0 ]; do
    case "$1" in
      --name) NAME=$2; shift 2;;
      --account-id) ACCOUNT=$2; shift 2;;
      --api-token) TOKEN=$2; shift 2;;
      --help)
        echo "Usage: deploy_free_tiers.sh cloudflare --name <worker-name> --account-id <account-id> --api-token <api-token>"
        return 0;;
      *)
        echo "Unknown option for cloudflare: $1"
        return 1;;
    esac
  done
  if [[ -z "$NAME" || -z "$ACCOUNT" || -z "$TOKEN" ]]; then
    echo "Name, account ID and API token are required for Cloudflare deployment."
    return 1
  fi
  echo "[Cloudflare] Preparing wrangler.toml..."
  cat > wrangler.toml <<EOF
name = "$NAME"
main = "index.js"
type = "javascript"
account_id = "$ACCOUNT"
workers_dev = true
EOF
  if [ ! -f index.js ]; then
    cat > index.js <<'EOF'
export default {
  async fetch(request, env) {
    return new Response("Hello from Prometheus RAV4 777!");
  },
};
EOF
  fi
  export CF_API_TOKEN="$TOKEN"
  echo "[Cloudflare] Publishing worker..."
  wrangler publish
}

case "$TARGET" in
  sagemaker)
    deploy_sagemaker "$@"
    ;;
  firebase)
    deploy_firebase "$@"
    ;;
  gcloud)
    deploy_gcloud "$@"
    ;;
  cloudflare)
    deploy_cloudflare "$@"
    ;;
  *)
    echo "Unknown target: $TARGET"
    exit 1
    ;;
esac