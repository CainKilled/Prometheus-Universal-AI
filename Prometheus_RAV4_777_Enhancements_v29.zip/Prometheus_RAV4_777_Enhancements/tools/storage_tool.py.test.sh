#!/bin/bash
# Simple tests for storage_tool
# Developed by Adam Henry Nagle

python - <<'PY'
import sys
sys.path.append('Prometheus_RAV4_777_Enhancements')
import os
import tempfile
from tools.storage_tool import local_write, local_read, local_list

# create a temporary file and directory
with tempfile.TemporaryDirectory() as tmpdir:
    file_path = os.path.join(tmpdir, "test.txt")
    # write to file
    local_write(file_path, "hello")
    # read from file
    content = local_read(file_path)
    assert content == "hello", f"Expected 'hello', got {content!r}"
    # list directory
    entries = local_list(tmpdir)
    assert "test.txt" in entries, f"test.txt should be in directory listing: {entries}"

print("storage_tool OK")
PY