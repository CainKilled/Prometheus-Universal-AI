"""
Comms Tool
==========

This module provides a simple command‑line interface around the
``CommsEngine``.  It allows you to send and receive internal messages
via an in‑memory queue and to make HTTP POST requests to external
services.  The CLI maintains a single global engine instance so
multiple commands in the same process can share state when using
internal messaging.

Usage examples::

    # enqueue a message for internal consumption
    python -m tools.comms_tool internal-send "hello world"

    # dequeue the next message (if any)
    python -m tools.comms_tool internal-receive

    # send a JSON payload to an HTTP endpoint
    python -m tools.comms_tool http --url https://example.com/api \
        --payload '{"message": "ping"}'

When imported, the module exposes three convenience functions:
``send_internal``, ``receive_internal`` and ``send_http``.

Developed and maintained by Adam Henry Nagle.  Contact:
603‑384‑8949, cainkilledabrl@icloud.com, nagleadam75@gmail.com.
"""

from __future__ import annotations

import argparse
import json
from typing import Any, Optional

from engines.comms_engine import CommsEngine


# maintain a single global engine to preserve the internal queue
_engine: Optional[CommsEngine] = None


def _get_engine() -> CommsEngine:
    """Return the global ``CommsEngine`` instance, creating it on demand."""
    global _engine
    if _engine is None:
        _engine = CommsEngine()
    return _engine


def send_internal(message: Any) -> None:
    """Send a message to the internal queue of the global engine."""
    engine = _get_engine()
    engine.send_internal(message)


def receive_internal() -> Optional[Any]:
    """Receive the next internal message if available.

    Returns
    -------
    Optional[Any]
        The message if one is queued, otherwise ``None``.
    """
    engine = _get_engine()
    return engine.receive_internal()


def send_http(url: str, payload: Any, timeout: int = 5) -> Any:
    """Send an HTTP POST request via the global engine.

    Parameters
    ----------
    url: str
        The endpoint to post to.
    payload: Any
        JSON‑serialisable object or string body.
    timeout: int, optional
        Timeout in seconds for the request (default is 5).

    Returns
    -------
    Any
        The JSON response if parsable, the raw text response, or an
        error dictionary on failure.
    """
    engine = _get_engine()
    return engine.send_http(url, payload, timeout=timeout)


def _main() -> None:
    """Entry point for the comms tool CLI."""
    parser = argparse.ArgumentParser(description="Comms Tool")
    sub = parser.add_subparsers(dest="cmd")
    # internal send
    send_parser = sub.add_parser("internal-send", help="Send an internal message")
    send_parser.add_argument("message", help="Message to enqueue")
    # internal receive
    sub.add_parser("internal-receive", help="Receive an internal message")
    # http send
    http_parser = sub.add_parser("http", help="Send a JSON HTTP POST request")
    http_parser.add_argument("--url", required=True, help="Target URL")
    http_parser.add_argument(
        "--payload",
        default="{}",
        help="JSON string payload to send (defaults to empty object)",
    )
    http_parser.add_argument(
        "--timeout",
        type=int,
        default=5,
        help="Request timeout in seconds (default 5)",
    )
    args = parser.parse_args()
    if args.cmd == "internal-send":
        send_internal(args.message)
        print("Message enqueued")
    elif args.cmd == "internal-receive":
        msg = receive_internal()
        print(msg if msg is not None else "No message")
    elif args.cmd == "http":
        try:
            payload: Any = json.loads(args.payload)
        except json.JSONDecodeError:
            # treat payload as a raw string if not valid JSON
            payload = args.payload
        result = send_http(args.url, payload, timeout=args.timeout)
        print(result)
    else:
        parser.print_help()


if __name__ == "__main__":  # pragma: no cover
    _main()