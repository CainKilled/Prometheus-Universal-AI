"""
Server Tool
===========

This module provides a command‑line interface for working with the
``ServerEngine``.  It allows you to start and stop a simple HTTP server
from the command line or import helper functions in other code.

Usage:

    python -m tools.server_tool start --host 0.0.0.0 --port 8080
    python -m tools.server_tool status
    python -m tools.server_tool stop

When imported, the module exposes ``start_server``, ``stop_server`` and
``server_status`` functions.  These maintain an internal global
``ServerEngine`` instance so multiple commands in the same process can
control a single server instance.

Developed and maintained by Adam Henry Nagle.  Contact:
603‑384‑8949, cainkilledabrl@icloud.com, nagleadam75@gmail.com.
"""

from __future__ import annotations

import argparse
from typing import Optional

from engines.server_engine import ServerEngine


_engine: Optional[ServerEngine] = None


def start_server(host: str = "127.0.0.1", port: int = 8000) -> bool:
    """Start the global server if not already running."""
    global _engine
    if _engine is None:
        _engine = ServerEngine(host=host, port=port)
        return _engine.start()
    return False


def stop_server() -> bool:
    """Stop the global server if running."""
    global _engine
    if _engine is not None:
        ok = _engine.stop()
        _engine = None
        return ok
    return False


def server_status() -> bool:
    """Return True if the global server is running."""
    return _engine is not None and _engine.status()


def _main() -> None:
    parser = argparse.ArgumentParser(description="Server Tool")
    sub = parser.add_subparsers(dest="cmd")
    start_parser = sub.add_parser("start", help="Start the server")
    start_parser.add_argument("--host", default="127.0.0.1", help="Bind host")
    start_parser.add_argument("--port", type=int, default=8000, help="Bind port")
    sub.add_parser("stop", help="Stop the server")
    sub.add_parser("status", help="Check server status")
    args = parser.parse_args()
    if args.cmd == "start":
        ok = start_server(args.host, args.port)
        print("Server started" if ok else "Server already running")
    elif args.cmd == "stop":
        ok = stop_server()
        print("Server stopped" if ok else "Server not running")
    elif args.cmd == "status":
        print("Server running" if server_status() else "Server not running")
    else:
        parser.print_help()


if __name__ == "__main__":
    _main()
