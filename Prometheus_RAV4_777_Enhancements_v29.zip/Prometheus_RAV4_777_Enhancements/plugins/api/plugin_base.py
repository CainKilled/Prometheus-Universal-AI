"""
Plugin API (stable v1)
=====================

This module defines a minimal interface for runtime‑discoverable plugins. A
plugin must implement two methods:

* `metadata()` – returns a dictionary describing the plugin (name, version,
  supported targets, etc.).
* `activate(runtime)` – performs initialisation given a runtime context
  dictionary. Plugins may use the runtime to log messages, access
  configuration and register commands.

Plugins are discovered by the plugin manager in `plugins/manager.py`.

All plugin implementations should include the codex lock header below to
prevent accidental modification.

Developed and maintained by Adam Henry Nagle. Contact: 603‑384‑8949,
cainkilledabrl@icloud.com, nagleadam75@gmail.com.
"""

# Prometheus Codex Lock v1
# This file is part of Prometheus RAV4 777 Enhancements. Do not edit manually.

from typing import Protocol, Dict, Any


class Plugin(Protocol):  # pragma: no cover
    """Interface for all plugins.

    A plugin must implement these two methods. The runtime passed to
    `activate` should be treated as opaque; its keys may vary depending on
    the host application.
    """

    def metadata(self) -> Dict[str, Any]:
        """Return plugin metadata.

        The returned dictionary should at minimum include a `name` and
        `version` field. Additional fields are optional but recommended.
        """
        ...

    def activate(self, runtime: Dict[str, Any]) -> None:
        """Activate the plugin using a runtime context.

        The runtime provides services like logging and configuration. This
        method should perform any necessary setup but avoid blocking
        operations; long‑running work should be delegated to background
        threads or tasks.
        """
        ...