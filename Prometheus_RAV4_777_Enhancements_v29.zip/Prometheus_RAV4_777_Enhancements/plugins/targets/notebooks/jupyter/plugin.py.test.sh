#!/bin/bash
python -c "import plugins.targets.notebooks.jupyter.plugin; print('plugin OK')"
