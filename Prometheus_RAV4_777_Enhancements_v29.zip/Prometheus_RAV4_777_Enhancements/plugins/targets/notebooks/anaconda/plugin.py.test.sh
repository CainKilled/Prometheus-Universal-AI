#!/bin/bash
python -c "import plugins.targets.notebooks.anaconda.plugin; print('plugin OK')"
