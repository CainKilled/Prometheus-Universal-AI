"""
Utilities Plugin
=================

Expose the Utilities engine through the runtime.  The plugin accepts
requests to perform file reading, writing, copying, moving, deletion and
disk usage queries.  Parameters are passed directly to the underlying
engine without modification.

Runtime parameters:

``action`` (str)
    The operation to perform (read, write, copy, move, delete, disk_usage).
``path``, ``src``, ``dst``, ``content``
    Additional parameters required for specific actions.
``root`` (str)
    Optional base path.  Defaults to current working directory.
``log`` (callable)
    Optional logger for status messages.  Defaults to ``print``.

Developed and maintained by Adam Henry Nagle.  Contact: 603‑384‑8949,
cainkilledabrl@icloud.com, nagleadam75@gmail.com.
"""

from __future__ import annotations

from typing import Dict, Any

from engines.utilities_engine import UtilitiesEngine
from plugins.api.plugin_base import Plugin


class UtilitiesPlugin:
    def metadata(self) -> Dict[str, Any]:
        return {
            'name': 'utilities',
            'version': '0.1.0',
            'description': 'Perform basic file and system operations.',
            'targets': ['file'],
        }

    def activate(self, runtime: Dict[str, Any]) -> Dict[str, Any] | None:
        # Pass all parameters through to the engine
        engine = UtilitiesEngine()
        return engine.run(runtime)


def get_plugin() -> Plugin:
    return UtilitiesPlugin()  # type: ignore[return-value]