#!/bin/bash
python -c "import plugins.targets.terminal.plugin; print('plugin OK')"
