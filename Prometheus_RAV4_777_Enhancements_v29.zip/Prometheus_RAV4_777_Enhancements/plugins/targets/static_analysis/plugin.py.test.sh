#!/bin/bash
# Smoke test for static_analysis plugin
python - <<'PY'
import sys
sys.path.insert(0, 'Prometheus_RAV4_777_Enhancements')
from plugins.targets.static_analysis.plugin import get_plugin
p = get_plugin()
meta = p.metadata()
assert meta['name'] == 'static_analysis'
print('static_analysis plugin OK')
PY