#!/bin/bash
python -c "import plugins.targets.tool_builder.plugin; print('plugin OK')"
