"""
Sender Plugin
=============

Expose the Sender engine to send TCP/UDP messages.  Supported action
is ``send`` which requires ``host``, ``port`` and ``message``, and
optionally ``protocol``.  See :mod:`engines.sender_engine` for
details.

Developed and maintained by Adam Henry Nagle.  Contact: 603‑384‑8949,
cainkilledabrl@icloud.com, nagleadam75@gmail.com.
"""

from __future__ import annotations

from typing import Dict, Any

from engines.sender_engine import SenderEngine
from plugins.api.plugin_base import Plugin


class SenderPlugin:
    def metadata(self) -> Dict[str, Any]:
        return {
            'name': 'sender',
            'version': '0.1.0',
            'description': 'Send TCP or UDP messages.',
            'targets': ['network'],
        }

    def activate(self, runtime: Dict[str, Any]) -> Dict[str, Any] | None:
        engine = SenderEngine()
        return engine.run(runtime)


def get_plugin() -> Plugin:
    return SenderPlugin()  # type: ignore[return-value]