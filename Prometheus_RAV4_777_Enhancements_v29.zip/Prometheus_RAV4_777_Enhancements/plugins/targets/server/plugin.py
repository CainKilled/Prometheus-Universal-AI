"""
Server Plugin
=============

This plugin provides a simple interface for starting an HTTP server via
the ``ServerEngine``.  It can be invoked through the CLI to launch
a basic web server that serves files from the current working
directory.  The plugin accepts the following runtime parameters:

``host``: The hostname or IP address to bind to (default: 127.0.0.1)
``port``: The port to listen on (default: 8000)
``action``: The action to perform.  Supported values:
    ``start`` – start a new server (default)
    ``status`` – return a boolean indicating if the server is running

Due to the stateless nature of plugin invocations, stopping a server
that was started by a previous invocation is not supported.  Use the
engine API directly if you need finer control over server lifecycle.

Developed and maintained by Adam Henry Nagle.  Contact:
603‑384‑8949, cainkilledabrl@icloud.com, nagleadam75@gmail.com.
"""

# Prometheus Codex Lock v1
# This file is part of Prometheus RAV4 777 Enhancements. Do not edit manually.

from typing import Dict, Any
from plugins.api.plugin_base import Plugin

from engines.server_engine import ServerEngine


class ServerPlugin:
    """Launch and inspect a simple HTTP server."""

    def metadata(self) -> Dict[str, Any]:
        return {
            "name": "server",
            "version": "1.0.0",
            "description": "Start or query a simple HTTP server using ServerEngine.",
            "targets": ["server"],
        }

    def activate(self, runtime: Dict[str, Any]) -> None:
        logger = runtime.get("log", print)
        host = runtime.get("host", "127.0.0.1")
        port = int(runtime.get("port", 8000))
        action = runtime.get("action", "start")
        engine = ServerEngine(host=host, port=port)
        if action == "start":
            ok = engine.start()
            if ok:
                logger(f"Server started at http://{host}:{port}/")
            else:
                logger("Server already running or could not start")
        elif action == "status":
            logger(f"Server running: {engine.status()}")
        else:
            logger(f"Unsupported action: {action}")


def get_plugin() -> Plugin:
    return ServerPlugin()  # type: ignore[return-value]