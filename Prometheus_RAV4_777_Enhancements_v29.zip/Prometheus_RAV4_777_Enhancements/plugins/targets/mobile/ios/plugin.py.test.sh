#!/bin/bash
python -c "import plugins.targets.mobile.ios.plugin; print('plugin OK')"
