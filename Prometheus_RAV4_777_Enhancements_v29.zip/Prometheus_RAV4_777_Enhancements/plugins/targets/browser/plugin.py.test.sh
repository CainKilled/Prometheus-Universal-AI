#!/bin/bash
python -c "import plugins.targets.browser.plugin; print('plugin OK')"
