"""Ethernet plugin package."""

from .plugin import get_plugin  # noqa: F401