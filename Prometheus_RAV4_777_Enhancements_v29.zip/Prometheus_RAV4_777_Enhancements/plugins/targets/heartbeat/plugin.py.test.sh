#!/bin/bash
# Smoke test for heartbeat plugin
python - <<'PY'
import sys
sys.path.insert(0, 'Prometheus_RAV4_777_Enhancements')
from plugins.targets.heartbeat.plugin import get_plugin
p = get_plugin()
assert p.metadata()['name'] == 'heartbeat'
print('heartbeat plugin OK')
PY