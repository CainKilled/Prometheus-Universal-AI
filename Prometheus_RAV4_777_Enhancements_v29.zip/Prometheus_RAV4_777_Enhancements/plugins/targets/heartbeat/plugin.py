"""
Heartbeat Plugin
================

This plugin provides access to the Heartbeat engine.  It starts and
stops periodic heartbeat messages that are emitted by a background
thread.  Heartbeats are printed by default but a custom callback
function can be supplied in the runtime parameters.

Runtime parameters:

``action`` (str)
    ``start`` (default) or ``stop``.
``interval`` (float)
    Seconds between heartbeats.  Default is 60.
``callback`` (callable)
    Function called with a timestamp string for each heartbeat.

Developed and maintained by Adam Henry Nagle.  Contact: 603‑384‑8949,
cainkilledabrl@icloud.com, nagleadam75@gmail.com.
"""

from __future__ import annotations

from typing import Dict, Any

from engines.heartbeat_engine import HeartbeatEngine
from plugins.api.plugin_base import Plugin


# Maintain a single engine instance to allow start/stop control across calls
_ENGINE: HeartbeatEngine | None = None


class HeartbeatPlugin:
    def metadata(self) -> Dict[str, Any]:
        return {
            'name': 'heartbeat',
            'version': '0.1.0',
            'description': 'Emit periodic heartbeat messages.',
            'targets': ['monitoring'],
        }

    def activate(self, runtime: Dict[str, Any]) -> Dict[str, Any] | None:
        global _ENGINE
        action = runtime.get('action', 'start')
        interval = runtime.get('interval')
        callback = runtime.get('callback')
        if _ENGINE is None:
            _ENGINE = HeartbeatEngine()
        return _ENGINE.run({'action': action, 'interval': interval, 'callback': callback})


def get_plugin() -> Plugin:
    return HeartbeatPlugin()  # type: ignore[return-value]