#!/bin/bash
python -c "import plugins.targets.wizard.plugin; print('plugin OK')"
