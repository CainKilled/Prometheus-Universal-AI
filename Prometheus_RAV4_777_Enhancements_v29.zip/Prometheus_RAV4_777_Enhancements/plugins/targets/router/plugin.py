"""
Router Plugin
=============

Expose the Router engine to inspect and manipulate the system routing
table.  Supported actions include ``routes``, ``add`` and ``delete``.
See :mod:`engines.router_engine` for details.

Developed and maintained by Adam Henry Nagle.  Contact: 603‑384‑8949,
cainkilledabrl@icloud.com, nagleadam75@gmail.com.
"""

from __future__ import annotations

from typing import Dict, Any

from engines.router_engine import RouterEngine
from plugins.api.plugin_base import Plugin


class RouterPlugin:
    def metadata(self) -> Dict[str, Any]:
        return {
            'name': 'router',
            'version': '0.1.0',
            'description': 'Inspect and modify the routing table (stub).',
            'targets': ['network'],
        }

    def activate(self, runtime: Dict[str, Any]) -> Dict[str, Any] | None:
        engine = RouterEngine()
        return engine.run(runtime)


def get_plugin() -> Plugin:
    return RouterPlugin()  # type: ignore[return-value]