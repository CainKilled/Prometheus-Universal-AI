#!/bin/bash
python -c "import plugins.targets.vector.plugin; print('plugin OK')"
