"""
Environment Plugin
===================

This plugin provides access to the :class:`~engines.environment_engine.EnvironmentEngine`
from the Prometheus runtime. It allows users to list available development
environments, view a specific environment definition, and scaffold a new
project based on an environment template.

All code in this module is developed and maintained by Adam Henry Nagle
(phone: 603‑384‑8949, emails: cainkilledabrl@icloud.com & nagleadam75@gmail.com).

Invocation Options
------------------

The plugin accepts the following parameters via the ``runtime`` dict:

``action``
    Required. One of ``list``, ``show``, or ``create``.

``name``
    Optional. The name of the environment to show or create. Required for
    ``show`` and ``create`` actions.

``destination``
    Optional. The path where the environment should be created. Required
    for the ``create`` action.

Example::

    runtime = {
        "root": "/path/to/Prometheus_RAV4_777_Enhancements",
        "action": "create",
        "name": "web_basic",
        "destination": "/tmp/my_web_app"
    }
    env_plugin(logger, runtime)

"""

import json
import os
from typing import Any, Dict

from engines.environment_engine import EnvironmentEngine


def activate(logger: callable, runtime: Dict[str, Any]) -> None:
    """Entry point for the environment plugin.

    This function is called by the Prometheus kernel. It parses the runtime
    dictionary, instantiates the :class:`EnvironmentEngine`, and performs
    the requested action.

    Parameters
    ----------
    logger : callable
        A logging function provided by the runtime. Use this to emit
        messages back to the caller.
    runtime : dict
        Dictionary containing runtime parameters. Expected keys are
        ``root``, ``action``, ``name``, and ``destination``.
    """
    root = runtime.get("root", os.getcwd())
    action = runtime.get("action")
    if not action:
        logger("No action specified for environment plugin")
        return
    engine = EnvironmentEngine(base_dir=root, logger=logger)
    try:
        if action == "list":
            envs = engine.list_definitions()
            logger(json.dumps(envs, indent=2))
        elif action == "show":
            name = runtime.get("name")
            if not name:
                logger("Missing 'name' for show action")
                return
            spec = engine.get_definition(name)
            logger(json.dumps(spec, indent=2))
        elif action == "create":
            name = runtime.get("name")
            destination = runtime.get("destination")
            if not name or not destination:
                logger("Missing 'name' or 'destination' for create action")
                return
            engine.create_environment(name, destination)
            logger(f"Environment '{name}' created at {destination}")
        else:
            logger(f"Unknown action: {action}")
    except Exception as exc:
        logger(f"Error: {exc}")


class EnvironmentPlugin:
    """Plugin wrapper for the environment engine.

    This class conforms to the Prometheus plugin protocol by providing
    ``metadata`` and ``activate`` methods.  The metadata identifies
    the plugin and describes its purpose.  The ``activate`` method
    delegates to the module-level :func:`activate` defined above.
    """

    def metadata(self) -> Dict[str, str]:
        return {
            "name": "environment",
            "version": "1.0.0",
            "description": "Manage development environment definitions and scaffolds",
        }

    def activate(self, runtime: Dict[str, Any]) -> None:
        log = runtime.get("log", print)
        activate(log, runtime)


def get_plugin() -> EnvironmentPlugin:
    """Return an instance of :class:`EnvironmentPlugin` for discovery."""
    return EnvironmentPlugin()
