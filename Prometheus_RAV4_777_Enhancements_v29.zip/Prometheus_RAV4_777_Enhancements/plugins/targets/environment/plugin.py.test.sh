#!/bin/bash
python -c "import plugins.targets.environment.plugin; print('plugin OK')"
