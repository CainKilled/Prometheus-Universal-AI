#!/bin/bash
# Smoke test for manifest plugin
python - <<'PY'
import sys
sys.path.insert(0, 'Prometheus_RAV4_777_Enhancements')
from plugins.targets.manifest.plugin import get_plugin
p = get_plugin()
meta = p.metadata()
assert meta['name'] == 'manifest'
print('manifest plugin OK')
PY