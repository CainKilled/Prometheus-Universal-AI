#!/bin/bash
python -c "import plugins.targets.databases.mongo.plugin; print('plugin OK')"
