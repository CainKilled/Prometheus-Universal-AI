"""
Theme Plugin
============

This plugin provides access to the Theme engine through the unified
runtime.  Users can list available themes, view a theme’s details and
apply a theme to the web dashboard.  Applying a theme writes a
``theme.css`` file under ``webapp/assets`` that defines CSS variables.

Runtime parameters:

``action`` (str)
    ``list`` (default), ``show`` or ``apply``.
``name`` (str)
    Theme name (without .json) for ``show`` or ``apply``.
``root`` (str)
    Optional root directory.  Defaults to current working directory.
``log`` (callable)
    Optional logger for status messages.  Defaults to ``print``.

Developed and maintained by Adam Henry Nagle.  Contact: 603‑384‑8949,
cainkilledabrl@icloud.com, nagleadam75@gmail.com.
"""

from __future__ import annotations

from typing import Dict, Any

from engines.theme_engine import ThemeEngine
from plugins.api.plugin_base import Plugin


class ThemePlugin:
    def metadata(self) -> Dict[str, Any]:
        return {
            'name': 'theme',
            'version': '0.1.0',
            'description': 'Manage and apply UI themes.',
            'targets': ['ui'],
        }

    def activate(self, runtime: Dict[str, Any]) -> Dict[str, Any] | None:
        action = runtime.get('action', 'list')
        name = runtime.get('name')
        root = runtime.get('root')
        log = runtime.get('log', print)
        engine = ThemeEngine()
        return engine.run({'action': action, 'name': name, 'root': root, 'log': log})


def get_plugin() -> Plugin:
    return ThemePlugin()  # type: ignore[return-value]