"""
Metal Plugin
============

Expose the Metal engine to perform GPU/Metal operations.  Since
Metal is not available in this environment, all operations are
stubbed.  Supported actions are ``info`` (list GPUs) and ``compile``
(compile Metal shader source to a digest).

Runtime parameters
------------------

See :mod:`engines.metal_engine` for details.

Developed and maintained by Adam Henry Nagle.  Contact: 603‑384‑8949,
cainkilledabrl@icloud.com, nagleadam75@gmail.com.
"""

from __future__ import annotations

from typing import Dict, Any

from engines.metal_engine import MetalEngine
from plugins.api.plugin_base import Plugin


class MetalPlugin:
    def metadata(self) -> Dict[str, Any]:
        return {
            'name': 'metal',
            'version': '0.1.0',
            'description': 'Perform stubbed GPU/Metal operations.',
            'targets': ['graphics'],
        }

    def activate(self, runtime: Dict[str, Any]) -> Dict[str, Any] | None:
        engine = MetalEngine()
        return engine.run(runtime)


def get_plugin() -> Plugin:
    return MetalPlugin()  # type: ignore[return-value]