"""
Beacon Plugin
=============

Expose the Beacon engine for broadcasting periodic UDP beacons.
Supported actions are ``start``, ``stop`` and ``status``.  See
:mod:`engines.beacon_engine` for details.

Developed and maintained by Adam Henry Nagle.  Contact: 603‑384‑8949,
cainkilledabrl@icloud.com, nagleadam75@gmail.com.
"""

from __future__ import annotations

from typing import Dict, Any

from engines.beacon_engine import BeaconEngine
from plugins.api.plugin_base import Plugin


class BeaconPlugin:
    def __init__(self) -> None:
        self.engine = BeaconEngine()

    def metadata(self) -> Dict[str, Any]:
        return {
            'name': 'beacon',
            'version': '0.1.0',
            'description': 'Broadcast a periodic UDP beacon.',
            'targets': ['network'],
        }

    def activate(self, runtime: Dict[str, Any]) -> Dict[str, Any] | None:
        return self.engine.run(runtime)


def get_plugin() -> Plugin:
    return BeaconPlugin()  # type: ignore[return-value]