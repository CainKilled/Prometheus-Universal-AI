#!/bin/bash
python -c "import plugins.targets.editor.vscode.plugin; print('plugin OK')"
