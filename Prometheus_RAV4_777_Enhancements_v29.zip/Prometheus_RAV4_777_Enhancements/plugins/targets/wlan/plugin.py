"""
WLAN Plugin
===========

Expose the Wlan engine for managing the ``wlan0`` interface.  Supported
actions include ``status``, ``info``, ``enable`` and ``disable``.
See :mod:`engines.wlan_engine` for details.

Developed and maintained by Adam Henry Nagle.  Contact: 603‑384‑8949,
cainkilledabrl@icloud.com, nagleadam75@gmail.com.
"""

from __future__ import annotations

from typing import Dict, Any

from engines.wlan_engine import WlanEngine
from plugins.api.plugin_base import Plugin


class WlanPlugin:
    def metadata(self) -> Dict[str, Any]:
        return {
            'name': 'wlan',
            'version': '0.1.0',
            'description': 'Manage the wlan0 wireless interface.',
            'targets': ['network'],
        }

    def activate(self, runtime: Dict[str, Any]) -> Dict[str, Any] | None:
        engine = WlanEngine()
        return engine.run(runtime)


def get_plugin() -> Plugin:
    return WlanPlugin()  # type: ignore[return-value]