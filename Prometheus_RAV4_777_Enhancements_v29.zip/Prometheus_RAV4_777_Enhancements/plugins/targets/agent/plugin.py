"""
Agent Plugin
============

Expose the Agent engine to manage long‑running helper components.
This plugin allows starting, stopping and querying the status of
named agents via the runtime.  Agents are represented by subprocesses
launched by the user through this plugin; the plugin does not
implement agent logic itself.

Runtime parameters
------------------

``action`` (str)
    ``start`` (default), ``stop`` or ``status``.
``name`` (str)
    Name of the agent to manage.  Required for ``stop`` and
    ``status`` actions.
``command`` (str)
    Command to run when starting an agent.  Required for ``start``.
``log`` (callable)
    Optional logger for status messages.  Defaults to ``print``.

Developed and maintained by Adam Henry Nagle.  Contact: 603‑384‑8949,
cainkilledabrl@icloud.com, nagleadam75@gmail.com.
"""

from __future__ import annotations

from typing import Dict, Any

from engines.agent_engine import AgentEngine
from plugins.api.plugin_base import Plugin


class AgentPlugin:
    def metadata(self) -> Dict[str, Any]:
        return {
            'name': 'agent',
            'version': '0.1.0',
            'description': 'Manage long‑running agents (start/stop/status).',
            'targets': ['system'],
        }

    def activate(self, runtime: Dict[str, Any]) -> Dict[str, Any] | None:
        engine = AgentEngine()
        return engine.run(runtime)


def get_plugin() -> Plugin:
    return AgentPlugin()  # type: ignore[return-value]