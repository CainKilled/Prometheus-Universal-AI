"""
Networking Plugin
=================

Expose the Networking engine to perform simple network diagnostics.  The
plugin accepts actions such as listing interfaces, querying interface
information or pinging hosts.  Wi‑Fi scanning and interface control are
stubbed for future extensions.

Runtime parameters:

``action`` (str)
    ``interfaces`` (default), ``info``, ``ping``, ``wifi_scan``, ``enable`` or
    ``disable``.
``iface`` (str)
    Interface name for ``info``, ``enable`` or ``disable`` actions.
``host`` (str)
    Hostname or IP address for ``ping``.
``count`` (int)
    Packet count for ``ping``.  Defaults to 1.
``log`` (callable)
    Optional logger for status messages.  Defaults to ``print``.

Developed and maintained by Adam Henry Nagle.  Contact: 603‑384‑8949,
cainkilledabrl@icloud.com, nagleadam75@gmail.com.
"""

from __future__ import annotations

from typing import Dict, Any

from engines.networking_engine import NetworkingEngine
from plugins.api.plugin_base import Plugin


class NetworkingPlugin:
    def metadata(self) -> Dict[str, Any]:
        return {
            'name': 'networking',
            'version': '0.1.0',
            'description': 'Run basic network diagnostics (interfaces, info, ping).',
            'targets': ['diagnostics'],
        }

    def activate(self, runtime: Dict[str, Any]) -> Dict[str, Any] | None:
        engine = NetworkingEngine()
        return engine.run(runtime)


def get_plugin() -> Plugin:
    return NetworkingPlugin()  # type: ignore[return-value]