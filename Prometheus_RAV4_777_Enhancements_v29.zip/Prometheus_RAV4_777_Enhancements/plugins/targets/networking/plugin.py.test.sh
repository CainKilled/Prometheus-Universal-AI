#!/bin/bash
# Smoke test for networking plugin
python - <<'PY'
import sys
sys.path.insert(0, 'Prometheus_RAV4_777_Enhancements')
from plugins.targets.networking.plugin import get_plugin
p = get_plugin()
assert p.metadata()['name'] == 'networking'
print('networking plugin OK')
PY