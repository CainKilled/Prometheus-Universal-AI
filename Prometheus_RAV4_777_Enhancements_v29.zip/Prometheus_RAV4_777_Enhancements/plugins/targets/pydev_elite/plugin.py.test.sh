#!/usr/bin/env bash
# Test script for pydev_elite plugin

python - <<'PY'
from plugins.targets.pydev_elite.plugin import get_plugin

plugin = get_plugin()
assert plugin.metadata()["name"] == "pydev_elite"
print("pydev_elite plugin OK")
PY