"""
Hugging Face Plugin
===================

This plugin provides a simple interface to the Hugging Face Inference API.
It wraps the ``HuggingFaceEngine`` and allows users to call models
directly from the Prometheus runtime.  You can specify the model
identifier, input text and optional generation parameters.  A Hugging
Face API token must be provided either via the ``token`` runtime
parameter or the ``HUGGINGFACE_API_TOKEN`` environment variable.

Runtime parameters:

    model (str): The Hugging Face model identifier.
    input (str): The input prompt for the model.
    parameters (dict): Optional additional parameters (e.g. max_new_tokens).
    token (str): Optional API token (falls back to environment variable).
    log (callable): Optional logger for status messages.

Example:

    kernel.run_plugin('huggingface', {
        'model': 'gpt2',
        'input': 'Once upon a time',
        'parameters': {'max_new_tokens': 20},
        'token': 'hf_YOUR_TOKEN',
    })

Developed and maintained by Adam Henry Nagle.  Contact: 603‑384‑8949,
cainkilledabrl@icloud.com, nagleadam75@gmail.com.
"""

from __future__ import annotations

from typing import Any, Dict

from engines.huggingface_engine import HuggingFaceEngine
from plugins.api.plugin_base import Plugin


class HuggingFacePlugin:
    def metadata(self) -> Dict[str, Any]:
        return {
            'name': 'huggingface',
            'version': '0.1.0',
            'description': 'Call Hugging Face models via the Inference API',
            'targets': ['ai', 'llm'],
        }

    def activate(self, runtime: Dict[str, Any]) -> Dict[str, Any] | None:
        model: str | None = runtime.get('model')
        input_text: str | None = runtime.get('input')
        parameters = runtime.get('parameters')
        token: str | None = runtime.get('token')
        log = runtime.get('log', print)
        if not model:
            log("HuggingFacePlugin: 'model' parameter is required")
            return {'error': "'model' is required"}
        if input_text is None:
            log("HuggingFacePlugin: 'input' parameter is required")
            return {'error': "'input' is required"}
        engine = HuggingFaceEngine()
        result = engine.generate(model=model, input_text=input_text, token=token, parameters=parameters)
        return result


def get_plugin() -> Plugin:
    return HuggingFacePlugin()  # type: ignore[return-value]