#!/bin/bash
python -c "import plugins.targets.universal.ide.plugin; print('plugin OK')"
