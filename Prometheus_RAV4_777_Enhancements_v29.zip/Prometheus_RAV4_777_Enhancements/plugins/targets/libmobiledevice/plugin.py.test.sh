#!/usr/bin/env bash
# Test script for LibMobileDeviceGUIPlugin

python - <<'PY'
import sys
# Extend sys.path to import the Prometheus package
sys.path.append('Prometheus_RAV4_777_Enhancements')
from plugins.targets.libmobiledevice.plugin import get_plugin

plugin = get_plugin()
assert plugin.metadata()['name'] == 'libmobiledevice_gui'
# Activate the plugin; since it launches a GUI in a background thread this
# should return immediately and not block.
plugin.activate({"log": lambda *args, **kwargs: None})
print("libmobiledevice GUI plugin OK")
PY