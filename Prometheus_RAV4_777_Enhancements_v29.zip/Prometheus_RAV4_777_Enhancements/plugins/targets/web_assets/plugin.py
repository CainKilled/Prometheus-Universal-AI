"""
Web Assets Plugin
=================

This plugin wraps the ``WebAssetsEngine`` and provides a simple
mechanism to build and minify front‑end assets from within the
Prometheus runtime.  It can be invoked via the CLI, REPL or HTTP
interface to prepare CSS and JS for deployment.  The plugin accepts
runtime parameters to specify the source and destination directories.

Runtime parameters:

    src_dir (str): Relative path to the assets directory (default
                   ``webapp/assets``).
    out_dir (str): Relative path to the output directory (default
                   ``webapp/dist``).
    log (callable): Optional logger.

Example:

    kernel.run_plugin('web_assets', {'src_dir': 'webapp/assets', 'out_dir': 'webapp/dist'})

Developed and maintained by Adam Henry Nagle.  Contact: 603‑384‑8949,
cainkilledabrl@icloud.com, nagleadam75@gmail.com.
"""

from __future__ import annotations

from typing import Any, Dict

from engines.web_assets_engine import WebAssetsEngine
from plugins.api.plugin_base import Plugin


class WebAssetsPlugin:
    def metadata(self) -> Dict[str, Any]:
        return {
            'name': 'web_assets',
            'version': '0.1.0',
            'description': 'Build and minify front‑end CSS and JS assets',
            'targets': ['web'],
        }

    def activate(self, runtime: Dict[str, Any]) -> Dict[str, Any] | None:
        src_dir = runtime.get('src_dir')
        out_dir = runtime.get('out_dir')
        log = runtime.get('log', print)
        engine = WebAssetsEngine(base_dir=runtime.get('base_dir'))
        try:
            result = engine.build_assets(src_dir=src_dir, out_dir=out_dir)
            log(f"WebAssetsPlugin: Built assets: {result}")
            return result
        except Exception as exc:
            log(f"WebAssetsPlugin: Error building assets: {exc}")
            return {'error': str(exc)}


def get_plugin() -> Plugin:
    return WebAssetsPlugin()  # type: ignore[return-value]