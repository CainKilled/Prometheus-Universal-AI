#!/usr/bin/env bash
# Test script for WebAssetsPlugin

python - <<'PY'
import sys
import os
sys.path.append('Prometheus_RAV4_777_Enhancements')
from plugins.targets.web_assets.plugin import get_plugin

plugin = get_plugin()
assert plugin.metadata()['name'] == 'web_assets'
# Run the plugin with default dirs
result = plugin.activate({'base_dir': 'Prometheus_RAV4_777_Enhancements', 'log': lambda *a, **k: None})
assert result, "Result should not be empty"
print('web assets plugin OK')
PY