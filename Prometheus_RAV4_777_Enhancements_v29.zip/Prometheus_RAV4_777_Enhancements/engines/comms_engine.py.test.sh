#!/usr/bin/env bash
# Test script for the CommsEngine

python - <<'PY'
import sys
sys.path.append('Prometheus_RAV4_777_Enhancements')
from engines.comms_engine import CommsEngine

ce = CommsEngine()
# internal messaging tests
ce.send_internal({"msg": "hello"})
assert ce.receive_internal() == {"msg": "hello"}
assert ce.receive_internal() is None
# external call test (requests may not be installed). Use a dummy URL; expect error or response.
res = ce.send_http("http://localhost:1", {"key": "value"}, timeout=1)
assert isinstance(res, dict)
print("comms_engine OK")
PY