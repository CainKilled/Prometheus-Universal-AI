"""
Receiver Engine
===============

This engine implements a simple network listener that can accept
messages from clients over TCP.  It supports starting a server on a
given host and port, stopping the server and reporting its status.

Runtime parameters
------------------

``action`` (str)
    Operation to perform.  Supported actions:

    * ``start`` – Start a TCP server.  Requires ``port``.  Optional
      ``host`` (default ``0.0.0.0``).  Starts a background thread
      listening for incoming connections.
    * ``stop`` – Stop the running server.
    * ``status`` – Return whether the server is running.

``host`` (str)
    Host to bind when starting a server.  Default ``0.0.0.0``.
``port`` (int)
    Port to listen on when starting a server.
``log`` (callable)
    Optional logger for status messages.  Defaults to ``print``.

Developed and maintained by Adam Henry Nagle.  Contact: 603‑384‑8949,
cainkilledabrl@icloud.com, nagleadam75@gmail.com.
"""

from __future__ import annotations

import socket
import threading
from typing import Dict, Any, Optional


class ReceiverEngine:
    """Engine that listens for incoming TCP messages on a background thread."""

    def __init__(self) -> None:
        self._server_thread: Optional[threading.Thread] = None
        self._sock: Optional[socket.socket] = None
        self._running = False

    def metadata(self) -> Dict[str, Any]:
        return {
            'name': 'receiver',
            'version': '0.1.0',
            'description': 'Start and stop a TCP listener to receive messages.',
        }

    def _serve(self, host: str, port: int, log) -> None:
        self._sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        self._sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        self._sock.bind((host, port))
        self._sock.listen(5)
        log(f"ReceiverEngine: listening on {host}:{port}")
        self._running = True
        try:
            while self._running:
                conn, addr = self._sock.accept()
                data = conn.recv(1024)
                log(f"ReceiverEngine: received {data!r} from {addr}")
                conn.close()
        except Exception as exc:
            log(f"ReceiverEngine: error {exc}")
        finally:
            self._running = False
            if self._sock:
                self._sock.close()
                self._sock = None

    def run(self, runtime: Dict[str, Any]) -> Dict[str, Any]:
        action = (runtime.get('action') or 'status').lower()
        log = runtime.get('log', print)
        if action == 'start':
            if self._running:
                return {'running': True, 'error': 'Already running'}
            port = runtime.get('port')
            if not port:
                return {'error': "'port' parameter required"}
            host = runtime.get('host', '0.0.0.0')
            self._server_thread = threading.Thread(target=self._serve, args=(host, int(port), log), daemon=True)
            self._server_thread.start()
            return {'running': True}
        if action == 'stop':
            if not self._running:
                return {'running': False, 'error': 'Not running'}
            self._running = False
            # Wake up server by connecting to it
            try:
                socket.create_connection(('127.0.0.1', self._sock.getsockname()[1])).close()
            except Exception:
                pass
            return {'running': False}
        if action == 'status':
            return {'running': self._running}
        return {'error': f"Unknown action '{action}'"}


def get_engine() -> ReceiverEngine:
    return ReceiverEngine()