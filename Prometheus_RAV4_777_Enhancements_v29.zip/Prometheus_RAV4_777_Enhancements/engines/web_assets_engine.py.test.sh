#!/usr/bin/env bash
# Test script for WebAssetsEngine

python - <<'PY'
import sys
sys.path.append('Prometheus_RAV4_777_Enhancements')
from engines.web_assets_engine import WebAssetsEngine

engine = WebAssetsEngine(base_dir='Prometheus_RAV4_777_Enhancements')
result = engine.build_assets(src_dir='webapp/assets', out_dir='webapp/dist')
assert isinstance(result, dict)
print('web assets engine OK')
PY