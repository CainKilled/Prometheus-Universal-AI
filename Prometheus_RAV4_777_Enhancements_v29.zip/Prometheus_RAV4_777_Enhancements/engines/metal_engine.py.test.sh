#!/bin/bash
# Smoke test for metal_engine
python - <<'PY'
import sys
sys.path.insert(0, 'Prometheus_RAV4_777_Enhancements')
from engines.metal_engine import MetalEngine
engine = MetalEngine()
assert engine.metadata()['name'] == 'metal'
print('metal_engine OK')
PY