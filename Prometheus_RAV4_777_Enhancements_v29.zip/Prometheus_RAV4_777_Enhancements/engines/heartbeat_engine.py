"""
Heartbeat Engine
================

The Heartbeat Engine emits periodic heartbeat messages to signal that a
process is alive.  It can be used by monitoring systems or other
components to detect liveness.  The engine runs a background thread
that calls a user‑provided callback on each tick.  It stops when
``stop`` action is requested.  Due to the asynchronous nature this
engine is best controlled via a plugin that maintains a singleton
instance.

Runtime parameters
------------------

``action`` (str)
    ``start`` to begin emitting heartbeats or ``stop`` to stop the
    heartbeat thread.  Defaults to ``start``.
``interval`` (float)
    Number of seconds between heartbeats.  Default is 60 seconds.
``callback`` (callable)
    Function to call on each heartbeat.  Defaults to printing a
    timestamped message.

Developed and maintained by Adam Henry Nagle.  Contact: 603‑384‑8949,
cainkilledabrl@icloud.com, nagleadam75@gmail.com.
"""

from __future__ import annotations

from typing import Dict, Any, Callable, Optional
import threading
import time
import datetime


class HeartbeatEngine:
    """Engine emitting periodic heartbeat messages."""

    def __init__(self) -> None:
        self._thread: Optional[threading.Thread] = None
        self._stop_event = threading.Event()

    def metadata(self) -> Dict[str, Any]:
        return {
            'name': 'heartbeat',
            'version': '0.1.0',
            'description': 'Emit periodic heartbeat messages in a background thread.',
        }

    def _run(self, interval: float, callback: Callable[[str], None]) -> None:
        while not self._stop_event.is_set():
            ts = datetime.datetime.utcnow().isoformat() + 'Z'
            try:
                callback(ts)
            except Exception:
                pass
            self._stop_event.wait(interval)

    def run(self, task: Dict[str, Any]) -> Dict[str, Any]:
        action = task.get('action', 'start')
        if action == 'start':
            if self._thread and self._thread.is_alive():
                return {'error': 'Heartbeat already running'}
            interval = float(task.get('interval', 60))
            callback = task.get('callback', lambda ts: print(f"heartbeat: {ts}"))
            self._stop_event.clear()
            self._thread = threading.Thread(target=self._run, args=(interval, callback), daemon=True)
            self._thread.start()
            return {'started': True, 'interval': interval}
        if action == 'stop':
            if self._thread and self._thread.is_alive():
                self._stop_event.set()
                self._thread.join(timeout=1)
                return {'stopped': True}
            return {'error': 'Heartbeat not running'}
        return {'error': f"Unknown action '{action}'"}


def get_engine() -> HeartbeatEngine:
    return HeartbeatEngine()