#!/bin/bash

# Test script for environment engine. Ensures that environment
# definitions can be listed and that a scaffold is correctly created.

set -euo pipefail

python - <<'PY'
import os
import sys
import tempfile
import json
import pathlib
sys.path.append('Prometheus_RAV4_777_Enhancements')
from engines.environment_engine import EnvironmentEngine

base_dir = pathlib.Path('Prometheus_RAV4_777_Enhancements').resolve()
engine = EnvironmentEngine(base_dir=str(base_dir), logger=print)
envs = engine.list_definitions()
assert 'web_basic' in envs and 'python_basic' in envs, f"Expected environment definitions missing: {envs}"

with tempfile.TemporaryDirectory() as tmpdir:
    engine.create_environment('web_basic', tmpdir)
    # check that index.html exists
    assert pathlib.Path(tmpdir, 'index.html').exists(), 'index.html missing in scaffold'
    # check that style.css exists
    assert pathlib.Path(tmpdir, 'style.css').exists(), 'style.css missing in scaffold'
    # check that script.js exists
    assert pathlib.Path(tmpdir, 'script.js').exists(), 'script.js missing in scaffold'
    print('Environment engine test passed')
PY