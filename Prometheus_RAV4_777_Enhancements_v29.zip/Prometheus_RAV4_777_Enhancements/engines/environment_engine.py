"""
Environment Engine
===================

This engine manages development environment definitions and can generate
starter projects based on those definitions. Environment definitions are
stored as JSON files under the ``environments/definitions`` directory. Each
definition contains metadata such as the environment name, a description,
supported languages and frameworks, and the name of a template directory
located under ``templates/environments``.  The engine exposes a simple
API to list available definitions, retrieve a specific definition, and
create a new project structure by copying the corresponding template
into a destination directory.

All code in this package is developed and maintained by Adam Henry Nagle
(phone: 603‑384‑8949, emails: cainkilledabrl@icloud.com & nagleadam75@gmail.com).

Usage Example::

    from engines.environment_engine import EnvironmentEngine
    engine = EnvironmentEngine(base_dir="/path/to/monorepo")
    defs = engine.list_definitions()  # returns list of available env names
    spec = engine.get_definition('web_basic')  # returns dict with env metadata
    engine.create_environment('web_basic', '/tmp/my_web_app')

"""

from __future__ import annotations

import json
import os
import shutil
from pathlib import Path
from typing import Dict, List, Optional


class EnvironmentEngine:
    """Engine for managing development environment definitions and scaffolding.

    Parameters
    ----------
    base_dir : str
        Path to the root of the monorepo containing ``environments`` and ``templates``.
    logger : callable, optional
        Optional logging function (e.g. ``print``). If provided, the engine
        will emit messages during operations.
    """

    def __init__(self, base_dir: str, logger: Optional[callable] = None) -> None:
        self.base_dir = Path(base_dir)
        self.definitions_dir = self.base_dir / "environments" / "definitions"
        self.templates_dir = self.base_dir / "templates" / "environments"
        self.logger = logger or (lambda *args, **kwargs: None)

    def _log(self, msg: str) -> None:
        if self.logger:
            self.logger(msg)

    def list_definitions(self) -> List[str]:
        """Return a list of available environment definition names.

        The method scans the ``environments/definitions`` directory for JSON files and
        returns their basename without the ``.json`` extension.
        """
        if not self.definitions_dir.exists():
            return []
        envs = []
        for path in sorted(self.definitions_dir.glob("*.json")):
            envs.append(path.stem)
        return envs

    def get_definition(self, name: str) -> Dict:
        """Load and return the JSON definition for a given environment.

        Parameters
        ----------
        name : str
            The name of the environment definition (without ``.json``).

        Returns
        -------
        dict
            Parsed JSON content of the environment definition.

        Raises
        ------
        FileNotFoundError
            If the definition file does not exist.
        json.JSONDecodeError
            If the definition file contains invalid JSON.
        """
        path = self.definitions_dir / f"{name}.json"
        if not path.exists():
            raise FileNotFoundError(f"Environment definition {name} not found")
        with path.open("r", encoding="utf-8") as f:
            return json.load(f)

    def create_environment(self, name: str, destination: str) -> None:
        """Create a new project based on the given environment definition.

        The method copies files from the corresponding template directory
        (``templates/environments/<template_name>``) into the ``destination``.

        Parameters
        ----------
        name : str
            The name of the environment definition to use.
        destination : str
            Path where the environment scaffold should be created. The
            destination directory will be created if it does not exist.

        Raises
        ------
        FileNotFoundError
            If the definition or template directory is missing.
        """
        spec = self.get_definition(name)
        template_name = spec.get("template")
        if not template_name:
            raise ValueError(f"Environment definition {name} missing 'template' field")
        src_dir = self.templates_dir / template_name
        if not src_dir.exists():
            raise FileNotFoundError(f"Template directory {src_dir} not found")

        dest = Path(destination)
        dest.mkdir(parents=True, exist_ok=True)
        for item in src_dir.rglob('*'):
            rel = item.relative_to(src_dir)
            target = dest / rel
            if item.is_dir():
                target.mkdir(exist_ok=True)
            else:
                # copy file preserving metadata
                shutil.copy2(item, target)
                self._log(f"Created {target}")
