"""
Beacon Engine
=============

The Beacon engine broadcasts a short UDP message on a regular
interval.  It can be used to advertise the presence of a service on
the local network.  The engine runs a background thread that sends a
packet to the broadcast address every few seconds.

Runtime parameters
------------------

``action`` (str)
    Operation to perform.  Supported actions:

    * ``start`` – Begin broadcasting.  Requires ``port`` (int) and
      optionally ``message`` (default ``Prometheus beacon``) and
      ``interval`` (float seconds, default 5).  Use ``host`` to
      specify the broadcast address (default ``255.255.255.255``).
    * ``stop`` – Stop broadcasting.
    * ``status`` – Return whether broadcasting is active.

``port`` (int)
    UDP port to broadcast to.
``message`` (str)
    Message to send in broadcast packets.
``interval`` (float)
    Time between broadcast messages in seconds.
``host`` (str)
    Broadcast address.  Default ``255.255.255.255``.
``log`` (callable)
    Optional logger for status messages.  Defaults to ``print``.

Developed and maintained by Adam Henry Nagle.  Contact: 603‑384‑8949,
cainkilledabrl@icloud.com, nagleadam75@gmail.com.
"""

from __future__ import annotations

import socket
import threading
import time
from typing import Dict, Any, Optional


class BeaconEngine:
    """Engine to broadcast periodic UDP beacons."""

    def __init__(self) -> None:
        self._thread: Optional[threading.Thread] = None
        self._running = False
        self._sock: Optional[socket.socket] = None

    def metadata(self) -> Dict[str, Any]:
        return {
            'name': 'beacon',
            'version': '0.1.0',
            'description': 'Broadcast a UDP beacon at regular intervals.',
        }

    def _broadcast_loop(self, host: str, port: int, message: str, interval: float, log) -> None:
        try:
            self._sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
            self._sock.setsockopt(socket.SOL_SOCKET, socket.SO_BROADCAST, 1)
            while self._running:
                self._sock.sendto(message.encode('utf-8'), (host, port))
                log(f"BeaconEngine: sent beacon to {host}:{port}")
                time.sleep(interval)
        except Exception as exc:
            log(f"BeaconEngine: error {exc}")
        finally:
            if self._sock:
                self._sock.close()
                self._sock = None

    def run(self, runtime: Dict[str, Any]) -> Dict[str, Any]:
        action = (runtime.get('action') or 'status').lower()
        log = runtime.get('log', print)
        if action == 'start':
            if self._running:
                return {'running': True, 'error': 'Beacon already running'}
            port = runtime.get('port')
            if not port:
                return {'error': "'port' parameter required"}
            message = runtime.get('message', 'Prometheus beacon')
            interval = float(runtime.get('interval', 5))
            host = runtime.get('host', '255.255.255.255')
            self._running = True
            self._thread = threading.Thread(target=self._broadcast_loop, args=(host, int(port), message, interval, log), daemon=True)
            self._thread.start()
            return {'running': True}
        if action == 'stop':
            if not self._running:
                return {'running': False, 'error': 'Beacon not running'}
            self._running = False
            return {'running': False}
        if action == 'status':
            return {'running': self._running}
        return {'error': f"Unknown action '{action}'"}


def get_engine() -> BeaconEngine:
    return BeaconEngine()