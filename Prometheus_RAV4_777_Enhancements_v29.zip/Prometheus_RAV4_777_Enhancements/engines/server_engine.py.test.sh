#!/usr/bin/env bash
# Test script for the ServerEngine

python - <<'PY'
import sys
sys.path.append('Prometheus_RAV4_777_Enhancements')
from engines.server_engine import ServerEngine

server = ServerEngine(host='127.0.0.1', port=8081)
assert not server.status()
started = server.start()
assert started
assert server.status()
stopped = server.stop()
assert stopped
assert not server.status()
print("server_engine OK")
PY