"""
Agent Engine
============

The Agent engine manages generic agents within the Prometheus runtime.  An
"agent" in this context is any long‑running helper component that performs
background work on behalf of the user or other parts of the system.  The
engine exposes simple actions to start, stop and query the status of
named agents.  It does not itself implement the logic of any specific
agent; instead, it orchestrates and monitors processes launched via
plugins or external scripts.  Future enhancements could allow it to
register new agent types, manage their configuration and supervise their
lifecycle more robustly.

Developed and maintained by Adam Henry Nagle.
Contact: 603‑384‑8949, cainkilledabrl@icloud.com, nagleadam75@gmail.com.
"""

from __future__ import annotations

import subprocess
import shlex
from typing import Dict, Any, Optional


class AgentEngine:
    """Simple engine for managing named agents.

    The engine tracks subprocesses it spawns in a dictionary keyed by
    agent name.  Each agent must correspond to an executable file on
    disk.  The runtime dictionary accepted by ``run`` should contain
    an ``action`` key indicating what to do (``start``, ``stop`` or
    ``status``) and a ``name`` key indicating the agent to act upon.
    Additional parameters may be used in the future.
    """

    def __init__(self) -> None:
        # Keep a mapping of agent names to subprocess.Popen instances
        self._agents: Dict[str, subprocess.Popen[Any] | None] = {}

    def run(self, runtime: Dict[str, Any]) -> Dict[str, Any]:
        """Execute an action against the agent engine.

        Parameters
        ----------
        runtime: dict
            A mapping containing at least an ``action`` key.  Valid actions
            are ``start``, ``stop`` and ``status``.  When starting an
            agent, a ``command`` string must also be provided.  When
            stopping or querying, ``name`` identifies the agent.

        Returns
        -------
        dict
            A result dictionary describing the outcome of the action.
        """
        action = (runtime.get("action") or "status").lower()
        name = runtime.get("name")
        if action not in {"start", "stop", "status"}:
            return {"error": f"Unknown action '{action}'"}
        if action in {"stop", "status"} and not name:
            return {"error": "'name' is required for stop/status actions"}
        if action == "start":
            cmd = runtime.get("command")
            if not cmd:
                return {"error": "'command' is required for start action"}
            # Do not allow restarting an agent with the same name
            if name in self._agents and self._agents[name] is not None:
                return {"error": f"Agent '{name}' is already running"}
            # Launch the command as a detached subprocess
            try:
                proc = subprocess.Popen(
                    shlex.split(cmd),
                    stdout=subprocess.PIPE,
                    stderr=subprocess.PIPE,
                    text=True,
                )
                self._agents[name] = proc
                return {"ok": True, "pid": proc.pid}
            except Exception as exc:
                return {"error": str(exc)}
        if action == "stop":
            proc = self._agents.get(name)
            if proc is None:
                return {"error": f"Agent '{name}' is not running"}
            try:
                proc.terminate()
                proc.wait(timeout=10)
                self._agents[name] = None
                return {"ok": True}
            except Exception as exc:
                return {"error": str(exc)}
        # status action
        if name:
            proc = self._agents.get(name)
            if proc is None:
                return {"running": False}
            running = proc.poll() is None
            return {"running": running}
        # global status: return all agent names and running flags
        status: Dict[str, bool] = {}
        for n, proc in self._agents.items():
            status[n] = proc is not None and proc.poll() is None
        return {"agents": status}