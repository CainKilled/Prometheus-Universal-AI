#!/bin/bash
# Smoke test for wlan_engine
python - <<'PY'
import sys
sys.path.insert(0, 'Prometheus_RAV4_777_Enhancements')
from engines.wlan_engine import WlanEngine
engine = WlanEngine()
assert engine.metadata()['name'] == 'wlan'
print('wlan_engine OK')
PY