"""
Sender Engine
=============

This engine provides a simple interface for sending TCP or UDP
messages to a remote host.  It supports sending a one‑time payload
over TCP or UDP and returns the result of the send operation.

Runtime parameters
------------------

``action`` (str)
    Operation to perform.  Supported actions:

    * ``send`` – Send a message.  Requires ``host``, ``port`` and
      ``message``.  Optional ``protocol`` (``tcp`` or ``udp``, default
      ``tcp``).

``host`` (str)
    Destination host.
``port`` (int)
    Destination port.
``message`` (str)
    Message payload to send.
``protocol`` (str)
    ``tcp`` or ``udp``.  Default ``tcp``.
``log`` (callable)
    Optional logger for status messages.  Defaults to ``print``.

Developed and maintained by Adam Henry Nagle.  Contact: 603‑384‑8949,
cainkilledabrl@icloud.com, nagleadam75@gmail.com.
"""

from __future__ import annotations

import socket
from typing import Dict, Any


class SenderEngine:
    """Engine for sending TCP/UDP messages."""

    def metadata(self) -> Dict[str, Any]:
        return {
            'name': 'sender',
            'version': '0.1.0',
            'description': 'Send a TCP or UDP message to a host/port.',
        }

    def run(self, runtime: Dict[str, Any]) -> Dict[str, Any]:
        action = (runtime.get('action') or 'send').lower()
        if action != 'send':
            return {'error': f"Unknown action '{action}'"}
        host = runtime.get('host')
        port = runtime.get('port')
        message = runtime.get('message')
        protocol = runtime.get('protocol', 'tcp').lower()
        if not host or not port or message is None:
            return {'error': "'host', 'port' and 'message' parameters required"}
        try:
            if protocol == 'udp':
                sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
                sent = sock.sendto(message.encode('utf-8'), (host, int(port)))
                sock.close()
                return {'sent': sent}
            # default tcp
            with socket.create_connection((host, int(port)), timeout=5) as s:
                s.sendall(message.encode('utf-8'))
                return {'sent': len(message)}
        except Exception as exc:
            return {'error': str(exc)}


def get_engine() -> SenderEngine:
    return SenderEngine()