"""
Communications Engine
=====================

This engine provides basic facilities for internal and external
communications.  It includes an in‑memory message queue for
asynchronous inter‑component messaging as well as simple HTTP
request functions for interacting with external services.  These
primitives can be used to build higher‑level messaging pipelines or
remote procedure calls within the Prometheus ecosystem.

Developed and maintained by Adam Henry Nagle.  Contact:
603‑384‑8949, cainkilledabrl@icloud.com, nagleadam75@gmail.com.
"""

# Prometheus Codex Lock v1
# This file is part of Prometheus RAV4 777 Enhancements. Do not edit manually.

from __future__ import annotations

import queue
from typing import Any, Optional

try:
    import requests  # type: ignore
except ImportError:
    requests = None  # fallback to None if requests isn't available


class CommsEngine:
    """A simple communications engine.

    Internal messages are queued using ``queue.Queue``.  External
    communications are performed using HTTP POST requests via the
    ``requests`` library if available.  These methods intentionally
    return basic types (strings, dicts) to avoid coupling with any
    particular framework.
    """

    def __init__(self) -> None:
        self._queue: queue.Queue[Any] = queue.Queue()

    # internal comms
    def send_internal(self, message: Any) -> None:
        """Enqueue a message for internal consumption."""
        self._queue.put(message)

    def receive_internal(self) -> Optional[Any]:
        """Retrieve the next internal message if one is available; otherwise return ``None``."""
        try:
            return self._queue.get_nowait()
        except queue.Empty:
            return None

    # external comms
    def send_http(self, url: str, payload: Any, timeout: int = 5) -> Any:
        """Send a JSON POST request to an external service.

        If the ``requests`` library is unavailable, this method returns
        an error dictionary.  The return value is the JSON response on
        success or a dictionary with an ``error`` key on failure.
        """
        if requests is None:
            return {"error": "requests library not installed"}
        try:
            response = requests.post(url, json=payload, timeout=timeout)
            try:
                return response.json()
            except ValueError:
                return response.text
        except Exception as exc:  # broad catch to avoid leaking exceptions
            return {"error": str(exc)}


__all__ = ["CommsEngine"]