#!/bin/bash
python -c "import engines.macros_engine; print('macros_engine OK')"
