#!/bin/bash
# Smoke test for heartbeat_engine
python - <<'PY'
import sys
sys.path.insert(0, 'Prometheus_RAV4_777_Enhancements')
from engines.heartbeat_engine import HeartbeatEngine
engine = HeartbeatEngine()
assert engine.metadata()['name'] == 'heartbeat'
print('heartbeat_engine OK')
PY