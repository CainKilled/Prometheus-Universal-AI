"""
Ethernet Engine
===============

This engine provides basic operations for wired Ethernet interfaces,
notably the typical ``eth0`` device on Linux systems.  It can report
interface status, enable or disable the interface, and return IP
address information.  When run on systems without ``ip`` or
``ifconfig``, operations will fall back to stubs.

Runtime parameters
------------------

``action`` (str)
    Operation to perform.  Supported actions:

    * ``status`` – Check whether eth0 is up and return link state.
    * ``enable`` – Bring the interface up (stub).
    * ``disable`` – Bring the interface down (stub).
    * ``info`` – Return IP address information for eth0.

``log`` (callable)
    Optional logger for status messages.  Defaults to ``print``.

Developed and maintained by Adam Henry Nagle.  Contact: 603‑384‑8949,
cainkilledabrl@icloud.com, nagleadam75@gmail.com.
"""

from __future__ import annotations

import subprocess
from typing import Dict, Any


class Eth0Engine:
    """Engine for basic Ethernet (eth0) operations."""

    def metadata(self) -> Dict[str, Any]:
        return {
            'name': 'eth0',
            'version': '0.1.0',
            'description': 'Manage wired Ethernet interface eth0.',
        }

    def run(self, runtime: Dict[str, Any]) -> Dict[str, Any]:
        action = (runtime.get('action') or 'status').lower()
        log = runtime.get('log', print)
        if action == 'status':
            try:
                result = subprocess.run(['cat', '/sys/class/net/eth0/operstate'], capture_output=True, text=True)
                if result.returncode == 0:
                    state = result.stdout.strip()
                    return {'state': state}
            except Exception:
                pass
            return {'state': 'unknown'}
        if action == 'info':
            try:
                result = subprocess.run(['ip', '-o', '-f', 'inet', 'addr', 'show', 'eth0'], capture_output=True, text=True)
                if result.returncode == 0:
                    fields = result.stdout.strip().split()
                    ip = None
                    for i, token in enumerate(fields):
                        if token == 'inet' and i + 1 < len(fields):
                            ip = fields[i+1]
                            break
                    return {'ip': ip}
            except Exception:
                pass
            return {'ip': None}
        if action in {'enable', 'disable'}:
            # Cannot modify network state in this environment
            return {'error': f'Ethernet {action} not implemented'}
        return {'error': f"Unknown action '{action}'"}


def get_engine() -> Eth0Engine:
    return Eth0Engine()