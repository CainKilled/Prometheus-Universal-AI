"""
Theme Engine
============

The Theme Engine manages user interface colour schemes and visual
configuration for the web dashboard and other graphical components.  It
loads theme definitions from JSON files stored under ``webapp/themes``
and can apply them by generating a CSS variables file.  This allows
users to switch between themes (e.g. ``light``, ``dark``, ``solarized``)
without editing the underlying HTML or JavaScript.

Runtime parameters
------------------

``action`` (str)
    ``list`` to list available themes, ``apply`` to activate a theme or
    ``show`` to display a theme’s definition.  Defaults to ``list``.
``name`` (str)
    The name of the theme to apply or show (without extension).  Required
    for ``apply`` and ``show`` actions.
``root`` (str)
    Optional root directory for resolution.  Defaults to current working
    directory.
``log`` (callable)
    Optional logger for status messages.  Defaults to ``print``.

Theme definitions
-----------------

A theme is defined in a JSON file under ``webapp/themes`` with a
structure like::

    {
      "name": "dark",
      "variables": {
        "--bg-color": "#0d1117",
        "--fg-color": "#c9d1d9",
        "--accent": "#58a6ff"
      }
    }

When a theme is applied the engine writes a ``theme.css`` file into
``webapp/assets`` containing CSS variable declarations based on the
selected theme.  This file can be loaded by the dashboard to update
styling at runtime.

Developed and maintained by Adam Henry Nagle.  Contact: 603‑384‑8949,
cainkilledabrl@icloud.com, nagleadam75@gmail.com.
"""

from __future__ import annotations

from pathlib import Path
from typing import Dict, Any
import json
import os


class ThemeEngine:
    """Engine for managing UI themes."""

    def metadata(self) -> Dict[str, Any]:
        return {
            "name": "theme",
            "version": "0.1.0",
            "description": "List, show and apply UI themes stored in webapp/themes.",
        }

    def run(self, task: Dict[str, Any]) -> Dict[str, Any]:
        action = task.get('action', 'list').lower()
        name = task.get('name')
        root = Path(task.get('root', os.getcwd())).resolve()
        log = task.get('log', print)
        themes_dir = root / 'webapp' / 'themes'
        assets_dir = root / 'webapp' / 'assets'
        if action == 'list':
            names = [p.stem for p in themes_dir.glob('*.json')]
            log(f"Available themes: {', '.join(names) if names else 'none'}")
            return {'themes': names}
        if action == 'show':
            if not name:
                return {'error': "'name' required for show"}
            theme_file = themes_dir / f"{name}.json"
            if not theme_file.exists():
                return {'error': f"Theme '{name}' not found"}
            try:
                data = json.loads(theme_file.read_text(encoding='utf-8'))
            except Exception as exc:
                return {'error': str(exc)}
            log(json.dumps(data, indent=2))
            return data
        if action == 'apply':
            if not name:
                return {'error': "'name' required for apply"}
            theme_file = themes_dir / f"{name}.json"
            if not theme_file.exists():
                return {'error': f"Theme '{name}' not found"}
            try:
                data = json.loads(theme_file.read_text(encoding='utf-8'))
            except Exception as exc:
                return {'error': str(exc)}
            variables = data.get('variables', {})
            css_lines = [':root {']
            for var, val in variables.items():
                css_lines.append(f"  {var}: {val};")
            css_lines.append('}')
            assets_dir.mkdir(parents=True, exist_ok=True)
            theme_css = assets_dir / 'theme.css'
            try:
                theme_css.write_text('\n'.join(css_lines), encoding='utf-8')
                log(f"ThemeEngine: Applied theme '{name}' to {theme_css}")
                return {'applied': name}
            except Exception as exc:
                return {'error': str(exc)}
        return {'error': f"Unknown action '{action}'"}


def get_engine() -> ThemeEngine:
    return ThemeEngine()