#!/bin/bash
# Smoke test for font_engine
python - <<'PY'
import sys
sys.path.insert(0, 'Prometheus_RAV4_777_Enhancements')
from engines.font_engine import FontEngine
engine = FontEngine()
assert engine.metadata()['name'] == 'font'
print('font_engine OK')
PY