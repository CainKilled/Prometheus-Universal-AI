"""
HuggingFace Inference Engine
=============================

This engine provides a simple wrapper around the Hugging Face
Inference API, allowing you to send text or other inputs to a model
hosted on huggingface.co and receive generated output.  It uses
Python's ``urllib`` library and therefore does not rely on external
dependencies.  To authenticate with the API you must provide an
access token either as a runtime parameter or via the
``HUGGINGFACE_API_TOKEN`` environment variable.  See
https://huggingface.co/docs/api-inference for details about the
available endpoints and required parameters.

Example usage:

    from engines.huggingface_engine import HuggingFaceEngine
    engine = HuggingFaceEngine()
    result = engine.generate(
        model="gpt2",
        input_text="Once upon a time",
        token="hf_your_token_here",
    )
    print(result)

Developed and maintained by Adam Henry Nagle.  Contact:
603‑384‑8949, cainkilledabrl@icloud.com, nagleadam75@gmail.com.
"""

from __future__ import annotations

import json
import os
from typing import Any, Dict, Optional
from urllib import request, error


class HuggingFaceEngine:
    """Simple interface to Hugging Face Inference API."""

    def __init__(self, base_url: str | None = None) -> None:
        # Default base URL; can be overridden for self‑hosted endpoints
        self.base_url = base_url or "https://api-inference.huggingface.co/models"

    def generate(
        self,
        model: str,
        input_text: str,
        token: Optional[str] = None,
        parameters: Optional[Dict[str, Any]] = None,
    ) -> Dict[str, Any]:
        """Call a Hugging Face model with the given input and return the result.

        Args:
            model: The model identifier (e.g. ``gpt2``, ``facebook/bart-large-cnn``).
            input_text: The text prompt to send to the model.
            token: The API token.  If omitted, ``HUGGINGFACE_API_TOKEN``
                environment variable will be used if set.
            parameters: Optional dictionary of additional parameters,
                such as ``max_new_tokens`` or ``temperature``.
        Returns:
            A dictionary containing either the JSON response from the API
            under ``result`` or an ``error`` key if the request failed.
        """
        auth_token = token or os.environ.get("HUGGINGFACE_API_TOKEN")
        if not auth_token:
            return {"error": "HuggingFace token is required (token parameter or HUGGINGFACE_API_TOKEN env var)"}
        if not model:
            return {"error": "Model name is required"}
        url = f"{self.base_url.rstrip('/')}/{model.strip()}"
        payload: Dict[str, Any] = {"inputs": input_text}
        if parameters:
            payload["parameters"] = parameters
        data = json.dumps(payload).encode("utf-8")
        headers = {
            "Authorization": f"Bearer {auth_token}",
            "Content-Type": "application/json",
        }
        req = request.Request(url, data=data, headers=headers, method="POST")
        try:
            with request.urlopen(req) as resp:
                resp_data = resp.read().decode("utf-8")
                try:
                    return {"result": json.loads(resp_data)}
                except json.JSONDecodeError:
                    return {"raw": resp_data}
        except error.HTTPError as http_err:
            return {"error": f"HTTP {http_err.code}: {http_err.reason}"}
        except Exception as exc:
            return {"error": str(exc)}