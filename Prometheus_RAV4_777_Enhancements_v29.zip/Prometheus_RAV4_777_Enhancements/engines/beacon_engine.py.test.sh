#!/bin/bash
# Smoke test for beacon_engine
python - <<'PY'
import sys
sys.path.insert(0, 'Prometheus_RAV4_777_Enhancements')
from engines.beacon_engine import BeaconEngine
engine = BeaconEngine()
assert engine.metadata()['name'] == 'beacon'
print('beacon_engine OK')
PY