"""
Manifest & Test Generator Engine
================================

This engine scans the project directory for engine and plugin modules and
ensures that each primary Python file has an associated manifest and test
script.  Manifests record the creation time and SHA‑256 digest of the file.
Test scripts perform a simple import or smoke test to verify that the
module loads correctly.  By generating these artefacts automatically the
project maintains a consistent level of metadata and validation across all
components.

Runtime parameters
------------------

``root`` (str)
    The root directory to scan.  Defaults to the current working
    directory.  Relative paths are resolved against the current working
    directory.
``kind`` (str)
    Optional filter limiting generation to ``engines``, ``plugins`` or
    ``all``.  When omitted all supported modules are processed.
``log`` (callable)
    Optional logger used for status messages.  Defaults to ``print``.

Developed and maintained by Adam Henry Nagle.  Contact: 603‑384‑8949,
cainkilledabrl@icloud.com, nagleadam75@gmail.com.
"""

from __future__ import annotations

from pathlib import Path
from datetime import datetime
from hashlib import sha256
from typing import Dict, Any, List
import json
import os
import inspect


class ManifestEngine:
    """Engine for generating manifests and test scripts for modules."""

    def metadata(self) -> Dict[str, Any]:
        return {
            "name": "manifest_generator",
            "version": "1.0.0",
            "description": "Generate manifest and test files for engines and plugins.",
        }

    def run(self, task: Dict[str, Any]) -> Dict[str, Any]:
        root = Path(task.get("root", os.getcwd())).resolve()
        kind = task.get("kind", "all").lower()
        log = task.get("log", print)
        generated: List[str] = []

        def ensure_manifest(py_path: Path) -> None:
            manifest_path = py_path.with_suffix(py_path.suffix + ".manifest.json")
            if manifest_path.exists():
                return
            # Compute file hash
            h = sha256()
            try:
                with py_path.open("rb") as fh:
                    for chunk in iter(lambda: fh.read(8192), b""):
                        h.update(chunk)
                digest = h.hexdigest()
            except Exception as exc:
                log(f"ManifestEngine: Failed to hash {py_path}: {exc}")
                return
            data = {
                "created_utc": datetime.utcnow().strftime("%Y-%m-%dT%H:%M:%SZ"),
                "sha256": digest,
                "file": str(py_path.relative_to(root)),
            }
            try:
                manifest_path.write_text(json.dumps(data, indent=2), encoding="utf-8")
                generated.append(str(manifest_path))
            except Exception as exc:
                log(f"ManifestEngine: Failed to write {manifest_path}: {exc}")

        def ensure_test(py_path: Path) -> None:
            test_path = py_path.with_suffix(py_path.suffix + ".test.sh")
            if test_path.exists():
                return
            module_name = py_path.stem
            # Determine import path relative to project root
            rel = py_path.relative_to(root)
            # Build Python import string (replace path separators with dots and strip .py)
            import_path = ".".join(rel.with_suffix("").parts)
            script = f"#!/bin/bash\npython -c \"import {import_path}; print('{module_name} OK')\"\n"
            try:
                test_path.write_text(script, encoding="utf-8")
                test_path.chmod(0o755)
                generated.append(str(test_path))
            except Exception as exc:
                log(f"ManifestEngine: Failed to write {test_path}: {exc}")

        # Walk directories based on kind
        dirs: List[Path] = []
        if kind in {"all", "engines"}:
            dirs.append(root / "engines")
        if kind in {"all", "plugins"}:
            dirs.append(root / "plugins" / "targets")
        for d in dirs:
            if not d.is_dir():
                continue
            for py_file in d.rglob("*.py"):
                # Skip __init__.py and test files
                if py_file.name.startswith("__") or py_file.name.endswith(".test.py"):
                    continue
                ensure_manifest(py_file)
                ensure_test(py_file)
        return {"ok": True, "generated": generated}


def get_engine() -> ManifestEngine:
    return ManifestEngine()