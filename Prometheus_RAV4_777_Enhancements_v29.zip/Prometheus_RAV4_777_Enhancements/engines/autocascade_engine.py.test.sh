#!/usr/bin/env bash
# Test script for AutoCascadeEngine

python - <<'PY'
import sys
sys.path.append('Prometheus_RAV4_777_Enhancements')
from engines.autocascade_engine import AutoCascadeEngine

# instantiate engine
engine = AutoCascadeEngine(base_dir='Prometheus_RAV4_777_Enhancements')
tools = engine.scan_tools()
assert isinstance(tools, list)
print("autocascade_engine OK")
PY