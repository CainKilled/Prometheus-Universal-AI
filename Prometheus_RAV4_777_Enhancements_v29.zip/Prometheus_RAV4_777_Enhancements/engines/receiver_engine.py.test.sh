#!/bin/bash
# Smoke test for receiver_engine
python - <<'PY'
import sys
sys.path.insert(0, 'Prometheus_RAV4_777_Enhancements')
from engines.receiver_engine import ReceiverEngine
engine = ReceiverEngine()
assert engine.metadata()['name'] == 'receiver'
print('receiver_engine OK')
PY