#!/bin/bash
# Smoke test for theme_engine
python - <<'PY'
import sys
sys.path.insert(0, 'Prometheus_RAV4_777_Enhancements')
from engines.theme_engine import ThemeEngine
engine = ThemeEngine()
assert engine.metadata()['name'] == 'theme'
print('theme_engine OK')
PY