"""
Wizard Engine
=============

This module contains helper functions for constructing wizard flows and
serialising them to JSON. A flow is a dictionary with a single key
``steps`` mapping to a list of step dictionaries. Each step contains
three keys: ``action`` (human readable label), ``plugin`` (the target
plugin name), and ``params`` (a mapping of parameter names to values).

Example::

    from Prometheus_RAV4_777_Enhancements.wizard.engine import make_step, save_flow

    steps = [
        make_step("say_hello", "terminal", {"command": "echo hi"}),
        make_step("list", "storage", {"provider": "local", "action": "list", "directory": "."})
    ]
    save_flow(steps, "wizard/flows/basic.json")

Then running the wizard plugin with this flow will execute the steps.
"""

import json
from typing import Dict, Any, List
from pathlib import Path


def make_step(action: str, plugin: str, params: Dict[str, Any] | None = None) -> Dict[str, Any]:
    """Construct a single step dictionary for a wizard flow."""
    return {
        "action": action,
        "plugin": plugin,
        "params": params or {},
    }


def make_flow(steps: List[Dict[str, Any]]) -> Dict[str, Any]:
    """Wrap a list of steps into a flow dictionary."""
    return {"steps": steps}


def save_flow(steps: List[Dict[str, Any]], path: str | Path) -> None:
    """Save a flow to the specified JSON path. Creates parent directories as needed."""
    flow = make_flow(steps)
    p = Path(path)
    if not p.parent.exists():
        p.parent.mkdir(parents=True, exist_ok=True)
    with p.open("w", encoding="utf-8") as f:
        json.dump(flow, f, indent=2)