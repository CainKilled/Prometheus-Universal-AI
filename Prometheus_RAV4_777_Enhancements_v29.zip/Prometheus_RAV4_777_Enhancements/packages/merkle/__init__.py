"""
Merkle Utilities
================

This package provides functions for computing SHA‑256 hashes and
merkle trees over file hierarchies, as well as generating directory
manifests. These utilities are used throughout the Prometheus
ecosystem to ensure content integrity and reproducibility.

Developed and maintained by Adam Henry Nagle. Contact: 603-384-8949,
cainkilledabrl@icloud.com, nagleadam75@gmail.com.
"""

from .tree import merkle_tree, file_hash, dir_manifest  # noqa: F401
