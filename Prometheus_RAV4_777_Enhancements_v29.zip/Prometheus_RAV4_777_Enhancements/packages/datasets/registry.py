"""
Dataset Registry
================

This module manages a registry of named datasets defined in JSON.
It provides functions to list available datasets and load a dataset
by name. The registry file is stored alongside this module in
``registry.json``. Each entry contains a name and a relative path
to a JSON file containing the actual data.

Developed and maintained by Adam Henry Nagle. Contact: 603-384-8949,
cainkilledabrl@icloud.com, nagleadam75@gmail.com.
"""

from pathlib import Path
import json
from typing import List, Any


def _root(base_dir: str) -> Path:
    return Path(base_dir) / "packages" / "datasets"


def list_datasets(base_dir: str) -> List[dict]:
    """Return metadata for all datasets registered in registry.json.

    Args:
        base_dir: The root of the repository.
    Returns:
        A list of dataset metadata dictionaries.
    """
    registry_path = _root(base_dir) / "registry.json"
    registry = json.loads(registry_path.read_text(encoding="utf-8"))
    return registry.get("datasets", [])


def get_dataset(base_dir: str, name: str) -> List[Any]:
    """Load a dataset by name.

    Args:
        base_dir: Root of the repository.
        name: Name of the dataset to load.
    Returns:
        The loaded dataset (list or dict)
    Raises:
        KeyError if the dataset is not found.
    """
    registry = json.loads((_root(base_dir) / "registry.json").read_text(encoding="utf-8"))
    for d in registry.get("datasets", []):
        if d.get("name") == name:
            path = d.get("path")
            if not path:
                raise KeyError(f"dataset {name} has no path")
            full_path = Path(base_dir) / path
            return json.loads(full_path.read_text(encoding="utf-8"))
    raise KeyError(f"dataset {name} not found")
