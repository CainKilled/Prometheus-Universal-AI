"""
Control Nexus v3 Smart Edition for Prometheus Infinity
-----------------------------------------------------

This module implements a robust control nexus for the Prometheus Infinity runtime.
It provides a rich command interface for managing pipelines, generating code with
AI assistance, creating safe state snapshots, compiling artifacts, and more.

The original concept for this tool came from early experimentation with
monolithic scripts. This implementation modernises the design by using
relative paths, defensive programming practices, and integrating with the
existing Prometheus infrastructure. All actions are logged via VaultTime and
signature verification is honoured through Codex Lock.  To add new commands or
macros simply extend the ``ALIASES`` and ``MACROS`` dictionaries below.

Author: Adam Henry Nagle
Phone: 6033848949
Emails: cainkilledabrl@icloud.com, nagleadam75@gmail.com
"""

from __future__ import annotations

import datetime
import json
import os
import shutil
import subprocess
import sys
import traceback
import uuid
from pathlib import Path
from typing import Any, Callable, Dict, List, Optional

import requests


# Determine the root of the monorepo dynamically based on this file's location.
# ``control_nexus_v3.py`` lives under ``agents/interfaces`` so we walk up two
# directories to reach the project root. Using ``resolve().parents`` ensures
# symbolic links are resolved and the resulting path is absolute.
ROOT = Path(__file__).resolve().parents[2]

# Define key directories relative to the project root. These directories will be
# created as needed when actions occur. Users can override these by setting
# environment variables (e.g. ``PROM_SAFE_DIR``).
SAFE_DIR = Path(os.getenv("PROM_SAFE_DIR", ROOT / "safestates"))
PIPELINES_DIR = Path(os.getenv("PROM_PIPELINES_DIR", ROOT / "pipelines"))
ARTIFACTS_DIR = Path(os.getenv("PROM_ARTIFACTS_DIR", ROOT / "artifacts"))
LOG_DIR = Path(os.getenv("PROM_LOG_DIR", ROOT / "logs"))

# Files used by the nexus.
BUILD_LOG = LOG_DIR / "build_log.json"
VAULTTIME_LOG = LOG_DIR / "vaulttime_nexus.log"
CODEX_SIGNATURES = Path(os.getenv("PROM_CODEX_SIGNATURES", ROOT / "codex" / "signatures.json"))

# HuggingFace model endpoint and token file.  To use the AI features you
# should place a VaultTime-sealed token in ``auth/hf_token.vault`` at the root
# of your repository. Without a token the AI functions will return an error.
HUGGINGFACE_API = os.getenv(
    "PROM_HF_API", "https://api-inference.huggingface.co/models/bigcode/starcoder2-3b"
)
HF_TOKEN_FILE = Path(os.getenv("PROM_HF_TOKEN", ROOT / "auth" / "hf_token.vault"))


def _ensure_dir(path: Path) -> None:
    """Ensure that the given directory exists."""
    if not path.exists():
        path.mkdir(parents=True, exist_ok=True)


def vaulttime_log(entry: Any) -> None:
    """Append a structured entry to the VaultTime log.

    Each log entry includes a trace ID and UTC timestamp. The log file is
    automatically created if it does not exist.
    """
    _ensure_dir(LOG_DIR)
    log_record = {
        "trace_id": str(uuid.uuid4()),
        "timestamp": datetime.datetime.utcnow().isoformat(),
        "entry": entry,
    }
    with open(VAULTTIME_LOG, "a", encoding="utf-8") as f:
        json.dump(log_record, f)
        f.write("\n")


def codex_lock_validate(file: str | Path) -> bool:
    """Validate a file's signature against Codex Lock signatures.

    If the signature file is missing or no matching entry exists, the
    validation fails and the event is logged. Signature verification is a
    placeholder; a real implementation should perform cryptographic checks.
    """
    sig_path = CODEX_SIGNATURES
    if not sig_path.exists():
        vaulttime_log(f"Codex signature file missing for {file}")
        return False
    with open(sig_path, encoding="utf-8") as f:
        signatures = json.load(f)
    hash_match = signatures.get(Path(file).name)
    if not hash_match:
        vaulttime_log(f"Codex lock failed for {file}")
        return False
    return True


def tbox_wrapper(func: Callable[..., Any], *args: Any, **kwargs: Any) -> Any:
    """Execute a function inside a TBOX safety wrapper.

    All invocations are logged before and after execution. If an exception
    occurs, a SafeState snapshot is created automatically and the exception
    is re-raised.
    """
    try:
        vaulttime_log(f"TBOX start: {func.__name__} with args={args} kwargs={kwargs}")
        result = func(*args, **kwargs)
        vaulttime_log(f"TBOX success: {func.__name__}")
        return result
    except Exception:
        vaulttime_log(f"TBOX error in {func.__name__}: {traceback.format_exc()}")
        # Generate a safe state and re-raise the exception
        create_safestate(f"rollback_{func.__name__}")
        raise


def skywalk_reindex() -> None:
    """Trigger a reindex of the SkyWalk awareness subsystem.

    This function attempts to run a script called ``skywalk_reindex.py`` in
    the repository root. If the script is missing, the error is logged but
    execution continues.
    """
    script = ROOT / "skywalk_reindex.py"
    subprocess.run([sys.executable, str(script)], check=False)
    vaulttime_log("SkyWalk awareness reindexed.")


def list_modules() -> List[str]:
    """Return a list of module identifiers from the infinity manifest.

    Modules are extracted from the ``subsystems`` and ``projects`` sections of
    ``infinity_manifest.json``. If the manifest is missing, an empty list is
    returned.
    """
    manifest_path = ROOT / "infinity_manifest.json"
    if not manifest_path.exists():
        vaulttime_log("Infinity manifest not found when listing modules.")
        return []
    with open(manifest_path, encoding="utf-8") as f:
        manifest = json.load(f)
    return [m["id"] for m in manifest.get("subsystems", [])] + [p["id"] for p in manifest.get("projects", [])]


def list_pipelines() -> List[str]:
    """Return a list of pipeline identifiers from the infinity manifest.

    Pipelines are extracted from the ``pipelines`` section of
    ``infinity_manifest.json``.
    """
    manifest_path = ROOT / "infinity_manifest.json"
    if not manifest_path.exists():
        vaulttime_log("Infinity manifest not found when listing pipelines.")
        return []
    with open(manifest_path, encoding="utf-8") as f:
        manifest = json.load(f)
    return [p["id"] for p in manifest.get("pipelines", [])]


def status_module(module: str) -> Dict[str, Any]:
    """Return the status of a module from the SkyWalk status directory.

    If the status file does not exist, the status is reported as unknown.
    """
    status_path = ROOT / "skywalk" / "status" / f"{module}.json"
    if not status_path.exists():
        return {"module": module, "status": "unknown", "last_check": None}
    with open(status_path, encoding="utf-8") as f:
        return json.load(f)


def run_pipeline(pipeline: str) -> Dict[str, Any]:
    """Execute a pipeline by invoking the generic runner.

    Pipelines are defined as JSON files in ``PIPELINES_DIR``. After running
    a pipeline the JC-Test is triggered and the build is logged.
    """
    file_path = PIPELINES_DIR / f"{pipeline}.json"
    if not file_path.exists():
        vaulttime_log(f"Pipeline not found: {pipeline}")
        return {"error": "Pipeline not found"}
    result = subprocess.run([sys.executable, str(ROOT / "runner.py"), str(file_path)], capture_output=True)
    jc_test_pipeline(pipeline)
    vaulttime_log(f"Pipeline {pipeline} executed with code {result.returncode}")
    return {"pipeline": pipeline, "code": result.returncode, "output": result.stdout.decode()}


def create_safestate(tag: str = "snapshot") -> str:
    """Create a SafeState snapshot with the given tag.

    SafeStates are stored as JSON files under ``SAFE_DIR``. A reindex of
    SkyWalk is triggered after creation.
    """
    _ensure_dir(SAFE_DIR)
    filename = SAFE_DIR / f"{tag}_{datetime.datetime.utcnow().isoformat()}.json"
    with open(filename, "w", encoding="utf-8") as f:
        json.dump({"tag": tag, "timestamp": datetime.datetime.utcnow().isoformat()}, f, indent=4)
    vaulttime_log(f"SafeState created: {filename}")
    skywalk_reindex()
    return str(filename)


def restore_safestate(file: str | Path, force: bool = False) -> Dict[str, Any]:
    """Restore a previously created SafeState.

    The ``force`` flag is reserved for future use; it currently has no effect
    beyond being logged. If the file does not exist an error is returned.
    """
    state_path = Path(file)
    if not state_path.exists():
        return {"error": "SafeState file not found"}
    vaulttime_log(f"Restoring SafeState: {state_path} (force={force})")
    # Real restoration logic would go here.
    return {"restored": str(state_path), "force": force}


def ai_generate(lang: str, prompt: str) -> str:
    """Generate code or text using the HuggingFace API.

    The user's token is read from the VaultTime-sealed token file. If the
    token is missing or the API call fails, a descriptive error is returned
    and logged.
    """
    if not HF_TOKEN_FILE.exists():
        vaulttime_log("Missing VaultTime-sealed HF token.")
        return "Error: No Hugging Face token."
    token = HF_TOKEN_FILE.read_text(encoding="utf-8").strip()
    headers = {"Authorization": f"Bearer {token}"}
    payload = {"inputs": f"Write {lang} code: {prompt}"}
    try:
        resp = requests.post(HUGGINGFACE_API, headers=headers, json=payload, timeout=60)
        if resp.status_code == 200:
            data = resp.json()
            # Response may be a list or dict depending on the model; handle both
            if isinstance(data, list) and data:
                return data[0].get("generated_text", "")
            return data.get("generated_text", "")
        vaulttime_log(f"HF API error ({resp.status_code}): {resp.text}")
        return "Error: Hugging Face API call failed."
    except Exception:
        vaulttime_log(f"HF API exception: {traceback.format_exc()}")
        return "Error: Exception during Hugging Face API call."


def compile_artifact(source_dir: str | Path, output_name: str) -> str:
    """Zip a directory into an artifact and record the build.

    The output ZIP is created in ``ARTIFACTS_DIR``. After zipping, Codex
    validation and CST++ validation hooks are invoked. A SkyWalk reindex is
    triggered after compilation.
    """
    _ensure_dir(ARTIFACTS_DIR)
    output_base = ARTIFACTS_DIR / output_name
    shutil.make_archive(str(output_base), "zip", str(source_dir))
    output_zip = f"{output_base}.zip"
    vaulttime_log(f"Compiled artifact: {output_zip}")
    # Perform signature validation and pseudo validation
    codex_lock_validate(output_zip)
    cst_validate(output_zip)
    log_build(output_zip)
    skywalk_reindex()
    return output_zip


def log_build(artifact: str | Path) -> None:
    """Append a build entry to the build log.

    The build log stores a list of records; each record includes the artifact
    path and a timestamp.
    """
    _ensure_dir(LOG_DIR)
    record = {"artifact": str(artifact), "timestamp": datetime.datetime.utcnow().isoformat()}
    if BUILD_LOG.exists():
        with open(BUILD_LOG, encoding="utf-8") as f:
            logs = json.load(f)
    else:
        logs = []
    logs.append(record)
    with open(BUILD_LOG, "w", encoding="utf-8") as f:
        json.dump(logs, f, indent=4)
    vaulttime_log(f"Build logged: {artifact}")


def jc_test_pipeline(pipeline: str) -> None:
    """Simulate a JC-Test on the given pipeline.

    In this placeholder implementation the JC-Test simply logs that it has
    executed. A real implementation should perform stress and compile-time
    testing on the pipeline output.
    """
    vaulttime_log(f"JC-Test: Stress-testing pipeline {pipeline}")


def cst_validate(file: str | Path) -> None:
    """Simulate CST++ validation of a build artifact.

    This placeholder logs that validation occurred. A real implementation
    should validate the artifact according to your project's standards.
    """
    vaulttime_log(f"CST++: Validating build {file}")


def diagnose_and_fix() -> Dict[str, Any]:
    """Run a diagnostic on the system and attempt automated fixes.

    The diagnostic performs AI-assisted suggestions, simulates restarting
    modules, and logs all actions taken. It returns a summary of actions.
    """
    ai_suggestion = ai_generate("python", "Suggest fixes for system-level errors and misconfigurations")
    actions = ["Validated pipelines", "Restarted failed modules", f"AI Suggestion: {ai_suggestion}"]
    vaulttime_log("Diagnosis run: " + json.dumps({"actions": actions}))
    return {"diagnosis": "No critical errors", "actions": actions}


def generate_code(lang: str, name: str) -> str:
    """Generate a code template using the AI and write it to disk.

    The generated file is stored under ``generated/<lang>/`` relative to the
    project root. The file is stamped with an auto-generated header.
    """
    dest_dir = ROOT / "generated" / lang
    _ensure_dir(dest_dir)
    ext = lang if lang != "bash" else "sh"
    file_path = dest_dir / f"{name}.{ext}"
    ai_code = ai_generate(lang, f"Create code template for {name}")
    with open(file_path, "w", encoding="utf-8") as f:
        f.write(f"# Auto-generated {lang} code: {name}\n{ai_code}\n")
    vaulttime_log(f"Generated code: {file_path}")
    codex_lock_validate(file_path)
    return str(file_path)


def godmode_force_rebuild() -> str:
    """Force a rebuild of the entire repository as a privileged action."""
    vaulttime_log("Godmode++++: Force rebuild triggered.")
    return compile_artifact(ROOT, "force_rebuild_bundle")


def godmode_force_rollback() -> Dict[str, Any]:
    """Force a rollback to the most recent SafeState as a privileged action."""
    vaulttime_log("Godmode++++: Force rollback to last SafeState.")
    snapshots = sorted(SAFE_DIR.glob("*.json"), key=os.path.getmtime, reverse=True)
    if not snapshots:
        return {"error": "No SafeStates available"}
    return restore_safestate(snapshots[0], force=True)


# Command aliases map short commands to functions. Each value should be a
# callable; arguments provided on the command line are passed through.
ALIASES: Dict[str, Callable[..., Any]] = {
    "nl": list_modules,
    "np": list_pipelines,
    "ns": status_module,
    "nr": run_pipeline,
    "nb": compile_artifact,
    "ng": generate_code,
    "ai": ai_generate,
}

# Macros combine multiple operations or privileged commands. These lambdas are
# executed without additional arguments.
MACROS: Dict[str, Callable[[], Any]] = {
    "fixall": diagnose_and_fix,
    "rebuild": lambda: compile_artifact(ROOT, "rebuild_package"),
    "deployall": lambda: run_pipeline("full_runtime_harden"),
    "safeall": lambda: create_safestate("all"),
    "godrebuild": godmode_force_rebuild,
    "godrollback": godmode_force_rollback,
}


def main(argv: Optional[List[str]] = None) -> None:
    """Entry point for running the Control Nexus from the command line."""
    args = argv or sys.argv[1:]
    cmd = args[0] if args else "help"
    try:
        if cmd in ALIASES:
            # Pass remaining args to alias function
            result = tbox_wrapper(ALIASES[cmd], *args[1:])
            print(result)
        elif cmd in MACROS:
            result = tbox_wrapper(MACROS[cmd])
            print(result)
        else:
            print("Available commands:")
            print("Aliases:", ", ".join(ALIASES.keys()))
            print("Macros:", ", ".join(MACROS.keys()))
    except Exception as exc:
        print(f"Error: {exc}")


if __name__ == "__main__":
    main()