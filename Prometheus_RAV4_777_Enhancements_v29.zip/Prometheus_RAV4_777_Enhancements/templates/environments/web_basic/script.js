//
// JavaScript for the basic web environment template.
// Developed by Adam Henry Nagle (603-384-8949).
//
document.addEventListener('DOMContentLoaded', () => {
    console.log('Welcome to your web app!');
});