# Java Basic Environment

This template provides a minimal Java application scaffold using Maven.
It includes a ``Main.java`` entry point and a ``pom.xml`` configured to
build and run the application with JDK 17. After generating a project
using this template, run ``mvn package`` to build it.

**Author:** Adam Henry Nagle — 603‑384‑8949 —
[cainkilledabrl@icloud.com](mailto:cainkilledabrl@icloud.com),
[nagleadam75@gmail.com](mailto:nagleadam75@gmail.com)