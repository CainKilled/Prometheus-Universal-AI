#!/usr/bin/env bash
set -euo pipefail
python -m py_compile "devswarm2/tasks.py"
echo "devswarm2 tasks compiled successfully"
