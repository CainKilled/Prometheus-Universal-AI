"""
SOP Loader
==========

This module contains functions for parsing and executing standard
operating procedures (SOPs) stored in Markdown files. SOP files may
include a JSON frontmatter section between ``---`` delimiters to
specify metadata such as the SOP name and owner. The body contains
steps, each of which is either a note or a shell command prefaced
with ``$``. When a SOP is executed, commands are run in the shell
using ``subprocess.run`` and notes are returned as informational
entries.

Developed and maintained by Adam Henry Nagle. Contact: 603‑384‑8949,
cainkilledabrl@icloud.com, nagleadam75@gmail.com.
"""

from __future__ import annotations

from pathlib import Path
import json
import re
import subprocess
from typing import Dict, Any, List

FRONTMATTER = re.compile(r"^---\s*\n(.*?)\n---\s*", re.S)

def parse_sop(base_dir: str, file: str) -> Dict[str, Any]:
    """Parse a SOP Markdown file and return its metadata and steps.

    :param base_dir: Base directory relative to which the file lives.
    :param file: Relative path to the SOP file.
    :returns: A dictionary with keys ``meta`` and ``steps``.
    """
    p = Path(base_dir) / "packages" / "sops" / file
    s = p.read_text(encoding="utf-8")
    m = FRONTMATTER.match(s)
    meta: Dict[str, Any] = json.loads(m.group(1)) if m else {}
    body = s[m.end():] if m else s
    steps: List[str] = [ln.strip() for ln in body.splitlines() if ln.strip()]
    return {"meta": meta, "steps": steps}

def run_sop(base_dir: str, file: str, logger=print) -> Dict[str, Any]:
    """Execute a SOP file and return a result report.

    Each step beginning with ``$ `` is executed as a shell command using
    ``subprocess.run``. Steps without a leading ``$ `` are returned as
    notes. The result dictionary contains ``ok`` (True if all commands
    exited with code 0) and ``results`` (list of per-step results).
    """
    sop = parse_sop(base_dir, file)
    results: List[Dict[str, Any]] = []
    for i, step in enumerate(sop["steps"], 1):
        if step.startswith("$ "):
            cmd = step[2:]
            logger(f"[SOP] {i}: {cmd}")
            proc = subprocess.run(cmd, capture_output=True, text=True, shell=True)
            results.append({"rc": proc.returncode, "out": proc.stdout, "err": proc.stderr})
        else:
            logger(f"[SOP] {i}: {step}")
            results.append({"note": step})
    ok = all(r.get("rc", 0) == 0 for r in results if "rc" in r)
    return {"ok": ok, "results": results}