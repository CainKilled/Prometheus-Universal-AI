"""
Datasets Package
================

This package provides a registry and utility functions for loading
structured data sets from JSON files. Datasets can represent
configuration values, default user collections, pre‑built tasks or
other structured inputs for the Prometheus engines.

Developed and maintained by Adam Henry Nagle. Contact: 603-384-8949,
cainkilledabrl@icloud.com, nagleadam75@gmail.com.
"""

from .registry import list_datasets, get_dataset  # noqa: F401
