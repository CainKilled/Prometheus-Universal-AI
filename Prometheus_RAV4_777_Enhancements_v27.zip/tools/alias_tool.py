"""
Alias Tool
==========

This tool provides a simple mechanism to register shorthand aliases
for running plugins with predefined parameters.  An alias maps a
command name to a target plugin and a dictionary of parameters.  For
example, you could define an alias ``lsdev`` that invokes the iOS
plugin to list connected devices, or ``hf_gpt2`` that calls the
Hugging Face plugin with the ``gpt2`` model.  Aliases are stored in
a JSON file at ``aliases.json`` within the same directory as this
module.  The file can be manually edited or managed via the CLI.

Usage from the command line:

    python -m tools.alias_tool add lsdev plugin=ios action=devices
    python -m tools.alias_tool list
    python -m tools.alias_tool remove lsdev

At runtime, the CLI can be extended to resolve aliases before
dispatching to plugins.  This tool is primarily a convenience for
predefining frequently used plugin invocations.

Developed and maintained by Adam Henry Nagle.  Contact:
603‑384‑8949, cainkilledabrl@icloud.com, nagleadam75@gmail.com.
"""

from __future__ import annotations

import argparse
import json
from pathlib import Path
from typing import Dict, Any


ALIAS_FILE = Path(__file__).resolve().parent / "aliases.json"


def load_aliases() -> Dict[str, Dict[str, Any]]:
    if ALIAS_FILE.exists():
        try:
            return json.loads(ALIAS_FILE.read_text(encoding="utf-8"))
        except Exception:
            return {}
    return {}


def save_aliases(aliases: Dict[str, Dict[str, Any]]) -> None:
    ALIAS_FILE.write_text(json.dumps(aliases, indent=2), encoding="utf-8")


def add_alias(name: str, target: str, params: Dict[str, Any]) -> None:
    aliases = load_aliases()
    aliases[name] = {"plugin": target, "params": params}
    save_aliases(aliases)


def remove_alias(name: str) -> None:
    aliases = load_aliases()
    if name in aliases:
        del aliases[name]
        save_aliases(aliases)


def list_aliases() -> Dict[str, Dict[str, Any]]:
    return load_aliases()


def main() -> None:
    parser = argparse.ArgumentParser(description="Manage CLI aliases for Prometheus plugins")
    subparsers = parser.add_subparsers(dest="command")
    # add
    add_p = subparsers.add_parser("add", help="Add a new alias")
    add_p.add_argument("name", help="Alias name")
    add_p.add_argument("target", help="Target plugin name")
    add_p.add_argument("pairs", nargs="*", help="key=value pairs for plugin params")
    # list
    subparsers.add_parser("list", help="List existing aliases")
    # remove
    rm_p = subparsers.add_parser("remove", help="Remove an alias")
    rm_p.add_argument("name", help="Alias name to remove")
    args = parser.parse_args()
    if args.command == "add":
        params: Dict[str, Any] = {}
        for pair in args.pairs:
            if "=" not in pair:
                raise ValueError(f"Invalid param '{pair}', expected key=value")
            k, v = pair.split("=", 1)
            # try to parse JSON values
            try:
                params[k] = json.loads(v)
            except json.JSONDecodeError:
                params[k] = v
        add_alias(args.name, args.target, params)
        print(f"Alias '{args.name}' added for plugin '{args.target}' with params {params}")
    elif args.command == "list":
        aliases = list_aliases()
        if not aliases:
            print("No aliases defined")
        else:
            for name, info in aliases.items():
                print(f"{name}: plugin={info['plugin']} params={info['params']}")
    elif args.command == "remove":
        remove_alias(args.name)
        print(f"Alias '{args.name}' removed")
    else:
        parser.print_help()


if __name__ == "__main__":
    main()