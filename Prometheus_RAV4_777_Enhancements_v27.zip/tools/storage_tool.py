"""
Storage Tool
============

This module provides a full‑stack command‑line interface for common
file and object storage operations.  It wraps the functionality of
the ``StoragePlugin`` in a reusable tool that can be invoked via
``python -m tools.storage_tool`` or imported directly in other code.

Supported backends:

* **local** – read, write and list files on the local filesystem.
* **s3** – upload, download and list objects in Amazon S3 (requires
  ``boto3`` to be installed).
* **azure** – upload, download and list blobs in Azure Blob Storage
  (requires ``azure-storage-blob``).

Examples:

    # read a local file
    python -m tools.storage_tool local read --file README.md

    # write to a local file
    python -m tools.storage_tool local write --file output.txt --data "Hello"

    # list files in a directory
    python -m tools.storage_tool local list --dir /tmp

    # upload a file to S3
    python -m tools.storage_tool s3 upload --bucket my-bucket --file README.md --key docs/README.md

    # download a file from S3
    python -m tools.storage_tool s3 download --bucket my-bucket --key docs/README.md --file README.md

    # list objects in an S3 bucket
    python -m tools.storage_tool s3 list --bucket my-bucket

    # upload to Azure Blob Storage
    python -m tools.storage_tool azure upload --container mycontainer --file README.md \
        --blob docs/README.md --connection-string "DefaultEndpointsProtocol=https;AccountName=..."

Developed and maintained by Adam Henry Nagle.  Contact:
603‑384‑8949, cainkilledabrl@icloud.com, nagleadam75@gmail.com.
"""

from __future__ import annotations

import argparse
import os
from typing import Optional, List


def local_read(file_path: str) -> str:
    """Read the contents of a local text file."""
    with open(file_path, "r", encoding="utf-8") as f:
        return f.read()


def local_write(file_path: str, data: str) -> None:
    """Write data to a local text file, overwriting any existing contents."""
    with open(file_path, "w", encoding="utf-8") as f:
        f.write(data)


def local_list(directory: str) -> List[str]:
    """List entries in a local directory."""
    return os.listdir(directory)


def s3_upload(bucket: str, file_path: str, key: Optional[str] = None) -> None:
    """Upload a local file to an S3 bucket.

    Requires the ``boto3`` library to be installed.
    """
    import boto3  # type: ignore
    s3 = boto3.client("s3")
    object_key = key or os.path.basename(file_path)
    s3.upload_file(file_path, bucket, object_key)


def s3_download(bucket: str, key: str, file_path: Optional[str] = None) -> None:
    """Download an object from S3 to a local file.

    Requires the ``boto3`` library to be installed.
    """
    import boto3  # type: ignore
    s3 = boto3.client("s3")
    out_path = file_path or key
    s3.download_file(bucket, key, out_path)


def s3_list(bucket: str) -> List[str]:
    """List object keys in an S3 bucket.

    Requires the ``boto3`` library to be installed.
    """
    import boto3  # type: ignore
    s3 = boto3.client("s3")
    response = s3.list_objects_v2(Bucket=bucket)
    return [obj["Key"] for obj in response.get("Contents", [])]


def azure_upload(
    container: str,
    file_path: str,
    blob_name: str,
    connection_string: str,
) -> None:
    """Upload a local file to an Azure Blob container.

    Requires the ``azure-storage-blob`` library to be installed.
    """
    from azure.storage.blob import BlobServiceClient  # type: ignore
    service = BlobServiceClient.from_connection_string(connection_string)
    blob_client = service.get_blob_client(container=container, blob=blob_name)
    with open(file_path, "rb") as data:
        blob_client.upload_blob(data, overwrite=True)


def azure_download(
    container: str,
    blob_name: str,
    file_path: Optional[str],
    connection_string: str,
) -> None:
    """Download a blob from Azure Storage to a local file.

    Requires the ``azure-storage-blob`` library to be installed.
    """
    from azure.storage.blob import BlobServiceClient  # type: ignore
    service = BlobServiceClient.from_connection_string(connection_string)
    blob_client = service.get_blob_client(container=container, blob=blob_name)
    out_path = file_path or blob_name
    with open(out_path, "wb") as f:
        data = blob_client.download_blob()
        f.write(data.readall())


def azure_list(container: str, connection_string: str) -> List[str]:
    """List blob names in an Azure container.

    Requires the ``azure-storage-blob`` library to be installed.
    """
    from azure.storage.blob import BlobServiceClient  # type: ignore
    service = BlobServiceClient.from_connection_string(connection_string)
    container_client = service.get_container_client(container)
    return [blob.name for blob in container_client.list_blobs()]


def _main() -> None:
    parser = argparse.ArgumentParser(description="Storage Tool")
    sub = parser.add_subparsers(dest="provider")
    # local commands
    local = sub.add_parser("local", help="Local file operations")
    local_sub = local.add_subparsers(dest="action")
    # local read
    read_parser = local_sub.add_parser("read", help="Read a local file")
    read_parser.add_argument("--file", required=True, help="Path to the file to read")
    # local write
    write_parser = local_sub.add_parser("write", help="Write to a local file")
    write_parser.add_argument("--file", required=True, help="Path to write to")
    write_parser.add_argument("--data", required=True, help="Data to write")
    # local list
    list_parser = local_sub.add_parser("list", help="List a directory")
    list_parser.add_argument(
        "--dir",
        default=os.getcwd(),
        help="Directory to list (default: current working directory)",
    )
    # s3 commands
    s3 = sub.add_parser("s3", help="Amazon S3 operations")
    s3_sub = s3.add_subparsers(dest="action")
    # s3 upload
    s3_up = s3_sub.add_parser("upload", help="Upload to S3")
    s3_up.add_argument("--bucket", required=True, help="S3 bucket name")
    s3_up.add_argument("--file", required=True, help="Local file path")
    s3_up.add_argument(
        "--key", help="Object key (defaults to file name)", default=None
    )
    # s3 download
    s3_down = s3_sub.add_parser("download", help="Download from S3")
    s3_down.add_argument("--bucket", required=True, help="S3 bucket name")
    s3_down.add_argument("--key", required=True, help="Object key")
    s3_down.add_argument(
        "--file", help="Destination file path (defaults to key)", default=None
    )
    # s3 list
    s3_list_parser = s3_sub.add_parser("list", help="List S3 bucket contents")
    s3_list_parser.add_argument("--bucket", required=True, help="S3 bucket name")
    # azure commands
    azure = sub.add_parser("azure", help="Azure Blob Storage operations")
    azure_sub = azure.add_subparsers(dest="action")
    # azure upload
    azure_up = azure_sub.add_parser("upload", help="Upload to Azure blob")
    azure_up.add_argument("--container", required=True, help="Azure container name")
    azure_up.add_argument("--file", required=True, help="Local file path")
    azure_up.add_argument("--blob", required=True, help="Blob name")
    azure_up.add_argument(
        "--connection-string",
        required=True,
        help="Azure Blob Storage connection string",
    )
    # azure download
    azure_down = azure_sub.add_parser("download", help="Download from Azure blob")
    azure_down.add_argument("--container", required=True, help="Azure container name")
    azure_down.add_argument("--blob", required=True, help="Blob name")
    azure_down.add_argument(
        "--file", help="Destination file path (defaults to blob name)", default=None
    )
    azure_down.add_argument(
        "--connection-string",
        required=True,
        help="Azure Blob Storage connection string",
    )
    # azure list
    azure_list_parser = azure_sub.add_parser("list", help="List Azure container contents")
    azure_list_parser.add_argument("--container", required=True, help="Azure container name")
    azure_list_parser.add_argument(
        "--connection-string",
        required=True,
        help="Azure Blob Storage connection string",
    )
    args = parser.parse_args()
    # handle local operations
    if args.provider == "local":
        if args.action == "read":
            content = local_read(args.file)
            print(content)
        elif args.action == "write":
            local_write(args.file, args.data)
            print(f"Wrote data to {args.file}")
        elif args.action == "list":
            entries = local_list(args.dir)
            for entry in entries:
                print(entry)
        else:
            parser.print_help()
        return
    # handle S3 operations
    if args.provider == "s3":
        try:
            if args.action == "upload":
                s3_upload(args.bucket, args.file, args.key)
                print(f"Uploaded {args.file} to s3://{args.bucket}/{args.key or os.path.basename(args.file)}")
            elif args.action == "download":
                s3_download(args.bucket, args.key, args.file)
                print(f"Downloaded s3://{args.bucket}/{args.key} to {args.file or args.key}")
            elif args.action == "list":
                keys = s3_list(args.bucket)
                for k in keys:
                    print(k)
            else:
                parser.print_help()
        except ImportError:
            print("boto3 is not installed. Install it to use S3 functionality.")
        return
    # handle Azure operations
    if args.provider == "azure":
        try:
            if args.action == "upload":
                azure_upload(
                    args.container,
                    args.file,
                    args.blob,
                    args.connection_string,
                )
                print(
                    f"Uploaded {args.file} to Azure container {args.container} as {args.blob}"
                )
            elif args.action == "download":
                azure_download(
                    args.container,
                    args.blob,
                    args.file,
                    args.connection_string,
                )
                print(
                    f"Downloaded Azure blob {args.blob} to {args.file or args.blob}"
                )
            elif args.action == "list":
                blobs = azure_list(args.container, args.connection_string)
                for b in blobs:
                    print(b)
            else:
                parser.print_help()
        except ImportError:
            print(
                "azure-storage-blob is not installed. Install it to use Azure Blob functionality."
            )
        return
    # no provider matched
    parser.print_help()


if __name__ == "__main__":  # pragma: no cover
    _main()