"""
Memory Loader Utility
---------------------

This module provides a simple helper for loading JSON memory configuration
files. It mirrors the behaviour of the original Node.js ``loadMemory.js`` but
is implemented in Python for easier integration into the Prometheus
ecosystem. The loader looks for a JSON file and returns its parsed
contents. If the file does not exist, ``None`` is returned and a
message is printed.

Author: Adam Henry Nagle
Phone: 6033848949
Emails: cainkilledabrl@icloud.com, nagleadam75@gmail.com
"""

from __future__ import annotations

import json
from pathlib import Path
from typing import Any, Dict, Optional


def load_memory(file_path: str = "wardog_memory.json") -> Optional[Dict[str, Any]]:
    """Load a memory configuration file from disk.

    Parameters
    ----------
    file_path: str
        The relative or absolute path to a JSON file containing memory
        configuration. Defaults to ``wardog_memory.json``.

    Returns
    -------
    dict or None
        The parsed configuration dictionary if the file exists, otherwise
        ``None``.
    """
    path = Path(file_path)
    if not path.exists():
        print(f"Memory config not found: {path}")
        return None
    with path.open("r", encoding="utf-8") as f:
        config = json.load(f)
    print(f"Loaded memory for: {config.get('user', 'unknown')}")
    return config


if __name__ == "__main__":
    # Demonstration of loading a memory file from the current working directory
    load_memory()