"""
libmobiledevice GUI wrapper
==========================

This package provides a simple graphical user interface (GUI) and profile
management layer for interacting with libimobiledevice tools.  The goal
is to expose common device management tasks (listing connected iOS
devices, retrieving device information, syncing files, etc.) through a
clickable interface rather than requiring users to run commands in a
terminal.  A lightweight profile manager stores the user's chosen
username and password the first time the tool is launched, encrypting
that information for later use.

The GUI is implemented using Python's ``tkinter`` toolkit and does
not depend on any external frameworks.  When a user opens the GUI for
the first time a registration dialog is displayed prompting for a
username and password.  Those credentials are then saved to a
JSON‑encoded file under the ``libmobiledevice_gui`` directory.  On
subsequent launches the tool reads the stored profile and uses it to
authenticate the user before displaying the main interface.

This module also exposes the underlying profile and GUI classes so
they can be driven programmatically from other parts of the
Prometheus ecosystem.  For example, the GUI can be launched via a
plugin or engine and integrated into helper swarms.

Developed and maintained by Adam Henry Nagle.  Contact:
603‑384‑8949, cainkilledabrl@icloud.com, nagleadam75@gmail.com.
"""

from .profile_manager import ProfileManager
from .gui import LibMobileDeviceGUI

__all__ = ["ProfileManager", "LibMobileDeviceGUI"]