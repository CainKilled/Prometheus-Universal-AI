"""
Truth Tree Walker
-----------------

This script provides an interactive command-line interface for exploring the
Prometheus Truth Tree. It loads the tree structure from a JSON file and
allows the user to navigate through branches and leaves. At leaves, the
script displays companion files, dependencies and relationship links. Use
the index numbers to traverse deeper into the tree or 'x' to go back.

By default the script attempts to load ``packages/datasets/truth_tree.json``
relative to the repository root. You can specify a custom path via the
``--file`` argument.

Author: Adam Henry Nagle
Phone: 6033848949
Emails: cainkilledabrl@icloud.com, nagleadam75@gmail.com
"""

from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path
from typing import Any, Dict, Tuple


def load_tree(json_path: Path) -> Dict[str, Any]:
    """Load a JSON file containing the truth tree and return its contents."""
    try:
        with open(json_path, "r", encoding="utf-8") as f:
            return json.load(f)
    except FileNotFoundError:
        raise SystemExit(f"Truth tree JSON not found at {json_path}")


def select_entry(entries: Tuple[Tuple[str, Dict[str, Any]], ...]) -> int:
    """Prompt the user to select an entry index."""
    while True:
        choice = input("Select node index (or 'x' to go back): ")
        if choice.lower() in {"x", "q"}:
            return -1
        try:
            idx = int(choice)
            if 0 <= idx < len(entries):
                return idx
            print("Index out of range.")
        except ValueError:
            print("Invalid choice; enter an integer or 'x'.")


def walk(node: Dict[str, Any], path: str) -> None:
    """Recursively navigate a tree node."""
    while True:
        children = node.get("children", {})
        if not children:
            print(f"\n\U0001F50D Leaf Node: {path}")
            for key in ("companions", "requires", "upstream", "downstream"):
                items = node.get(key) or []
                if items:
                    print(f"  • {key.capitalize()}: {', '.join(items)}")
            input("\nPress Enter to go back...")
            return
        print(f"\n\U0001F4C1 {path}")
        entries = list(children.items())
        for i, (name, subnode) in enumerate(entries):
            kind = subnode.get("type", "node")
            print(f"  [{i}] {name} ({kind})")
        idx = select_entry(tuple(entries))
        if idx == -1:
            return
        selected_name, selected_node = entries[idx]
        walk(selected_node, f"{path}/{selected_name}")


def main(argv: Any = None) -> None:
    """Entry point for the truth tree walker."""
    parser = argparse.ArgumentParser(description="Explore the Prometheus Truth Tree interactively.")
    parser.add_argument(
        "--file",
        type=str,
        default=None,
        help="Path to a JSON file containing the truth tree. Defaults to packages/datasets/truth_tree.json.",
    )
    args = parser.parse_args(argv)
    # Compute default path relative to this script (../packages/datasets/truth_tree.json)
    repo_root = Path(__file__).resolve().parents[1]
    default_json = repo_root / "packages" / "datasets" / "truth_tree.json"
    json_file = Path(args.file) if args.file else default_json
    tree_data = load_tree(json_file)
    root_key = next(iter(tree_data))
    walk(tree_data[root_key], root_key)


if __name__ == "__main__":
    main()