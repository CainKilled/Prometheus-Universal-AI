/*
  Main JavaScript for Prometheus Dashboard

  This script drives the interactive behaviour of the web dashboard.
  It fetches the list of available plugins from the backend and
  populates the sidebar.  When a plugin is selected it displays a
  form where users can provide JSON parameters and submit a request.
  The response from the server is rendered as formatted JSON in
  the output area.  Additional plugin‑specific UI (such as the
  adapter dropdown for the swarm plugin) can be added here.

  Developed and maintained by Adam Henry Nagle.
*/

async function loadPlugins() {
  const res = await fetch('/plugins');
  const plugins = await res.json();
  const ul = document.getElementById('plugins');
  plugins.forEach(p => {
    const li = document.createElement('li');
    li.textContent = `${p.name}`;
    li.onclick = () => selectPlugin(p);
    ul.appendChild(li);
  });
}

function selectPlugin(plugin) {
  document.getElementById('selectedTitle').textContent = `Run ${plugin.name}`;
  const form = document.getElementById('pluginForm');
  form.style.display = 'block';
  const paramsDiv = document.getElementById('paramInputs');
  paramsDiv.innerHTML = '';
  // Provide generic input for runtime params
  // If the swarm plugin is selected, provide a dropdown for adapter type
  if (plugin.name === 'swarm') {
    const typeLabel = document.createElement('label');
    typeLabel.textContent = 'Adapter type:';
    const select = document.createElement('select');
    select.id = 'swarmType';
    ['git','docker','http','llm_cli','livekit','webkit'].forEach(opt => {
      const option = document.createElement('option');
      option.value = opt;
      option.textContent = opt;
      select.appendChild(option);
    });
    paramsDiv.appendChild(typeLabel);
    paramsDiv.appendChild(select);
  }
  // Generic JSON parameters input
  const label = document.createElement('label');
  label.textContent = 'Parameters (JSON):';
  const textarea = document.createElement('textarea');
  textarea.id = 'paramField';
  textarea.rows = 5;
  textarea.style.width = '100%';
  paramsDiv.appendChild(label);
  paramsDiv.appendChild(textarea);
  form.onsubmit = async (e) => {
    e.preventDefault();
    const paramText = textarea.value.trim() || '{}';
    let params;
    try {
      params = JSON.parse(paramText);
    } catch (ex) {
      alert('Invalid JSON');
      return;
    }
    // If swarm plugin, set type from dropdown
    if (plugin.name === 'swarm') {
      const sel = document.getElementById('swarmType');
      if (sel && sel.value) {
        params.type = sel.value;
      }
    }
    const resp = await fetch(`/run/${plugin.name}`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(params)
    });
    const json = await resp.json();
    document.getElementById('output').textContent = JSON.stringify(json, null, 2);
  };
}

// Kick off loading of plugins on page load
document.addEventListener('DOMContentLoaded', loadPlugins);