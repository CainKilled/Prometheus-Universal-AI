"""
Macros Plugin
=============

This plugin exposes the macros engine to the Prometheus runtime.  It
allows users to list available macros, load their definitions and
execute them via the unified CLI or other interfaces.  Macro files
should be stored in the ``macros`` directory under the project root
and follow the JSON format documented in ``macros_engine.py``.

Runtime parameters:

    action (str): ``list``, ``run`` or ``show``.  Defaults to ``list``.
    name (str):   Name of the macro to run or show (without .json).
    log (callable): Optional logger for status messages.
    kernel: The runtime kernel required to execute plugin steps.  If
        omitted for run action the macro will execute shell steps only.

Developed and maintained by Adam Henry Nagle.  Contact: 603‑384‑8949,
cainkilledabrl@icloud.com, nagleadam75@gmail.com.
"""

from __future__ import annotations

from typing import Any, Dict

from engines.macros_engine import MacrosEngine
from plugins.api.plugin_base import Plugin
import json


class MacrosPlugin:
    def metadata(self) -> Dict[str, Any]:
        return {
            'name': 'macros',
            'version': '0.1.0',
            'description': 'List and execute declarative macros stored under macros/',
            'targets': ['workflow'],
        }

    def activate(self, runtime: Dict[str, Any]) -> Dict[str, Any] | None:
        action: str = runtime.get('action', 'list').lower()
        name = runtime.get('name')
        log = runtime.get('log', print)
        kernel = runtime.get('kernel')
        engine = MacrosEngine()
        if action == 'list':
            names = engine.list_macros()
            log(f"Available macros: {', '.join(names) if names else 'none'}")
            return {'macros': names}
        if action == 'show':
            if not name:
                log("MacrosPlugin: 'name' is required for show action")
                return {'error': "'name' is required"}
            try:
                definition = engine.load_macro(name)
                log(json.dumps(definition, indent=2))
                return definition
            except Exception as exc:
                log(f"MacrosPlugin: {exc}")
                return {'error': str(exc)}
        if action == 'run':
            if not name:
                log("MacrosPlugin: 'name' is required for run action")
                return {'error': "'name' is required"}
            try:
                if kernel is None:
                    # Create a dummy kernel that can run shell commands only
                    class DummyKernel:
                        @staticmethod
                        def run_plugin(_name: str, _params: Dict[str, Any]) -> Dict[str, Any]:
                            return {'error': 'kernel not provided for plugin step'}
                    kernel = DummyKernel()
                result = engine.run_macro(name, kernel=kernel, logger=log)
                return result
            except Exception as exc:
                log(f"MacrosPlugin: {exc}")
                return {'error': str(exc)}
        log(f"MacrosPlugin: Unknown action '{action}'")
        return {'error': f"Unknown action '{action}'"}


def get_plugin() -> Plugin:
    return MacrosPlugin()  # type: ignore[return-value]