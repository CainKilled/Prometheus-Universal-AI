#!/usr/bin/env bash
set -euo pipefail
python -m py_compile "plugins/targets/gateway/plugin.py"
echo "gateway plugin compiled successfully"
