#!/usr/bin/env bash
# Test script for HuggingFacePlugin

python - <<'PY'
import sys
sys.path.append('Prometheus_RAV4_777_Enhancements')
from plugins.targets.huggingface.plugin import get_plugin

plugin = get_plugin()
assert plugin.metadata()['name'] == 'huggingface'
# Skip actual API call since it requires a valid token and network.
print("huggingface plugin OK")
PY