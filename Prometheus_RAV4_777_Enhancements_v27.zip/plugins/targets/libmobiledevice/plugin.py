"""
libmobiledevice GUI Plugin
==========================

This plugin exposes the graphical libmobiledevice tool to the Prometheus
plugin system.  When activated it launches the Tkinter interface from
``libtools.libmobiledevice_gui`` in a background thread.  The GUI
provides password‑protected access to a handful of common
libimobiledevice commands (listing devices, querying device
information).  Launching the GUI via the plugin allows it to be
invoked through the unified CLI, REPL or HTTP API without directly
importing the Tkinter module in user code.

Developed and maintained by Adam Henry Nagle.  Contact: 603‑384‑8949,
cainkilledabrl@icloud.com, nagleadam75@gmail.com.
"""

from typing import Dict, Any
import threading
from plugins.api.plugin_base import Plugin


class LibMobileDeviceGUIPlugin:
    """Plugin wrapper for the libmobiledevice GUI."""

    def metadata(self) -> Dict[str, Any]:
        return {
            "name": "libmobiledevice_gui",
            "version": "0.1.0",
            "description": "Launch a password‑protected GUI for libimobiledevice commands.",
            "targets": ["gui", "mobile"],
        }

    def activate(self, runtime: Dict[str, Any]) -> None:
        """Start the GUI in a background thread.

        The runtime dictionary may optionally include a ``log`` function to
        receive status messages.  Because the Tkinter main loop is
        blocking, the GUI is started on a separate daemon thread so that
        the caller does not block on activation.  Once started the GUI
        handles its own lifecycle until the user closes it.
        """
        logger = runtime.get("log", print)
        try:
            from libtools.libmobiledevice_gui.gui import main as start_gui
        except Exception as exc:
            logger(f"libmobiledevice_gui: Failed to import GUI: {exc}")
            return
        def run_gui() -> None:
            try:
                start_gui()
            except Exception as exc:
                logger(f"libmobiledevice_gui: Error running GUI: {exc}")
        t = threading.Thread(target=run_gui, daemon=True)
        t.start()
        logger("libmobiledevice_gui: GUI started in background thread")


def get_plugin() -> Plugin:
    return LibMobileDeviceGUIPlugin()  # type: ignore[return-value]