"""Bug hunting engine for simple static analysis of Python code.

This engine scans Python source files for patterns that may be
indicative of insecure or risky behaviour, such as use of
``eval``, ``exec``, or shell execution via ``os.system``.  It is
intended as a basic static analysis tool that can be extended with
additional rules.  Detected issues are returned as a list of
findings with file names and line numbers.

Author: Adam Henry Nagle
Contact: 603‑384‑8949; cainkilledabrl@icloud.com; nagleadam75@gmail.com
"""

from __future__ import annotations

import os
import re
from pathlib import Path
from typing import Dict, List, Optional


DEFAULT_PATTERNS = [
    r'\beval\s*\(',
    r'\bexec\s*\(',
    r'os\.system\s*\(',
    r'subprocess\.Popen\s*\(',
    r'\bshell\s*=\s*True',
]


def scan_codebase(base_dir: str, patterns: Optional[List[str]] = None) -> List[Dict[str, object]]:
    """Scan a directory tree for suspicious Python code patterns.

    Parameters
    ----------
    base_dir: str
        The directory tree to search.  Only ``.py`` files are scanned.
    patterns: list[str], optional
        Regular expressions representing risky patterns.  If None,
        defaults to a predefined set.

    Returns
    -------
    list of dict
        Each dict has keys ``file``, ``line_number`` and ``snippet``.
    """
    results: List[Dict[str, object]] = []
    compiled = [re.compile(p) for p in (patterns or DEFAULT_PATTERNS)]
    for root, _, files in os.walk(base_dir):
        for fname in files:
            if fname.endswith('.py'):
                fpath = os.path.join(root, fname)
                try:
                    with open(fpath, 'r', encoding='utf-8', errors='ignore') as f:
                        for lineno, line in enumerate(f, 1):
                            for pat in compiled:
                                if pat.search(line):
                                    results.append({
                                        'file': os.path.relpath(fpath, base_dir),
                                        'line_number': lineno,
                                        'snippet': line.strip(),
                                        'pattern': pat.pattern,
                                    })
                                    break
                except Exception:
                    pass
    return results


class BugHuntingEngine:
    """Engine wrapper for basic static bug hunting.

    The ``run`` method accepts a mapping containing a ``'base_dir'``
    key pointing to the directory to scan.  Optionally, a list of
    regex patterns may be provided via ``'patterns'``.
    """
    def run(self, runtime: Dict[str, object]) -> Dict[str, object]:
        base_dir = runtime.get('base_dir')
        if not base_dir:
            return {"error": "Missing base_dir"}
        patterns = runtime.get('patterns')
        return {'findings': scan_codebase(base_dir, patterns)}