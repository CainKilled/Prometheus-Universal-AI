"""
Web Assets Engine
=================

This engine provides simple build utilities for front‑end assets used
by the Prometheus dashboard.  It can combine and minify CSS and
JavaScript files and copy them to an output directory.  The engine
does not rely on third‑party packages; minification is done via
trivial whitespace stripping and newline removal.

Example usage:

    from engines.web_assets_engine import WebAssetsEngine
    engine = WebAssetsEngine()
    engine.build_assets(src_dir="webapp/assets", out_dir="webapp/dist")

The ``build_assets`` method will read all ``.css`` and ``.js`` files
under ``src_dir``, minify them and write the results into ``out_dir``.
Directories are created if they do not exist.  The engine returns a
dictionary mapping filenames to their minified sizes.

Developed and maintained by Adam Henry Nagle.  Contact:
603‑384‑8949, cainkilledabrl@icloud.com, nagleadam75@gmail.com.
"""

from __future__ import annotations

import os
from pathlib import Path
from typing import Dict, Optional


class WebAssetsEngine:
    """Manage and build front‑end CSS/JS assets."""

    def __init__(self, base_dir: Optional[str] = None) -> None:
        # Base directory of the repository; defaults to this file's grandparent
        if base_dir is None:
            self.base_dir = Path(__file__).resolve().parents[1]
        else:
            self.base_dir = Path(base_dir)

    def minify(self, content: str) -> str:
        """Trivially minify CSS or JS by removing newline and excess whitespace."""
        return "".join(line.strip() for line in content.splitlines())

    def build_assets(self, src_dir: str | None = None, out_dir: str | None = None) -> Dict[str, int]:
        """Minify all CSS and JS files in ``src_dir`` and write them to ``out_dir``.

        Args:
            src_dir: Relative path to the source assets directory.  Defaults
                to ``webapp/assets`` under the base directory.
            out_dir: Relative path to the output directory.  Defaults to
                ``webapp/dist`` under the base directory.

        Returns:
            A dictionary mapping filenames to minified sizes in bytes.
        """
        src = self.base_dir / (src_dir or "webapp/assets")
        out = self.base_dir / (out_dir or "webapp/dist")
        out.mkdir(parents=True, exist_ok=True)
        result: Dict[str, int] = {}
        for path in src.glob("**/*"):
            if path.suffix.lower() not in {'.css', '.js'}:
                continue
            rel_name = path.relative_to(src).name
            content = path.read_text(encoding="utf-8")
            minified = self.minify(content)
            dest_path = out / rel_name.replace(path.suffix, f".min{path.suffix}")
            dest_path.write_text(minified, encoding="utf-8")
            result[str(dest_path)] = len(minified)
        return result