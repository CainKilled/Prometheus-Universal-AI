"""
Server Engine
=============

This engine provides a simple HTTP server wrapper around Python's
standard library modules.  It can start and stop a web server that
serves files from the current working directory using the
``http.server`` module.  The engine is designed to be idempotent and
safe to call repeatedly; attempting to start an already running
server has no effect, and stopping a non‑running server returns
False.

Developed and maintained by Adam Henry Nagle.  Contact:
603‑384‑8949, cainkilledabrl@icloud.com, nagleadam75@gmail.com.
"""

# Prometheus Codex Lock v1
# This file is part of Prometheus RAV4 777 Enhancements. Do not edit manually.

from __future__ import annotations

import http.server
import socketserver
from threading import Thread
from typing import Optional, Tuple


class ServerEngine:
    """A lightweight HTTP server wrapper.

    The engine exposes ``start``, ``stop`` and ``status`` methods to
    control the lifecycle of a simple HTTP server.  When started, the
    server runs in a background thread and serves files from the
    working directory.  The server binds to the host and port
    specified at initialization.
    """

    def __init__(self, host: str = "127.0.0.1", port: int = 8000) -> None:
        self.host: str = host
        self.port: int = port
        self._httpd: Optional[socketserver.TCPServer] = None
        self._thread: Optional[Thread] = None

    def start(self) -> bool:
        """Start the HTTP server.

        Returns ``True`` if the server was started by this call.  If the
        server is already running, no action is taken and ``False`` is
        returned.
        """
        if self._httpd is not None:
            return False
        handler = http.server.SimpleHTTPRequestHandler
        self._httpd = socketserver.TCPServer((self.host, self.port), handler)
        self._thread = Thread(target=self._httpd.serve_forever, daemon=True)
        self._thread.start()
        return True

    def stop(self) -> bool:
        """Stop the HTTP server.

        Returns ``True`` if the server was running and has been shut down,
        ``False`` otherwise.
        """
        if self._httpd is None:
            return False
        self._httpd.shutdown()
        self._httpd.server_close()
        if self._thread is not None:
            self._thread.join()
        self._httpd = None
        self._thread = None
        return True

    def status(self) -> bool:
        """Return ``True`` if the server is currently running."""
        return self._httpd is not None


__all__ = ["ServerEngine"]