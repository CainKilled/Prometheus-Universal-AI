#!/usr/bin/env python3
"""
Self-Contained AI Tool Generator
A modular, standalone system for generating various tools and utilities
without external dependencies. Designed for AI automation integration.
"""

import json
import re
import os
import sys
import time
import random
import hashlib
import base64
from datetime import datetime
from typing import Dict, List, Any, Optional, Callable, Union
from dataclasses import dataclass, asdict
from enum import Enum
import inspect

class ToolType(Enum):
    """Available tool types for generation"""
    DATA_PROCESSOR = "data_processor"
    FILE_HANDLER = "file_handler"
    TEXT_ANALYZER = "text_analyzer"
    CALCULATOR = "calculator"
    VALIDATOR = "validator"
    FORMATTER = "formatter"
    CONVERTER = "converter"
    GENERATOR = "generator"
    UTILITY = "utility"
    AUTOMATION = "automation"

@dataclass
class ToolSpec:
    """Specification for tool generation"""
    name: str
    tool_type: ToolType
    description: str
    inputs: List[Dict[str, str]]
    outputs: List[Dict[str, str]]
    parameters: Dict[str, Any]
    requirements: List[str]

@dataclass
class GeneratedTool:
    """Container for generated tool"""
    id: str
    spec: ToolSpec
    code: str
    metadata: Dict[str, Any]
    created_at: datetime

class AIToolGenerator:
    """Main AI Tool Generator class"""
    
    def __init__(self):
        self.tools_registry = {}
        self.templates = self._initialize_templates()
        self.validators = self._initialize_validators()
        self.generators = self._initialize_generators()
        
    def _initialize_templates(self) -> Dict[str, str]:
        """Initialize code templates for different tool types"""
        return {
            ToolType.DATA_PROCESSOR: '''
class {class_name}:
    """Generated data processor: {description}"""
    
    def __init__(self):
        self.name = "{name}"
        self.version = "1.0.0"
        self.metadata = {metadata}
    
    def process(self, data, **kwargs):
        """Main processing function"""
        try:
            {processing_logic}
            return self._format_output(result)
        except Exception as e:
            return {{"error": str(e), "success": False}}
    
    def _format_output(self, result):
        """Format output according to specification"""
        return {{
            "success": True,
            "data": result,
            "timestamp": "{timestamp}",
            "tool": self.name
        }}
    
    {additional_methods}
''',
            
            ToolType.FILE_HANDLER: '''
class {class_name}:
    """Generated file handler: {description}"""
    
    def __init__(self):
        self.name = "{name}"
        self.supported_formats = {supported_formats}
        self.metadata = {metadata}
    
    def handle_file(self, filepath, operation="read", **kwargs):
        """Main file handling function"""
        try:
            if operation == "read":
                return self._read_file(filepath, **kwargs)
            elif operation == "write":
                return self._write_file(filepath, kwargs.get('data'), **kwargs)
            elif operation == "process":
                return self._process_file(filepath, **kwargs)
            else:
                raise ValueError(f"Unsupported operation: {{operation}}")
        except Exception as e:
            return {{"error": str(e), "success": False}}
    
    def _read_file(self, filepath, **kwargs):
        """Read file content"""
        {read_logic}
    
    def _write_file(self, filepath, data, **kwargs):
        """Write data to file"""
        {write_logic}
    
    def _process_file(self, filepath, **kwargs):
        """Process file content"""
        {process_logic}
    
    {additional_methods}
''',
            
            ToolType.TEXT_ANALYZER: '''
class {class_name}:
    """Generated text analyzer: {description}"""
    
    def __init__(self):
        self.name = "{name}"
        self.analysis_types = {analysis_types}
        self.metadata = {metadata}
    
    def analyze(self, text, analysis_type="full", **kwargs):
        """Main analysis function"""
        try:
            results = {{}}
            
            if analysis_type in ["full", "basic"]:
                results.update(self._basic_analysis(text))
            
            if analysis_type in ["full", "advanced"]:
                results.update(self._advanced_analysis(text))
            
            {custom_analysis}
            
            return self._format_results(results)
        except Exception as e:
            return {{"error": str(e), "success": False}}
    
    def _basic_analysis(self, text):
        """Basic text analysis"""
        return {{
            "length": len(text),
            "words": len(text.split()),
            "lines": len(text.split('\\n')),
            "characters": len(text.replace(' ', ''))
        }}
    
    def _advanced_analysis(self, text):
        """Advanced text analysis"""
        {advanced_logic}
    
    def _format_results(self, results):
        """Format analysis results"""
        return {{
            "success": True,
            "analysis": results,
            "timestamp": "{timestamp}",
            "tool": self.name
        }}
    
    {additional_methods}
''',
            
            ToolType.VALIDATOR: '''
class {class_name}:
    """Generated validator: {description}"""
    
    def __init__(self):
        self.name = "{name}"
        self.validation_rules = {validation_rules}
        self.metadata = {metadata}
    
    def validate(self, data, rule_set="default", **kwargs):
        """Main validation function"""
        results = {{
            "valid": True,
            "errors": [],
            "warnings": [],
            "details": {{}}
        }}
        
        try:
            {validation_logic}
            
            return self._format_validation_results(results)
        except Exception as e:
            results["valid"] = False
            results["errors"].append(f"Validation error: {{str(e)}}")
            return results
    
    def _format_validation_results(self, results):
        """Format validation results"""
        return {{
            "success": True,
            "validation": results,
            "timestamp": "{timestamp}",
            "tool": self.name
        }}
    
    {additional_methods}
''',
            
            ToolType.UTILITY: '''
class {class_name}:
    """Generated utility tool: {description}"""
    
    def __init__(self):
        self.name = "{name}"
        self.utilities = {utilities}
        self.metadata = {metadata}
    
    def execute(self, utility_name, *args, **kwargs):
        """Execute specified utility function"""
        try:
            if utility_name not in self.utilities:
                raise ValueError(f"Unknown utility: {{utility_name}}")
            
            method_name = f"_{{utility_name}}"
            if hasattr(self, method_name):
                return getattr(self, method_name)(*args, **kwargs)
            else:
                raise NotImplementedError(f"Utility {{utility_name}} not implemented")
                
        except Exception as e:
            return {{"error": str(e), "success": False}}
    
    {utility_methods}
    
    def get_available_utilities(self):
        """Get list of available utilities"""
        return list(self.utilities.keys())
    
    {additional_methods}
'''
        }
    
    def _initialize_validators(self) -> Dict[str, Callable]:
        """Initialize input validators"""
        return {
            "string": lambda x: isinstance(x, str),
            "integer": lambda x: isinstance(x, int),
            "float": lambda x: isinstance(x, (int, float)),
            "list": lambda x: isinstance(x, list),
            "dict": lambda x: isinstance(x, dict),
            "boolean": lambda x: isinstance(x, bool),
            "file_path": lambda x: isinstance(x, str) and len(x) > 0,
            "json": lambda x: self._validate_json(x)
        }
    
    def _validate_json(self, value) -> bool:
        """Validate JSON string"""
        try:
            json.loads(value) if isinstance(value, str) else json.dumps(value)
            return True
        except:
            return False
    
    def _initialize_generators(self) -> Dict[ToolType, Callable]:
        """Initialize code generators for each tool type"""
        return {
            ToolType.DATA_PROCESSOR: self._generate_data_processor,
            ToolType.FILE_HANDLER: self._generate_file_handler,
            ToolType.TEXT_ANALYZER: self._generate_text_analyzer,
            ToolType.CALCULATOR: self._generate_calculator,
            ToolType.VALIDATOR: self._generate_validator,
            ToolType.FORMATTER: self._generate_formatter,
            ToolType.CONVERTER: self._generate_converter,
            ToolType.GENERATOR: self._generate_generator_tool,
            ToolType.UTILITY: self._generate_utility,
            ToolType.AUTOMATION: self._generate_automation
        }
    
    def generate_tool(self, spec: ToolSpec) -> GeneratedTool:
        """Generate a tool based on specification"""
        if not self._validate_spec(spec):
            raise ValueError("Invalid tool specification")
        
        generator = self.generators.get(spec.tool_type)
        if not generator:
            raise ValueError(f"No generator available for tool type: {spec.tool_type}")
        
        tool_id = self._generate_tool_id(spec)
        code = generator(spec)
        metadata = self._generate_metadata(spec)
        
        tool = GeneratedTool(
            id=tool_id,
            spec=spec,
            code=code,
            metadata=metadata,
            created_at=datetime.now()
        )
        
        self.tools_registry[tool_id] = tool
        return tool
    
    def _validate_spec(self, spec: ToolSpec) -> bool:
        """Validate tool specification"""
        required_fields = ['name', 'tool_type', 'description', 'inputs', 'outputs']
        for field in required_fields:
            if not hasattr(spec, field) or getattr(spec, field) is None:
                return False
        return True
    
    def _generate_tool_id(self, spec: ToolSpec) -> str:
        """Generate unique tool ID"""
        content = f"{spec.name}_{spec.tool_type.value}_{datetime.now().isoformat()}"
        return hashlib.md5(content.encode()).hexdigest()[:12]
    
    def _generate_metadata(self, spec: ToolSpec) -> Dict[str, Any]:
        """Generate tool metadata"""
        return {
            "name": spec.name,
            "type": spec.tool_type.value,
            "description": spec.description,
            "inputs": spec.inputs,
            "outputs": spec.outputs,
            "parameters": spec.parameters,
            "requirements": spec.requirements,
            "generated_at": datetime.now().isoformat(),
            "version": "1.0.0"
        }
    
    def _generate_data_processor(self, spec: ToolSpec) -> str:
        """Generate data processor tool"""
        class_name = self._to_class_name(spec.name)
        
        # Generate processing logic based on spec
        processing_logic = self._generate_processing_logic(spec)
        additional_methods = self._generate_additional_methods(spec)
        
        return self.templates[ToolType.DATA_PROCESSOR].format(
            class_name=class_name,
            name=spec.name,
            description=spec.description,
            metadata=json.dumps(asdict(spec), indent=2),
            processing_logic=processing_logic,
            timestamp=datetime.now().isoformat(),
            additional_methods=additional_methods
        )
    
    def _generate_file_handler(self, spec: ToolSpec) -> str:
        """Generate file handler tool"""
        class_name = self._to_class_name(spec.name)
        
        supported_formats = spec.parameters.get('formats', ['txt', 'json', 'csv'])
        read_logic = self._generate_file_read_logic(spec)
        write_logic = self._generate_file_write_logic(spec)
        process_logic = self._generate_file_process_logic(spec)
        additional_methods = self._generate_additional_methods(spec)
        
        return self.templates[ToolType.FILE_HANDLER].format(
            class_name=class_name,
            name=spec.name,
            description=spec.description,
            supported_formats=supported_formats,
            metadata=json.dumps(asdict(spec), indent=2),
            read_logic=read_logic,
            write_logic=write_logic,
            process_logic=process_logic,
            additional_methods=additional_methods
        )
    
    def _generate_text_analyzer(self, spec: ToolSpec) -> str:
        """Generate text analyzer tool"""
        class_name = self._to_class_name(spec.name)
        
        analysis_types = spec.parameters.get('analysis_types', ['basic', 'advanced'])
        custom_analysis = self._generate_custom_analysis_logic(spec)
        advanced_logic = self._generate_advanced_analysis_logic(spec)
        additional_methods = self._generate_additional_methods(spec)
        
        return self.templates[ToolType.TEXT_ANALYZER].format(
            class_name=class_name,
            name=spec.name,
            description=spec.description,
            analysis_types=analysis_types,
            metadata=json.dumps(asdict(spec), indent=2),
            custom_analysis=custom_analysis,
            advanced_logic=advanced_logic,
            timestamp=datetime.now().isoformat(),
            additional_methods=additional_methods
        )
    
    def _generate_calculator(self, spec: ToolSpec) -> str:
        """Generate calculator tool"""
        class_name = self._to_class_name(spec.name)
        operations = spec.parameters.get('operations', ['add', 'subtract', 'multiply', 'divide'])
        
        calc_methods = []
        for op in operations:
            calc_methods.append(self._generate_calc_method(op))
        
        return f'''
class {class_name}:
    """Generated calculator: {spec.description}"""
    
    def __init__(self):
        self.name = "{spec.name}"
        self.operations = {operations}
        self.metadata = {json.dumps(asdict(spec), indent=2)}
    
    def calculate(self, operation, *args, **kwargs):
        """Perform calculation"""
        try:
            method_name = f"_{{operation}}"
            if hasattr(self, method_name):
                return {{
                    "success": True,
                    "result": getattr(self, method_name)(*args, **kwargs),
                    "operation": operation,
                    "timestamp": "{datetime.now().isoformat()}"
                }}
            else:
                raise ValueError(f"Unknown operation: {{operation}}")
        except Exception as e:
            return {{"error": str(e), "success": False}}
    
    {chr(10).join(calc_methods)}
    
    def get_available_operations(self):
        """Get available operations"""
        return self.operations
'''
    
    def _generate_validator(self, spec: ToolSpec) -> str:
        """Generate validator tool"""
        class_name = self._to_class_name(spec.name)
        
        validation_rules = spec.parameters.get('rules', {})
        validation_logic = self._generate_validation_logic(spec)
        additional_methods = self._generate_additional_methods(spec)
        
        return self.templates[ToolType.VALIDATOR].format(
            class_name=class_name,
            name=spec.name,
            description=spec.description,
            validation_rules=json.dumps(validation_rules),
            metadata=json.dumps(asdict(spec), indent=2),
            validation_logic=validation_logic,
            timestamp=datetime.now().isoformat(),
            additional_methods=additional_methods
        )
    
    def _generate_formatter(self, spec: ToolSpec) -> str:
        """Generate formatter tool"""
        class_name = self._to_class_name(spec.name)
        formats = spec.parameters.get('formats', ['json', 'xml', 'yaml'])
        
        format_methods = []
        for fmt in formats:
            format_methods.append(self._generate_format_method(fmt))
        
        return f'''
class {class_name}:
    """Generated formatter: {spec.description}"""
    
    def __init__(self):
        self.name = "{spec.name}"
        self.formats = {formats}
        self.metadata = {json.dumps(asdict(spec), indent=2)}
    
    def format_data(self, data, target_format, **kwargs):
        """Format data to target format"""
        try:
            method_name = f"_format_{{target_format}}"
            if hasattr(self, method_name):
                result = getattr(self, method_name)(data, **kwargs)
                return {{
                    "success": True,
                    "formatted_data": result,
                    "format": target_format,
                    "timestamp": "{datetime.now().isoformat()}"
                }}
            else:
                raise ValueError(f"Unsupported format: {{target_format}}")
        except Exception as e:
            return {{"error": str(e), "success": False}}
    
    {chr(10).join(format_methods)}
    
    def get_supported_formats(self):
        """Get supported formats"""
        return self.formats
'''
    
    def _generate_converter(self, spec: ToolSpec) -> str:
        """Generate converter tool"""
        class_name = self._to_class_name(spec.name)
        conversions = spec.parameters.get('conversions', [])
        
        return f'''
class {class_name}:
    """Generated converter: {spec.description}"""
    
    def __init__(self):
        self.name = "{spec.name}"
        self.conversions = {conversions}
        self.metadata = {json.dumps(asdict(spec), indent=2)}
    
    def convert(self, value, from_unit, to_unit, **kwargs):
        """Convert value between units"""
        try:
            conversion_key = f"{{from_unit}}_to_{{to_unit}}"
            result = self._perform_conversion(value, from_unit, to_unit)
            
            return {{
                "success": True,
                "original_value": value,
                "converted_value": result,
                "from_unit": from_unit,
                "to_unit": to_unit,
                "timestamp": "{datetime.now().isoformat()}"
            }}
        except Exception as e:
            return {{"error": str(e), "success": False}}
    
    def _perform_conversion(self, value, from_unit, to_unit):
        """Perform the actual conversion"""
        # Basic conversion logic - can be extended
        conversion_factors = {{
            "meters_to_feet": 3.28084,
            "feet_to_meters": 0.3048,
            "celsius_to_fahrenheit": lambda x: (x * 9/5) + 32,
            "fahrenheit_to_celsius": lambda x: (x - 32) * 5/9,
            "kg_to_pounds": 2.20462,
            "pounds_to_kg": 0.453592
        }}
        
        key = f"{{from_unit}}_to_{{to_unit}}"
        if key in conversion_factors:
            factor = conversion_factors[key]
            return factor(value) if callable(factor) else value * factor
        else:
            raise ValueError(f"Conversion not supported: {{from_unit}} to {{to_unit}}")
'''
    
    def _generate_generator_tool(self, spec: ToolSpec) -> str:
        """Generate generator tool"""
        class_name = self._to_class_name(spec.name)
        generation_types = spec.parameters.get('types', ['uuid', 'hash', 'random'])
        
        return f'''
class {class_name}:
    """Generated generator tool: {spec.description}"""
    
    def __init__(self):
        self.name = "{spec.name}"
        self.generation_types = {generation_types}
        self.metadata = {json.dumps(asdict(spec), indent=2)}
    
    def generate(self, generation_type, **kwargs):
        """Generate content based on type"""
        try:
            method_name = f"_generate_{{generation_type}}"
            if hasattr(self, method_name):
                result = getattr(self, method_name)(**kwargs)
                return {{
                    "success": True,
                    "generated": result,
                    "type": generation_type,
                    "timestamp": "{datetime.now().isoformat()}"
                }}
            else:
                raise ValueError(f"Unknown generation type: {{generation_type}}")
        except Exception as e:
            return {{"error": str(e), "success": False}}
    
    def _generate_uuid(self, **kwargs):
        """Generate UUID"""
        import uuid
        return str(uuid.uuid4())
    
    def _generate_hash(self, **kwargs):
        """Generate hash"""
        data = kwargs.get('data', str(time.time()))
        return hashlib.sha256(str(data).encode()).hexdigest()
    
    def _generate_random(self, **kwargs):
        """Generate random value"""
        type_val = kwargs.get('type', 'string')
        length = kwargs.get('length', 10)
        
        if type_val == 'string':
            chars = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789'
            return ''.join(random.choice(chars) for _ in range(length))
        elif type_val == 'number':
            return random.randint(kwargs.get('min', 1), kwargs.get('max', 100))
        else:
            return random.random()
'''
    
    def _generate_utility(self, spec: ToolSpec) -> str:
        """Generate utility tool"""
        class_name = self._to_class_name(spec.name)
        utilities = spec.parameters.get('utilities', [])
        
        utility_methods = []
        for util in utilities:
            utility_methods.append(self._generate_utility_method(util))
        
        return self.templates[ToolType.UTILITY].format(
            class_name=class_name,
            name=spec.name,
            description=spec.description,
            utilities=utilities,
            metadata=json.dumps(asdict(spec), indent=2),
            utility_methods=chr(10).join(utility_methods),
            additional_methods=""
        )
    
    def _generate_automation(self, spec: ToolSpec) -> str:
        """Generate automation tool"""
        class_name = self._to_class_name(spec.name)
        
        return f'''
class {class_name}:
    """Generated automation tool: {spec.description}"""
    
    def __init__(self):
        self.name = "{spec.name}"
        self.tasks = []
        self.metadata = {json.dumps(asdict(spec), indent=2)}
    
    def add_task(self, task_name, task_function, **kwargs):
        """Add automation task"""
        task = {{
            "name": task_name,
            "function": task_function,
            "parameters": kwargs,
            "created_at": "{datetime.now().isoformat()}"
        }}
        self.tasks.append(task)
        return task
    
    def execute_task(self, task_name, **override_params):
        """Execute specific task"""
        try:
            task = next((t for t in self.tasks if t["name"] == task_name), None)
            if not task:
                raise ValueError(f"Task not found: {{task_name}}")
            
            params = task["parameters"].copy()
            params.update(override_params)
            
            if callable(task["function"]):
                result = task["function"](**params)
            else:
                result = f"Executed task: {{task_name}}"
            
            return {{
                "success": True,
                "task": task_name,
                "result": result,
                "timestamp": "{datetime.now().isoformat()}"
            }}
        except Exception as e:
            return {{"error": str(e), "success": False}}
    
    def execute_all_tasks(self):
        """Execute all tasks in sequence"""
        results = []
        for task in self.tasks:
            result = self.execute_task(task["name"])
            results.append(result)
        return results
    
    def get_tasks(self):
        """Get list of tasks"""
        return [t["name"] for t in self.tasks]
'''
    
    # Helper methods for code generation
    def _to_class_name(self, name: str) -> str:
        """Convert name to class name format"""
        return ''.join(word.capitalize() for word in re.split(r'[_\s-]', name))
    
    def _generate_processing_logic(self, spec: ToolSpec) -> str:
        """Generate processing logic based on spec"""
        logic_type = spec.parameters.get('logic', 'basic')
        
        if logic_type == 'filter':
            return '''
            if isinstance(data, list):
                filter_func = kwargs.get('filter_func', lambda x: True)
                result = [item for item in data if filter_func(item)]
            else:
                result = data
            '''
        elif logic_type == 'transform':
            return '''
            transform_func = kwargs.get('transform_func', lambda x: x)
            if isinstance(data, list):
                result = [transform_func(item) for item in data]
            else:
                result = transform_func(data)
            '''
        else:
            return '''
            # Basic processing
            result = data
            if kwargs.get('uppercase', False) and isinstance(data, str):
                result = data.upper()
            elif kwargs.get('lowercase', False) and isinstance(data, str):
                result = data.lower()
            '''
    
    def _generate_additional_methods(self, spec: ToolSpec) -> str:
        """Generate additional methods based on spec"""
        methods = []
        
        if 'helpers' in spec.parameters:
            for helper in spec.parameters['helpers']:
                methods.append(f'''
    def {helper}(self, *args, **kwargs):
        """Helper method: {helper}"""
        # Implementation for {helper}
        return args[0] if args else None
                ''')
        
        return '\n'.join(methods)
    
    def _generate_file_read_logic(self, spec: ToolSpec) -> str:
        """Generate file reading logic"""
        return '''
        with open(filepath, 'r', encoding='utf-8') as f:
            content = f.read()
        
        if filepath.endswith('.json'):
            return {"success": True, "data": json.loads(content)}
        else:
            return {"success": True, "data": content}
        '''
    
    def _generate_file_write_logic(self, spec: ToolSpec) -> str:
        """Generate file writing logic"""
        return '''
        if filepath.endswith('.json'):
            with open(filepath, 'w', encoding='utf-8') as f:
                json.dump(data, f, indent=2)
        else:
            with open(filepath, 'w', encoding='utf-8') as f:
                f.write(str(data))
        return {"success": True, "message": "File written successfully"}
        '''
    
    def _generate_file_process_logic(self, spec: ToolSpec) -> str:
        """Generate file processing logic"""
        return '''
        content = self._read_file(filepath)
        if content.get("success"):
            # Process the content
            processed = kwargs.get('processor', lambda x: x)(content["data"])
            return {"success": True, "processed_data": processed}
        return content
        '''
    
    def _generate_custom_analysis_logic(self, spec: ToolSpec) -> str:
        """Generate custom analysis logic"""
        custom_analyses = spec.parameters.get('custom_analyses', [])
        logic = []
        
        for analysis in custom_analyses:
            logic.append(f'''
            if analysis_type in ["full", "{analysis}"]:
                results["{analysis}"] = self._analyze_{analysis}(text)
            ''')
        
        return '\n'.join(logic)
    
    def _generate_advanced_analysis_logic(self, spec: ToolSpec) -> str:
        """Generate advanced analysis logic"""
        return '''
        words = text.split()
        sentences = text.split('.')
        
        return {
            "avg_word_length": sum(len(word) for word in words) / len(words) if words else 0,
            "sentences": len([s for s in sentences if s.strip()]),
            "unique_words": len(set(word.lower() for word in words)),
            "readability_score": self._calculate_readability(text)
        }
        '''
    
    def _generate_validation_logic(self, spec: ToolSpec) -> str:
        """Generate validation logic"""
        rules = spec.parameters.get('rules', {})
        logic = []
        
        for rule_name, rule_config in rules.items():
            logic.append(f'''
            # Validate {rule_name}
            if not self._validate_{rule_name}(data, rule_set):
                results["valid"] = False
                results["errors"].append("Failed {rule_name} validation")
            ''')
        
        return '\n'.join(logic)
    
    def _generate_calc_method(self, operation: str) -> str:
        """Generate calculator method"""
        operations_map = {
            'add': 'return sum(args)',
            'subtract': 'return args[0] - sum(args[1:]) if len(args) > 1 else -args[0]',
            'multiply': 'result = 1\n        for arg in args:\n            result *= arg\n        return result',
            'divide': 'result = args[0]\n        for arg in args[1:]:\n            if arg == 0:\n                raise ValueError("Division by zero")\n            result /= arg\n        return result'
        }
        
        logic = operations_map.get(operation, 'return args[0] if args else 0')
        
        return f'''
    def _{operation}(self, *args):
        """Perform {operation} operation"""
        if not args:
            raise ValueError("No arguments provided")
        {logic}
        '''
    
    def _generate_format_method(self, format_type: str) -> str:
        """Generate format method"""
        if format_type == 'json':
            return '''
    def _format_json(self, data, **kwargs):
        """Format data as JSON"""
        indent = kwargs.get('indent', 2)
        return json.dumps(data, indent=indent)
        '''
        elif format_type == 'xml':
            return '''
    def _format_xml(self, data, **kwargs):
        """Format data as XML"""
        root_tag = kwargs.get('root_tag', 'root')
        
        def dict_to_xml(d, tag='item'):
            xml = f'<{tag}>'
            for key, value in d.items():
                if isinstance(value, dict):
                    xml += dict_to_xml(value, key)
                elif isinstance(value, list):
                    for item in value:
                        xml += dict_to_xml({key: item}, key)
                else:
                    xml += f'<{key}>{value}</{key}>'
            xml += f'</{tag}>'
            return xml
        
        if isinstance(data, dict):
            return dict_to_xml(data, root_tag)
        else:
            return f'<{root_tag}>{data}</{root_tag}>'
        '''
        elif format_type == 'csv':
            return '''
    def _format_csv(self, data, **kwargs):
        """Format data as CSV"""
        delimiter = kwargs.get('delimiter', ',')
        
        if isinstance(data, list) and data and isinstance(data[0], dict):
            headers = list(data[0].keys())
            csv_content = delimiter.join(headers) + '\\n'
            for row in data:
                csv_content += delimiter.join(str(row.get(h, '')) for h in headers) + '\\n'
            return csv_content
        else:
            return str(data)
        '''
        else:
            return f'''
    def _format_{format_type}(self, data, **kwargs):
        """Format data as {format_type}"""
        return str(data)
        '''
    
    def _generate_utility_method(self, utility_name: str) -> str:
        """Generate utility method"""
        utility_methods = {
            'hash_string': '''
    def _hash_string(self, text, algorithm='sha256'):
        """Hash a string"""
        import hashlib
        hash_func = getattr(hashlib, algorithm, hashlib.sha256)
        return hash_func(text.encode()).hexdigest()
            ''',
            'encode_base64': '''
    def _encode_base64(self, data):
        """Encode data to base64"""
        if isinstance(data, str):
            data = data.encode()
        return base64.b64encode(data).decode()
            ''',
            'decode_base64': '''
    def _decode_base64(self, encoded_data):
        """Decode base64 data"""
        return base64.b64decode(encoded_data).decode()
            ''',
            'generate_timestamp': '''
    def _generate_timestamp(self, format_str='%Y-%m-%d %H:%M:%S'):
        """Generate timestamp"""
        return datetime.now().strftime(format_str)
            ''',
            'validate_email': '''
    def _validate_email(self, email):
        """Validate email format"""
        pattern = r'^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\\.[a-zA-Z]{2,}
        return bool(re.match(pattern, email))
            ''',
            'clean_text': '''
    def _clean_text(self, text, remove_special=True, lowercase=True):
        """Clean text data"""
        if remove_special:
            text = re.sub(r'[^a-zA-Z0-9\\s]', '', text)
        if lowercase:
            text = text.lower()
        return text.strip()
            '''
        }
        
        return utility_methods.get(utility_name, f'''
    def _{utility_name}(self, *args, **kwargs):
        """Utility method: {utility_name}"""
        return args[0] if args else None
        ''')
    
    # Tool management methods
    def get_tool(self, tool_id: str) -> Optional[GeneratedTool]:
        """Retrieve a generated tool by ID"""
        return self.tools_registry.get(tool_id)
    
    def list_tools(self) -> List[Dict[str, Any]]:
        """List all generated tools"""
        return [
            {
                "id": tool.id,
                "name": tool.spec.name,
                "type": tool.spec.tool_type.value,
                "description": tool.spec.description,
                "created_at": tool.created_at.isoformat()
            }
            for tool in self.tools_registry.values()
        ]
    
    def save_tool(self, tool_id: str, filepath: str) -> bool:
        """Save generated tool to file"""
        tool = self.get_tool(tool_id)
        if not tool:
            return False
        
        try:
            with open(filepath, 'w', encoding='utf-8') as f:
                f.write(tool.code)
            return True
        except Exception:
            return False
    
    def export_tool_package(self, tool_id: str, output_dir: str) -> Dict[str, Any]:
        """Export tool as complete package"""
        tool = self.get_tool(tool_id)
        if not tool:
            return {"success": False, "error": "Tool not found"}
        
        try:
            os.makedirs(output_dir, exist_ok=True)
            
            # Save main tool file
            tool_file = os.path.join(output_dir, f"{tool.spec.name.lower().replace(' ', '_')}.py")
            with open(tool_file, 'w', encoding='utf-8') as f:
                f.write(tool.code)
            
            # Save metadata
            metadata_file = os.path.join(output_dir, "metadata.json")
            with open(metadata_file, 'w', encoding='utf-8') as f:
                json.dump(tool.metadata, f, indent=2)
            
            # Save usage example
            example_file = os.path.join(output_dir, "example_usage.py")
            example_code = self._generate_usage_example(tool)
            with open(example_file, 'w', encoding='utf-8') as f:
                f.write(example_code)
            
            # Save README
            readme_file = os.path.join(output_dir, "README.md")
            readme_content = self._generate_readme(tool)
            with open(readme_file, 'w', encoding='utf-8') as f:
                f.write(readme_content)
            
            return {
                "success": True,
                "package_directory": output_dir,
                "files": [tool_file, metadata_file, example_file, readme_file]
            }
        except Exception as e:
            return {"success": False, "error": str(e)}
    
    def _generate_usage_example(self, tool: GeneratedTool) -> str:
        """Generate usage example for tool"""
        class_name = self._to_class_name(tool.spec.name)
        
        return f'''#!/usr/bin/env python3
"""
Usage example for {tool.spec.name}
Generated by AI Tool Generator
"""

from {tool.spec.name.lower().replace(' ', '_')} import {class_name}

def main():
    # Initialize the tool
    tool = {class_name}()
    
    print(f"Tool: {{tool.name}}")
    print(f"Description: {tool.spec.description}")
    
    # Example usage based on tool type
    {self._generate_example_usage_by_type(tool)}

if __name__ == "__main__":
    main()
'''
    
    def _generate_example_usage_by_type(self, tool: GeneratedTool) -> str:
        """Generate specific usage examples based on tool type"""
        examples = {
            ToolType.DATA_PROCESSOR: '''
    # Example data processing
    sample_data = ["apple", "banana", "cherry"]
    result = tool.process(sample_data, uppercase=True)
    print(f"Processed data: {result}")
    ''',
            ToolType.FILE_HANDLER: '''
    # Example file handling
    result = tool.handle_file("sample.txt", operation="read")
    print(f"File content: {result}")
    ''',
            ToolType.TEXT_ANALYZER: '''
    # Example text analysis
    sample_text = "This is a sample text for analysis."
    result = tool.analyze(sample_text, analysis_type="full")
    print(f"Analysis result: {result}")
    ''',
            ToolType.CALCULATOR: '''
    # Example calculations
    result = tool.calculate("add", 10, 20, 30)
    print(f"Addition result: {result}")
    
    result = tool.calculate("multiply", 5, 4)
    print(f"Multiplication result: {result}")
    ''',
            ToolType.VALIDATOR: '''
    # Example validation
    sample_data = {"email": "test@example.com", "age": 25}
    result = tool.validate(sample_data, rule_set="default")
    print(f"Validation result: {result}")
    ''',
            ToolType.FORMATTER: '''
    # Example formatting
    sample_data = {"name": "John", "age": 30}
    result = tool.format_data(sample_data, "json")
    print(f"Formatted data: {result}")
    ''',
            ToolType.CONVERTER: '''
    # Example conversion
    result = tool.convert(100, "meters", "feet")
    print(f"Conversion result: {result}")
    ''',
            ToolType.GENERATOR: '''
    # Example generation
    result = tool.generate("uuid")
    print(f"Generated UUID: {result}")
    
    result = tool.generate("random", type="string", length=8)
    print(f"Generated random string: {result}")
    ''',
            ToolType.UTILITY: '''
    # Example utility usage
    utilities = tool.get_available_utilities()
    print(f"Available utilities: {utilities}")
    
    if utilities:
        result = tool.execute(utilities[0], "sample data")
        print(f"Utility result: {result}")
    ''',
            ToolType.AUTOMATION: '''
    # Example automation
    def sample_task():
        return "Task completed successfully"
    
    tool.add_task("sample_task", sample_task)
    result = tool.execute_task("sample_task")
    print(f"Task result: {result}")
    '''
        }
        
        return examples.get(tool.spec.tool_type, '    # No specific example available')
    
    def _generate_readme(self, tool: GeneratedTool) -> str:
        """Generate README for tool"""
        return f'''# {tool.spec.name}

{tool.spec.description}

## Overview

This tool was automatically generated by the AI Tool Generator system.

**Tool Type:** {tool.spec.tool_type.value}  
**Generated:** {tool.created_at.strftime('%Y-%m-%d %H:%M:%S')}  
**Version:** {tool.metadata.get('version', '1.0.0')}

## Inputs

{self._format_io_specs(tool.spec.inputs)}

## Outputs

{self._format_io_specs(tool.spec.outputs)}

## Parameters

```json
{json.dumps(tool.spec.parameters, indent=2)}
```

## Requirements

{self._format_requirements(tool.spec.requirements)}

## Usage

See `example_usage.py` for complete usage examples.

```python
from {tool.spec.name.lower().replace(' ', '_')} import {self._to_class_name(tool.spec.name)}

# Initialize the tool
tool = {self._to_class_name(tool.spec.name)}()

# Use the tool
# (See example_usage.py for specific examples)
```

## Integration

This tool is designed to be modular and can be easily integrated into existing systems:

1. Import the tool class
2. Initialize with any required parameters
3. Call the appropriate methods
4. Handle responses (all methods return structured dictionaries)

## Error Handling

All tool methods return structured responses with success indicators:

```python
{
    "success": true/false,
    "data": "result_data",  # on success
    "error": "error_message"  # on failure
}
```

## Standalone Operation

This tool operates completely standalone with no external dependencies beyond Python standard library.
'''
    
    def _format_io_specs(self, specs: List[Dict[str, str]]) -> str:
        """Format input/output specifications"""
        if not specs:
            return "- None specified"
        
        formatted = []
        for spec in specs:
            name = spec.get('name', 'Unknown')
            type_val = spec.get('type', 'Any')
            desc = spec.get('description', 'No description')
            formatted.append(f"- **{name}** ({type_val}): {desc}")
        
        return '\n'.join(formatted)
    
    def _format_requirements(self, requirements: List[str]) -> str:
        """Format requirements list"""
        if not requirements:
            return "- No external requirements (Python standard library only)"
        
        return '\n'.join(f"- {req}" for req in requirements)
    
    # Integration helpers
    def create_tool_from_dict(self, spec_dict: Dict[str, Any]) -> GeneratedTool:
        """Create tool from dictionary specification"""
        tool_type = ToolType(spec_dict['tool_type'])
        spec = ToolSpec(
            name=spec_dict['name'],
            tool_type=tool_type,
            description=spec_dict['description'],
            inputs=spec_dict.get('inputs', []),
            outputs=spec_dict.get('outputs', []),
            parameters=spec_dict.get('parameters', {}),
            requirements=spec_dict.get('requirements', [])
        )
        return self.generate_tool(spec)
    
    def batch_generate_tools(self, spec_list: List[Dict[str, Any]]) -> List[GeneratedTool]:
        """Generate multiple tools from specification list"""
        tools = []
        for spec_dict in spec_list:
            try:
                tool = self.create_tool_from_dict(spec_dict)
                tools.append(tool)
            except Exception as e:
                print(f"Error generating tool {spec_dict.get('name', 'Unknown')}: {e}")
        return tools
    
    def get_available_tool_types(self) -> List[str]:
        """Get list of available tool types"""
        return [tool_type.value for tool_type in ToolType]
    
    def validate_tool_spec_dict(self, spec_dict: Dict[str, Any]) -> Dict[str, Any]:
        """Validate tool specification dictionary"""
        required_fields = ['name', 'tool_type', 'description']
        missing_fields = [field for field in required_fields if field not in spec_dict]
        
        errors = []
        warnings = []
        
        if missing_fields:
            errors.append(f"Missing required fields: {', '.join(missing_fields)}")
        
        if spec_dict.get('tool_type') not in [t.value for t in ToolType]:
            errors.append(f"Invalid tool_type: {spec_dict.get('tool_type')}")
        
        if not spec_dict.get('inputs'):
            warnings.append("No inputs specified")
        
        if not spec_dict.get('outputs'):
            warnings.append("No outputs specified")
        
        return {
            "valid": len(errors) == 0,
            "errors": errors,
            "warnings": warnings
        }


# Example usage and testing
def main():
    """Main function demonstrating the AI Tool Generator"""
    generator = AIToolGenerator()
    
    print("=== AI Tool Generator Demo ===")
    print(f"Available tool types: {generator.get_available_tool_types()}")
    
    # Example 1: Data Processor
    data_processor_spec = ToolSpec(
        name="Text Data Processor",
        tool_type=ToolType.DATA_PROCESSOR,
        description="Process text data with various transformations",
        inputs=[{"name": "text_data", "type": "string", "description": "Input text to process"}],
        outputs=[{"name": "processed_text", "type": "string", "description": "Processed text result"}],
        parameters={"logic": "transform", "helpers": ["clean_data", "validate_input"]},
        requirements=[]
    )
    
    # Example 2: File Handler
    file_handler_spec = ToolSpec(
        name="JSON File Manager",
        tool_type=ToolType.FILE_HANDLER,
        description="Handle JSON file operations",
        inputs=[{"name": "filepath", "type": "string", "description": "Path to JSON file"}],
        outputs=[{"name": "file_content", "type": "dict", "description": "JSON file content"}],
        parameters={"formats": ["json", "txt"], "encoding": "utf-8"},
        requirements=[]
    )
    
    # Example 3: Calculator
    calculator_spec = ToolSpec(
        name="Advanced Calculator",
        tool_type=ToolType.CALCULATOR,
        description="Perform mathematical calculations",
        inputs=[{"name": "numbers", "type": "list", "description": "Numbers to calculate"}],
        outputs=[{"name": "result", "type": "float", "description": "Calculation result"}],
        parameters={"operations": ["add", "subtract", "multiply", "divide", "power"]},
        requirements=[]
    )
    
    # Generate tools
    specs = [data_processor_spec, file_handler_spec, calculator_spec]
    generated_tools = []
    
    for spec in specs:
        try:
            tool = generator.generate_tool(spec)
            generated_tools.append(tool)
            print(f"✓ Generated tool: {tool.spec.name} (ID: {tool.id})")
        except Exception as e:
            print(f"✗ Failed to generate {spec.name}: {e}")
    
    # List all tools
    print(f"\nGenerated {len(generated_tools)} tools:")
    for tool_info in generator.list_tools():
        print(f"- {tool_info['name']} ({tool_info['type']}) - {tool_info['id']}")
    
    # Export first tool as example
    if generated_tools:
        tool_id = generated_tools[0].id
        export_result = generator.export_tool_package(tool_id, f"./generated_tool_{tool_id}")
        if export_result["success"]:
            print(f"\n✓ Exported tool package to: {export_result['package_directory']}")
            print(f"Files created: {len(export_result['files'])}")
        else:
            print(f"✗ Export failed: {export_result['error']}")


if __name__ == "__main__":
    main()