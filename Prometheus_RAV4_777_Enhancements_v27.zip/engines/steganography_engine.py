"""Steganography engine for detecting hidden data in image files.

This module provides simple functions to scan image files for
possible steganographic content and (optionally) to embed data
into images using a least‑significant bit technique.  It is not
intended to be a comprehensive steganography toolkit but rather
a lightweight detector that can be extended or replaced with
more sophisticated analyses as needed.

Author: Adam Henry Nagle
Contact: 603‑384‑8949; cainkilledabrl@icloud.com; nagleadam75@gmail.com

Functions
---------
scan_file_for_steganography(file_path: str) -> dict
    Scan the given image file for a magic marker in its LSBs.  If
    a marker is found, return the decoded message; otherwise return
    information indicating no hidden content was detected.

Notes
-----
The current implementation looks for a message starting with
``'STEGO:'`` embedded in the least significant bits of the image's
pixel channels.  Images without that prefix are considered clean.

Because this engine relies on the Pillow library, it will raise
ImportError if Pillow is unavailable.  See the test script for
a minimal example of usage.
"""

from __future__ import annotations

import os
from typing import Dict, Optional

try:
    from PIL import Image
except ImportError as exc:  # pragma: no cover
    raise ImportError("Pillow is required for steganography_engine") from exc


def _extract_lsb_bits(image: Image.Image, num_bytes: int = 32) -> bytes:
    """Extract a number of bytes from the least significant bits of an image.

    Parameters
    ----------
    image: Image.Image
        The Pillow image to process.  Only the RGB channels are used.
    num_bytes: int
        The maximum number of bytes to extract.  Defaults to 32 bytes.

    Returns
    -------
    bytes
        The raw bytes decoded from the LSBs of the pixel values.
    """
    pixels = list(image.getdata())
    bits = []
    for r, g, b in pixels:
        bits.append(r & 1)
        bits.append(g & 1)
        bits.append(b & 1)
        if len(bits) >= num_bytes * 8:
            break
    out = bytearray()
    for i in range(0, len(bits), 8):
        byte = 0
        for j in range(8):
            if i + j < len(bits):
                byte |= (bits[i + j] << (7 - j))
        out.append(byte)
    return bytes(out)


def scan_file_for_steganography(file_path: str) -> Dict[str, Optional[str]]:
    """Scan an image file for a hidden message.

    This function attempts to open the provided file as an image and
    extract the least significant bits from its pixel data.  If the
    extracted bytes begin with the ASCII sequence ``b'STEGO:'``, the
    remainder of the sequence is interpreted as a UTF‑8 encoded message
    and returned.

    Parameters
    ----------
    file_path: str
        Path to the image file to check.

    Returns
    -------
    dict
        A dictionary with keys ``'file'``, ``'hidden'`` and
        optionally ``'message'``.  ``'hidden'`` is True if a
        message was detected, False otherwise.
    """
    result = {"file": file_path, "hidden": False, "message": None}
    if not os.path.isfile(file_path):
        return result
    try:
        with Image.open(file_path) as img:
            # Ensure we work with RGB values
            img = img.convert('RGB')
            raw = _extract_lsb_bits(img)
            # Look for the STEGO marker
            if raw.startswith(b'STEGO:'):
                try:
                    msg = raw[len(b'STEGO:'):].rstrip(b'\x00').decode('utf-8', errors='replace')
                except Exception:
                    msg = None
                result["hidden"] = True
                result["message"] = msg
    except Exception:
        # If the file cannot be opened as an image, silently ignore
        pass
    return result


class SteganographyEngine:
    """Engine wrapper for the steganography detection functionality.

    Instances of this class can be used in a manner similar to other
    Prometheus engines.  The ``run`` method accepts a mapping with
    ``'file_path'`` pointing to the image to scan.
    """

    def run(self, runtime: Dict[str, str]) -> Dict[str, Optional[str]]:
        file_path = runtime.get('file_path')
        if not file_path:
            return {"error": "Missing file_path"}
        return scan_file_for_steganography(file_path)