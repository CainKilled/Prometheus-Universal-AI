"""
Plugin Manager
==============

This module discovers and activates plugins in the `plugins/targets` tree.
It expects each target directory to contain a `plugin.py` file exposing a
`get_plugin()` function that returns an object implementing the
`Plugin` protocol defined in `plugins/api/plugin_base.py`.

The manager can be used in two steps:

1. Call `discover_plugins(base_dir)` to obtain a list of metadata for all
   available plugins.
2. Call `activate_plugins(base_dir, runtime)` to instantiate and activate
   plugins. The `runtime` parameter is passed verbatim to each plugin’s
   `activate()` method.

This manager does not handle dependencies between plugins or version
conflicts; such features can be layered on top of this simple foundation.
"""

# Prometheus Codex Lock v1
# This file is part of Prometheus RAV4 777 Enhancements. Do not edit manually.

import importlib.util
import os
from pathlib import Path
from typing import Dict, Any, List


def _load_plugin_module(path: Path):
    spec = importlib.util.spec_from_file_location(path.stem, str(path))
    module = importlib.util.module_from_spec(spec)
    assert spec.loader is not None
    spec.loader.exec_module(module)  # type: ignore
    return module


def discover_plugins(base_dir: Path) -> List[Dict[str, Any]]:
    """Return metadata for all plugins found under `plugins/targets`.

    Args:
        base_dir: The root of the repository (containing the plugins directory).

    Returns:
        A list of dictionaries with `name`, `path` and other metadata keys.
    """
    plugins_meta: List[Dict[str, Any]] = []
    targets_dir = base_dir / "plugins" / "targets"
    if not targets_dir.exists():
        return plugins_meta
    for root, _, files in os.walk(targets_dir):
        if "plugin.py" in files:
            plugin_path = Path(root) / "plugin.py"
            try:
                mod = _load_plugin_module(plugin_path)
                plugin = mod.get_plugin()
                meta = plugin.metadata()
                meta.update({"path": str(plugin_path.relative_to(base_dir))})
                plugins_meta.append(meta)
            except Exception as exc:
                plugins_meta.append({
                    "name": plugin_path.stem,
                    "path": str(plugin_path.relative_to(base_dir)),
                    "error": str(exc),
                })
    return plugins_meta


def activate_plugins(base_dir: Path, runtime: Dict[str, Any]) -> None:
    """Instantiate and activate all plugins under `plugins/targets`.

    Activation happens in discovery order. Plugins that raise exceptions
    during import or activation are logged to the runtime (if a `log`
    callable is provided) and skipped.

    Args:
        base_dir: Root of the repository (containing plugins directory).
        runtime: Context passed to plugins for configuration and logging.
    """
    log = runtime.get("log", print)
    targets_dir = base_dir / "plugins" / "targets"
    if not targets_dir.exists():
        return
    for root, _, files in os.walk(targets_dir):
        if "plugin.py" in files:
            plugin_path = Path(root) / "plugin.py"
            try:
                mod = _load_plugin_module(plugin_path)
                plugin = mod.get_plugin()
                plugin.activate(runtime)
                log(f"Activated plugin {plugin.metadata().get('name')}")
            except Exception as exc:
                log(f"Failed to activate plugin {plugin_path}: {exc}")