"""
CI/CD Plugin
============

This plugin orchestrates continuous integration and deployment tasks. It
executes a sequence of shell commands to build, test and deploy
generated projects. Commands are executed sequentially, and their output
is streamed through the provided logger. This makes it easy to hook
into existing CI/CD pipelines or to run local pipelines as part of the
Prometheus ecosystem.

Runtime keys:
    steps (list[str]): A list of shell commands to execute in order.
    cwd (str): Working directory where commands should be run. Defaults
        to the current working directory.

Example usage:
    {
      "steps": [
        "pip install -r requirements.txt",
        "pytest",
        "docker build -t myapp .",
        "docker push myapp"
      ],
      "cwd": "/path/to/project",
      "log": logger
    }

Commands are executed with ``shell=True`` so they can include pipes and
shell operators. Use caution and validate the commands to avoid
injecting untrusted input.
"""

# Prometheus Codex Lock v1
# This file is part of Prometheus RAV4 777 Enhancements. Do not edit manually.

from typing import Dict, Any
from plugins.api.plugin_base import Plugin


class CICDPlugin:
    def metadata(self) -> Dict[str, Any]:
        return {
            "name": "cicd",
            "version": "0.1.0",
            "description": "Local CI/CD pipeline runner",
            "targets": ["cicd", "pipeline"],
        }

    def activate(self, runtime: Dict[str, Any]) -> None:
        """
        Execute a list of CI/CD steps sequentially.

        Each step is a shell command. Output is streamed to the logger.
        If any command returns a non‑zero exit code, subsequent commands
        will still be executed, but the exit code will be logged. Use
        this behaviour to collect as much information as possible from a
        failing pipeline.
        """
        import subprocess
        import os
        logger = runtime.get("log", print)
        steps = runtime.get("steps", [])
        cwd = runtime.get("cwd", os.getcwd())
        if not steps:
            logger("CICDPlugin: no steps provided")
            return
        for step in steps:
            logger(f"Executing CI/CD step: {step}")
            try:
                proc = subprocess.Popen(
                    step,
                    cwd=cwd,
                    shell=True,
                    stdout=subprocess.PIPE,
                    stderr=subprocess.STDOUT,
                    text=True
                )
                for line in proc.stdout:
                    logger(line.rstrip())
                return_code = proc.wait()
                if return_code != 0:
                    logger(f"Step exited with code {return_code}")
            except Exception as exc:
                logger(f"Error executing step '{step}': {exc}")


def get_plugin() -> Plugin:
    return CICDPlugin()  # type: ignore[return-value]