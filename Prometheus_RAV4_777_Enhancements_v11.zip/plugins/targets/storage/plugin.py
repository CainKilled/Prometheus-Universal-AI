"""
Storage Plugin
==============

This plugin provides a scaffold for integrating file and object storage
backends. Examples include local file systems, Amazon S3, Azure Blob
Storage or Google Cloud Storage. Use libraries like `boto3` for AWS or
`azure-storage-blob` for Azure. The plugin should support reading and
writing files used by generated projects, storing backups or artefacts.
"""

# Prometheus Codex Lock v1
# This file is part of Prometheus RAV4 777 Enhancements. Do not edit manually.

from typing import Dict, Any
from plugins.api.plugin_base import Plugin


class StoragePlugin:
    def metadata(self) -> Dict[str, Any]:
        return {
            "name": "storage",
            "version": "0.1.0",
            "description": "File and object storage integration scaffold",
            "targets": ["storage"],
        }

    def activate(self, runtime: Dict[str, Any]) -> None:
        """
        Perform file and object storage operations.

        This plugin supports local file operations out of the box and attempts
        to use `boto3` for Amazon S3 and `azure.storage.blob` for Azure Blob
        Storage if available. Provide the following keys in the runtime
        dictionary:

            provider (str): One of ``local``, ``s3``, or ``azure``. Defaults to
                ``local``.
            action (str): For ``local``: ``read``, ``write``, or ``list``.
                For ``s3`` and ``azure``: ``upload``, ``download``, or ``list``.
            file_path (str): Path to the local file (for read/write/upload/download).
            directory (str): Directory path to list (local only).
            bucket (str): S3 bucket name or Azure container name.
            object_name (str): S3 object key or Azure blob name.
            data (str): Text content to write to a local file.

        Any results or errors are logged via the provided logger.
        """
        import os
        logger = runtime.get("log", print)
        provider = runtime.get("provider", "local").lower()
        action = runtime.get("action")
        try:
            if provider == "local":
                # Local file operations
                if action == "read":
                    file_path = runtime.get("file_path")
                    if not file_path:
                        logger("file_path is required for local read action")
                    else:
                        try:
                            with open(file_path, "r", encoding="utf-8") as f:
                                content = f.read()
                            logger(content)
                        except Exception as e:
                            logger(f"Error reading file {file_path}: {e}")
                elif action == "write":
                    file_path = runtime.get("file_path")
                    data = runtime.get("data", "")
                    if not file_path:
                        logger("file_path is required for local write action")
                    else:
                        try:
                            with open(file_path, "w", encoding="utf-8") as f:
                                f.write(data)
                            logger(f"Wrote data to {file_path}")
                        except Exception as e:
                            logger(f"Error writing file {file_path}: {e}")
                elif action == "list":
                    directory = runtime.get("directory", os.getcwd())
                    try:
                        entries = os.listdir(directory)
                        for entry in entries:
                            logger(entry)
                    except Exception as e:
                        logger(f"Error listing directory {directory}: {e}")
                else:
                    logger(f"Unknown local storage action: {action}")
            elif provider == "s3":
                # S3 operations using boto3
                try:
                    import boto3
                    s3 = boto3.client('s3')
                    if action == "upload":
                        bucket = runtime.get("bucket")
                        file_path = runtime.get("file_path")
                        object_name = runtime.get("object_name") or os.path.basename(file_path or "")
                        if not (bucket and file_path):
                            logger("bucket and file_path are required for s3 upload")
                        else:
                            s3.upload_file(file_path, bucket, object_name)
                            logger(f"Uploaded {file_path} to s3://{bucket}/{object_name}")
                    elif action == "download":
                        bucket = runtime.get("bucket")
                        object_name = runtime.get("object_name")
                        file_path = runtime.get("file_path") or object_name
                        if not (bucket and object_name):
                            logger("bucket and object_name are required for s3 download")
                        else:
                            s3.download_file(bucket, object_name, file_path)
                            logger(f"Downloaded s3://{bucket}/{object_name} to {file_path}")
                    elif action == "list":
                        bucket = runtime.get("bucket")
                        if not bucket:
                            logger("bucket is required for s3 list")
                        else:
                            response = s3.list_objects_v2(Bucket=bucket)
                            contents = response.get('Contents', [])
                            for obj in contents:
                                logger(obj['Key'])
                    else:
                        logger(f"Unknown S3 action: {action}")
                except ImportError:
                    logger("boto3 is not installed. Install it to use S3 storage.")
                except Exception as e:
                    logger(f"S3 error: {e}")
            elif provider == "azure":
                # Azure Blob Storage operations
                try:
                    from azure.storage.blob import BlobServiceClient
                    connection_string = runtime.get("connection_string")
                    if not connection_string:
                        logger("connection_string is required for Azure operations")
                    else:
                        service = BlobServiceClient.from_connection_string(connection_string)
                        if action == "upload":
                            container = runtime.get("bucket")  # container name
                            blob_name = runtime.get("object_name")
                            file_path = runtime.get("file_path")
                            if not (container and blob_name and file_path):
                                logger("bucket (container), object_name and file_path are required for Azure upload")
                            else:
                                blob_client = service.get_blob_client(container=container, blob=blob_name)
                                with open(file_path, "rb") as data:
                                    blob_client.upload_blob(data, overwrite=True)
                                logger(f"Uploaded {file_path} to Azure container {container} as {blob_name}")
                        elif action == "download":
                            container = runtime.get("bucket")
                            blob_name = runtime.get("object_name")
                            file_path = runtime.get("file_path") or blob_name
                            if not (container and blob_name):
                                logger("bucket (container) and object_name are required for Azure download")
                            else:
                                blob_client = service.get_blob_client(container=container, blob=blob_name)
                                with open(file_path, "wb") as f:
                                    data = blob_client.download_blob()
                                    f.write(data.readall())
                                logger(f"Downloaded Azure blob {blob_name} to {file_path}")
                        elif action == "list":
                            container = runtime.get("bucket")
                            if not container:
                                logger("bucket (container) is required for Azure list")
                            else:
                                container_client = service.get_container_client(container)
                                for blob in container_client.list_blobs():
                                    logger(blob.name)
                        else:
                            logger(f"Unknown Azure action: {action}")
                except ImportError:
                    logger("azure-storage-blob is not installed. Install it to use Azure storage.")
                except Exception as e:
                    logger(f"Azure Blob error: {e}")
            else:
                logger(f"Unknown storage provider: {provider}")
        except Exception as exc:
            logger(f"Storage plugin error: {exc}")


def get_plugin() -> Plugin:
    return StoragePlugin()  # type: ignore[return-value]