# iOS Plugin

This directory contains a fully functional plugin for integrating iOS
devices with the Prometheus ecosystem. Unlike Android, Apple does not
provide an ADB‑like interface, but the open‑source
[libimobiledevice](https://libimobiledevice.org/) project offers a suite
of command‑line tools for interacting with iOS devices. The plugin
wraps these tools to perform common tasks such as listing devices,
retrieving device information, installing IPA files and uninstalling
applications.

Useful commands include:

* `idevice_id` – List connected device UDIDs
* `ideviceinfo` – Query device information
* `ideviceinstaller` – Install or uninstall applications (IPA files)
* `idevicesyslog` – View system logs

Install libimobiledevice on your system and ensure its tools (e.g.
`idevice_id`, `ideviceinfo`, `ideviceinstaller`) are on your PATH. The
plugin will automatically locate and invoke them using `subprocess`.
Supported actions:

* `devices` – List connected device UDIDs.
* `info` – Query device information.
* `install` – Install an IPA file (`ipa` runtime key required).
* `uninstall` – Uninstall an application by bundle identifier (`bundle_id` runtime key required).

See the main README for instructions on how to activate plugins and use the CLI.