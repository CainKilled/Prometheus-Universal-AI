"""
Android Studio Plugin
=====================

This plugin scaffolds integration with Android Studio and the Gradle build
system. Use the `gradlew` command included in generated Android projects
to build, run and test apps. The plugin could create a Gradle project
based on Prometheus specs and invoke Android Studio via the `studio`
command to open it. Refer to [Android Studio CLI options](https://developer.android.com/studio/command-line)
for details.
"""

# Prometheus Codex Lock v1
# This file is part of Prometheus RAV4 777 Enhancements. Do not edit manually.

from typing import Dict, Any
from plugins.api.plugin_base import Plugin


class AndroidStudioPlugin:
    def metadata(self) -> Dict[str, Any]:
        """
        Return metadata describing this plugin. The description has been
        updated to reflect that it provides a working integration with
        Android Studio and Gradle rather than just a stub. See
        ``activate`` for supported actions.
        """
        return {
            "name": "android_studio",
            "version": "1.0.0",
            "description": "Integration with Android Studio and Gradle build system",
            "targets": ["ide", "android_studio"],
        }

    def activate(self, runtime: Dict[str, Any]) -> None:
        """
        Perform an action using Android Studio or the Gradle wrapper.

        Supported runtime keys:

            action (str): One of ``build``, ``run``, ``test``, ``clean`` or ``open``.
                Defaults to ``build``.
            project_dir (str): Path to the Android project. Defaults to the
                current working directory.
            gradle_task (str): Custom Gradle task to run. If provided, it
                overrides the default tasks used for ``build``, ``run``, etc.
            log (callable): Optional logger callable. Defaults to ``print``.

        The plugin attempts to locate the Gradle wrapper (``gradlew``) in
        ``project_dir``. If not found, it falls back to the system ``gradle``
        command. To open Android Studio, it looks for a ``studio`` or
        ``android-studio`` executable on the PATH. The return code and
        command output are logged.
        """
        import os
        import subprocess
        import shutil
        logger = runtime.get("log", print)
        action = str(runtime.get("action", "build")).lower()
        project_dir = os.path.abspath(str(runtime.get("project_dir", os.getcwd())))
        gradle_task = runtime.get("gradle_task")
        # Determine gradle wrapper or system gradle
        gradlew_path = os.path.join(project_dir, "gradlew")
        if os.path.isfile(gradlew_path) and os.access(gradlew_path, os.X_OK):
            gradle_cmd = [gradlew_path]
        else:
            gradle_sys = shutil.which("gradle")
            gradle_cmd = [gradle_sys] if gradle_sys else None
        def run_cmd(cmd: list[str]) -> None:
            if cmd[0] is None:
                logger("AndroidStudioPlugin: Gradle executable not found; please install Gradle or include gradlew in project.")
                return
            try:
                logger(f"AndroidStudioPlugin: Running {' '.join(cmd)} in {project_dir}")
                result = subprocess.run(cmd, cwd=project_dir, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True)
                logger(result.stdout.rstrip())
                if result.returncode != 0:
                    logger(f"AndroidStudioPlugin: Command exited with code {result.returncode}")
            except Exception as exc:
                logger(f"AndroidStudioPlugin: Error executing {' '.join(cmd)}: {exc}")
        if action == "open":
            # Launch Android Studio GUI
            studio = shutil.which("studio") or shutil.which("android-studio")
            if studio is None:
                logger("AndroidStudioPlugin: Android Studio executable not found on PATH.")
                return
            try:
                logger(f"AndroidStudioPlugin: Opening project {project_dir} in Android Studio")
                result = subprocess.run([studio, project_dir], stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True)
                logger(result.stdout.rstrip())
                if result.returncode != 0:
                    logger(f"AndroidStudioPlugin: Studio exited with code {result.returncode}")
            except Exception as exc:
                logger(f"AndroidStudioPlugin: Error launching Android Studio: {exc}")
            return
        # Determine gradle task based on action if not explicitly provided
        task_map = {
            "build": "assembleDebug",
            "run": "installDebug",
            "test": "test",
            "clean": "clean",
        }
        task = gradle_task if gradle_task else task_map.get(action)
        if not task:
            logger(f"AndroidStudioPlugin: Unknown action '{action}'. Supported actions: build, run, test, clean, open.")
            return
        if gradle_cmd is None:
            logger("AndroidStudioPlugin: No Gradle executable available.")
            return
        run_cmd(gradle_cmd + [task])


def get_plugin() -> Plugin:
    return AndroidStudioPlugin()  # type: ignore[return-value]