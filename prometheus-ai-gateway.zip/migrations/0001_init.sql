create table if not exists tenants (
  id uuid primary key default gen_random_uuid(),
  name text not null unique,
  plan text not null default 'free',
  created_at timestamptz not null default now()
);

create table if not exists api_keys (
  id uuid primary key default gen_random_uuid(),
  tenant_id uuid not null references tenants(id) on delete cascade,
  key_hash text not null unique,
  label text,
  created_at timestamptz not null default now(),
  last_used_at timestamptz
);

create table if not exists routes (
  id uuid primary key default gen_random_uuid(),
  name text not null,
  path text not null,
  provider text not null,
  model text,
  plugins text[] default '{}',
  config jsonb default '{}'::jsonb,
  created_at timestamptz not null default now()
);

create table if not exists audit_logs (
  id bigserial primary key,
  at timestamptz not null default now(),
  tenant_id uuid,
  route_id uuid,
  event text not null,
  meta jsonb
);
