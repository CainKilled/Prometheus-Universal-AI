import Fastify, { FastifyReply, FastifyRequest } from 'fastify';
import cors from '@fastify/cors';
import { Pool } from 'pg';
import Redis from 'ioredis';
import pino from 'pino';
import { z } from 'zod';
import { authMiddleware, getTenantFromKey } from './modules/auth.js';
import { PolicyEngine } from './modules/policy.js';
import { ChatProviderRouter } from './providers/router.js';
import { pluginChain } from './plugins/chain.js';
import { migrate } from './modules/migrate.js';
import underPressure from '@fastify/under-pressure';

const logger = pino({ level: process.env.NODE_ENV === 'production' ? 'info' : 'debug' });
const app = Fastify({ logger });

await app.register(cors, { origin: true });
await app.register(underPressure, { maxEventLoopDelay: 2000, retryAfter: 50 });

const pool = new Pool({ connectionString: process.env.DATABASE_URL });
const redis = new Redis(process.env.REDIS_URL || "redis://localhost:6379/0");
await migrate(pool);

const policy = new PolicyEngine(pool, redis);
const chatRouter = new ChatProviderRouter();

// Health
app.get('/health', async () => ({ ok: true }));

// Public AI chat proxy
const ChatBody = z.object({
  model: z.string(),
  messages: z.array(z.object({ role: z.string(), content: z.any() })),
  stream: z.boolean().optional(),
  provider: z.string().optional()
});

app.post('/v1/ai/chat', { preHandler: [authMiddleware(pool), policy.enforce(), pluginChain.pre] }, async (req: FastifyRequest, reply: FastifyReply) => {
  const body = ChatBody.parse(req.body);
  const ctx = (req as any).ctx;
  const result = await chatRouter.handle(ctx, body);
  const final = await pluginChain.post(ctx, result);
  reply.send(final);
});

// Admin: simple list routes/keys
app.get('/admin/tenants', async (_req, _reply) => {
  const r = await pool.query("select id, name, plan, created_at from tenants order by created_at desc");
  return r.rows;
});

app.get('/admin/routes', async (_req, _reply) => {
  const r = await pool.query("select * from routes order by created_at desc");
  return r.rows;
});

// 404
app.setNotFoundHandler((_req, reply) => reply.code(404).send({ error: "not_found" }));

const port = Number(process.env.PORT || 8080);
app.listen({ port, host: "0.0.0.0" }).then(() => logger.info({ port }, "Gateway listening"));
