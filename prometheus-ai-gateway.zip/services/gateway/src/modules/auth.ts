import { FastifyRequest } from 'fastify';
import argon2 from 'argon2';
import { Pool } from 'pg';

export function authMiddleware(pool: Pool) {
  return async function (req: FastifyRequest) {
    const key = (req.headers['x-api-key'] || req.headers['authorization']) as string | undefined;
    if (!key) throw new Error("missing_api_key");
    const { rows } = await pool.query("select api_keys.id, api_keys.key_hash, tenants.id as tenant_id, tenants.plan from api_keys join tenants on tenants.id=api_keys.tenant_id");
    let ok = false, tenantId: string | null = null, plan: string | null = null;
    for (const row of rows) {
      if (await argon2.verify(row.key_hash, key)) { ok = true; tenantId = row.tenant_id; plan = row.plan; break; }
    }
    if (!ok || !tenantId) throw new Error("invalid_api_key");
    (req as any).ctx = { tenantId, plan };
  }
}
export async function getTenantFromKey(_pool: Pool, _key: string) { return null; }
