import { Pool } from 'pg';
import fs from 'node:fs';
import path from 'node:path';

export async function migrate(pool: Pool) {
  await pool.query("create extension if not exists pgcrypto");
  const sql = fs.readFileSync(path.join(process.cwd(), '../../migrations/0001_init.sql'), 'utf-8');
  await pool.query(sql);
}
