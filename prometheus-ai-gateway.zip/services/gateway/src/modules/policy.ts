import { Pool } from 'pg';
import Redis from 'ioredis';
import { FastifyRequest } from 'fastify';

export class PolicyEngine {
  constructor(private pool: Pool, private redis: Redis) {}

  enforce() {
    return async (req: FastifyRequest) => {
      const ctx = (req as any).ctx;
      const key = `rl:${ctx.tenantId}:${new Date().toISOString().slice(0,13)}`;
      const used = await this.redis.incr(key);
      if (used === 1) await this.redis.expire(key, 3600);
      const limit = ctx.plan === 'pro' ? 10000 : 1000;
      if (used > limit) {
        const err: any = new Error("rate_limit_exceeded");
        err.statusCode = 429;
        throw err;
      }
    }
  }
}
