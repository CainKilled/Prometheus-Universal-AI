import type { FastifyRequest, FastifyReply } from 'fastify';

export const pluginChain = {
  async pre(req: FastifyRequest) {
    (req as any).ctx = { ...(req as any).ctx, state: {} };
    // Example: set a trace id
    (req as any).ctx.state.traceId = cryptoRandom();
  },
  async post(ctx: any, result: any) {
    // Example: redact tool calls or normalize shape
    return result;
  }
};

function cryptoRandom() {
  return Math.random().toString(36).slice(2) + Math.random().toString(36).slice(2);
}
