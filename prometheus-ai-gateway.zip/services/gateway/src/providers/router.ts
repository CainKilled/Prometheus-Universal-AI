import { FastifyRequest } from 'fastify';
import { callOpenAI } from './vendors/openai.js';
import { callAnthropic } from './vendors/anthropic.js';
import { callMistral } from './vendors/mistral.js';
import { callGoogle } from './vendors/google.js';

export class ChatProviderRouter {
  async handle(ctx: any, body: any) {
    const provider = body.provider || this.inferProvider(body.model);
    if (!provider) throw new Error("unknown_provider");
    switch (provider) {
      case 'openai': return callOpenAI(body);
      case 'anthropic': return callAnthropic(body);
      case 'mistral': return callMistral(body);
      case 'google': return callGoogle(body);
      default: throw new Error("unsupported_provider");
    }
  }
  inferProvider(model: string): string | null {
    if (model.startsWith("gpt") || model.includes("o1") || model.includes("o3")) return "openai";
    if (model.startsWith("claude")) return "anthropic";
    if (model.startsWith("mistral") || model.startsWith("ministral")) return "mistral";
    if (model.startsWith("gemini")) return "google";
    return null;
  }
}
