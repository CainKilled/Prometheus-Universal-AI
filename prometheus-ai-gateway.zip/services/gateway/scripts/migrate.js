import { Pool } from 'pg';
import fs from 'node:fs';
import path from 'node:path';

const pool = new Pool({ connectionString: process.env.DATABASE_URL });
const sql = fs.readFileSync(path.join(process.cwd(), '../../migrations/0001_init.sql'), 'utf-8');

const run = async () => {
  await pool.query("create extension if not exists pgcrypto");
  await pool.query(sql);
  console.log("✅ migrations applied");
  await pool.end();
};

run().catch((e) => { console.error(e); process.exit(1); });
