import crypto from 'node:crypto';
import { Pool } from 'pg';
import argon2 from 'argon2';

const pool = new Pool({ connectionString: process.env.DATABASE_URL });

async function main() {
  // dev helper: create tenant + key
  const name = "dev-tenant";
  const key = crypto.randomBytes(24).toString('base64url');
  const keyHash = await argon2.hash(key);
  const t = await pool.query("insert into tenants(name, plan) values($1,$2) on conflict(name) do update set plan=excluded.plan returning id", [name, "pro"]);
  const tenantId = t.rows[0].id;
  await pool.query("insert into api_keys(tenant_id, key_hash, label) values($1,$2,$3) on conflict do nothing", [tenantId, keyHash, "dev-key"]);
  console.log("Admin/dev key (save it):", key);
  await pool.end();
}
main().catch(e => { console.error(e); process.exit(1); });
