import React from 'react'
import ReactDOM from 'react-dom/client'
import { useEffect, useState } from 'react'

const API_BASE = import.meta.env.VITE_ADMIN_API_BASE || "http://localhost:8080/admin";

function App() {
  const [tenants, setTenants] = useState<any[]>([]);
  const [routes, setRoutes] = useState<any[]>([]);

  useEffect(() => {
    fetch(API_BASE + "/tenants").then(r => r.json()).then(setTenants);
    fetch(API_BASE + "/routes").then(r => r.json()).then(setRoutes);
  }, []);

  return (
    <div style={{ fontFamily: 'system-ui', padding: 16 }}>
      <h1>Prometheus Gateway Admin</h1>

      <h2>Tenants</h2>
      <ul>
        {tenants.map(t => <li key={t.id}>{t.name} — plan: {t.plan}</li>)}
      </ul>

      <h2>Routes</h2>
      <ul>
        {routes.map(r => <li key={r.id}>{r.name} → {r.provider} ({r.path})</li>)}
      </ul>
    </div>
  )
}

ReactDOM.createRoot(document.getElementById('root')!).render(<App />)
