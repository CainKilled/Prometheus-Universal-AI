# Architecture

- **Fastify Gateway** exposes public APIs under `/v1/*` and Admin under `/admin/*`.
- **PostgreSQL** stores tenants, keys, routes, plans, quotas, and audit logs.
- **Redis** backs sliding‑window rate limiting and short‑lived caches.
- **Plugin Engine** allows PRE, POST, and ERROR hooks per route or tenant.
- **Providers** are thin adapters implementing a common interface:
  - `chat()`
  - `embeddings()`
  - `images()`
- **Policy Engine** composes checks: auth → plan → route → plugin chain → provider.

See `docs/PLUGIN_API.md` for plugin development.
