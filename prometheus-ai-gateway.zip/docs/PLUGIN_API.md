# Plugin API (MVP)

```ts
export type HookContext = {
  req: FastifyRequest;
  reply: FastifyReply;
  tenant: Tenant | null;
  route: RouteConfig | null;
  state: Record<string, any>;
};

export interface GatewayPlugin {
  name: string;
  order?: number; // lower = earlier
  pre?(ctx: HookContext): Promise<void>;
  post?(ctx: HookContext, result: any): Promise<any>;
  onError?(ctx: HookContext, err: Error): Promise<void>;
}
```

Register plugins by placing them under `plugins/` and referencing them in DB or env `GATEWAY_PLUGINS=rateLimit,guardrails`.
