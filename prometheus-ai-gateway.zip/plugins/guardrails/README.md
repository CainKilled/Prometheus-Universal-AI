Example guardrails plugin idea:
- Scan prompts/outputs for PII or policy‑restricted content and block or transform.
- Provide redact/allow lists per tenant/route.
