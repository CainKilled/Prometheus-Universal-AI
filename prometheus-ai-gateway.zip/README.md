# Prometheus AI Gateway (Kong‑style, AI‑native)

A lightweight, extensible AI API gateway inspired by Kong. Features:

- **Multi‑tenant API keys** with RBAC and plans (free/pro/enterprise)
- **Policy engine** (rate limits, quotas, routing, guardrails)
- **Pluggable providers** (OpenAI, Anthropic, Google, Mistral, Local via OpenAI‑compat)
- **Observability** (structured logs, request metrics, traces)
- **Edge‑style plugins** (pre, post, and error hooks)
- **Admin API + Web UI** to manage routes, keys, plans, and plugins
- **PostgreSQL** for config/state, **Redis** for ratelimits/queues
- **NATS** event bus (optional) for async tasks & streaming logs

## Quick start

```bash
# 1) Launch stack
docker compose up --build

# 2) Create an admin token (dev only)
docker compose exec gateway node scripts/make-admin.js

# 3) Call the AI proxy (replace YOUR_KEY)
curl -H "x-api-key: YOUR_KEY"      -H "content-type: application/json"      -d '{"model":"gpt-4o-mini","messages":[{"role":"user","content":"Hello!"}]}'      http://localhost:8080/v1/ai/chat
```

### Directory layout
- `services/gateway` — Fastify TypeScript gateway
- `services/admin-ui` — React + Vite admin panel
- `migrations` — SQL schema
- `plugins` — Example gateway plugins
- `docker-compose.yml` — Dev stack
- `docs/` — Architecture & plugin API

**Note:** This is an MVP scaffold, meant to run locally and be productionizable.
