#!/usr/bin/env bash
set -euo pipefail
python -m py_compile "engines/idea_to_app_engine.py"
echo "[OK] idea_to_app_engine.py"