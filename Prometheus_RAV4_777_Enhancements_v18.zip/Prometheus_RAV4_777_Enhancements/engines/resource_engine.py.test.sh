#!/usr/bin/env bash
set -euo pipefail
python -m py_compile "engines/resource_engine.py"
echo "[OK] resource_engine.py"