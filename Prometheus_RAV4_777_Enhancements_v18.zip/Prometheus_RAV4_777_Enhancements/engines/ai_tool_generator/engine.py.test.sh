#!/usr/bin/env bash
# Test script for ai_tool_generator engine

python - <<'PY'
from engines.ai_tool_generator.engine import get_generator

gen = get_generator()
assert gen is not None
print("ai_tool_generator engine OK")
PY