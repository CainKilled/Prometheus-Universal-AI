"""
AI Tool Generator Engine
========================

This module exposes a wrapper around the standalone AI tool generator
implementation provided in ``generator_impl.py``.  The underlying
implementation is copied from the user’s uploaded ``ai_tool_generator.py``
script and can generate Python tools from structured specifications.  This
wrapper provides a stable API for the Prometheus ecosystem while keeping
the heavy implementation separate.  It also documents ownership and
contact information inline for attribution.

Developed and maintained by Adam Henry Nagle. Contact: 603‑384‑8949,
cainkilledabrl@icloud.com, nagleadam75@gmail.com.
"""

# Prometheus Codex Lock v1
# This file is part of Prometheus RAV4 777 Enhancements. Do not edit manually.

from typing import Any, Dict

from .generator_impl import (
    AIToolGenerator,
    ToolSpec,
    ToolType,
    GeneratedTool,
)


def get_generator() -> AIToolGenerator:
    """Return a new instance of :class:`AIToolGenerator`.

    This function is provided as a convenience for consumers of the
    Prometheus engine API.  It simply constructs and returns a new
    ``AIToolGenerator``.  Each call returns a fresh instance; callers
    may choose to cache or reuse the returned object as appropriate.
    """

    return AIToolGenerator()


__all__ = [
    "AIToolGenerator",
    "ToolSpec",
    "ToolType",
    "GeneratedTool",
    "get_generator",
]