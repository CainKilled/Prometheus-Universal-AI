"""
Prometheus HTTP Server
======================

This module exposes a lightweight REST API for interacting with the
Prometheus kernel. It provides endpoints for listing plugins, running
plugins, executing wizard flows and managing templates. The server uses
Python’s built‑in ``http.server`` to avoid external dependencies. It is
intended for development and experimentation; for production use a
full‑featured web framework may be preferred.

Endpoints:

    GET  /plugins
        Return a JSON array of available plugins with their metadata.

    GET  /templates
        Return a JSON array of available template names.

    POST /run/<plugin_name>
        Run the specified plugin with a JSON object in the request body
        containing runtime parameters. Returns the plugin’s output (if
        any) as JSON.

    POST /flow
        Execute a wizard flow. The body must contain a JSON object with
        keys ``flow`` (path to flow file) and optional ``ctx`` (context
        dictionary). Returns status JSON.

Example usage:

    $ python server.py
    Serving on http://localhost:8000
    # In another terminal:
    $ curl -X GET http://localhost:8000/plugins
    $ curl -X POST http://localhost:8000/run/terminal -d '{"command": "echo hi"}' -H 'Content-Type: application/json'
"""

from __future__ import annotations

import json
import os
from http.server import BaseHTTPRequestHandler, HTTPServer
from urllib.parse import urlparse
from typing import Any, Dict

from core.kernel import PrometheusKernel
from templates.template_db import list_templates


class PrometheusHTTPHandler(BaseHTTPRequestHandler):
    # Initialize kernel once for all requests
    _kernel: PrometheusKernel | None = None

    @property
    def kernel(self) -> PrometheusKernel:
        if self.__class__._kernel is None:
            base_dir = os.path.dirname(os.path.abspath(__file__))
            k = PrometheusKernel(base_dir)
            k.load_plugins()
            self.__class__._kernel = k
        return self.__class__._kernel

    def _send_json(self, data: Any, status: int = 200) -> None:
        body = json.dumps(data).encode('utf-8')
        self.send_response(status)
        self.send_header('Content-Type', 'application/json')
        self.send_header('Content-Length', str(len(body)))
        # Simple CORS for development
        self.send_header('Access-Control-Allow-Origin', '*')
        self.end_headers()
        self.wfile.write(body)

    def do_OPTIONS(self) -> None:
        """Handle CORS preflight requests."""
        self.send_response(200)
        self.send_header('Access-Control-Allow-Origin', '*')
        self.send_header('Access-Control-Allow-Methods', 'GET, POST, OPTIONS')
        self.send_header('Access-Control-Allow-Headers', 'Content-Type')
        self.end_headers()

    def do_GET(self) -> None:
        parsed = urlparse(self.path)
        path = parsed.path
        if path == '/plugins':
            plugins = self.kernel.list_plugins()
            # Only expose name and description for brevity
            result = [{'name': p.get('name'), 'description': p.get('description'), 'targets': p.get('targets')} for p in plugins]
            self._send_json(result)
            return
        if path == '/templates':
            names = list_templates()
            self._send_json(names)
            return
        # Unknown path
        self._send_json({'error': f'Path {path} not found'}, status=404)

    def do_POST(self) -> None:
        parsed = urlparse(self.path)
        path = parsed.path
        content_length = int(self.headers.get('Content-Length', 0))
        body = self.rfile.read(content_length) if content_length > 0 else b''
        # Parse JSON body if present
        params: Dict[str, Any] = {}
        if body:
            try:
                params = json.loads(body.decode('utf-8'))
            except json.JSONDecodeError:
                self._send_json({'error': 'Invalid JSON body'}, status=400)
                return
        # /run/<plugin_name>
        if path.startswith('/run/'):
            plugin_name = path.split('/run/', 1)[1]
            try:
                result = self.kernel.run_plugin(plugin_name, params)
                self._send_json({'result': result})
            except KeyError:
                self._send_json({'error': f'Plugin {plugin_name} not found'}, status=404)
            except Exception as exc:
                self._send_json({'error': str(exc)}, status=500)
            return
        # /flow
        if path == '/flow':
            flow_path = params.get('flow')
            ctx = params.get('ctx', {})
            if not flow_path:
                self._send_json({'error': "'flow' key required"}, status=400)
                return
            try:
                self.kernel.run_flow(flow_path, ctx)
                self._send_json({'status': 'ok'})
            except Exception as exc:
                self._send_json({'error': str(exc)}, status=500)
            return
        self._send_json({'error': f'Path {path} not found'}, status=404)


def main() -> None:
    server_address = ('', 8000)
    httpd = HTTPServer(server_address, PrometheusHTTPHandler)
    print(f"Serving on http://localhost:{server_address[1]}")
    try:
        httpd.serve_forever()
    except KeyboardInterrupt:
        print("Shutting down server")
        httpd.server_close()


if __name__ == '__main__':
    main()