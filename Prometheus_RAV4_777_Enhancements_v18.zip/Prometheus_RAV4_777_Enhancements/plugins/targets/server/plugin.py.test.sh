#!/usr/bin/env bash
# Test script for ServerPlugin

python - <<'PY'
import sys
sys.path.append('Prometheus_RAV4_777_Enhancements')
from plugins.targets.server.plugin import get_plugin

plugin = get_plugin()
assert plugin.metadata()['name'] == 'server'
runtime = {"host": "127.0.0.1", "port": 8091, "action": "start", "log": lambda *a: None}
plugin.activate(runtime)
print("server plugin OK")
PY