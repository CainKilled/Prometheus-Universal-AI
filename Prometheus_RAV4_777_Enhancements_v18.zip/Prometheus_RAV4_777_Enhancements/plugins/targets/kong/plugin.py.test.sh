#!/usr/bin/env bash
set -euo pipefail
python -m py_compile "plugins/targets/kong/plugin.py"
echo "kong plugin compiled successfully"
