"""
Jupyter Plugin
==============

This plugin scaffolds integration with Jupyter Notebook environments. It
could generate `.ipynb` files from specifications, launch kernels or
instrument notebooks to call Prometheus APIs. Use the [nbformat](https://nbformat.readthedocs.io/en/latest/)
library to create notebooks programmatically and [jupyter_client](https://jupyter-client.readthedocs.io/)
to manage kernels.

Developed and maintained by Adam Henry Nagle. Contact: 603‑384‑8949,
cainkilledabrl@icloud.com, nagleadam75@gmail.com.
"""

# Prometheus Codex Lock v1
# This file is part of Prometheus RAV4 777 Enhancements. Do not edit manually.

from typing import Dict, Any
from plugins.api.plugin_base import Plugin


class JupyterPlugin:
    def metadata(self) -> Dict[str, Any]:
        return {
            "name": "jupyter",
            "version": "0.1.0",
            "description": "Jupyter Notebook integration scaffold",
            "targets": ["notebook", "jupyter"],
        }

    def activate(self, runtime: Dict[str, Any]) -> None:
        """
        Create or open a Jupyter Notebook and optionally start a Jupyter server.

        Runtime keys:
            notebook_path (str): The file path to the notebook. If the file
                does not exist and ``create`` is True, a simple notebook is
                created using nbformat. Defaults to ``Untitled.ipynb`` in the
                current working directory.
            create (bool): If True and the notebook does not exist, create a
                blank notebook. Defaults to False.
            launch (bool): If True, launch the Jupyter notebook server in
                the directory containing the notebook. Defaults to False.
        """
        import os
        import subprocess
        logger = runtime.get("log", print)
        notebook_path = runtime.get("notebook_path", os.path.join(os.getcwd(), "Untitled.ipynb"))
        create = runtime.get("create", False)
        launch = runtime.get("launch", False)
        # Create notebook if requested
        if create:
            try:
                from nbformat import v4 as nbf
                nb = nbf.new_notebook(cells=[nbf.new_markdown_cell("# New Notebook")])
                import nbformat
                with open(notebook_path, "w", encoding="utf-8") as f:
                    nbformat.write(nb, f)
                logger(f"Created new notebook at {notebook_path}")
            except ImportError:
                logger("nbformat is not installed. Unable to create notebook.")
        # Launch jupyter server if requested
        if launch:
            try:
                logger(f"Launching Jupyter notebook server for {notebook_path}")
                # The '--NotebookApp.open_browser' flag prevents automatic browser launch.
                result = subprocess.Popen([
                    "jupyter", "notebook", notebook_path, "--NotebookApp.open_browser=False"
                ], stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True)
                logger("Jupyter server started. Use Ctrl+C to stop it.")
                # Optionally stream a few lines of output
                for _ in range(5):
                    line = result.stdout.readline()
                    if not line:
                        break
                    logger(line.rstrip())
            except FileNotFoundError:
                logger("Jupyter executable not found. Please install Jupyter.")
            except Exception as exc:
                logger(f"Error launching Jupyter notebook server: {exc}")
        else:
            logger("Jupyter plugin activated. No action taken because launch=False.")


def get_plugin() -> Plugin:
    return JupyterPlugin()  # type: ignore[return-value]