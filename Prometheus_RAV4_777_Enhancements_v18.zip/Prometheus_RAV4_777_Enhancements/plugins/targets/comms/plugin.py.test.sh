#!/usr/bin/env bash
# Test script for CommsPlugin

python - <<'PY'
import sys, json
sys.path.append('Prometheus_RAV4_777_Enhancements')
from plugins.targets.comms.plugin import get_plugin

plugin = get_plugin()
assert plugin.metadata()['name'] == 'comms'
# Internal send/receive
result_msgs = []
def logger(msg):
    result_msgs.append(msg)
runtime = {"type": "internal-send", "message": {"foo": "bar"}, "log": logger}
plugin.activate(runtime)
runtime = {"type": "internal-receive", "log": logger}
plugin.activate(runtime)
assert "{\'foo\': \'bar\'}" in "".join(result_msgs)
# HTTP request (should return error or dict)
runtime = {"type": "http", "url": "http://localhost:1", "payload": {"x": 1}, "log": logger}
plugin.activate(runtime)
print("comms plugin OK")
PY