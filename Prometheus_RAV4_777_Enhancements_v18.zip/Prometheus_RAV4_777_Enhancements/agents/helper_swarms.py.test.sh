#!/usr/bin/env bash
set -euo pipefail
python -m py_compile "agents/helper_swarms.py"
echo "helper_swarms compiled successfully"
