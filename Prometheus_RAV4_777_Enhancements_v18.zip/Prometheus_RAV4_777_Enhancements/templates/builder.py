"""
Template Builder Engine
=======================

This engine consumes templates from the template database and writes
project skeletons to disk. A template is a dictionary mapping file
paths relative to the project root to file content strings. Variables in
the form ``{{var_name}}`` are substituted with values provided in the
call. For example, a template might specify ``"README.md": "# {{project_name}}"``
and calling ``generate_from_template("my_template", "/tmp/myproj", {"project_name": "Hello"})``
would create ``/tmp/myproj/README.md`` containing ``"# Hello"``.
"""

import os
from pathlib import Path
from typing import Dict, Any

from .template_db import get_template


def substitute(content: str, variables: Dict[str, Any]) -> str:
    """Simple templating: replace ``{{var}}`` with the string representation of variables[var]."""
    result = content
    for key, value in variables.items():
        placeholder = f"{{{{{key}}}}}"
        result = result.replace(placeholder, str(value))
    return result


def generate_from_template(name: str, output_dir: str | Path, variables: Dict[str, Any] | None = None) -> None:
    """Generate a project from a template.

    Args:
        name: Name of the template to load.
        output_dir: Directory to write the project into.
        variables: Mapping of variable names to values for substitution.
    """
    tmpl = get_template(name)
    if tmpl is None:
        raise FileNotFoundError(f"Template '{name}' not found")
    output = Path(output_dir)
    output.mkdir(parents=True, exist_ok=True)
    vars_map = variables or {}
    files: Dict[str, str] = tmpl.get("files", {})
    for rel_path, content in files.items():
        out_path = output / rel_path
        out_path.parent.mkdir(parents=True, exist_ok=True)
        rendered = substitute(content, vars_map)
        with out_path.open("w", encoding="utf-8") as f:
            f.write(rendered)


def create_template_from_project(project_dir: str | Path, name: str, overwrite: bool = False) -> None:
    """Create a template from an existing project directory.

    Walks the directory tree and captures file paths and content into a
    template dictionary. Ignores hidden files and directories by default.
    The resulting template is saved to the template database.
    """
    from .template_db import add_template
    project = Path(project_dir)
    if not project.exists() or not project.is_dir():
        raise FileNotFoundError(f"Project directory {project_dir} does not exist")
    files: Dict[str, str] = {}
    for path in project.rglob("*"):
        if path.is_file() and not any(part.startswith(".") for part in path.relative_to(project).parts):
            rel = str(path.relative_to(project))
            with path.open("r", encoding="utf-8", errors="ignore") as f:
                files[rel] = f.read()
    tmpl = {"files": files}
    add_template(name, tmpl, overwrite=overwrite)