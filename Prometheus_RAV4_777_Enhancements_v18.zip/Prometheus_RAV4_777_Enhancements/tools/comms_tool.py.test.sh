#!/bin/bash
# Simple tests for comms_tool
# Developed by Adam Henry Nagle

python - <<'PY'
import sys
sys.path.append('Prometheus_RAV4_777_Enhancements')
from tools.comms_tool import send_internal, receive_internal

# enqueue and dequeue a message
send_internal("hello")
msg = receive_internal()
assert msg == "hello", f"Expected 'hello', got {msg!r}"

print("comms_tool OK")
PY