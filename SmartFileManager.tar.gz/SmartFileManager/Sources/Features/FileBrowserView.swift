import SwiftUI
import UniformTypeIdentifiers

struct FileBrowserView: View {
    @EnvironmentObject var bookmarkStore: BookmarkStore
    @State private var selectedURL: URL?
    @State private var showPicker = false
    @State private var directoryContents: [URL] = []
    @State private var error: String?

    var body: some View {
        NavigationView {
            List {
                Section(header: Text("Bookmarked Folders")) {
                    ForEach(bookmarkStore.bookmarkedURLs, id: \._id) { b in
                        Button(action: { openFolder(b.url) }) {
                            HStack {
                                Image(systemName: "externaldrive")
                                Text(b.url.lastPathComponent)
                                Spacer()
                                if b.requiresSecurityScope { Text("scoped").font(.caption).foregroundColor(.secondary) }
                            }
                        }
                        .contextMenu {
                            Button(role: .destructive) { bookmarkStore.remove(b.url) } label: {
                                Label("Remove Bookmark", systemImage: "trash")
                            }
                        }
                    }
                }
                Section(header: Text("Contents")) {
                    ForEach(directoryContents, id: \.self) { url in
                        HStack {
                            Image(systemName: (try? url.resourceValues(forKeys: [.isDirectoryKey]).isDirectory) == true ? "folder" : "doc.text")
                            Text(url.lastPathComponent)
                            Spacer()
                            Menu {
                                Button("Rename") { quickRename(url) }
                                Button("Duplicate") { tryAction { try FileActions.duplicate(itemAt: url) } }
                                Button("Move to…") { moveTo(url) }
                                Button(role: .destructive) { tryAction { try FileActions.delete(itemAt: url) } } label: { Text("Delete") }
                                Button("Share") { share(url) }
                            } label: {
                                Image(systemName: "ellipsis.circle")
                            }
                        }
                    }
                }
            }
            .navigationTitle("SmartFileManager")
            .toolbar {
                ToolbarItem(placement: .navigationBarTrailing) {
                    Menu {
                        Button { showPicker = true } label: { Label("Add Folder Bookmark", systemImage: "plus") }
                        Button { refresh() } label: { Label("Refresh", systemImage: "arrow.clockwise") }
                    } label: {
                        Image(systemName: "ellipsis.circle")
                    }
                }
            }
            .sheet(isPresented: $showPicker) {
                DocumentPickerView(onPick: { urls in
                    for u in urls {
                        bookmarkStore.add(u)
                    }
                })
            }
            .onAppear { refresh() }
            .alert(item: $error) { e in
                Alert(title: Text("Error"), message: Text(e), dismissButton: .default(Text("OK")))
            }
        }
    }

    func openFolder(_ url: URL) {
        do {
            directoryContents = try FileAccess.listDirectory(url)
        } catch {
            self.error = error.localizedDescription
        }
    }

    func refresh() {
        if let first = bookmarkStore.bookmarkedURLs.first?.url {
            openFolder(first)
        }
    }

    func tryAction(_ action: () throws -> Void) {
        do { try action(); refresh() } catch { self.error = error.localizedDescription }
    }

    func quickRename(_ url: URL) {
        // Simple demo: append " copy" if available
        let newName = url.deletingPathExtension().lastPathComponent + " (renamed)"
        let withExt = newName + (url.pathExtension.isEmpty ? "" : "." + url.pathExtension)
        let newURL = url.deletingLastPathComponent().appendingPathComponent(withExt)
        tryAction { try FileActions.rename(itemAt: url, to: newURL) }
    }

    func moveTo(_ url: URL) {
        // In a real app, present a folder picker; here we'll move into the first bookmark if present
        guard let dest = bookmarkStore.bookmarkedURLs.dropFirst().first?.url else { return }
        tryAction { try FileActions.move(itemAt: url, toFolder: dest) }
    }

    func share(_ url: URL) {
        // Implemented by using ShareLink on iOS 16+
        // This is a placeholder hook for a better share sheet integration.
    }
}

struct DocumentPickerView: UIViewControllerRepresentable {
    var onPick: ([URL]) -> Void

    func makeUIViewController(context: Context) -> UIDocumentPickerViewController {
        let controller = UIDocumentPickerViewController(forOpeningContentTypes: [UTType.folder, UTType.item], asCopy: false)
        controller.allowsMultipleSelection = true
        controller.delegate = context.coordinator
        return controller
    }

    func updateUIViewController(_ uiViewController: UIDocumentPickerViewController, context: Context) {}

    func makeCoordinator() -> Coordinator { Coordinator(onPick: onPick) }

    final class Coordinator: NSObject, UIDocumentPickerDelegate {
        let onPick: ([URL]) -> Void
        init(onPick: @escaping ([URL]) -> Void) { self.onPick = onPick }

        func documentPicker(_ controller: UIDocumentPickerViewController, didPickDocumentsAt urls: [URL]) {
            onPick(urls)
        }
    }
}
