import SwiftUI

struct SettingsView: View {
    var body: some View {
        NavigationView {
            Form {
                Section(header: Text("About")) {
                    LabeledContent("Owner", value: "Adam Nagle")
                    LabeledContent("Contact", value: "cainkilledabel@icloud.com")
                    LabeledContent("Phone", value: "603-384-8949")
                    LabeledContent("Version", value: "1.0.0")
                }
                Section(header: Text("Legal")) {
                    Text("MIT License. © 2025 Adam Nagle")
                }
            }
            .navigationTitle("Settings")
        }
    }
}
