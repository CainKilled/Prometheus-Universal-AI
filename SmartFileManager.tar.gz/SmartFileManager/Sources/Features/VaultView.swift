import SwiftUI

struct VaultView: View {
    @EnvironmentObject var vault: VaultManager
    @State private var message: String = ""

    var body: some View {
        NavigationView {
            List {
                Section("Key") {
                    Button("Generate Key") { vault.generateAndStoreKey() }
                    Button("Delete Key") { vault.deleteKey() }
                    Text(vault.hasKey ? "Key present" : "No key")
                }
                Section("Test") {
                    TextField("Message", text: $message)
                    Button("Encrypt + Decrypt") {
                        do {
                            let cipher = try vault.encrypt(Data(message.utf8))
                            let plain = try vault.decrypt(cipher)
                            message = String(decoding: plain, as: UTF8.self)
                        } catch {
                            message = "⚠️ " + error.localizedDescription
                        }
                    }
                }
            }
            .navigationTitle("Vault")
        }
    }
}
