import SwiftUI

struct TagsView: View {
    @EnvironmentObject var tagStore: TagStore

    @State private var newTag = ""

    var body: some View {
        NavigationView {
            List {
                ForEach(tagStore.tags, id: \.self) { tag in
                    HStack {
                        Text(tag)
                        Spacer()
                        Button(role: .destructive) { tagStore.remove(tag) } label: { Image(systemName: "trash") }
                    }
                }
                HStack {
                    TextField("New tag", text: $newTag)
                    Button("Add") {
                        let t = newTag.trimmingCharacters(in: .whitespacesAndNewlines)
                        guard !t.isEmpty else { return }
                        tagStore.add(t); newTag = ""
                    }
                }
            }
            .navigationTitle("Tags")
        }
    }
}
