import SwiftUI

struct RootView: View {
    var body: some View {
        TabView {
            FileBrowserView()
                .tabItem { Label("Browse", systemImage: "folder") }
            VaultView()
                .tabItem { Label("Vault", systemImage: "lock.square") }
            TagsView()
                .tabItem { Label("Tags", systemImage: "tag") }
            SettingsView()
                .tabItem { Label("Settings", systemImage: "gearshape") }
        }
    }
}
