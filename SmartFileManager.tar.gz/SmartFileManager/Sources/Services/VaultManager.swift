import Foundation
import CryptoKit

final class VaultManager: ObservableObject {
    static let shared = VaultManager()
    private let keyKey = "vault.symkey.v1"
    @Published var hasKey: Bool = false

    private init() {
        hasKey = (KeychainHelper.get(key: keyKey) != nil)
    }

    func generateAndStoreKey() {
        let key = SymmetricKey(size: .bits256)
        let data = key.withUnsafeBytes { Data(Array($0)) }
        if KeychainHelper.set(key: keyKey, data: data) {
            hasKey = true
        }
    }

    func deleteKey() {
        KeychainHelper.delete(key: keyKey)
        hasKey = false
    }

    private func loadKey() throws -> SymmetricKey {
        guard let data = KeychainHelper.get(key: keyKey) else {
            throw NSError(domain: "Vault", code: 1, userInfo: [NSLocalizedDescriptionKey: "No key in Keychain"])
        }
        return SymmetricKey(data: data)
    }

    func encrypt(_ data: Data) throws -> Data {
        let key = try loadKey()
        let sealed = try AES.GCM.seal(data, using: key)
        return (sealed.nonce.data + sealed.ciphertext + (sealed.tag))
    }

    func decrypt(_ blob: Data) throws -> Data {
        let key = try loadKey()
        // Split blob: 12b nonce, (len-28) ciphertext, 16b tag
        guard blob.count > 28 else { throw NSError(domain: "Vault", code: 2, userInfo: [NSLocalizedDescriptionKey: "Cipher too short"]) }
        let nonce = try AES.GCM.Nonce(data: blob.prefix(12))
        let tag = blob.suffix(16)
        let ciphertext = blob.dropFirst(12).dropLast(16)
        let sealed = try AES.GCM.SealedBox(nonce: nonce, ciphertext: ciphertext, tag: tag)
        return try AES.GCM.open(sealed, using: key)
    }
}

private extension AES.GCM.Nonce {
    var data: Data { withUnsafeBytes { Data(Array($0)) } }
}
