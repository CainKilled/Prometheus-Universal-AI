import Foundation

final class TagStore: ObservableObject {
    @Published var tags: [String] = []
    private let url: URL

    init() {
        let appSupport = FileManager.default.urls(for: .applicationSupportDirectory, in: .userDomainMask).first!
        self.url = appSupport.appendingPathComponent("tags.json")
        load()
    }

    func add(_ tag: String) {
        if !tags.contains(where: { $0.caseInsensitiveCompare(tag) == .orderedSame }) {
            tags.append(tag)
            save()
        }
    }

    func remove(_ tag: String) {
        tags.removeAll { $0.caseInsensitiveCompare(tag) == .orderedSame }
        save()
    }

    private func load() {
        if let data = try? Data(contentsOf: url), let arr = try? JSONDecoder().decode([String].self, from: data) {
            tags = arr
        }
    }

    private func save() {
        try? FileManager.default.createDirectory(at: url.deletingLastPathComponent(), withIntermediateDirectories: True, attributes: nil)
        if let data = try? JSONEncoder().encode(tags) {
            try? data.write(to: url)
        }
    }
}
