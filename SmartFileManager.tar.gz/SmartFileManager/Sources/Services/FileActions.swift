import Foundation

enum FileActions {
    static func rename(itemAt url: URL, to newURL: URL) throws {
        try FileManager.default.moveItem(at: url, to: newURL)
    }

    static func duplicate(itemAt url: URL) throws {
        let dest = url.deletingLastPathComponent().appendingPathComponent(url.deletingPathExtension().lastPathComponent + " copy").appendingPathExtension(url.pathExtension)
        try FileManager.default.copyItem(at: url, to: dest)
    }

    static func move(itemAt url: URL, toFolder folder: URL) throws {
        let dest = folder.appendingPathComponent(url.lastPathComponent)
        try FileManager.default.moveItem(at: url, to: dest)
    }

    static func delete(itemAt url: URL) throws {
        try FileManager.default.removeItem(at: url)
    }
}
