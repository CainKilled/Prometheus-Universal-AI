import Foundation

enum FileAccess {
    static func listDirectory(_ url: URL) throws -> [URL] {
        var isDir: ObjCBool = false
        guard FileManager.default.fileExists(atPath: url.path, isDirectory: &isDir), isDir.boolValue else {
            throw NSError(domain: "SmartFileManager", code: 1, userInfo: [NSLocalizedDescriptionKey: "Not a directory"])
        }
        let contents = try FileManager.default.contentsOfDirectory(at: url, includingPropertiesForKeys: [.isDirectoryKey], options: [.skipsHiddenFiles])
        return contents.sorted { $0.lastPathComponent.lowercased() < $1.lastPathComponent.lowercased() }
    }
}
