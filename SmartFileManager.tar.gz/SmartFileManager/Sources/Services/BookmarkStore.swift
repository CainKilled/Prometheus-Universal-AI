import Foundation
import SwiftUI

struct BookmarkEntry {
    let url: URL
    let data: Data
    let requiresSecurityScope: Bool

    var _id: String { url.absoluteString }
}

final class BookmarkStore: ObservableObject {
    @Published var bookmarkedURLs: [BookmarkEntry] = []
    private let key = "bookmarks.v1"

    init() {
        load()
    }

    func add(_ url: URL) {
        do {
            let scoped = url.startAccessingSecurityScopedResource()
            defer { if scoped { url.stopAccessingSecurityScopedResource() } }
            let data = try url.bookmarkData(options: [.withSecurityScope], includingResourceValuesForKeys: nil, relativeTo: nil)
            var store = UserDefaults.standard.data(forKey: key).flatMap { try? JSONDecoder().decode([Data].self, from: $0) } ?? []
            store.append(data)
            let encoded = try JSONEncoder().encode(store)
            UserDefaults.standard.set(encoded, forKey: key)
            load()
        } catch {
            print("Bookmark add error: \(error)")
        }
    }

    func remove(_ url: URL) {
        let current = UserDefaults.standard.data(forKey: key).flatMap { try? JSONDecoder().decode([Data].self, from: $0) } ?? []
        let filtered = current.filter { data in
            var isStale = false
            if let resolved = try? URL(resolvingBookmarkData: data, options: [.withSecurityScope], relativeTo: nil, bookmarkDataIsStale: &isStale) {
                return resolved != url
            }
            return true
        }
        if let encoded = try? JSONEncoder().encode(filtered) {
            UserDefaults.standard.set(encoded, forKey: key)
        }
        load()
    }

    func load() {
        var results: [BookmarkEntry] = []
        let store = UserDefaults.standard.data(forKey: key).flatMap { try? JSONDecoder().decode([Data].self, from: $0) } ?? []
        for data in store {
            var isStale = false
            if let url = try? URL(resolvingBookmarkData: data, options: [.withSecurityScope], relativeTo: nil, bookmarkDataIsStale: &isStale) {
                results.append(BookmarkEntry(url: url, data: data, requiresSecurityScope: true))
            }
        }
        self.bookmarkedURLs = results
    }
}
