import SwiftUI

@main
struct SmartFileManagerApp: App {
    @StateObject private var bookmarkStore = BookmarkStore()
    @StateObject private var tagStore = TagStore()
    @StateObject private var vault = VaultManager.shared

    var body: some Scene {
        WindowGroup {
            RootView()
                .environmentObject(bookmarkStore)
                .environmentObject(tagStore)
                .environmentObject(vault)
        }
    }
}
