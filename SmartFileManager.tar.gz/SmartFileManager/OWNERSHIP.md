# OWNERSHIP.md

**Project:** SmartFileManager (iOS)
**Owner/Developer/Engineer:** Adam Nagle
**Contact:** 603-384-8949 · cainkilledabel@icloud.com

This project and all derivative works are authored for and owned by Adam Nagle.
All rights reserved, except as explicitly granted via the chosen license.
