#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
NAME="SmartFileManager-src-$(date +%Y%m%d-%H%M%S).tar.gz"
tar -czf "$NAME" .
echo "Created $NAME"
