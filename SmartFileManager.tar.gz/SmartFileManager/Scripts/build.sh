#!/usr/bin/env bash
set -euo pipefail
SCHEME="SmartFileManager"
DESTINATION="generic/platform=iOS"
xcodebuild -scheme "$SCHEME" -destination "$DESTINATION" -configuration Release build
