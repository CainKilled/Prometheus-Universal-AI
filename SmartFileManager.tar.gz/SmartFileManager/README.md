# SmartFileManager (iOS, SwiftUI)

**Owner/Developer/Engineer:** Adam Nagle · 603-384-8949 · cainkilledabel@icloud.com

A *platinum-grade*, privacy-first file manager for iOS with:
- Security-scoped bookmark-based folder access (via Files picker)
- Fast browsing with inline quick actions (rename, move, duplicate, delete, share)
- Local tag system (JSON store) with multi-select and batch operations
- Built-in **Secure Vault** using CryptoKit (AES.GCM) with a key stored in the Keychain
- Minimal **Privacy Manifest** and Info.plist configuration
- Reproducible build via **XcodeGen** (`project.yml`)

> Package contains source-only. Generate Xcode project with XcodeGen, open in Xcode, set your Team in Signing, and build/archive.
> For sideload, export an `.ipa` (e.g., with AltStore or Sideloadly).

## Quick Start

```bash
# 1) Install XcodeGen (one-time)
brew install xcodegen

# 2) Generate Xcode project
./Scripts/gen.sh

# 3) Open in Xcode
open SmartFileManager.xcodeproj

# 4) In Xcode: set Signing team, then run on device or Archive → Distribute (Developer ID / Ad Hoc)
```

## Sideload Notes

- iOS requires apps to be signed. To sideload, export an IPA via Xcode and install with **AltStore** or **Sideloadly**.
- A raw `.tar.gz` cannot be installed directly on iOS devices.

## Ownership & Licensing

All code and artifacts are produced for and owned by **Adam Nagle** with the identifiers above.
See `OWNERSHIP.md` and `LICENSE`.
