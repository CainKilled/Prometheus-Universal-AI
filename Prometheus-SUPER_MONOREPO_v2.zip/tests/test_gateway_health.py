# This is a lightweight import test; full service test runs in container
def test_import_gateway():
    import importlib
    m = importlib.import_module("services.gateway.prometheus_ai_gateway.main")
    assert hasattr(m, "app")
