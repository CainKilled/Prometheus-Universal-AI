import unittest
from runtime.event_bus import EventBus

class TestBus(unittest.TestCase):
    def test_publish_subscribe(self):
        bus = EventBus()
        seen = []
        bus.subscribe("x", lambda p: seen.append(p))
        bus.publish("x", {"a":1})
        self.assertEqual(seen, [{"a":1}])

if __name__ == "__main__":
    unittest.main()
