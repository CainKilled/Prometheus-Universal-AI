import json
from tools.policy.policy_engine import enforce_policy

def test_enforce_policy_runs():
    res = enforce_policy(".")
    assert "ok" in res
