import subprocess, sys

def test_cli_health():
    proc = subprocess.run([sys.executable, "prometheus_cli.py", "health"], capture_output=True, text=True)
    assert proc.returncode == 0
    assert "status" in proc.stdout
