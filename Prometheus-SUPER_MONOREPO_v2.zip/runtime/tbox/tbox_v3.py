import subprocess, json, sys
from pathlib import Path

class TBOXRunner:
    def __init__(self, root: str = "."):
        self.root = Path(root)

    def run_cmd(self, cmd: str) -> dict:
        try:
            proc = subprocess.run(cmd, shell=True, capture_output=True, text=True, cwd=self.root)
            return {"cmd": cmd, "code": proc.returncode, "stdout": proc.stdout, "stderr": proc.stderr}
        except Exception as e:
            return {"cmd": cmd, "code": -1, "stdout": "", "stderr": str(e)}

    def run_all(self) -> dict:
        steps = [
            "python tools/policy/placeholder_gate.py --root . --out policy_placeholder_report.json",
            "python tools/sbom/sbom_build.py --root . --out sbom.json",
            "python runtime/storage/cloud_adapters.py --check",
        ]
        results = [self.run_cmd(s) for s in steps]
        return {"results": results, "ok": all(r["code"] == 0 for r in results)}

if __name__ == "__main__":
    runner = TBOXRunner(".")
    if "--run-all" in sys.argv:
        res = runner.run_all()
        print(json.dumps(res, indent=2))
        sys.exit(0 if res["ok"] else 3)
