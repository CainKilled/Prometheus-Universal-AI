from typing import Callable, Dict, List, Any
import threading

class EventBus:
    def __init__(self):
        self._subs: Dict[str, List[Callable[[Any], None]]] = {}
        self._lock = threading.RLock()
    def subscribe(self, topic, handler):
        with self._lock:
            self._subs.setdefault(topic, []).append(handler)
    def publish(self, topic, payload):
        with self._lock:
            handlers = list(self._subs.get(topic, []))
        for h in handlers:
            try:
                h(payload)
            except Exception as e:
                print(f"[event_bus] handler error on {topic}: {e}")
