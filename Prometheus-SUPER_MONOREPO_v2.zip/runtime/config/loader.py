import os, json, re
from pathlib import Path
from typing import Dict, Any

def _naive_yaml_to_json(text: str) -> Any:
    # minimal YAML loader: supports dicts, lists, scalars (string/number/bool)
    # This is intentionally simple to avoid external deps.
    import ast
    # Replace ':' with ':' in a Python-dict-like manner; crude but works for simple YAML.
    # If parsing fails, return {}
    try:
        lines = []
        indent_stack = [0]
        for raw in text.splitlines():
            if not raw.strip() or raw.strip().startswith("#"):
                continue
            indent = len(raw) - len(raw.lstrip(" "))
            key_val = raw.strip()
            # Convert "key: value" -> "'key': value"
            if re.match(r"^[^\-][^:]*:\s*(.*)$", key_val):
                k, v = key_val.split(":", 1)
                k = k.strip()
                v = v.strip()
                if v == "":
                    # start of nested dict
                    lines.append(" " * indent + f"'{k}': " + "{")
                    indent_stack.append(indent + 2)
                else:
                    # basic scalar or list start
                    if v.lower() in ("true","false","null"):
                        v2 = {"true":"True","false":"False","null":"None"}[v.lower()]
                    else:
                        try:
                            float(v); v2 = v
                        except:
                            v2 = repr(v)
                    lines.append(" " * indent + f"'{k}': {v2},")
            elif key_val.startswith("- "):
                # list item
                v = key_val[2:].strip()
                if v.lower() in ("true","false","null"):
                    v2 = {"true":"True","false":"False","null":"None"}[v.lower()]
                else:
                    try:
                        float(v); v2 = v
                    except:
                        v2 = repr(v)
                lines.append(" " * indent + f"{v2},")
            elif key_val == "}":
                lines.append(key_val)
            else:
                # fallback ignore
                pass
        # Wrap as dict if not already
        py_text = "{\n" + "\n".join(lines) + "\n}"
        py_text = re.sub(r",\s*([}\]])", r"\1", py_text)  # trailing commas
        return ast.literal_eval(py_text)
    except Exception:
        return {}

def load_config_dir(cfg_dir: str = "config") -> Dict[str, Any]:
    root = Path(cfg_dir)
    merged: Dict[str, Any] = {}
    if not root.exists():
        return merged
    for p in sorted(root.glob("**/*")):
        if p.is_file():
            try:
                if p.suffix.lower() == ".json":
                    data = json.loads(p.read_text())
                elif p.suffix.lower() in (".yaml", ".yml"):
                    data = _naive_yaml_to_json(p.read_text())
                else:
                    continue
                # shallow merge by filename stem
                merged[p.stem] = data
            except Exception:
                merged[p.stem] = {"_error": f"failed_to_parse:{p.name}"}
    return merged
