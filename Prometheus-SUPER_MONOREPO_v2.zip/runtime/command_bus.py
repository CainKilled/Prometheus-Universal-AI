from typing import Callable, Dict, Any, List

class CommandBus:
    def __init__(self):
        self._cmds: Dict[str, Callable[..., Any]] = {}
        self._pre: List[Callable[[str, dict], None]] = []
        self._post: List[Callable[[str, dict, Any], None]] = []
    def register(self, name, fn):
        if name in self._cmds:
            raise ValueError(f"Command '{name}' already registered")
        self._cmds[name] = fn
        return fn
    def dispatch(self, name, **kwargs):
        if name not in self._cmds:
            raise KeyError(f"Unknown command: {name}")
        for h in self._pre:
            h(name, kwargs)
        res = self._cmds[name](**kwargs)
        for h in self._post:
            h(name, kwargs, res)
        return res
