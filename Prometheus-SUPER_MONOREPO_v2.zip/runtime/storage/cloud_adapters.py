#!/usr/bin/env python3
"""
runtime.storage.cloud_adapters
Adapter registry and a '--check' mode to validate environment/credentials.
"""
import os, sys, json
from pathlib import Path

ADAPTERS = {
    "aws": {"env": ["AWS_ACCESS_KEY_ID","AWS_SECRET_ACCESS_KEY"], "opt": ["AWS_DEFAULT_REGION"]},
    "gcp": {"env": ["GOOGLE_APPLICATION_CREDENTIALS"], "opt": []},
    "azure": {"env": ["AZURE_STORAGE_CONNECTION_STRING"], "opt": []},
}

def check():
    report = {"adapters": {}, "ok": True}
    for name, cfg in ADAPTERS.items():
        missing = [e for e in cfg["env"] if not os.getenv(e)]
        entry = {"required": cfg["env"], "optional": cfg["opt"], "missing": missing, "status": "green" if not missing else "red"}
        if missing:
            report["ok"] = False
        report["adapters"][name] = entry
    print(json.dumps(report, indent=2))
    return 0 if report["ok"] else 3

def main():
    if "--check" in sys.argv:
        sys.exit(check())
    print("Use '--check' to validate environment for cloud adapters.")

if __name__ == "__main__":
    main()
