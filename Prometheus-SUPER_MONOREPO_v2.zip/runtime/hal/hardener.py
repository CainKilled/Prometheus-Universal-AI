import os, re, stat, json
from pathlib import Path
from typing import Dict, List

SHEBANG_RE = re.compile(r"^#!")

class HALHardener:
    def __init__(self, root: str = "."):
        self.root = Path(root)

    def _is_exec_script(self, p: Path) -> bool:
        try:
            with p.open("r", errors="ignore") as f:
                head = f.read(128)
            return bool(SHEBANG_RE.match(head))
        except Exception:
            return False

    def enforce_permissions(self) -> Dict:
        fixed = []
        for r, _, files in os.walk(self.root):
            if "_autogen_" in r:
                continue
            for name in files:
                p = Path(r) / name
                try:
                    st = p.stat()
                    # Remove world-writable
                    if st.st_mode & stat.S_IWOTH:
                        new_mode = st.st_mode & ~stat.S_IWOTH
                        os.chmod(p, new_mode)
                        fixed.append(str(p.relative_to(self.root)) + ": -world-writable")
                    # Ensure exec bit for shebang scripts
                    if self._is_exec_script(p) and not (st.st_mode & stat.S_IXUSR):
                        os.chmod(p, st.st_mode | stat.S_IXUSR)
                        fixed.append(str(p.relative_to(self.root)) + ": +exec")
                except Exception:
                    continue
        return {"fixed": fixed}

    def scan_secrets(self) -> Dict:
        patterns = {
            "aws": re.compile(r"AKIA[0-9A-Z]{16}"),
            "generic_hex": re.compile(r"\b[a-f0-9]{32,64}\b"),
            "pem_key": re.compile(r"-----BEGIN (RSA|EC|OPENSSH) PRIVATE KEY-----"),
        }
        matches = []
        for r, _, files in os.walk(self.root):
            if "_autogen_" in r:
                continue
            for name in files:
                p = Path(r) / name
                if p.suffix.lower() in {".py",".json",".yaml",".yml",".sh",".env",".ini",".cfg",".txt",".md"}:
                    try:
                        content = p.read_text(errors="ignore")
                    except Exception:
                        continue
                    for label, rx in patterns.items():
                        for m in rx.finditer(content):
                            matches.append({"file": str(p.relative_to(self.root)), "type": label, "span": [m.start(), m.end()]})
        return {"findings": matches}

    def apply(self) -> Dict:
        perms = self.enforce_permissions()
        secrets = self.scan_secrets()
        return {"permissions": perms, "secrets": secrets}
