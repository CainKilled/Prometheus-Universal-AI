from ..event_bus import EventBus
from ..command_bus import CommandBus
import os, time
bus = EventBus()
cmd = CommandBus()
@cmd.register('start')
def start(services='all', dry_run=False):
    os.environ.setdefault('PROMETHEUS_MODE','runtime')
    bus.publish('lifecycle:starting', {'services': services, 'ts': time.time(), 'dry_run': dry_run})
    started = [] if dry_run else ['hal','tbox','vaulttime','control_nexus']
    bus.publish('lifecycle:started', {'services': started, 'ts': time.time(), 'dry_run': dry_run})
    return {'ok': True, 'started': started, 'dry_run': dry_run}
