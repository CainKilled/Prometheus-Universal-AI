from ..event_bus import EventBus
from ..command_bus import CommandBus
bus = EventBus()
cmd = CommandBus()
@cmd.register('health')
def health():
    return {'ok': True, 'components': ['event_bus','command_bus'], 'status':'green'}
