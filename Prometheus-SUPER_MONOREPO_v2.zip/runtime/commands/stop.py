from ..event_bus import EventBus
from ..command_bus import CommandBus
import time
bus = EventBus()
cmd = CommandBus()
@cmd.register('stop')
def stop(services='all', force=False):
    bus.publish('lifecycle:stopping', {'services': services, 'ts': time.time(), 'force': force})
    stopped = ['hal','tbox','vaulttime','control_nexus']
    bus.publish('lifecycle:stopped', {'services': stopped, 'ts': time.time(), 'force': force})
    return {'ok': True, 'stopped': stopped, 'force': force}
