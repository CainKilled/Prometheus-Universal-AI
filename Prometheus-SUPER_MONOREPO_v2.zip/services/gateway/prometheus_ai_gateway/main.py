from fastapi import FastAPI, Request, HTTPException
from typing import Dict
import os

API_KEY = os.getenv("PROMETHEUS_API_KEY", "dev-" + "x"*16)
app = FastAPI(title="Prometheus AI Gateway")

@app.middleware("http")
async def auth(request: Request, call_next):
    key = request.headers.get("x-api-key")
    if key != API_KEY and request.url.path not in ("/health", "/"):
        raise HTTPException(status_code=401, detail="Invalid API key")
    return await call_next(request)

@app.get("/")
def root():
    return {"service": "Prometheus AI Gateway", "status": "online"}

@app.get("/health")
def health():
    return {"ok": True}

@app.post("/route")
async def route(payload: Dict):
    # Minimal router stub: echoes route and policy checks
    return {"ok": True, "routed": payload, "policy": "default_allow_local"}
