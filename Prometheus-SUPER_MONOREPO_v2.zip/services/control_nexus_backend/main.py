from fastapi import FastAPI
from runtime.commands.health import health as health_cmd
from runtime.commands.start import start as start_cmd
from runtime.commands.stop import stop as stop_cmd

app = FastAPI(title="Control Nexus Backend")

@app.get("/health")
def health():
    return health_cmd()

@app.post("/start")
def start():
    return start_cmd(services="all", dry_run=False)

@app.post("/stop")
def stop():
    return stop_cmd(services="all", force=False)
