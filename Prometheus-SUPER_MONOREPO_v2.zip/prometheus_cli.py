import argparse
from runtime.commands.start import cmd as start_cmd
from runtime.commands.stop import cmd as stop_cmd
from runtime.commands.health import cmd as health_cmd

def main():
    p = argparse.ArgumentParser(description='Prometheus Runtime CLI')
    sub = p.add_subparsers(dest='command', required=True)
    ps = sub.add_parser('start'); ps.add_argument('--services', default='all'); ps.add_argument('--dry-run', action='store_true')
    pt = sub.add_parser('stop'); pt.add_argument('--services', default='all'); pt.add_argument('--force', action='store_true')
    sub.add_parser('health')
    a = p.parse_args()
    if a.command=='start': print(start_cmd.dispatch('start', services=a.services, dry_run=a.dry_run))
    elif a.command=='stop': print(stop_cmd.dispatch('stop', services=a.services, force=a.force))
    elif a.command=='health': print(health_cmd.dispatch('health'))
if __name__=='__main__': main()
