import random, string
def generate(length=64):
    alphabet = string.ascii_letters + string.digits
    return ''.join(random.choice(alphabet) for _ in range(length))
if __name__ == "__main__":
    print(generate())
