import json
from pathlib import Path

TEMPLATE = "def {name}():\n    \"\"\"Generated function {name} that returns a constant for testing.\"\"\"\n    return {value}\n"

class NAGL777Wizard:
    def __init__(self, root: str = "."):
        self.root = Path(root)

    def generate_module(self, module: str, symbol: str, value: int = 777):
        pkg = self.root / "generated" / module
        pkg.mkdir(parents=True, exist_ok=True)
        (pkg / "__init__.py").write_text("# Generated module\n")
        (pkg / f"{symbol}.py").write_text(TEMPLATE.format(name=symbol, value=value))
        return str(pkg)

    def run(self, module="nagl", symbol="blessing"):
        return {"created": self.generate_module(module, symbol)}

if __name__ == "__main__":
    print(json.dumps(NAGL777Wizard().run(), indent=2))
