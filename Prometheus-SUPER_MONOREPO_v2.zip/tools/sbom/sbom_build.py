#!/usr/bin/env python3
"""
tools.sbom.sbom_build
Generate a lightweight SBOM (files + sha256) for the repo.
"""
import os, sys, hashlib, json
from pathlib import Path
from datetime import datetime

def sha256_file(p: Path) -> str:
    h = hashlib.sha256()
    with p.open("rb") as f:
        for chunk in iter(lambda: f.read(65536), b""):
            h.update(chunk)
    return h.hexdigest()

def main(root: str = ".",
         out: str = "sbom.json",
         include_exts = (".py",".sh",".ts",".js",".json",".yaml",".yml",".toml",".md",".txt",".html",".css",".scss",".sql",".ini",".cfg",".env",".dockerfile")):
    rootp = Path(root).resolve()
    items = []
    for r, d, files in os.walk(rootp):
        if "_autogen_" in r:
            continue
        for name in files:
            p = Path(r) / name
            if name == "Dockerfile" or p.suffix.lower() in include_exts:
                try:
                    digest = sha256_file(p)
                except Exception as e:
                    digest = f"error:{e}"
                items.append({
                    "path": str(p.relative_to(rootp)),
                    "sha256": digest,
                    "size": p.stat().st_size
                })
    sbom = {
        "generated_at": datetime.utcnow().isoformat() + "Z",
        "root": str(rootp),
        "count": len(items),
        "items": items
    }
    Path(out).write_text(json.dumps(sbom, indent=2))
    print(f"SBOM written to {out} ({len(items)} items)")

if __name__ == "__main__":
    import argparse
    ap = argparse.ArgumentParser()
    ap.add_argument("--root", default=".")
    ap.add_argument("--out", default="sbom.json")
    args = ap.parse_args()
    main(args.root, args.out)
