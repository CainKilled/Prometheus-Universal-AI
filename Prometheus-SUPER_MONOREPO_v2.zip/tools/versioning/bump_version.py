import json, sys
from pathlib import Path
def bump(part: str):
    vpath = Path("version.json")
    data = json.loads(vpath.read_text())
    major, minor, patch = [int(x) for x in data["version"].split(".")]
    if part == "major":
        major, minor, patch = major+1, 0, 0
    elif part == "minor":
        minor, patch = minor+1, 0
    else:
        patch += 1
    data["version"] = f"{major}.{minor}.{patch}"
    vpath.write_text(json.dumps(data, indent=2))
    print(data["version"])
if __name__ == "__main__":
    part = sys.argv[1] if len(sys.argv) > 1 else "patch"
    bump(part)
