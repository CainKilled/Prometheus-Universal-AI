import os, json, hashlib, hmac
from pathlib import Path
from datetime import datetime

class VaultTimeSigner:
    def __init__(self, identity: str = "Adam"):
        self.identity = identity

    def sign(self, message: str = "Prometheus Artifact", secret_env="VAULTTIME_SECRET") -> dict:
        ts = datetime.utcnow().isoformat() + "Z"
        secret = os.getenv(secret_env, "")
        base = f"{self.identity}|{message}|{ts}".encode()
        digest = hashlib.sha256(base).hexdigest()
        mac = hmac.new(secret.encode(), base, hashlib.sha256).hexdigest() if secret else None
        payload = {"identity": self.identity, "message": message, "timestamp": ts, "sha256": digest, "hmac": mac, "secret_env": secret_env if secret else None}
        Path("VAULTTIME_SIGNATURE.json").write_text(json.dumps(payload, indent=2))
        return payload

if __name__ == "__main__":
    print(json.dumps(VaultTimeSigner().sign(), indent=2))
