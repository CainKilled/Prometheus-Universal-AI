import compileall, sys
def main(root: str = "."):
    ok = compileall.compile_dir(root, force=True, quiet=1)
    print("bytecode_compiled=", bool(ok))
    return 0 if ok else 2
if __name__ == "__main__":
    root = sys.argv[1] if len(sys.argv) > 1 else "."
    raise SystemExit(main(root))
