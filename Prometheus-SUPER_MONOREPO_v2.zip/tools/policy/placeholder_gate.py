#!/usr/bin/env python3
"""
tools.policy.placeholder_gate
Scan a repo for placeholder markers and emit a JSON report.
Exits with non-zero code if findings are present, to gate CI.
"""
import os, re, sys, json
from pathlib import Path

PATTERNS = {
    "TODO": re.compile(r"\bTODO\b|ToDo|TO DO", re.IGNORECASE),
    "FIXME": re.compile(r"\bFIXME\b", re.IGNORECASE),
    "PLACEHOLDER": re.compile(r"place[-\s_]*holder|stub|tbd|lorem ipsum", re.IGNORECASE),
    "NOT_IMPLEMENTED": re.compile(r"NotImplementedError|raise\s+NotImplementedError", re.IGNORECASE),
}
TEXT_EXTS = {".py",".md",".txt",".json",".yaml",".yml",".toml",".ini",".cfg",".sh",".bash",".zsh",".ps1",".bat",".cmd",".ts",".tsx",".js",".jsx",".html",".css",".scss",".sql",".csv",".env",".dockerfile"}

def is_text_file(p: Path):
    return p.name == "Dockerfile" or p.suffix.lower() in TEXT_EXTS

def scan(root: Path):
    findings = []
    for r, _, files in os.walk(root):
        if "_autogen_" in r:
            continue
        for name in files:
            p = Path(r) / name
            if p.is_file() and is_text_file(p):
                try:
                    content = p.read_text(errors="ignore")
                except Exception:
                    content = ""
                for i, line in enumerate(content.splitlines(), 1):
                    for label, rx in PATTERNS.items():
                        if rx.search(line):
                            findings.append({"file": str(p.relative_to(root)), "line": i, "issue": label, "snippet": line.strip()})
    return findings

def main(root: str = ".", out: str = "policy_placeholder_report.json"):
    rp = Path(root).resolve()
    findings = scan(rp)
    Path(out).write_text(json.dumps({"count": len(findings), "findings": findings}, indent=2))
    print(f"Wrote placeholder report to {out} (count={len(findings)})")
    if findings:
        sys.exit(2)

if __name__ == "__main__":
    import argparse
    ap = argparse.ArgumentParser()
    ap.add_argument("--root", default=".")
    ap.add_argument("--out", default="policy_placeholder_report.json")
    args = ap.parse_args()
    main(args.root, args.out)
