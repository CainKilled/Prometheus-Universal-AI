#!/usr/bin/env python3
import os, re, sys, json
from pathlib import Path
from runtime.config.loader import load_config_dir

def enforce_policy(root: str = ".") -> dict:
    cfg = load_config_dir("config").get("policy", {})
    required_files = cfg.get("required_files", [])
    banned_patterns = [re.compile(p) for p in cfg.get("banned_patterns", [])]
    max_len = int(cfg.get("max_python_line_length", 120))

    errors = []
    # required files
    for rf in required_files:
        if not (Path(root) / rf).exists():
            errors.append({"type":"required_file_missing", "path": rf})

    # scan files
    for r, _, files in os.walk(root):
        if "_autogen_" in r:
            continue
        for name in files:
            p = Path(r) / name
            # ban patterns
            try:
                text = p.read_text(errors="ignore")
            except Exception:
                text = ""
            for rx in banned_patterns:
                if rx.search(text):
                    errors.append({"type":"banned_pattern", "path": str(p.relative_to(root)), "pattern": rx.pattern})
            # max line length for python
            if p.suffix == ".py":
                for i, line in enumerate(text.splitlines(), 1):
                    if len(line) > max_len:
                        errors.append({"type":"line_too_long", "path": str(p.relative_to(root)), "line": i, "len": len(line)})
    return {"ok": not errors, "errors": errors, "config": cfg}

if __name__ == "__main__":
    res = enforce_policy(".")
    print(json.dumps(res, indent=2))
    sys.exit(0 if res["ok"] else 5)
