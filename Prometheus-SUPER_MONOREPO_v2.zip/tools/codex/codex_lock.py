import os, json, hashlib, hmac, time
from pathlib import Path
from datetime import datetime

SKIP_DIRS = {".git", "__pycache__", "_autogen_reports"}
SKIP_EXTS = {".zip", ".tar", ".gz", ".tgz", ".xz", ".7z", ".pdf"}

class CodexLock:
    def __init__(self, root: str = "."):
        self.root = Path(root)

    def _iter_files(self):
        for r, dirs, files in os.walk(self.root):
            # prune dirs
            dirs[:] = [d for d in dirs if d not in SKIP_DIRS]
            for name in files:
                p = Path(r) / name
                if p.suffix.lower() in SKIP_EXTS: 
                    continue
                yield p

    def tree_hash(self, max_bytes=5_000_000, deadline_sec=45) -> str:
        h = hashlib.sha256()
        deadline = time.time() + deadline_sec
        for p in sorted(self._iter_files(), key=lambda x: str(x).lower()):
            if time.time() > deadline:
                break
            h.update(str(p.relative_to(self.root)).encode())
            try:
                data = p.read_bytes()
                if len(data) > max_bytes:
                    h.update(b"__TRUNC__")
                    h.update(hashlib.sha256(data[:max_bytes]).digest())
                else:
                    h.update(data)
            except Exception:
                continue
        return h.hexdigest()

    def sign(self, secret_env="CODEX_SECRET") -> dict:
        tree_digest = self.tree_hash()
        secret = os.getenv(secret_env, "")
        signature = hmac.new(secret.encode(), tree_digest.encode(), hashlib.sha256).hexdigest() if secret else None
        payload = {
            "generated_at": datetime.utcnow().isoformat() + "Z",
            "root": str(self.root.resolve()),
            "tree_sha256": tree_digest,
            "hmac": signature,
            "secret_env": secret_env if secret else None
        }
        Path("CODEX_LOCK.json").write_text(json.dumps(payload, indent=2))
        return payload

if __name__ == "__main__":
    lock = CodexLock(".")
    print(json.dumps(lock.sign(), indent=2))
