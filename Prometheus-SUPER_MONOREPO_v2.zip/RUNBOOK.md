
# Prometheus Universe — Runbook

## Quick Commands
```bash
# a) Build SBOM
python tools/sbom/sbom_build.py --root . --out sbom.json

# b) Health check for cloud adapters
python runtime/storage/cloud_adapters.py --check

# c) Placeholder gate (CI-failing if stubs found)
python tools/policy/placeholder_gate.py --root . --out policy_placeholder_report.json

# a+b
python tools/sbom/sbom_build.py --root . --out sbom.json && python runtime/storage/cloud_adapters.py --check

# a+c
python tools/policy/placeholder_gate.py --root . --out policy_placeholder_report.json && python tools/sbom/sbom_build.py --root . --out sbom.json
```

## Runtime Lifecycle
```bash
# Health
python prometheus_cli.py health

# Start (dry-run)
python prometheus_cli.py start --dry-run

# Start (real)
python prometheus_cli.py start --services all

# Stop
python prometheus_cli.py stop --services all
```
