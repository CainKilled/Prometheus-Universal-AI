# Prometheus Super Monorepo (E Pluribus Unum)

A self-contained cross-platform DevOps/SecOps suite with:
- Runtime busses and lifecycle commands
- HAL hardening & TBOX v3+ verification
- Codex lock & VaultTime signatures
- AI Gateway service + reverse-proxy config
- Wizards: RAV4_777 and NAGL_777
- Versioning, CI/CD, Docker, Control Nexus UI, packaging scripts

## Quickstart
```bash
make health
make ab
make ac
python runtime/tbox/tbox_v3.py --run-all
python tools/codex/codex_lock.py
python tools/vaulttime/sign.py
```
