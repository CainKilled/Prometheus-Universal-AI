#!/usr/bin/env bash
set -euo pipefail
ROOT="${1:-.}"
NAME="prometheus_bundle_$(date +%Y%m%d_%H%M%S).zip"
(cd "$ROOT" && zip -r "$NAME" . -x "*/__pycache__/*" -x "*.pyc" -x "*.pyo")
echo "FORGED: $NAME"
