## Security checklist
- [ ] No secrets committed
- [ ] Placeholder gate passes
- [ ] Policy engine passes
- [ ] SBOM built
- [ ] Unit tests added/updated
- [ ] Bandit scan passes
