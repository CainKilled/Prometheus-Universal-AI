# Security Policy
- Report vulnerabilities privately via security@your-domain.example
- No secrets in code; use environment variables and secret stores.
- All PRs must pass: placeholder gate, policy engine, SBOM, unit tests, and Bandit scan.
