#!/usr/bin/env ruby
puts 'Hello, NAGL-777 (Ruby)'
