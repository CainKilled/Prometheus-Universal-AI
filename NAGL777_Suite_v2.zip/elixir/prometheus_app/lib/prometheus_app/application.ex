defmodule PrometheusApp.Application do
  use Application
  def start(_t,_a) do
    IO.puts("Hello, NAGL-777 (Elixir)")
    Supervisor.start_link([], strategy: :one_for_one, name: PrometheusApp.Supervisor)
  end
end
