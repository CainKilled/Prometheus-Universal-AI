console.log("Hello, NAGL-777 (JavaScript Node CLI)");
