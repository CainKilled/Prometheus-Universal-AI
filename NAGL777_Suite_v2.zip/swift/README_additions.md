# Swift Additions
Use Swift Package Manager (SPM) to generate an Xcode project:
```bash
swift package init --type executable
swift build
```
