# Xcode Integration
For SwiftPM projects, open the package in Xcode. For Objective-C CLI, create a macOS Command Line Tool and import `main.m`.
