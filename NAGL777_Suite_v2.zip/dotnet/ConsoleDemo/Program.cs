System.Console.WriteLine("Hello, NAGL-777 (.NET Console)");
