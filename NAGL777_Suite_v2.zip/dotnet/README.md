# .NET Console Demo
Build: `dotnet build dotnet/ConsoleDemo/ConsoleDemo.csproj -c Release`
