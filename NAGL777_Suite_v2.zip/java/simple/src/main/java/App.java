public class App{public static void main(String[]a){System.out.println("Hello, NAGL-777 (Java)");}}
