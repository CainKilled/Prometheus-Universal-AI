#import <Foundation/Foundation.h>
int main(int argc, const char * argv[]) {
    @autoreleasepool { NSLog(@"Hello, NAGL-777 (Objective-C CLI)"); }
    return 0;
}
