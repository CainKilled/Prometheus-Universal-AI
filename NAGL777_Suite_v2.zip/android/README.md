# Android (APK) Skeleton
Open `android/PrometheusApp` in Android Studio and build.
