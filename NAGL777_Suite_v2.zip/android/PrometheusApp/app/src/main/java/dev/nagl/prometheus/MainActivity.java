package dev.nagl.prometheus;
import android.app.Activity; import android.os.Bundle; import android.widget.TextView;
public class MainActivity extends Activity {
  protected void onCreate(Bundle b){ super.onCreate(b); TextView tv=new TextView(this); tv.setText("Hello, NAGL-777 (Android)"); setContentView(tv); }
}
