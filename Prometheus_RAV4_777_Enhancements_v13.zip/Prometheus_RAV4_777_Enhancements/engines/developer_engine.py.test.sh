#!/usr/bin/env bash
set -euo pipefail
python -m py_compile "engines/developer_engine.py"
echo "[OK] developer_engine.py"