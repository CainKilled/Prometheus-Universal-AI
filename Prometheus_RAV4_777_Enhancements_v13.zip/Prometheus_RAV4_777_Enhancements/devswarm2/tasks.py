"""
DevSwarm Task Definitions
=========================

This module provides basic dataclasses and scheduling utilities for
defining and running tasks within the DevSwarm and HyperHiveMind
ecosystem. Tasks encapsulate a type, payload and schedule; roles
represent the class of agent best suited to execute a task; jobs group
tasks together. A simple cron‑like scheduler runs jobs at specified
times.

These constructs are intentionally lightweight so that they can be
extended or replaced in the future with more sophisticated schedulers
without breaking the API. All objects are designed to be idempotent:
running the same job multiple times yields the same side effects.
"""

from __future__ import annotations

import datetime
import threading
import time
from dataclasses import dataclass, field
from enum import Enum, auto
from typing import Callable, Dict, List, Optional


class Role(Enum):
    """Define roles for swarm agents."""

    LOW = auto()
    MID = auto()
    HIGH = auto()


@dataclass
class Task:
    """Represents a single unit of work for the swarm."""

    name: str
    type: str
    parameters: Dict[str, any] = field(default_factory=dict)
    schedule: str | None = None  # Cron‑like schedule (e.g. '*/5 * * * *')


@dataclass
class Job:
    """A collection of tasks executed together."""

    name: str
    tasks: List[Task]
    role: Role = Role.MID


class CronScheduler:
    """
    Very simple cron‑like scheduler. It runs jobs at the top of a
    minute matching the schedule string. The schedule string uses five
    fields: minute hour day month weekday, with '*' meaning any value.
    Only numeric values and '*' are supported.
    """

    def __init__(self) -> None:
        self.jobs: List[Job] = []
        self.running = False
        self.thread: Optional[threading.Thread] = None

    def add_job(self, job: Job) -> None:
        self.jobs.append(job)

    def start(self, executor: Callable[[Task], None]) -> None:
        """Start the scheduler. The executor is called for each task when due."""
        if not self.running:
            self.running = True
            self.thread = threading.Thread(target=self._run_loop, args=(executor,), daemon=True)
            self.thread.start()

    def stop(self) -> None:
        self.running = False
        if self.thread:
            self.thread.join(timeout=5.0)

    @staticmethod
    def _match_field(value: int, field: str) -> bool:
        if field == "*":
            return True
        try:
            return int(field) == value
        except ValueError:
            return False

    def _should_run(self, schedule: str, dt: datetime.datetime) -> bool:
        parts = schedule.split()
        if len(parts) != 5:
            return False
        minute, hour, day, month, weekday = parts
        return (
            self._match_field(dt.minute, minute)
            and self._match_field(dt.hour, hour)
            and self._match_field(dt.day, day)
            and self._match_field(dt.month, month)
            and self._match_field(dt.weekday(), weekday)
        )

    def _run_loop(self, executor: Callable[[Task], None]) -> None:
        """Internal loop to check schedules every minute."""
        while self.running:
            now = datetime.datetime.now()
            for job in self.jobs:
                for task in job.tasks:
                    # If no schedule is given, run every iteration
                    if task.schedule is None or self._should_run(task.schedule, now):
                        try:
                            executor(task)
                        except Exception as exc:
                            print(f"CronScheduler: Error executing task {task.name}: {exc}")
            # Sleep until the next minute tick
            sleep_time = 60 - now.second
            if sleep_time <= 0:
                sleep_time = 60
            time.sleep(sleep_time)


def example_executor(task: Task) -> None:
    """Example executor that sends a task to the DevSwarm orchestrator."""
    from devswarm2.orchestrator import DevSwarmOrchestrator
    orchestrator = DevSwarmOrchestrator()
    # Register default adapters as in SwarmPlugin
    from devswarm2.adapters import (
        LLMCLIAdapter,
        LiveKitAdapter,
        WebKitAdapter,
        GitAdapter,
        DockerAdapter,
        HTTPAdapter,
    )
    orchestrator.register_adapter('llm_cli', LLMCLIAdapter())
    orchestrator.register_adapter('livekit', LiveKitAdapter())
    orchestrator.register_adapter('webkit', WebKitAdapter())
    orchestrator.register_adapter('git', GitAdapter())
    orchestrator.register_adapter('docker', DockerAdapter())
    orchestrator.register_adapter('http', HTTPAdapter())
    # Build payload with type
    payload = {'type': task.type, **task.parameters}
    orchestrator.run_task(payload)
