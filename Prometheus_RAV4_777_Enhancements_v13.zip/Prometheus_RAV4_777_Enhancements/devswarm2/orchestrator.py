"""
DevSwarm Orchestrator v2
========================

This module provides a lightweight orchestrator for managing tasks across
a swarm of developer agents. Tasks are described as dictionaries
containing a ``type`` field and other parameters. Adapters are
responsible for executing tasks of specific types. For example, an
``llm`` adapter might handle tasks that ask language models for
completion, while a ``livekit`` adapter could coordinate media
streaming. The orchestrator maintains a registry of adapters and
dispatches tasks accordingly.

Adapters must implement a ``run(task: dict, logger: callable)`` method
returning a result. They can be registered at runtime with
``register_adapter(name, adapter_instance)``.

This design allows dynamic extension of the swarm with new capabilities,
and is analogous to the HyperHiveMind devswarm concept described by
Prometheus. The orchestrator itself does not schedule concurrency; that
responsibility could be added by integrating with the QQFFPP scheduler or
DevSwarm engine.
"""

from typing import Dict, Any, Callable, Optional


class DevSwarmOrchestrator:
    def __init__(self) -> None:
        self.adapters: Dict[str, Any] = {}

    def register_adapter(self, name: str, adapter: Any) -> None:
        """Register an adapter with a unique name."""
        self.adapters[name] = adapter

    def unregister_adapter(self, name: str) -> None:
        """Remove an adapter from the registry."""
        self.adapters.pop(name, None)

    def run_task(self, task: Dict[str, Any], logger: Callable[[str], None] = print) -> Optional[Any]:
        """Run a task by dispatching it to the appropriate adapter.

        A task must include a ``type`` field indicating which adapter to use.
        Additional keys are passed through to the adapter. The adapter is
        expected to return a result or raise an exception; any exceptions
        are caught and logged.
        """
        ttype = task.get("type")
        if not ttype:
            logger("DevSwarmOrchestrator: Task missing 'type'")
            return None
        adapter = self.adapters.get(ttype)
        if not adapter:
            logger(f"DevSwarmOrchestrator: No adapter registered for type '{ttype}'")
            return None
        try:
            return adapter.run(task, logger)
        except Exception as exc:
            logger(f"DevSwarmOrchestrator: Error running task {task}: {exc}")
            return None