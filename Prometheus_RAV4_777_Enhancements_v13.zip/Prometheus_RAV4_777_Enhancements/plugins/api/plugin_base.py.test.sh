#!/usr/bin/env bash
set -euo pipefail
python -m py_compile "plugins/api/plugin_base.py"
echo "plugin_base compiled successfully"