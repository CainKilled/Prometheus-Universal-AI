"""
Swarm Plugin
============

This plugin provides a thin wrapper around the DevSwarm v2
orchestrator. It allows you to run tasks through one of the
registered adapters (LLM CLI, LiveKit, WebKit, Git, Docker, HTTP,
etc.) using the unified plugin invocation mechanism. This means you
can drive Git operations, container builds, HTTP requests and more via
the same API used for other plugins, the CLI, the REPL or the
Prometheus HTTP server.

Runtime parameters:

    type (str): The adapter type to use (e.g. ``git``, ``docker``, ``http``,
        ``llm_cli``, ``livekit``, ``webkit``). Required.
    ...        Any additional key/value pairs supported by the selected
        adapter. See the adapter documentation for supported fields.
    log (callable): Optional logger function. Defaults to ``print``.

Examples:

    # Clone a repository
    kernel.run_plugin('swarm', {'type': 'git', 'action': 'clone', 'repo_url': 'https://github.com/foo/bar.git'})

    # Pull a Docker image
    kernel.run_plugin('swarm', {'type': 'docker', 'action': 'pull', 'image': 'python:3.11'})

    # Make an HTTP GET request
    kernel.run_plugin('swarm', {'type': 'http', 'url': 'https://example.com'})
"""

from __future__ import annotations

from typing import Dict, Any

from devswarm2.orchestrator import DevSwarmOrchestrator
from devswarm2.adapters import (
    LLMCLIAdapter,
    LiveKitAdapter,
    WebKitAdapter,
    GitAdapter,
    DockerAdapter,
    HTTPAdapter,
)
from plugins.api.plugin_base import Plugin


class SwarmPlugin:
    def __init__(self) -> None:
        # Initialise an orchestrator and register adapters once
        self.orchestrator = DevSwarmOrchestrator()
        self.orchestrator.register_adapter('llm_cli', LLMCLIAdapter())
        self.orchestrator.register_adapter('livekit', LiveKitAdapter())
        self.orchestrator.register_adapter('webkit', WebKitAdapter())
        self.orchestrator.register_adapter('git', GitAdapter())
        self.orchestrator.register_adapter('docker', DockerAdapter())
        self.orchestrator.register_adapter('http', HTTPAdapter())

    def metadata(self) -> Dict[str, Any]:
        return {
            'name': 'swarm',
            'version': '1.0.0',
            'description': 'Run tasks via the DevSwarm orchestrator (git, docker, http, llm_cli, livekit, webkit)',
            'targets': ['devswarm'],
        }

    def activate(self, runtime: Dict[str, Any]) -> Dict[str, Any] | None:
        logger = runtime.get('log', print)
        task_type = runtime.get('type')
        if not task_type:
            logger("SwarmPlugin: 'type' parameter is required")
            return {'error': "'type' parameter is required"}
        # Build task dict from runtime excluding reserved keys
        task: Dict[str, Any] = {k: v for k, v in runtime.items() if k not in {'log'}}
        # Dispatch via orchestrator
        result = self.orchestrator.run_task(task, logger)
        return result


def get_plugin() -> Plugin:
    return SwarmPlugin()  # type: ignore[return-value]