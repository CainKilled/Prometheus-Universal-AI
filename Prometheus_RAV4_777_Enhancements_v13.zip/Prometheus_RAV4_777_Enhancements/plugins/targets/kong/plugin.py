"""
API Gateway (Kong) Plugin
=========================

This plugin provides a minimal, self‑contained API gateway inspired by
Kong. It allows you to define simple routes that forward incoming
requests to backend services. The implementation uses Python's
built‑in ``http.server`` and ``urllib.request`` modules to avoid
external dependencies and to remain idempotent. While it cannot match
the full feature set of Kong, it demonstrates how a plug‑in can expose
a gateway interface within the Prometheus ecosystem.

Routes are configured via the runtime dictionary. Each route is a
mapping from a path prefix to a target URL. When the gateway receives
a request on that path, it forwards the request to the corresponding
target and returns the backend's response to the caller. Only GET and
POST methods are supported in this minimal version.

Runtime parameters:

    routes (dict): Mapping of path prefixes to backend URLs.
    port (int):    Port number to bind the gateway on (default: 8080).

Example:

    kernel.run_plugin('kong', {
        'routes': {'/ai/': 'https://api.example.com/v1/'},
        'port': 8000,
    })
"""

from __future__ import annotations

import json
import threading
from http.server import BaseHTTPRequestHandler, HTTPServer
from urllib import request, parse, error
from typing import Dict, Any, Tuple

from plugins.api.plugin_base import Plugin


class ProxyHandler(BaseHTTPRequestHandler):
    """Request handler that proxies incoming requests based on route config."""

    routes: Dict[str, str] = {}

    def _forward(self, method: str, body: bytes | None) -> Tuple[int, bytes, Dict[str, str]]:
        # Determine target based on longest matching prefix
        target_prefix = ''
        for prefix in ProxyHandler.routes:
            if self.path.startswith(prefix) and len(prefix) > len(target_prefix):
                target_prefix = prefix
        if not target_prefix:
            return 404, b'Not found', {}
        target_base = ProxyHandler.routes[target_prefix]
        forward_path = self.path[len(target_prefix):]
        url = parse.urljoin(target_base, forward_path)
        # Build request
        headers = {k: v for k, v in self.headers.items() if k.lower() != 'host'}
        req = request.Request(url, data=body if method == 'POST' else None, headers=headers, method=method)
        try:
            with request.urlopen(req) as resp:
                return resp.status, resp.read(), dict(resp.headers)
        except error.HTTPError as http_err:
            return http_err.code, http_err.read(), dict(http_err.headers)
        except Exception as exc:
            return 502, str(exc).encode('utf-8'), {}

    def do_GET(self) -> None:
        status, resp_body, resp_headers = self._forward('GET', None)
        self.send_response(status)
        for k, v in resp_headers.items():
            # Avoid duplicate 'Transfer-Encoding' header
            if k.lower() != 'transfer-encoding':
                self.send_header(k, v)
        self.end_headers()
        self.wfile.write(resp_body)

    def do_POST(self) -> None:
        content_length = int(self.headers.get('Content-Length', 0))
        body = self.rfile.read(content_length) if content_length > 0 else None
        status, resp_body, resp_headers = self._forward('POST', body)
        self.send_response(status)
        for k, v in resp_headers.items():
            if k.lower() != 'transfer-encoding':
                self.send_header(k, v)
        self.end_headers()
        self.wfile.write(resp_body)


class KongPlugin:
    def metadata(self) -> Dict[str, Any]:
        return {
            'name': 'kong',
            'version': '1.0.0',
            'description': 'Lightweight API gateway for routing requests to backend services',
            'targets': ['gateway', 'proxy'],
        }

    def activate(self, runtime: Dict[str, Any]) -> Dict[str, Any] | None:
        routes: Dict[str, str] = runtime.get('routes', {})
        port: int = runtime.get('port', 8080)
        log = runtime.get('log', print)
        if not routes:
            log("KongPlugin: 'routes' parameter is required")
            return {'error': "'routes' is required"}
        ProxyHandler.routes = routes
        server = HTTPServer(('0.0.0.0', port), ProxyHandler)
        thread = threading.Thread(target=server.serve_forever, daemon=True)
        thread.start()
        log(f"KongPlugin: API gateway started on port {port} with routes: {routes}")
        # Return server and thread for potential shutdown control
        return {'status': 'running', 'port': port}


def get_plugin() -> Plugin:
    return KongPlugin()  # type: ignore[return-value]
