"""AI Gateway plugin package."""
