"""
AI Gateway Plugin
=================

This plugin exposes a simple interface for routing requests through an
AI gateway. The aim is to provide a unified entry point to different
large language model services (LLMs) or AI endpoints, inspired by
projects such as the open‑source Prometheus Gateway (a security‑first
LLM gateway)【223813531082503†L146-L149】. While this implementation is
minimal and does not bundle any external dependencies, it demonstrates
how the architecture can be extended to support secure, observable AI
model access.

The plugin accepts runtime parameters that specify the target
``endpoint``, the ``model`` to use and a ``payload`` containing the
input for the model. It performs a POST request using the built‑in
``urllib`` library. If the request succeeds, the JSON response is
returned; otherwise an error dictionary is returned. A future version
could integrate authentication, rate limiting and monitoring.

Runtime parameters:

    endpoint (str): Base URL of the AI service (e.g. ``https://api.example.com/v1/chat``)
    model (str):    Name of the model to call (optional).
    payload (dict): JSON‑serialisable payload for the model (required).
    headers (dict): Additional HTTP headers (optional).

Example:

    kernel.run_plugin('gateway', {
        'endpoint': 'https://api.openai.com/v1/chat/completions',
        'model': 'gpt-4o',
        'payload': {'messages': [{'role': 'user', 'content': 'Hello!'}]},
        'headers': {'Authorization': 'Bearer YOUR_TOKEN'},
    })
"""

from __future__ import annotations

import json
from typing import Any, Dict
from urllib import request, error

from plugins.api.plugin_base import Plugin


class AIGatewayPlugin:
    def metadata(self) -> Dict[str, Any]:
        return {
            'name': 'gateway',
            'version': '1.0.0',
            'description': 'Route requests to AI model endpoints via a unified API',
            'targets': ['ai', 'llm'],
        }

    def activate(self, runtime: Dict[str, Any]) -> Dict[str, Any] | None:
        endpoint: str | None = runtime.get('endpoint')
        payload: Dict[str, Any] | None = runtime.get('payload')
        headers: Dict[str, Any] = runtime.get('headers', {})
        model: str | None = runtime.get('model')
        log = runtime.get('log', print)
        if not endpoint:
            log("AIGatewayPlugin: 'endpoint' parameter is required")
            return {'error': "'endpoint' is required"}
        if payload is None:
            log("AIGatewayPlugin: 'payload' parameter is required")
            return {'error': "'payload' is required"}
        # Include model in payload if provided and not already present
        if model and 'model' not in payload:
            payload['model'] = model
        try:
            data = json.dumps(payload).encode('utf-8')
            req = request.Request(endpoint, data=data, headers={'Content-Type': 'application/json', **headers})
            with request.urlopen(req) as resp:
                resp_body = resp.read()
                try:
                    return json.loads(resp_body.decode('utf-8'))
                except json.JSONDecodeError:
                    return {'raw': resp_body.decode('utf-8')}
        except error.HTTPError as http_err:
            log(f"AIGatewayPlugin: HTTP error {http_err.code}: {http_err.reason}")
            return {'error': f"HTTP {http_err.code}: {http_err.reason}"}
        except Exception as exc:
            log(f"AIGatewayPlugin: Exception calling {endpoint}: {exc}")
            return {'error': str(exc)}


def get_plugin() -> Plugin:
    return AIGatewayPlugin()  # type: ignore[return-value]
