"""
Environment Definitions
=======================

This package holds environment configuration files such as dev,
test and production settings. Each file should be a JSON document
containing key/value pairs. The kernel or individual plugins may
load these files to adjust behaviour depending on the active
environment.

For example, ``default.json`` defines fallback variables. You
can create additional files like ``dev.json`` or ``prod.json``
containing secrets, API endpoints or other deployment‑specific
information. Environment files are never committed to source control
when they contain sensitive data.
"""
