# scripts/Install-WireGuardTunnel.ps1
param(
  [Parameter(Mandatory=$true)] [string] $ConfPath
)
# Requires WireGuard for Windows installed. This installs the tunnel as a service.
# Example: .\Install-WireGuardTunnel.ps1 -ConfPath "C:\path\to\toshiba.conf"
$wg = "$Env:ProgramFiles\WireGuard\wireguard.exe"
if (-Not (Test-Path $wg)) { Write-Error "WireGuard not found at $wg"; exit 1 }
& $wg /installtunnelservice $ConfPath
Write-Output "Installed service for $ConfPath"
