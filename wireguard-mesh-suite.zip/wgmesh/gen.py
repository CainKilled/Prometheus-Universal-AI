#!/usr/bin/env python3
"""
wgmesh/gen.py — WireGuard mesh generator (keys, configs, QR codes).

Usage:
  python wgmesh/gen.py --config wgmesh/devices.yaml --out out --server toshiba --endpoint 203.0.113.5:51820 --dns 1.1.1.1 --psk
"""
import os, sys, subprocess, base64, yaml, argparse
from jinja2 import Template

try:
    import nacl.public, nacl.utils
except Exception:
    nacl = None

try:
    import qrcode
except Exception:
    qrcode = None

def run(cmd, check=True, input=None):
    return subprocess.run(cmd, input=input, text=True, capture_output=True, check=check)

def have_wg():
    from shutil import which
    return which("wg") is not None

def gen_keypair():
    # Prefer wg
    if have_wg():
        sk = run(["wg", "genkey"]).stdout.strip()
        pk = run(["wg", "pubkey"], input=sk).stdout.strip()
        return sk, pk
    # Fallback to PyNaCl
    if nacl is not None:
        sk_obj = nacl.public.PrivateKey.generate()
        sk = base64.b64encode(bytes(sk_obj)).decode()
        pk = base64.b64encode(bytes(sk_obj.public_key)).decode()
        return sk, pk
    # Placeholder (strong random, but not valid wg key format) — user must replace.
    sk = base64.b64encode(os.urandom(32)).decode()
    pk = "REPLACE_WITH_PUBLIC_KEY"
    return sk, pk

def gen_psk():
    if have_wg():
        return run(["wg", "genpsk"]).stdout.strip()
    return base64.b64encode(os.urandom(32)).decode()

def render_template(tpl_path, **ctx):
    tpl = Template(open(tpl_path, "r", encoding="utf-8").read())
    return tpl.render(**ctx)

def write(path, text):
    os.makedirs(os.path.dirname(path), exist_ok=True)
    open(path, "w", encoding="utf-8").write(text)

def make_qr(conf_text, out_png):
    if qrcode is None:
        return False
    img = qrcode.make(conf_text)
    img.save(out_png)
    return True

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--config", required=True)
    ap.add_argument("--out", required=True)
    ap.add_argument("--server", required=True, help="server device id (e.g., toshiba)")
    ap.add_argument("--endpoint", required=True, help="public_ip:port of the server")
    ap.add_argument("--dns", default=None)
    ap.add_argument("--psk", action="store_true", help="enable preshared keys for clients")
    args = ap.parse_args()

    data = yaml.safe_load(open(args.config, "r", encoding="utf-8"))
    devices = {d["id"]: d for d in data["devices"]}
    if args.server not in devices or devices[args.server]["role"] != "server":
        print("Server id not found or not a server in devices.yaml", file=sys.stderr)
        sys.exit(1)

    server = devices[args.server]
    # Generate keys for all
    for dev in devices.values():
        sk, pk = gen_keypair()
        dev["private_key"] = sk
        dev["public_key"] = pk

    # PSK per client (optional)
    if args.psk:
        for dev in devices.values():
            if dev["id"] == args.server: continue
            dev["preshared_key"] = gen_psk()

    # Render server config
    peers = []
    for dev in devices.values():
        if dev["id"] == args.server: continue
        peers.append({
            "public_key": dev["public_key"],
            "address": dev["address"],
            "preshared_key": dev.get("preshared_key")
        })
    server_conf = render_template(
        os.path.join(os.path.dirname(__file__), "..", "templates", "server.conf.j2"),
        server=server, listen_port=data["network"]["listen_port"], peers=peers, dns=args.dns
    )
    write(os.path.join(args.out, "toshiba.conf"), server_conf)

    # Render clients
    for dev in devices.values():
        if dev["id"] == args.server: continue
        client_conf = render_template(
            os.path.join(os.path.dirname(__file__), "..", "templates", "client.conf.j2"),
            client=dev, server=server, preshared_key=dev.get("preshared_key"),
            allowed_ips=dev["address"], endpoint=args.endpoint, dns=args.dns
        )
        conf_path = os.path.join(args.out, f"{dev['id']}.conf")
        write(conf_path, client_conf)
        # QR for iOS
        png_path = os.path.join(args.out, f"{dev['id']}.png")
        make_qr(client_conf, png_path)

    print(f"Generated configs in: {args.out}")
    print("IMPORTANT: Keep these files secret. Private keys must not be shared.")
    if not have_wg() and nacl is None:
        print("WARNING: 'wg' and PyNaCl are missing. Public keys are placeholders. Install one and re-run.")

if __name__ == "__main__":
    main()
