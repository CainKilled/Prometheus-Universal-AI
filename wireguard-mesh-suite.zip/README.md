# WireGuard Mesh Suite (Hub & Spoke for 3 Devices)
**Version:** 1.0.0 • **Date:** 2025-09-03

A complete, **production‑grade** toolkit to generate and manage a private **WireGuard** mesh
among your three devices (hub-and-spoke):

- **Toshiba C875** — Hub (server)
- **iPhone QE** — Client
- **iPhone 8** — Client

> This suite generates keys (via `wg` or PyNaCl), configs, optional **preshared keys**,
> and **QR codes** for iOS import. It also includes service helpers for Windows/macOS/Linux.

## Topology
```
        (Public IP / Port)
                |
           [Toshiba] 10.77.0.1/32  (hub, listens on 51820/UDP)
            /      \
  [iPhone QE]     [iPhone 8]
   10.77.0.2/32    10.77.0.3/32
```

- Each client peers with the hub. Clients can reach each other **via the hub**.
- Add more peers later by extending `wgmesh/devices.yaml` and re-running the generator.

## Quick Start
```bash
python -m venv .venv && source .venv/bin/activate
pip install -r requirements.txt

# Generate everything (keys, .conf files, QR codes)
python wgmesh/gen.py   --config wgmesh/devices.yaml   --out out   --server toshiba   --endpoint <TOSHIBA_PUBLIC_IP>:51820   --dns 1.1.1.1   --psk
```

Outputs will be under `out/`:
- `toshiba.conf` — import into WireGuard on Toshiba (Windows/Linux/macOS).
- `iphone_qe.conf` + `iphone_qe.png` — iOS config + QR code.
- `iphone_8.conf` + `iphone_8.png` — iOS config + QR code.

## Install on each device

### Toshiba (Windows)
1. Install **WireGuard for Windows**.
2. Import `out/toshiba.conf` in the app.
3. (Optional) install as a service (see `scripts/Install-WireGuardTunnel.ps1`).

### Toshiba (Linux/macOS)
```bash
sudo cp out/toshiba.conf /etc/wireguard/wg0.conf
sudo wg-quick up wg0
# enable at boot (Linux)
sudo systemctl enable wg-quick@wg0
```

### iPhone QE / iPhone 8 (iOS)
- Open WireGuard app → **Add a tunnel** → **Scan from QR code** → scan `out/iphone_qe.png` and `out/iphone_8.png`.

## Security Hardening
- **Curve25519** keys, **Preshared Keys** (optional) per peer pair.
- Limit **AllowedIPs** to peer /32 addresses (no 0.0.0.0/0 unless you want full tunnel).
- **PersistentKeepalive=25** on mobile peers to maintain NAT bindings.
- Keep the **Private Keys** offline; configs in `out/` are secrets. Back them up securely.
- Restrict hub’s firewall to UDP/51820 inbound only.

See `SECURITY.md` for more.

## Files
- `wgmesh/devices.yaml` — device roster + mesh addresses
- `wgmesh/gen.py` — generator (keys, configs, QR)
- `templates/*.j2` — Jinja2 templates for server/client configs
- `scripts/Install-WireGuardTunnel.ps1` — Windows install helper
- `scripts/macos_launchd_example.plist` — example launchd (macOS)
- `requirements.txt` — `PyNaCl`, `PyYAML`, `Jinja2`, `qrcode`, `Pillow`

---

**Note:** If `wg` is installed, the generator uses it. Otherwise it falls back to **PyNaCl**. If neither is available, it creates **placeholders** you can replace manually.
