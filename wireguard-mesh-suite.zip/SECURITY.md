# SECURITY.md

- Prefer a **stable public IP** (or dynamic DNS) for the hub (Toshiba). Forward UDP/51820 on your router to Toshiba.
- Use **preshared keys** (PSKs) in addition to normal keypairs for extra confidentiality.
- Keep `out/*.conf` private. Anyone with a private key and peer info could join.
- Mobile peers keep NAT alive via `PersistentKeepalive = 25`.
- Avoid `AllowedIPs = 0.0.0.0/0` unless you explicitly want a full-tunnel VPN.
- Rotate keys periodically: re-run the generator with `--rotate` (coming soon) or regenerate keys on peers and update configs.
