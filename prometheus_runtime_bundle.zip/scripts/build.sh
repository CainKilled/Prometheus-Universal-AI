#!/usr/bin/env bash
set -euo pipefail
docker build -t prometheus-ui:latest -f docker/Dockerfile .
docker build -t prometheus-window-server:latest prometheus-window-server
