#!/usr/bin/env bash
set -euo pipefail
docker run --rm -p 8000:8000 -v "$PWD/tools":/app/tools prometheus-ui:latest &
docker run --rm -p 9000:9000 prometheus-window-server:latest &
wait
