from fastapi import FastAPI
from pydantic import BaseModel
import platform

app = FastAPI(title="Prometheus Window Server")

class Echo(BaseModel):
    message: str

@app.get("/health")
def health():
    return {"status":"ok","python":platform.python_version()}

@app.post("/echo")
def echo(payload: Echo):
    return {"echo": payload.message}
