from flask import Flask, render_template, request, jsonify
import subprocess, json, os, sys

app = Flask(__name__)

@app.get("/")
def index():
    return render_template("index.html")

@app.post("/run")
def run_tool():
    payload = request.get_json(force=True)
    tool = payload.get("tool")
    args = payload.get("args", [])
    if not tool:
        return jsonify({"ok": False, "error": "missing 'tool'"}), 400
    tool_path = os.path.join(os.path.dirname(__file__), "..", "tools", f"{tool}.py")
    if not os.path.exists(tool_path):
        return jsonify({"ok": False, "error": f"tool '{tool}' not found"}), 404
    try:
        res = subprocess.run([sys.executable, tool_path, *args], capture_output=True, text=True, timeout=60)
        return jsonify({"ok": res.returncode == 0, "returncode": res.returncode, "stdout": res.stdout, "stderr": res.stderr})
    except Exception as e:
        return jsonify({"ok": False, "error": str(e)}), 500

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=8000, debug=True)
