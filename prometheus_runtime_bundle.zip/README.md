# Prometheus Runtime Bundle (Minimal Reference Scaffold)

This bundle includes a runnable reference for:
- `prometheus_ui` (Flask app)  
- Core CLI tools: hal, skywalk, phoenix, codex, controlnexus, awareness, wardog, vaulttime, tbox, schrodinger, jctest  
- `prometheus-window-server` (FastAPI stub)  
- Dockerfiles, CI, and example configs

> NOTE: This is a reference scaffold for demonstration & extension. Harden before production.
