#!/usr/bin/env python
import argparse, sys, json, time, os, hashlib, base64
from typing import Any, Dict

RET_OK=0
RET_ERR=1
RET_WARN=2

def main():
    ap = argparse.ArgumentParser(prog="tbox", description="Trusted Build box verifier (env attestation).")
    ap.add_argument("--info", action="store_true", help="print tool spec")
    ap.add_argument("--input", help="input file or data", default=None)
    ap.add_argument("--output", help="output file path", default=None)
    args = ap.parse_args()

    if args.info:
        spec = {
            "name":"tbox",
            "purpose":"Check CI environment and dependencies.",
            "inputs":["--input (file/data)"],
            "outputs":["--output (file)"],
            "return_codes":{"RET_OK":0,"RET_ERR":1,"RET_WARN":2},
            "example":"tbox --input sample.txt --output out.json"
        }
        print(json.dumps(spec, indent=2)); return RET_OK

    try:
        data = ""
        if args.input and os.path.exists(args.input):
            with open(args.input,'rb') as f: data = f.read()
        elif args.input:
            data = args.input.encode()
        else:
            data = b""
        digest = hashlib.sha256(data).hexdigest()
        out = {"tool":"tbox","ts":int(time.time()),"sha256":digest}
        payload = json.dumps(out, indent=2).encode()
        if args.output:
            with open(args.output,'wb') as f: f.write(payload)
        else:
            sys.stdout.write(payload.decode()+"\n")
        return RET_OK
    except Exception as e:
        sys.stderr.write(str(e)+"\n")
        return RET_ERR

if __name__ == "__main__":
    sys.exit(main())
