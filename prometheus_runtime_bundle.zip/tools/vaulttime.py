#!/usr/bin/env python
import argparse, sys, json, time, os, hashlib, base64
from typing import Any, Dict

RET_OK=0
RET_ERR=1
RET_WARN=2

def sign_bytes(data: bytes, key_path: str) -> str:
    # Simple HMAC-like placeholder using sha256 (for demo only!). Replace with Ed25519/PyNaCl.
    secret = open(key_path,'rb').read() if os.path.exists(key_path) else b""
    digest = hashlib.sha256(secret + b"|" + data).digest()
    return base64.b64encode(digest).decode()

def main():
    ap = argparse.ArgumentParser(prog="vaulttime", description="Signing & sealing tool (demo)")
    sub = ap.add_subparsers(dest="cmd", required=True)

    s = sub.add_parser("seal", help="Seal an artifact with signature and timestamp")
    s.add_argument("--in", dest="inp", required=True)
    s.add_argument("--out", dest="out", required=True)
    s.add_argument("--key", dest="key", required=True)

    v = sub.add_parser("verify", help="Verify a sealed artifact")
    v.add_argument("--in", dest="inp", required=True)
    v.add_argument("--key", dest="key", required=True)

    i = sub.add_parser("info", help="Print tool spec")

    args = ap.parse_args()

    if args.cmd == "info":
        spec = {
            "name":"vaulttime",
            "purpose":"Sign/verify and seal artifacts with timestamp",
            "inputs":["seal --in file --out file --key private.key","verify --in file --key public.key"],
            "outputs":[".seal.json"],
            "return_codes":{"RET_OK":0,"RET_ERR":1,"RET_WARN":2}
        }
        print(json.dumps(spec, indent=2)); return RET_OK

    if args.cmd == "seal":
        data = open(args.inp,'rb').read()
        sig = sign_bytes(data, args.key)
        seal = {
            "algorithm":"DEMO-SHA256-HMACLIKE",
            "signature": sig,
            "ts": int(time.time()),
            "file": os.path.basename(args.inp),
            "sha256": hashlib.sha256(data).hexdigest()
        }
        open(args.out,'w').write(json.dumps(seal, indent=2))
        print(json.dumps({"ok":True,"out":args.out}, indent=2))
        return RET_OK

    if args.cmd == "verify":
        # Demo verify: recompute and compare if .seal.json is alongside
        seal_path = args.inp if args.inp.endswith(".seal.json") else args.inp + ".seal.json"
        if not os.path.exists(seal_path):
            print(json.dumps({"ok":False,"error":"seal file not found"})); return RET_ERR
        seal = json.load(open(seal_path))
        file_path = seal["file"]
        if not os.path.exists(file_path):
            print(json.dumps({"ok":False,"error":"sealed file missing"})); return RET_ERR
        data = open(file_path,'rb').read()
        expect = hashlib.sha256(data).hexdigest()
        ok = (expect == seal["sha256"])
        print(json.dumps({"ok":ok,"sha256":expect,"seal_sha256":seal["sha256"]}, indent=2))
        return RET_OK if ok else RET_ERR

    return RET_ERR

if __name__ == "__main__":
    sys.exit(main())
