#!/usr/bin/env python
import argparse, sys, json, time, subprocess, pathlib

RET_OK=0
RET_ERR=1

TESTS = [
    {"id":"unit.tools.import","cmd":[sys.executable,"-c","import os,sys;print('ok')"]},
    {"id":"lint.black","cmd":["bash","-lc","black --version || true"]},
    {"id":"type.mypy","cmd":["bash","-lc","mypy --version || true"]},
    {"id":"sec.bandit","cmd":["bash","-lc","bandit --version || true"]},
]

def run_cmd(cmd):
    try:
        res = subprocess.run(cmd, capture_output=True, text=True, timeout=60)
        return {"returncode":res.returncode, "stdout":res.stdout, "stderr":res.stderr}
    except Exception as e:
        return {"returncode":1, "stdout":"", "stderr":str(e)}

def main():
    ap = argparse.ArgumentParser(prog="jctest", description="Full test-suite runner")
    ap.add_argument("--full-suite", action="store_true", help="run full suite")
    args = ap.parse_args()

    results = []
    for t in TESTS:
        r = run_cmd(t["cmd"])
        status = "pass" if r["returncode"] == 0 else "warn"
        results.append({"id":t["id"], "status":status, "detail":r})

    ok = all(r["status"]=="pass" for r in results)
    print(json.dumps({"summary":{"ok":ok,"total":len(results)},"results":results}, indent=2))
    return RET_OK if ok else RET_ERR

if __name__ == "__main__":
    sys.exit(main())
