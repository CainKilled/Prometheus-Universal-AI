# Security

- Align with OWASP ASVS L2+, NIST 800-53 moderate baseline, SLSA 3 for supply chain.
- Use code signing via `vaulttime` (Ed25519, Sigstore/Cosign optional).
- Enable CI gates: lint, type-check, tests, SCA, SAST.
