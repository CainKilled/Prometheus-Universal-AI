#!/usr/bin/env bash
set -euo pipefail
python -m py_compile "engines/architect_engine.py"
echo "[OK] architect_engine.py"