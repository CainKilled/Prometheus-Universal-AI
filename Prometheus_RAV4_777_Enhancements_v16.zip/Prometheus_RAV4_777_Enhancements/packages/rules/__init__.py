"""
Rules Package
=============

This package implements a minimal JSONLogic‑like rules engine for
evaluating boolean expressions against a context. Rules are expressed
as JSON objects where the single key is an operator and the value is
either a single argument or a list of arguments. Supported operators
include equality, inequality, greater than, less than, logical
conjunction/disjunction and membership checks. See `engine.py` for
implementation details.

Developed and maintained by Adam Henry Nagle. Contact: 603‑384‑8949,
cainkilledabrl@icloud.com, nagleadam75@gmail.com.
"""

from .engine import evaluate, compile_rule  # noqa: F401