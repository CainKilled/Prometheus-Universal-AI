"""
Merkle Tree Utilities
=====================

This module implements basic functions for computing SHA‑256 file
hashes, building merkle trees from directory hierarchies and
generating directory manifests. Merkle trees are useful for
efficiently verifying large directory structures or creating
immutable manifests for deployment artifacts.

Developed and maintained by Adam Henry Nagle. Contact: 603-384-8949,
cainkilledabrl@icloud.com, nagleadam75@gmail.com.
"""

from pathlib import Path
import hashlib
import json
import time
from typing import Dict, Any


def file_hash(p: Path) -> str:
    """Compute the SHA‑256 hash of a file.

    Args:
        p: Path object to the file.
    Returns:
        Hexadecimal SHA‑256 hash string.
    """
    h = hashlib.sha256()
    with p.open("rb") as f:
        for chunk in iter(lambda: f.read(8192), b""):
            h.update(chunk)
    return h.hexdigest()


def merkle_tree(root: str, ignore= (".git", "__pycache__")) -> Dict[str, Any]:
    """Recursively compute a merkle tree for a directory.

    Args:
        root: Root directory path as string.
        ignore: Tuple of directory names to skip.
    Returns:
        A dictionary containing the merkle root hash and children listing.
    """
    rootp = Path(root)
    def walk(d: Path) -> Dict[str, Any]:
        entries = []
        for p in sorted(d.iterdir(), key=lambda x: x.name):
            if any(tok in p.parts for tok in ignore):
                continue
            if p.is_dir():
                sub = walk(p)
                node_hash = hashlib.sha256(("dir:" + sub["hash"]).encode()).hexdigest()
                entries.append({"type": "dir", "name": p.name, "hash": node_hash, "children": sub["children"]})
            else:
                h = file_hash(p)
                entries.append({"type": "file", "name": p.name, "hash": h})
        roll = hashlib.sha256()
        for e in entries:
            roll.update((e["type"] + ":" + e["name"] + ":" + e["hash"]).encode())
        return {"hash": roll.hexdigest(), "children": entries}
    return walk(rootp)


def dir_manifest(root: str) -> Dict[str, Any]:
    """Generate a manifest for a directory using a merkle tree.

    Args:
        root: Root directory path as string.
    Returns:
        Dictionary with creation timestamp and merkle root.
    """
    tree = merkle_tree(root)
    return {
        "created_utc": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
        "merkle_root": tree["hash"],
        "tree": tree,
    }
