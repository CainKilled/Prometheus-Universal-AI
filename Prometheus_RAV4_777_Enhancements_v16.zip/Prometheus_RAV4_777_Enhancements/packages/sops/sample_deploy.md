---
{"name": "Sample Deploy", "owner": "Adam Henry Nagle", "contact": {"phone": "603-384-8949", "emails": ["cainkilledabrl@icloud.com", "nagleadam75@gmail.com"]}}
---
# Sample Deployment Procedure

This SOP outlines a simple deployment procedure consisting of three
commands. It is intended as an example for testing the SOP runner.

$ echo "ENV OK"
$ echo "BUILD OK"
$ echo "DEPLOY OK"