"""
Vector Storage Plugin
====================

This plugin provides a simple interface for storing and querying
embeddings (vectors) to support retrieval‑augmented generation (RAG).
It can operate in three modes depending on the ``provider`` runtime
parameter:

* ``local`` – Vectors are stored in a JSON file on disk (``vector_store.json``)
  under the plugin directory. Cosine similarity is used for recall.
* ``pinecone`` – Requires the ``pinecone-client`` library. The plugin
  will attempt to upsert and query vectors in a Pinecone index. You must
  provide ``api_key`` and ``environment`` in the runtime, as well as
  ``index_name``.
* ``weaviate`` – Requires the ``weaviate-client`` library. Similar to
  Pinecone; you must supply ``url`` and optionally ``api_key``.

If the chosen provider’s library is unavailable, the plugin falls back
to the local implementation.

Runtime keys:
    provider (str): "local", "pinecone", or "weaviate" (default: "local").
    action (str): "upsert" or "query".
    namespace (str): Logical grouping for vectors (default: "default").
    vectors (list): For upsert – a list of dicts {"id": str, "values": list[float]}.
    queries (list): For query – a list of vectors (list[float]) to search against.
    top_k (int): For query – number of nearest neighbours to return (default: 5).

This plugin is experimental and not a drop‑in replacement for full
vector databases, but it demonstrates how to integrate them.

Developed and maintained by Adam Henry Nagle. Contact: 603‑384‑8949,
cainkilledabrl@icloud.com, nagleadam75@gmail.com.
"""

# Prometheus Codex Lock v1
# This file is part of Prometheus RAV4 777 Enhancements. Do not edit manually.

from __future__ import annotations

import json
import math
import os
from pathlib import Path
from typing import Dict, Any, List, Tuple

from plugins.api.plugin_base import Plugin


STORE_FILE = Path(__file__).parent / "vector_store.json"


def _load_store() -> Dict[str, Dict[str, List[float]]]:
    if STORE_FILE.exists():
        with open(STORE_FILE, "r", encoding="utf-8") as f:
            return json.load(f)
    return {}


def _save_store(store: Dict[str, Dict[str, List[float]]]) -> None:
    with open(STORE_FILE, "w", encoding="utf-8") as f:
        json.dump(store, f)


def _cosine_similarity(a: List[float], b: List[float]) -> float:
    dot = sum(x * y for x, y in zip(a, b))
    norm_a = math.sqrt(sum(x * x for x in a))
    norm_b = math.sqrt(sum(y * y for y in b))
    if norm_a == 0 or norm_b == 0:
        return 0.0
    return dot / (norm_a * norm_b)


class VectorPlugin:
    def metadata(self) -> Dict[str, Any]:
        return {
            "name": "vector",
            "version": "0.1.0",
            "description": "Vector storage and recall for embeddings",
            "targets": ["vector", "rag"],
        }

    def activate(self, runtime: Dict[str, Any]) -> None:
        logger = runtime.get("log", print)
        provider = runtime.get("provider", "local").lower()
        action = runtime.get("action")
        namespace = runtime.get("namespace", "default")
        top_k = int(runtime.get("top_k", 5))
        if action not in {"upsert", "query"}:
            logger(f"VectorPlugin: Unsupported action '{action}'")
            return
        # Try external providers first
        if provider == "pinecone":
            try:
                import pinecone  # type: ignore
                api_key = runtime.get("api_key")
                environment = runtime.get("environment")
                index_name = runtime.get("index_name")
                if not all([api_key, environment, index_name]):
                    raise ValueError("api_key, environment and index_name must be provided for Pinecone")
                pinecone.init(api_key=api_key, environment=environment)
                index = pinecone.Index(index_name)
                if action == "upsert":
                    vectors = runtime.get("vectors", [])
                    # Format: [(id, vector, metadata_dict)] but metadata is optional
                    to_upsert = [(v.get("id"), v.get("values"), v.get("metadata", {})) for v in vectors]
                    index.upsert(vectors=to_upsert, namespace=namespace)  # type: ignore[call-arg]
                    logger(f"VectorPlugin: Upserted {len(to_upsert)} vectors to Pinecone")
                else:  # query
                    queries = runtime.get("queries", [])
                    for q in queries:
                        res = index.query(queries=[q], top_k=top_k, include_values=True, namespace=namespace)  # type: ignore[call-arg]
                        logger(str(res))
                return
            except Exception as exc:
                logger(f"VectorPlugin: Pinecone error or unavailable – falling back to local: {exc}")
                provider = "local"
        if provider == "weaviate":
            try:
                import weaviate  # type: ignore
                url = runtime.get("url")
                api_key = runtime.get("api_key")
                client = weaviate.Client(url=url, auth_client_secret=weaviate.AuthApiKey(api_key) if api_key else None)
                # For simplicity, we assume a collection named after namespace exists.
                if action == "upsert":
                    coll = client.collection(namespace)
                    vectors = runtime.get("vectors", [])
                    objects = []
                    for v in vectors:
                        objects.append({"id": v.get("id"), "vector": v.get("values"), "properties": v.get("metadata", {})})
                    coll.data.insert_many(objects)  # type: ignore
                    logger(f"VectorPlugin: Upserted {len(objects)} vectors to Weaviate")
                else:
                    coll = client.collection(namespace)
                    queries = runtime.get("queries", [])
                    for q in queries:
                        res = coll.query.near_vector(vector=q, limit=top_k)  # type: ignore
                        logger(str(res))
                return
            except Exception as exc:
                logger(f"VectorPlugin: Weaviate error or unavailable – falling back to local: {exc}")
                provider = "local"
        # Local provider
        store = _load_store()
        namespace_store = store.setdefault(namespace, {})
        if action == "upsert":
            count = 0
            for v in runtime.get("vectors", []):
                vid = v.get("id")
                values = v.get("values")
                if vid and values:
                    namespace_store[vid] = values
                    count += 1
            _save_store(store)
            logger(f"VectorPlugin: Upserted {count} vectors locally to namespace '{namespace}'")
        else:  # query
            queries = runtime.get("queries", [])
            for q in queries:
                # Compute similarity to all vectors in namespace
                sims: List[Tuple[str, float]] = []
                for vid, vals in namespace_store.items():
                    sims.append((vid, _cosine_similarity(q, vals)))
                sims.sort(key=lambda x: x[1], reverse=True)
                results = sims[:top_k]
                logger(f"VectorPlugin: Query results for namespace '{namespace}': {results}")


def get_plugin() -> Plugin:
    return VectorPlugin()  # type: ignore[return-value]