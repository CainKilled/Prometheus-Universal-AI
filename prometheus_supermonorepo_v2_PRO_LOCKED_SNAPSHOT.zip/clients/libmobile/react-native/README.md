
# React Native (Expo) client for libmobile

## Prereqs
- Node 18+
- `npm i -g expo-cli` (or use `npx expo`)

## Run
```bash
npm install
API_BASE=http://localhost:8000 npm run start
# press i for iOS simulator or a for Android
```
