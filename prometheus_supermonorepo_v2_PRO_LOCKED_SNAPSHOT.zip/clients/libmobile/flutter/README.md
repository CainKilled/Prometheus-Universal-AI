
# Flutter client for libmobile

## Run
```bash
flutter run -d chrome --dart-define=API_BASE=http://localhost:8000
# or device/simulator with API_BASE pointing to your network-accessible API
```
