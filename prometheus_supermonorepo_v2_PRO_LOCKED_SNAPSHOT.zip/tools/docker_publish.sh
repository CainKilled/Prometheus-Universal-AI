
#!/usr/bin/env bash
set -euo pipefail

DOCKER_REGISTRIES="${DOCKER_REGISTRIES:-ghcr.io,docker.io}"
DOCKER_NAMESPACE="${DOCKER_NAMESPACE:-$USER}"
VERSION="${VERSION:?set VERSION like v1.0.0}"
PLATFORMS="${PLATFORMS:-linux/amd64,linux/arm64}"

echo "[*] Registries=${DOCKER_REGISTRIES} namespace=${DOCKER_NAMESPACE} version=${VERSION} platforms=${PLATFORMS}"

# Ensure buildx
docker buildx version >/dev/null 2>&1 || { echo "docker buildx not available"; exit 2; }

# Discover Dockerfiles
mapfile -t DOCKERFILES < <(git ls-files '**/Dockerfile' || true)
if [ ${#DOCKERFILES[@]} -eq 0 ]; then
  echo "No Dockerfiles found."
  exit 0
fi

IFS=',' read -r -a REGS <<< "$DOCKER_REGISTRIES"

for df in "${DOCKERFILES[@]}"; do
  ctx="$(dirname "$df")"
  name="$(echo "$ctx" | tr '/._' '-' | tr '[:upper:]' '[:lower:]')"
  tags=()
  for reg in "${REGS[@]}"; do
    image="${reg}/${DOCKER_NAMESPACE}/${name}"
    tags+=("--tag" "${image}:${VERSION}" "--tag" "${image}:latest")
  done
  echo "[*] Building multi-registry tags for $df (context=$ctx)"
  docker buildx build --platform "$PLATFORMS" -f "$df" "$ctx" "${tags[@]}" --push
done

echo "[*] Done. Images pushed to: ${DOCKER_REGISTRIES}"
