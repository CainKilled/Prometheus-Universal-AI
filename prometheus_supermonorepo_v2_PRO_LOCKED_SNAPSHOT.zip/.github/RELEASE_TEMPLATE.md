# Release Notes

Version: ${{ env.VERSION }}

## Artifacts
See attached files. Each artifact has:
- SHA256 in `SHA256SUMS.txt`
- HMAC of SHA256SUMS in `SHA256SUMS.txt.hmac`
- Optional cosign signatures (`.sig`) if configured
- Optional GPG signatures (`.asc`) if configured
- Per-file VaultTime seals embedded in companion manifests and under `SEALS/`
