#!/usr/bin/env python3
import argparse, json, os, re, shutil, sys, tempfile, time, hashlib, zipfile, tarfile
from datetime import datetime, timezone
from pathlib import Path
ISO = "%Y-%m-%dT%H:%M:%SZ"
def sha256_bytes(b: bytes) -> str:
    h = hashlib.sha256(); h.update(b); return h.hexdigest()
def sha256_file(p: Path) -> str:
    h = hashlib.sha256()
    with p.open("rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()
def slug(s: str) -> str:
    s = s.strip().lower()
    s = re.sub(r"[^a-z0-9\-_.]+", "-", s)
    s = re.sub(r"-+", "-", s).strip("-")
    return s or "untitled"
def to_iso(ts: float | int | None) -> str | None:
    if ts is None: return None
    try:
        return datetime.fromtimestamp(float(ts), tz=timezone.utc).strftime(ISO)
    except Exception:
        return None
def read_export(source: Path):
    if source.is_file() and source.suffix.lower() == ".zip":
        tmp = Path(tempfile.mkdtemp(prefix="chatgpt_export_"))
        with zipfile.ZipFile(source, "r") as z:
            z.extractall(tmp)
        root = tmp
    else:
        root = source
    conv = None
    for name in ("conversations.json", "conversations/conversations.json"):
        p = root / name
        if p.exists():
            conv = p; break
    if conv is None:
        raise FileNotFoundError("conversations.json not found in export")
    files_dir = root / "files"
    return root, json.loads(conv.read_text(encoding="utf-8")), files_dir if files_dir.exists() else None
def normalize_conversations(data):
    if isinstance(data, list): return data
    if isinstance(data, dict) and "conversations" in data and isinstance(data["conversations"], list):
        return data["conversations"]
    return [data]
def render_thread_md(conv: dict) -> str:
    title = conv.get("title") or "Untitled"
    cid = conv.get("id") or conv.get("conversation_id") or "unknown"
    create_iso = to_iso(conv.get("create_time")) or ""
    update_iso = to_iso(conv.get("update_time")) or ""
    messages = []
    if isinstance(conv.get("mapping"), dict):
        for node_id, node in conv["mapping"].items():
            msg = node.get("message")
            if not msg: continue
            author = (msg.get("author") or {}).get("role") or "unknown"
            content = msg.get("content")
            if isinstance(content, dict) and isinstance(content.get("parts"), list):
                text = "\n\n".join(str(p) for p in content["parts"])
            elif isinstance(content, str):
                text = content
            else:
                text = json.dumps(content, ensure_ascii=False)
            ts = msg.get("create_time") or node.get("create_time")
            messages.append({"author": author, "text": text, "ts": float(ts) if ts else None})
    elif isinstance(conv.get("messages"), list):
        for m in conv["messages"]:
            author = (m.get("author") or {}).get("role") or m.get("role") or "unknown"
            c = m.get("content")
            if isinstance(c, dict) and isinstance(c.get("parts"), list):
                text = "\n\n".join(str(p) for p in c["parts"])
            elif isinstance(c, str):
                text = c
            else:
                text = json.dumps(c, ensure_ascii=False)
            ts = m.get("create_time") or m.get("timestamp")
            messages.append({"author": author, "text": text, "ts": float(ts) if ts else None})
    else:
        messages.append({"author": "system", "text": "Raw conversation structure preserved in raw.json", "ts": None})
    messages.sort(key=lambda m: (m["ts"] is None, m["ts"] or 0))
    lines = []
    lines.append("---")
    lines.append(f'title: "{title.replace("\"","\\\"")}"')
    lines.append(f"id: {json.dumps(cid)}")
    if create_iso: lines.append(f"created_at: {create_iso}")
    if update_iso: lines.append(f"updated_at: {update_iso}")
    lines.append("source: chatgpt_export")
    lines.append("schema: v1-contextual")
    lines.append("---\n")
    for m in messages:
        tstamp = to_iso(m["ts"]) or ""
        hdr = f"## {m['author']}  {tstamp}".rstrip()
        lines.append(hdr); lines.append(""); lines.append(m["text"]); lines.append(""); lines.append("---"); lines.append("")
    return "\n".join(lines).rstrip() + "\n"
def write_manifest(dir_path: Path) -> dict:
    items = []
    for p in sorted(dir_path.rglob("*")):
        if p.is_dir(): continue
        rel = p.relative_to(dir_path).as_posix()
        items.append({"path": rel, "size": p.stat().st_size, "sha256": sha256_file(p)})
    manifest = {"generated_at": datetime.now(timezone.utc).strftime(ISO), "root": dir_path.name, "items": items}
    (dir_path / "manifest.json").write_text(json.dumps(manifest, indent=2), encoding="utf-8")
    return manifest
def seal_tar(dir_path: Path) -> Path:
    out = dir_path.with_suffix(".tar.gz")
    with tarfile.open(out, "w:gz") as tar:
        tar.add(dir_path, arcname=dir_path.name)
    return out
def ensure_dir(p: Path) -> None:
    p.mkdir(parents=True, exist_ok=True)
def process(source: Path, dest_root: Path, do_seal: bool, dry_run: bool) -> list[dict]:
    root, data, files_dir = read_export(source)
    convs = normalize_conversations(data)
    results = []
    export_files_cache = files_dir if files_dir else None
    for conv in convs:
        title = conv.get("title") or "Untitled"
        cid = conv.get("id") or conv.get("conversation_id") or sha256_bytes(json.dumps(conv).encode())[:12]
        created = to_iso(conv.get("create_time")) or "unknown"
        yyyy_mm = (created or "unknown")[:7].replace("unknown", "undated")
        leaf = f"{slug(title)}_{cid[:8]}"
        out_dir = dest_root / yyyy_mm / leaf
        ensure_dir(out_dir)
        thread_md = render_thread_md(conv)
        raw_json = json.dumps(conv, ensure_ascii=False, indent=2)
        attach_dir = out_dir / "_attachments"
        ensure_dir(attach_dir)
        if export_files_cache:
            dest_files = attach_dir / "export_files_snapshot"
            if not dest_files.exists() and not dry_run:
                shutil.copytree(export_files_cache, dest_files)
        if not dry_run:
            (out_dir / "thread.md").write_text(thread_md, encoding="utf-8")
            (out_dir / "raw.json").write_text(raw_json, encoding="utf-8")
            manifest = write_manifest(out_dir)
            tar_path = None
            if do_seal:
                tar_path = seal_tar(out_dir)
            results.append({
                "conversation_id": cid,
                "title": title,
                "dir": out_dir.as_posix(),
                "created_at": created,
                "sealed_tar": tar_path.as_posix() if tar_path else None,
                "manifest_hash": sha256_file(out_dir / "manifest.json")
            })
        else:
            results.append({
                "conversation_id": cid,
                "title": title,
                "dir": out_dir.as_posix(),
                "created_at": created,
                "sealed_tar": None,
                "manifest_hash": None
            })
    return results
def update_index(dest_root: Path, results: list[dict]) -> None:
    idx_path = dest_root / "index.json"
    if idx_path.exists():
        existing = json.loads(idx_path.read_text(encoding="utf-8"))
        if not isinstance(existing, list): existing = []
    else:
        existing = []
    by_id = {e["conversation_id"]: e for e in existing if isinstance(e, dict) and "conversation_id" in e}
    for r in results:
        by_id[r["conversation_id"]] = r
    merged = sorted(by_id.values(), key=lambda e: (e.get("created_at") or "", e.get("title") or ""))
    idx_path.write_text(json.dumps(merged, indent=2), encoding="utf-8")
def rollup(dest_root: Path) -> None:
    payload = {"generated_at": datetime.now(timezone.utc).strftime(ISO), "root": "knowledge/chatgpt", "tree": []}
    for yyyy_mm in sorted({p.parent.name for p in dest_root.rglob("thread.md")}):
        month_dir = dest_root / yyyy_mm
        month_entry = {"month": yyyy_mm, "conversations": []}
        for conv_dir in sorted([p.parent for p in month_dir.rglob("thread.md")]):
            mpath = conv_dir / "manifest.json"
            if not mpath.exists(): continue
            month_entry["conversations"].append({
                "dir": conv_dir.name,
                "manifest_sha256": sha256_file(mpath),
                "thread_sha256": sha256_file(conv_dir / "thread.md"),
                "raw_sha256": sha256_file(conv_dir / "raw.json")
            })
        payload["tree"].append(month_entry)
    (dest_root / "vaulttime_rollup.json").write_text(json.dumps(payload, indent=2), encoding="utf-8")
def main():
    ap = argparse.ArgumentParser(description="ChatGPT contextual ingest → Prometheus bind")
    ap.add_argument("--source", type=str, help="Path to ChatGPT export .zip or directory")
    ap.add_argument("--dest", type=str, help="Destination knowledge root (e.g., .../knowledge/chatgpt)")
    ap.add_argument("--seal-tar", type=int, default=1, help="1 to create per-conversation .tar.gz")
    ap.add_argument("--dry-run", action="store_true", help="Preview only; no writes")
    ap.add_argument("--rollup", type=str, default=None, help="If set, compute rollup for given dest path and exit")
    args = ap.parse_args()
    if args.rollup:
      dest_root = Path(args.rollup).expanduser().resolve()
      rollup(dest_root)
      print(f"Rollup written at {dest_root}/vaulttime_rollup.json")
      return
    if not args.source or not args.dest:
        print("Missing --source and/or --dest", file=sys.stderr); sys.exit(2)
    source = Path(args.source).expanduser().resolve()
    dest_root = Path(args.dest).expanduser().resolve()
    dest_root.mkdir(parents=True, exist_ok=True)
    results = process(source, dest_root, bool(args.seal_tar), args.dry_run)
    update_index(dest_root, results)
    rollup(dest_root)
    print(f"Ingested {len(results)} conversations into {dest_root}")
if __name__ == "__main__":
    main()
