#!/usr/bin/env python3
import argparse, subprocess, sys, shutil, os, tarfile, zipfile
from pathlib import Path
from typing import List, Dict, Any
import yaml
from rich.console import Console
console = Console()
ROOT = Path(__file__).resolve().parents[2]
from tools.orchestrator.agents.registry import get_agent
def run_cmd(cmd: List[str], cwd: Path) -> int:
  return subprocess.call(cmd, cwd=str(cwd))
def archive_dir(src: Path, dst: Path, fmt: str):
  dst.parent.mkdir(parents=True, exist_ok=True)
  if fmt == "zip":
    with zipfile.ZipFile(dst, "w", compression=zipfile.ZIP_DEFLATED) as z:
      for p in src.rglob("*"):
        if p.is_file(): z.write(p, p.relative_to(src))
  elif fmt == "tar.gz":
    with tarfile.open(dst, "w:gz") as t:
      t.add(src, arcname=src.name)
  else:
    raise SystemExit(f"Unsupported archive format: {fmt}")
def matches_any(rel: Path, patterns: List[str]) -> bool:
  import fnmatch
  s = rel.as_posix()
  return any(fnmatch.fnmatch(s, pat) for pat in patterns)
def package_project(proj: Dict[str, Any], global_cfg: Dict[str, Any]) -> Path:
  name = proj["name"]
  root = (ROOT / proj["root"]).resolve()
  out_dir = ROOT / global_cfg["packaging"]["out_dir"] / name
  fmt = global_cfg["packaging"]["archive_format"]
  if out_dir.exists(): shutil.rmtree(out_dir)
  out_dir.mkdir(parents=True, exist_ok=True)
  include = proj.get("package", {}).get("include", ["**/*"])
  exclude = proj.get("package", {}).get("exclude", [])
  for p in root.rglob("*"):
    if p.is_file():
      rel = p.relative_to(root)
      if matches_any(rel, include) and not matches_any(rel, exclude):
        dest = out_dir / rel; dest.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(p, dest)
  archive_path = ROOT / global_cfg["packaging"]["out_dir"] / f"{name}.zip"
  if archive_path.exists(): archive_path.unlink()
  archive_dir(out_dir, archive_path, "zip")
  return archive_path
def load_config(path: Path) -> Dict[str, Any]:
  return yaml.safe_load(path.read_text())
def main():
  ap = argparse.ArgumentParser()
  ap.add_argument("run", nargs='?')
  ap.add_argument("--config", required=True)
  ap.add_argument("--phases", default="build,test,package,codex,verify,upload")
  ap.add_argument("--project", default=None)
  args = ap.parse_args()
  cfg = load_config(Path(args.config))
  global_cfg = cfg["global"]
  projects = cfg["projects"]
  if args.project:
    projects = [p for p in projects if p["name"] == args.project]
    if not projects: console.print(f"No project named {args.project}"); sys.exit(2)
  phases = [p.strip() for p in args.phases.split(",")]
  for proj in projects:
    name = proj["name"]; root = (ROOT / proj["root"]).resolve()
    console.rule(f"{name}")
    if "forge" in phases:
      get_agent("forge").run(name=name, root=str(root))
    if "build" in phases and "build" in proj:
      if run_cmd(proj["build"]["cmd"], root) != 0: console.print(f"Build failed for {name}"); sys.exit(1)
    if "test" in phases and "test" in proj:
      if run_cmd(proj["test"]["cmd"], root) != 0: console.print(f"Tests failed for {name}"); sys.exit(1)
    pkg_path = None
    if "package" in phases and "package" in proj:
      pkg_path = package_project(proj, global_cfg); console.print(f"Packaged {name} -> {pkg_path}")
    if "codex" in phases:
      get_agent("codex").run(name=name, root=str(root), artifact=str(pkg_path) if pkg_path else None)
    if "verify" in phases:
      get_agent("verify").run(name=name, root=str(root))
    if "upload" in phases:
      upload_root = ROOT / global_cfg["packaging"]["out_dir"]
      get_agent("upload").run(
        name=name, root=str(ROOT), upload_path=str(upload_root),
        drive_root_name=global_cfg["drive"]["root_name"],
        dest_subpath=global_cfg["drive"]["dest_subpath"],
        threads=int(global_cfg["drive"]["threads"])
      )
if __name__ == "__main__":
  main()
