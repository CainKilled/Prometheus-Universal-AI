#!/usr/bin/env bash
set -euo pipefail
ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
PY="${PYTHON_BIN:-python3}"
ORCH="${ROOT_DIR}/tools/orchestrator/orchestrator.py"
CONF="${ROOT_DIR}/prometheus.config.yml"
function ensure_venv() {
  if [[ -n "${VIRTUAL_ENV:-}" ]]; then return 0; fi
  if [[ ! -d "${ROOT_DIR}/.venv" ]]; then
    "${PY}" -m venv "${ROOT_DIR}/.venv"
  fi
  source "${ROOT_DIR}/.venv/bin/activate"
  pip install --upgrade pip >/dev/null
  pip install -r "${ROOT_DIR}/tools/orchestrator/requirements.txt" >/dev/null
  pip install -r "${ROOT_DIR}/tools/drive_uploader/requirements.txt" >/dev/null || true
}
cmd="${1:-help}"; shift || true
case "${cmd}" in
  forge)
    ensure_venv
    "${PY}" "${ORCH}" run --config "${CONF}" --phases forge,build,test,package,codex,verify,upload "$@"
    ;;
  build|test|package|codex|verify|upload)
    ensure_venv
    "${PY}" "${ORCH}" run --config "${CONF}" --phases "${cmd}" "$@"
    ;;
  help|*)
    echo "Usage: scripts/prometheus_total_entrypoint.sh <forge|build|test|package|codex|verify|upload> [--project <name>]"
    ;;
esac
