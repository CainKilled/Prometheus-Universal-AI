
import os
from typing import List
from fastapi import FastAPI, HTTPException
from pydantic import BaseModel
from sqlalchemy import create_engine, text
from sqlalchemy.orm import Session

DATABASE_URL = os.getenv("DATABASE_URL", "sqlite:///./libmobile.db")

engine = create_engine(
    DATABASE_URL,
    connect_args={"check_same_thread": False} if DATABASE_URL.startswith("sqlite") else {},
)

app = FastAPI(title="libmobile API")

def init_db():
    with engine.begin() as conn:
        conn.execute(text("CREATE TABLE IF NOT EXISTS notes (id INTEGER PRIMARY KEY AUTOINCREMENT, text TEXT NOT NULL)"))

@app.on_event("startup")
def startup():
    init_db()

class NoteIn(BaseModel):
    text: str

class NoteOut(BaseModel):
    id: int
    text: str

@app.get("/health")
def health():
    return {"status": "ok"}

@app.get("/v1/notes", response_model=List[NoteOut])
def list_notes():
    with Session(engine) as s:
        rows = s.execute(text("SELECT id, text FROM notes ORDER BY id")).all()
        return [{"id": r[0], "text": r[1]} for r in rows]

@app.post("/v1/notes", response_model=NoteOut)
def create_note(note: NoteIn):
    with Session(engine) as s:
        res = s.execute(text("INSERT INTO notes (text) VALUES (:t)"), {"t": note.text})
        s.commit()
        rid = s.execute(text("SELECT last_insert_rowid()")).scalar() if DATABASE_URL.startswith("sqlite") else res.lastrowid
        if rid is None:
            rid = s.execute(text("SELECT MAX(id) FROM notes")).scalar()
        return {"id": int(rid), "text": note.text}
