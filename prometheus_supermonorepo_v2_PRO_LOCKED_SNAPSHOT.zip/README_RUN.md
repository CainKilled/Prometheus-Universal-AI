
## Releases and signing
Local:
```bash
export VAULTTIME_KEY="your-strong-secret"
export VERSION="v1.0.0"
make release
# Artifacts at dist/releases/$VERSION
```

GitHub Actions:
- Add repository secrets:
  - VAULTTIME_KEY (required)
  - COSIGN_PRIVATE_KEY (base64, optional) and COSIGN_PASSWORD (optional)
  - GPG_PRIVATE_KEY (base64, optional) and GPG_PASSPHRASE (optional)
- Push a tag v1.2.3 or run the Release workflow with version=v1.2.3.


## Docker publishing
Local (build & push all Dockerfiles):
```bash
export VERSION=v1.0.0
export DOCKER_REGISTRY=ghcr.io
export DOCKER_NAMESPACE=<your-gh-username-or-org>
./tools/docker_publish.sh
```

GitHub:
- Push a tag (`v*`) or dispatch **Docker Publish** workflow.
- Ensure repository has `packages: write` permission (default for GHCR via GITHUB_TOKEN).
- Optional: set `COSIGN_PRIVATE_KEY`/`COSIGN_PASSWORD` secrets to sign images.

## libmobile app
```bash
# Compose
cd apps/libmobile/infra
docker compose up --build

# API health
curl http://localhost:8000/health

# Web UI
open http://localhost:8080   # or start your browser
```


## Armada ops
- **Docker (multi-registry):**
  - Secrets for Docker Hub in GitHub: `DOCKERHUB_USERNAME`, `DOCKERHUB_TOKEN`
  - Local: `DOCKER_REGISTRIES=ghcr.io,docker.io DOCKER_NAMESPACE=<ns> VERSION=v1.0.0 ./tools/docker_publish.sh`
- **Kubernetes (Helm):**
  - Set `KUBECONFIG_BASE64` secret. Run CD workflow `CD - libmobile k8s` with `version` matching your image tag.
- **SBOM & Security:**
  - `sbom.yml` produces SPDX SBOM, `security-scan` runs Grype. Results uploaded as artifacts.
- **SLSA provenance:**
  - `slsa-provenance.yml` attaches provenance when Release workflow completes.

## Mobile clients
- Flutter client: `clients/libmobile/flutter` (see README)
- React Native (Expo): `clients/libmobile/react-native` (see README)
