# Intent Regeneration v3 (usefulness-aware)

## Run
```bash
python tools/regenerate_google_intents.py \
  --logs-dir logs/usage \
  --existing nlp/google_intents.json \
  --out nlp/google_intents.json \
  --policy nlp/intent_pruning_policy.json \
  --checkpoint state/intents.ckpt.json

# With owner approvals and archive dir
python tools/regenerate_google_intents.py \
  --logs-dir logs/usage \
  --existing nlp/google_intents.json \
  --out nlp/google_intents.json \
  --policy nlp/intent_pruning_policy.json \
  --checkpoint state/intents.ckpt.json \
  --owner-approvals state/owner_approvals.json \
  --archive-dir nlp/archive

# Phase-2 confirmation + archive (soft delete)
python tools/regenerate_google_intents.py \
  --logs-dir logs/usage \
  --existing nlp/google_intents.json \
  --out nlp/google_intents.json \
  --policy nlp/intent_pruning_policy.json \
  --checkpoint state/intents.ckpt.json \
  --prune-allow

# Dry run (no writes)
python tools/regenerate_google_intents.py --logs-dir logs/usage --dry-run
```

## Restore from archive
```bash
python tools/intent_restore.py --archive-dir nlp/archive --intents INTENT_NAME_1 INTENT_NAME_2
```

## Open PR
```bash
git checkout -b chore/nlp-intents-regen-$(date +%Y-%m-%d)
git add nlp/google_intents.json nlp/*.json tools/*.py tests/*.py .github/PULL_REQUEST_TEMPLATE/intent-regeneration.md
git commit -m "chore(nlp): regenerate google_intents.json (v3 usefulness + cocoon + archive)"
git push -u origin HEAD
gh pr create --title "NLP: regenerate google_intents.json (v3 usefulness + cocoon + archive)" --fill --body-file .github/PULL_REQUEST_TEMPLATE/intent-regeneration.md
```
