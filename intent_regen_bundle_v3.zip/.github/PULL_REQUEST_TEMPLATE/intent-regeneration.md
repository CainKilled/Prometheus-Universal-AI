# NLP: Regenerate google_intents.json (v3 usefulness, cocoon, archive)

- Two-phase prune with usefulness override and *cocoon* state for rare-but-valuable intents.
- Default action after confirmation window is **archive** (soft delete) vs hard-delete.
- Owner approvals supported via `--owner-approvals` JSON.
- Explain reports: `state/intents_explain.csv` and `state/intents_explain.jsonl`.

## Safety & Determinism
- Atomic writes, job checkpoint + lock, deterministic input hash.
- Hard never-prune tags: compliance/payments/auth/legal/p0.
- Delete requires `--prune-allow` and passes safe-delete cap.
