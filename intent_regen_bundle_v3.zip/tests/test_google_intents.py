#!/usr/bin/env python3
import json, sys, os

ROOT = os.path.dirname(os.path.dirname(__file__))
TARGET = os.path.join(ROOT, "nlp", "google_intents.json")
SCHEMA = os.path.join(ROOT, "nlp", "google_intents.schema.json")

ALLOWED = {"active","pending_prune","cocoon","pruned"}

def fail(msg): print(f"[FAIL] {msg}"); sys.exit(1)

def load_json(p):
    with open(p, "r") as f: return json.load(f)

def main():
    doc = load_json(TARGET)
    schema = load_json(SCHEMA)
    if not isinstance(doc, dict): fail("Top-level must be object")
    for k in ["version","updated_at","intents"]:
        if k not in doc: fail(f"Missing key: {k}")
    if not isinstance(doc["intents"], list): fail("intents must be list")
    for it in doc["intents"]:
        if "name" not in it or "phrases" not in it: fail("intent missing fields")
        meta = it.get("meta", {})
        st = meta.get("status","active")
        if st not in ALLOWED: fail(f"invalid status: {st}")
    print("[OK] Schema-lite + status check passed.")

if __name__ == "__main__":
    main()
