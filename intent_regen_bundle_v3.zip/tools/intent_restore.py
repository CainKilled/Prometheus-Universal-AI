#!/usr/bin/env python3
# tools/intent_restore.py
# Restore archived intents back into google_intents.json by name.

import os, sys, json, argparse, datetime, tempfile

def read_json(p):
    with open(p, "r") as f:
        return json.load(f)

def write_atomic(path, obj):
    d = os.path.dirname(path)
    os.makedirs(d, exist_ok=True)
    tmp = tempfile.NamedTemporaryFile("w", dir=d, delete=False, suffix=".json")
    json.dump(obj, tmp, indent=2)
    tmp.close()
    os.replace(tmp.name, path)

def find_in_archive(archive_dir, names):
    hits = []
    for root, _, files in os.walk(archive_dir):
        for name in files:
            if not name.endswith(".json"): continue
            p = os.path.join(root, name)
            try:
                doc = read_json(p)
            except Exception:
                continue
            for e in doc.get("entries", []):
                if e.get("name") in names:
                    hits.append(e)
    return hits

def main():
    ap = argparse.ArgumentParser(description="Restore archived intents by name.")
    ap.add_argument("--archive-dir", default="nlp/archive")
    ap.add_argument("--intents", nargs="+", required=True, help="Intent names to restore")
    ap.add_argument("--existing", default="nlp/google_intents.json")
    ap.add_argument("--out", default="nlp/google_intents.json")
    args = ap.parse_args()

    doc = read_json(args.existing)
    intents = {i["name"]: i for i in doc.get("intents", [])}
    hits = find_in_archive(args.archive_dir, set(args.intents))
    if not hits:
        print("No matching archived intents found."); sys.exit(1)

    for e in hits:
        e["meta"]["status"] = "active"
        e["rationale"] = {"decision": "restored", "thresholds": {}, "triggers": [], "computed": {}}
        intents[e["name"]] = {"name": e["name"], "phrases": e.get("phrases", []), "meta": e.get("meta", {}), "rationale": e.get("rationale", {})}

    out_doc = {
        **doc,
        "updated_at": datetime.datetime.utcnow().replace(microsecond=0).isoformat() + "Z",
        "intents": sorted(intents.values(), key=lambda x: x["name"])
    }
    write_atomic(args.out, out_doc)
    print("[OK] Restored:", ", ".join(i["name"] for i in hits))

if __name__ == "__main__":
    main()
