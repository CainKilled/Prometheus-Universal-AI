#!/usr/bin/env python3
# tools/regenerate_google_intents.py (v3)
# Resume-safe, deterministic regeneration with usefulness-aware pruning,
# cocoon state, owner approvals, archiving by default, and explain reports.

import os, sys, json, time, uuid, hashlib, argparse, datetime, tempfile, csv
from pathlib import Path

ALLOWED_STATUSES = {"active","pending_prune","cocoon","pruned"}

def now_utc():
    return datetime.datetime.utcnow().replace(microsecond=0).isoformat() + "Z"

def read_json(path, default=None):
    try:
        with open(path, "r") as f:
            return json.load(f)
    except FileNotFoundError:
        return default

def write_atomic(path, obj):
    d = os.path.dirname(path)
    os.makedirs(d, exist_ok=True)
    tmp = tempfile.NamedTemporaryFile("w", dir=d, delete=False, suffix=".json")
    json.dump(obj, tmp, indent=2)
    tmp.close()
    os.replace(tmp.name, path)

def sha256_bytes(b):
    import hashlib
    h = hashlib.sha256()
    h.update(b)
    return h.hexdigest()

def sha256_of_events(events):
    data = ("\n".join(json.dumps(e, sort_keys=True) for e in events)).encode("utf-8")
    return sha256_bytes(data)

def parse_logs(logs_dir, window_end_iso):
    events = []
    for root, _, files in os.walk(logs_dir):
        for name in files:
            if not name.endswith(".jsonl"): continue
            p = os.path.join(root, name)
            with open(p, "r", errors="ignore") as f:
                for line in f:
                    line=line.strip()
                    if not line: continue
                    try:
                        ev = json.loads(line)
                    except Exception:
                        continue
                    ts = ev.get("timestamp")
                    if not ts: 
                        continue
                    if ts > window_end_iso:
                        continue
                    events.append(ev)
    events.sort(key=lambda e: (e.get("timestamp",""), e.get("utterance","")))
    return events, sha256_of_events(events)

def days_between(end_iso, start_iso):
    try:
        end = datetime.datetime.fromisoformat(end_iso.replace("Z",""))
        start = datetime.datetime.fromisoformat(start_iso.replace("Z",""))
        return (end - start).days
    except Exception:
        return 0

def decay_weight(days, half_life_days):
    return 0.5 ** (days / max(1.0, half_life_days))

def aggregate(events, window_end_iso, half_life_days):
    per_intent = {}
    unlabeled = []
    for ev in events:
        ts = ev.get("timestamp")
        utter = ev.get("utterance","").strip()
        intent = ev.get("intent")
        if intent:
            stats = per_intent.setdefault(intent, {"total_count":0,"last_seen_at":"1970-01-01T00:00:00Z","activity_score":0.0,"examples":[]})
            stats["total_count"] += 1
            if ts > stats["last_seen_at"]:
                stats["last_seen_at"] = ts
            d = days_between(window_end_iso, ts)
            stats["activity_score"] += decay_weight(d, half_life_days)
            if utter and len(stats["examples"]) < 5:
                stats["examples"].append(utter)
        else:
            if utter:
                unlabeled.append(utter)
    # Candidate mining (placeholder heuristic => human review)
    from collections import Counter
    pref = Counter([u.lower().split()[0] for u in unlabeled if u.strip()])
    candidates = []
    for token, cnt in pref.most_common(25):
        if token and cnt >= 5:
            candidates.append({"proposed_name": f"{token}_intent", "evidence": cnt, "note": "auto-mined; human review required"})
    return per_intent, candidates

def uniqueness_estimator(phrases):
    toks = []
    for p in phrases or []:
        toks.extend([t for t in p.lower().split() if t.isalpha()])
    if not toks: return 0.5
    distinct = len(set(toks))
    return max(0.0, min(1.0, distinct / (len(toks) + 5.0)))

def calc_usefulness(meta, policy):
    w = policy["usefulness"]["weights"]
    max_dep = max(1, policy["usefulness"].get("max_dependency_count", 12))
    rebuild_cost = float(meta.get("rebuild_cost", 0.0))
    dependency_count = float(meta.get("dependency_count", 0))
    dependency_norm = min(1.0, dependency_count / max_dep)
    uniqueness = float(meta.get("uniqueness", 0.5))
    compliance_critical = 1.0 if meta.get("compliance_critical", False) else 0.0
    biz_criticality = float(meta.get("biz_criticality", 0.0))
    score = (
        w["rebuild_cost"] * rebuild_cost +
        w["dependency_count"] * dependency_norm +
        w["uniqueness"] * uniqueness +
        w["compliance_critical"] * compliance_critical +
        w["biz_criticality"] * biz_criticality
    )
    return max(0.0, min(1.0, round(score, 6)))

def main():
    ap = argparse.ArgumentParser(description="Regenerate nlp/google_intents.json from logs (usefulness-aware).")
    ap.add_argument("--logs-dir", required=True)
    ap.add_argument("--existing", default="nlp/google_intents.json")
    ap.add_argument("--out", default="nlp/google_intents.json")
    ap.add_argument("--policy", default="nlp/intent_pruning_policy.json")
    ap.add_argument("--checkpoint", default="state/intents.ckpt.json")
    ap.add_argument("--owner-approvals", default=None, help="JSON mapping: {intent: {approved: bool, approved_at: iso}}")
    ap.add_argument("--prune-allow", action="store_true", help="Allow deletion/archive after phase-2")
    ap.add_argument("--dry-run", action="store_true")
    ap.add_argument("--archive-dir", default=None)
    ap.add_argument("--explain-csv", default="state/intents_explain.csv")
    ap.add_argument("--explain-jsonl", default="state/intents_explain.jsonl")
    args = ap.parse_args()

    policy = read_json(args.policy, {})
    window_end = now_utc()

    # Lock (2h TTL)
    lock_path = args.checkpoint + ".lock"
    if os.path.exists(lock_path) and (time.time() - os.path.getmtime(lock_path)) < 2*3600:
        print("[ABORT] Another run appears active.", file=sys.stderr); sys.exit(2)
    open(lock_path, "w").write(window_end)

    try:
        events, input_hash = parse_logs(args.logs_dir, window_end)
        existing = read_json(args.existing, {"version":5,"updated_at":window_end,"intents":[],"pending_prune":[],"new_intent_candidates":[]})
        existing_intents = {it["name"]: it for it in existing.get("intents", [])}
        per_intent, candidates = aggregate(events, window_end, policy.get("half_life_days",14))
        approvals = read_json(args.owner_approvals, {}) if args.owner_approvals else {}

        keep_threshold = float(policy.get("usefulness",{}).get("keep_threshold",0.70))
        cocoon_threshold = float(policy.get("usefulness",{}).get("cocoon_threshold",0.50))
        hard_never = set(policy.get("hard_never_prune_tags", []))

        out_intents, pending_prune = [], []
        report_rows = []
        archive_entries = []

        def days_since(iso):
            try:
                return (datetime.datetime.fromisoformat(window_end.replace("Z","")) - datetime.datetime.fromisoformat(iso.replace("Z",""))).days
            except Exception:
                return 9999

        for name, it in existing_intents.items():
            meta = it.get("meta", {})
            tags = set(meta.get("tags", []))
            created = meta.get("created_at", window_end)
            last_seen = per_intent.get(name, {}).get("last_seen_at", meta.get("last_seen_at", created))
            activity = per_intent.get(name, {}).get("activity_score", meta.get("activity_score", 0.0))
            total = per_intent.get(name, {}).get("total_count", meta.get("total_count", 0))

            # Defaults + computed
            base = {
                "rebuild_cost": meta.get("rebuild_cost", 0.0),
                "dependency_count": meta.get("dependency_count", 0),
                "uniqueness": meta.get("uniqueness", uniqueness_estimator(it.get("phrases", []))),
                "compliance_critical": meta.get("compliance_critical", False),
                "biz_criticality": meta.get("biz_criticality", 0.0)
            }
            usefulness = calc_usefulness(base, policy)

            merged_meta = {
                "created_at": created,
                "last_seen_at": last_seen,
                "activity_score": round(activity, 6),
                "total_count": total,
                "protect": bool(meta.get("protect", False)),
                "status": meta.get("status", "active"),
                "tags": sorted(list(tags)),
                "owner": meta.get("owner"),
                "owner_approved_at": meta.get("owner_approved_at"),
                **base,
                "usefulness_score": usefulness,
                "prune_reason_codes": meta.get("prune_reason_codes", []),
                "marked_at": meta.get("marked_at")
            }

            # Decision
            reasons = []
            triggers = []
            decision = "keep_active"

            # Hard keep
            if merged_meta["protect"] or (hard_never & tags):
                decision = "keep_hard"
                reasons.append("protect_or_hard_tag")
            else:
                # New intent grace
                if days_since(merged_meta["created_at"]) < policy.get("new_intent_grace_days",30):
                    decision = "keep_new_grace"
                    reasons.append("new_intent_grace")
                else:
                    inactive = days_since(merged_meta["last_seen_at"]) >= policy.get("inactive_days_to_mark",45)
                    low_signal = merged_meta["total_count"] < policy.get("min_frequency_threshold",3)
                    if inactive: triggers.append("inactive")
                    if low_signal: triggers.append("low_signal")

                    if inactive or low_signal:
                        if usefulness >= keep_threshold:
                            decision = "keep_useful"
                            reasons.append("usefulness_override")
                        elif usefulness >= cocoon_threshold:
                            decision = "cocoon"
                            reasons.append("cocooned")
                            merged_meta["status"] = "cocoon"
                        else:
                            # Phase-1 mark
                            if merged_meta["status"] == "active":
                                merged_meta["status"] = "pending_prune"
                                merged_meta["marked_at"] = now_utc()
                            decision = "pending_prune"

                            # Phase-2 readiness
                            marked_at = merged_meta.get("marked_at") or now_utc()
                            phase2_ready = days_since(marked_at) >= policy.get("pending_prune_confirmation_days",14)

                            # Owner approval logic
                            needs_owner = any(t in policy.get("owner_policy",{}).get("require_for_tags",[]) for t in merged_meta["tags"]) or bool(merged_meta.get("owner"))
                            owner_ok = False
                            if merged_meta.get("owner"):
                                app = approvals.get(name) or {}
                                if app.get("approved"):
                                    merged_meta["owner_approved_at"] = app.get("approved_at", now_utc())
                                    owner_ok = True

                            if phase2_ready:
                                if args.prune_allow and (not needs_owner or owner_ok):
                                    decision = "archive"
                                else:
                                    reasons.append("pending_prune_wait_owner" if needs_owner and not owner_ok else "pending_prune_confirm_window")

            # Rationale
            rationale = {
                "decision": decision,
                "thresholds": {
                    "inactive_days_to_mark": policy.get("inactive_days_to_mark"),
                    "min_frequency_threshold": policy.get("min_frequency_threshold"),
                    "keep_threshold": keep_threshold,
                    "cocoon_threshold": cocoon_threshold
                },
                "triggers": triggers,
                "computed": {
                    "usefulness_score": usefulness,
                    "total_count": merged_meta["total_count"],
                    "days_since_last_seen": days_since(merged_meta["last_seen_at"])
                }
            }

            # Apply
            intent_obj = {"name": name, "phrases": it.get("phrases", []), "meta": merged_meta, "rationale": rationale}

            # Route by decision
            if decision == "archive":
                # Archive (soft delete) entry
                archive_entries.append(intent_obj)
                # Do not include in out_intents
                pass
            elif decision.startswith("pending_prune"):
                pending_prune.append(intent_obj)
            else:
                # keep_* or cocoon
                out_intents.append(intent_obj)

            # Report
            report_rows.append({
                "name": name,
                "decision": decision,
                "usefulness_score": usefulness,
                "total_count": merged_meta["total_count"],
                "last_seen_at": merged_meta["last_seen_at"],
                "created_at": merged_meta["created_at"],
                "status_out": merged_meta["status"],
                "tags": "|".join(merged_meta["tags"] or []),
                "triggers": "|".join(triggers),
                "reason_codes": "|".join(reasons)
            })

        # Add brand-new labeled intents seen in logs
        existing_names = set(existing_intents.keys())
        kept_names = {i["name"] for i in out_intents} | {i["name"] for i in pending_prune}
        for name, stats in per_intent.items():
            if name not in existing_names and name not in kept_names:
                out_intents.append({
                    "name": name,
                    "phrases": [],
                    "meta": {
                        "created_at": now_utc(),
                        "last_seen_at": stats["last_seen_at"],
                        "activity_score": round(stats["activity_score"], 6),
                        "total_count": stats["total_count"],
                        "protect": False,
                        "status": "active",
                        "tags": [],
                        "rebuild_cost": 0.0,
                        "dependency_count": 0,
                        "uniqueness": 0.5,
                        "compliance_critical": False,
                        "biz_criticality": 0.0,
                        "usefulness_score": 0.25,
                        "prune_reason_codes": []
                    },
                    "rationale": {
                        "decision": "keep_active",
                        "thresholds": {},
                        "triggers": [],
                        "computed": {}
                    }
                })

        # Compose output
        out_doc = {
            "version": max(5, int(existing.get("version", 5))),
            "updated_at": now_utc(),
            "intents": sorted(out_intents, key=lambda x: x["name"]),
            "pending_prune": sorted(pending_prune, key=lambda x: x["name"]),
            "new_intent_candidates": candidates,
            "meta": {
                "job_id": str(uuid.uuid4()),
                "window_end": window_end,
                "input_hash": sha256_of_events(events),
                "policy_version": policy.get("policy_version")
            }
        }

        # Write outputs (or dry-run)
        if not args.dry_run:
            write_atomic(args.out, out_doc)
        else:
            print("[DRY-RUN] Skipped write to", args.out)

        # Archive file if needed
        archive_dir = args.archive_dir or policy.get("archiving",{}).get("archive_dir","nlp/archive")
        if archive_entries and not args.dry_run:
            Path(archive_dir).mkdir(parents=True, exist_ok=True)
            stamp = datetime.datetime.utcnow().strftime("%Y%m%d%H%M%S")
            arch_path = os.path.join(archive_dir, f"archive_{stamp}.json")
            # Add SHA of source file to each entry (for restore provenance)
            try:
                with open(args.existing, "rb") as sf:
                    src_sha = hashlib.sha256(sf.read()).hexdigest()
            except Exception:
                src_sha = None
            for e in archive_entries:
                e["archived_at"] = now_utc()
                e["source_sha256"] = src_sha
                e["meta"]["status"] = "pruned"
                e["meta"]["prune_reason_codes"] = list(set((e["meta"].get("prune_reason_codes") or []) + ["archived"]))
            write_atomic(arch_path, {"entries": archive_entries, "created_at": now_utc()})
            print("Archived:", arch_path)

        # Explain reports
        Path(os.path.dirname(args.explain_csv)).mkdir(parents=True, exist_ok=True)
        with open(args.explain_csv, "w", newline="") as f:
            writer = csv.DictWriter(f, fieldnames=["name","decision","usefulness_score","total_count","last_seen_at","created_at","status_out","tags","triggers","reason_codes"])
            writer.writeheader()
            for r in report_rows:
                writer.writerow(r)
        with open(args.explain_jsonl, "w") as f:
            for it in out_doc["intents"] + out_doc["pending_prune"] + archive_entries:
                f.write(json.dumps({"name": it["name"], "decision": it.get("rationale",{}).get("decision"), "rationale": it.get("rationale",{}), "meta": it.get("meta",{})}) + "\n")

        # Checkpoint
        ck = {
            "job_id": out_doc["meta"]["job_id"],
            "window_end": window_end,
            "input_hash": out_doc["meta"]["input_hash"],
            "out_path": args.out,
            "updated_at": now_utc()
        }
        if not args.dry_run:
            write_atomic(args.checkpoint, ck)

        print("[OK] Regeneration complete.")
        print("Output:", args.out)
        print("Explain CSV:", args.explain_csv)
        print("Explain JSONL:", args.explain_jsonl)

    finally:
        try: os.remove(lock_path)
        except FileNotFoundError: pass

if __name__ == "__main__":
    main()
