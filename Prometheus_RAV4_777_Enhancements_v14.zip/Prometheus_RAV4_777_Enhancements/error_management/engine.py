"""
Smart Error Management 777 Engine
=================================

This module defines a framework for classifying and handling errors across
the Prometheus ecosystem. The engine associates exceptions with error
categories (transient, permanent, configuration, etc.), logs them in a
structured way and dispatches to registered handlers. Consumers can
register custom handlers for specific categories or exception types.

Developed and maintained by Adam Henry Nagle. Contact: 603‑384‑8949,
cainkilledabrl@icloud.com, nagleadam75@gmail.com.
"""

# Prometheus Codex Lock v1
# This file is part of Prometheus RAV4 777 Enhancements. Do not edit manually.

import enum
import time
from dataclasses import dataclass
from typing import Callable, Dict, Optional, Any, Type


class ErrorCategory(enum.Enum):
    """Classification of errors for consistent handling."""

    TRANSIENT = "transient"  # e.g. network hiccups, temporary unavailability
    PERMANENT = "permanent"  # e.g. invalid input, not recoverable by retry
    CONFIGURATION = "configuration"  # e.g. missing config, environment issues
    SECURITY = "security"  # e.g. authentication or permission errors
    UNKNOWN = "unknown"  # fallback when category cannot be determined


@dataclass
class ErrorEvent:
    """Structured representation of an error occurrence."""

    message: str
    category: ErrorCategory
    timestamp: float
    exception: Optional[Exception] = None
    context: Optional[Dict[str, Any]] = None


class ErrorManager:
    """Central registry for error handlers and dispatching.

    Handlers can be registered globally for categories or specifically for
    exception types. When handling an error, the manager first checks for
    a handler registered for the exception type, then falls back to the
    category handler and finally to a default handler.
    """

    def __init__(self) -> None:
        self.category_handlers: Dict[ErrorCategory, Callable[[ErrorEvent], None]] = {}
        self.exception_handlers: Dict[Type[BaseException], Callable[[ErrorEvent], None]] = {}
        self.default_handler: Callable[[ErrorEvent], None] = self._print_handler

    @staticmethod
    def _print_handler(event: ErrorEvent) -> None:
        print(f"[{event.category.value.upper()}] {event.message}")
        if event.exception:
            print(f"Exception: {event.exception!r}")
        if event.context:
            print(f"Context: {event.context}")

    def register_category_handler(self, category: ErrorCategory, handler: Callable[[ErrorEvent], None]) -> None:
        """Register a handler for a specific error category."""
        self.category_handlers[category] = handler

    def register_exception_handler(self, exc_type: Type[BaseException], handler: Callable[[ErrorEvent], None]) -> None:
        """Register a handler for a specific exception type."""
        self.exception_handlers[exc_type] = handler

    def classify(self, exc: BaseException) -> ErrorCategory:
        """Determine the category of an exception.

        In this simple implementation we classify `FileNotFoundError` as
        configuration errors and `PermissionError` as security errors. All
        other builtin exceptions default to unknown. Applications should
        extend this method with more sophisticated classification logic.
        """
        if isinstance(exc, FileNotFoundError):
            return ErrorCategory.CONFIGURATION
        if isinstance(exc, PermissionError):
            return ErrorCategory.SECURITY
        return ErrorCategory.UNKNOWN

    def handle(self, message: str, exc: Optional[BaseException] = None, context: Optional[Dict[str, Any]] = None) -> None:
        """Handle an error with optional exception and context.

        Selects the most specific handler available and calls it with an
        `ErrorEvent`.
        """
        category = self.classify(exc) if exc else ErrorCategory.UNKNOWN
        event = ErrorEvent(message=message, category=category, timestamp=time.time(), exception=exc, context=context)
        # Try exception specific handler
        if exc:
            for etype, handler in self.exception_handlers.items():
                if isinstance(exc, etype):
                    handler(event)
                    return
        # Fall back to category handler
        handler = self.category_handlers.get(category, self.default_handler)
        handler(event)