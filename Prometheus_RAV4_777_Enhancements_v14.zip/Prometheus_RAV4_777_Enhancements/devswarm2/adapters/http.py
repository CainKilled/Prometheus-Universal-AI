"""
HTTP Adapter
===========

This adapter performs HTTP requests on behalf of the DevSwarm
orchestrator. It supports ``GET`` and ``POST`` methods and
automatically falls back to Python's built‑in ``urllib`` if the
``requests`` library is unavailable. Tasks must specify at least a
``url``. Additional optional keys include ``method`` (default
"GET"), ``headers`` (a dict) and ``data`` (for POST bodies).

Responses include the HTTP status code and up to 1 kB of body
content. Large bodies are truncated to avoid excessive memory
consumption. Errors in the request or library availability are
returned as ``error`` fields. Logging captures the request and
results.
"""

from __future__ import annotations

from typing import Dict, Any, Callable, Optional
import json

try:
    import requests  # type: ignore
except ImportError:
    requests = None  # type: ignore

from urllib import request as urllib_request  # type: ignore
from urllib import error as urllib_error  # type: ignore


class HTTPAdapter:
    """Adapter that performs HTTP GET and POST requests."""

    MAX_BODY = 1024  # maximum bytes of body to return

    def _requests_fetch(self, url: str, method: str, headers: Optional[Dict[str, str]], data: Optional[Any], logger: Callable[[str], None]) -> Dict[str, Any]:
        """Perform an HTTP request using the requests library."""
        try:
            if method == "GET":
                resp = requests.get(url, headers=headers)
            else:
                # If data is a dict, send as JSON
                if isinstance(data, dict):
                    resp = requests.post(url, json=data, headers=headers)
                else:
                    resp = requests.post(url, data=data, headers=headers)
            logger(f"HTTPAdapter: requests {method} {url} -> {resp.status_code}")
            body = resp.text[: self.MAX_BODY]
            return {"status": resp.status_code, "body": body}
        except Exception as exc:
            logger(f"HTTPAdapter: requests error for {url}: {exc}")
            return {"error": str(exc)}

    def _urllib_fetch(self, url: str, method: str, headers: Optional[Dict[str, str]], data: Optional[Any], logger: Callable[[str], None]) -> Dict[str, Any]:
        """Perform an HTTP request using urllib."""
        try:
            if method == "GET":
                req = urllib_request.Request(url, headers=headers or {})
            else:
                # encode data
                if isinstance(data, dict):
                    encoded = json.dumps(data).encode()
                    content_type = "application/json"
                else:
                    encoded = str(data).encode() if data is not None else b""
                    content_type = "application/x-www-form-urlencoded"
                headers = headers or {}
                headers.setdefault("Content-Type", content_type)
                req = urllib_request.Request(url, data=encoded, headers=headers, method="POST")
            with urllib_request.urlopen(req) as resp:
                status = resp.getcode()
                body = resp.read(self.MAX_BODY).decode()
                logger(f"HTTPAdapter: urllib {method} {url} -> {status}")
                return {"status": status, "body": body}
        except urllib_error.HTTPError as exc:
            logger(f"HTTPAdapter: urllib HTTPError for {url}: {exc.code}")
            return {"status": exc.code, "error": exc.reason}
        except Exception as exc:
            logger(f"HTTPAdapter: urllib error for {url}: {exc}")
            return {"error": str(exc)}

    def run(self, task: Dict[str, Any], logger: Callable[[str], None]) -> Dict[str, Any]:
        url = task.get("url")
        if not url:
            logger("HTTPAdapter: missing url")
            return {"error": "missing url"}
        method = str(task.get("method", "GET")).upper()
        headers = task.get("headers")
        data = task.get("data")
        # Use requests if available
        if requests is not None:
            return self._requests_fetch(url, method, headers, data, logger)
        else:
            return self._urllib_fetch(url, method, headers, data, logger)