"""
Android Plugin
==============

This plugin scaffolds integration with Android devices and the Android
development ecosystem. Use the [Android Debug Bridge (ADB)](https://developer.android.com/tools/adb)
and [fastboot](https://source.android.com/docs/core/architecture/bootloader/fastboot)
tools to interact with devices for debugging, flashing and testing. For
rooted devices, [Magisk](https://github.com/topjohnwu/Magisk) can be used to
manage root and modules.

Your implementation should call out to these tools via Python’s
    `subprocess` module or an appropriate wrapper. For example, to list
    connected devices you could run `adb devices` and parse the output.

    Developed and maintained by Adam Henry Nagle. Contact: 603‑384‑8949,
    cainkilledabrl@icloud.com, nagleadam75@gmail.com.
"""

# Prometheus Codex Lock v1
# This file is part of Prometheus RAV4 777 Enhancements. Do not edit manually.

from typing import Dict, Any
from plugins.api.plugin_base import Plugin


class AndroidPlugin:
    def metadata(self) -> Dict[str, Any]:
        """
        Return metadata for this plugin. The version has been bumped
        and the description clarifies that this plugin now performs real
        operations using ADB and Fastboot. See ``activate`` for details.
        """
        return {
            "name": "android",
            "version": "1.0.0",
            "description": "Interact with Android devices via ADB, Fastboot and Magisk",
            "targets": ["mobile", "android"],
        }

    def activate(self, runtime: Dict[str, Any]) -> None:
        """
        Execute an Android device management action.

        Supported runtime keys:

            action (str): One of ``devices``, ``install``, ``uninstall``, ``shell``,
                ``reboot``, ``flash``, ``magisk``. Defaults to ``devices``.
            apk (str): Path to an APK file to install (for ``install``).
            package (str): Package name to uninstall (for ``uninstall``).
            command (str or list[str]): Shell command to run on device (for ``shell``).
            img (str): Path to a boot/system image file to flash (for ``flash``).
            partition (str): Partition name to flash (e.g. ``boot``, ``recovery``).
            device (str): Device serial number (optional). Passed via ``-s``.
            log (callable): Optional logger.

        The plugin uses ``adb`` for most actions and ``fastboot`` for
        flashing. It checks for the presence of these executables via
        ``shutil.which`` before invoking them.
        """
        import subprocess
        import shutil
        import shlex
        logger = runtime.get("log", print)
        action = str(runtime.get("action", "devices")).lower()
        device = runtime.get("device")
        adb = shutil.which("adb")
        fastboot = shutil.which("fastboot")
        magisk = shutil.which("magisk")  # optional for root management
        if not adb and action != "flash":
            logger("AndroidPlugin: 'adb' executable not found. Please install Android Platform Tools.")
            return
        if action == "flash" and not fastboot:
            logger("AndroidPlugin: 'fastboot' executable not found. Cannot flash partitions.")
            return
        # Build base command with optional device serial
        def build_cmd(base: str) -> list[str]:
            cmd = [base]
            if device:
                cmd.extend(["-s", str(device)])
            return cmd
        def run_cmd(cmd: list[str]) -> None:
            try:
                logger(f"AndroidPlugin: Running {' '.join(cmd)}")
                result = subprocess.run(cmd, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True)
                logger(result.stdout.rstrip())
                if result.returncode != 0:
                    logger(f"AndroidPlugin: Command exited with code {result.returncode}")
            except Exception as exc:
                logger(f"AndroidPlugin: Error executing {' '.join(cmd)}: {exc}")
        # Action handlers
        if action == "devices":
            cmd = build_cmd(adb) + ["devices"]
            run_cmd(cmd)
            return
        if action == "install":
            apk_path = runtime.get("apk")
            if not apk_path:
                logger("AndroidPlugin: 'apk' path must be provided for install action")
                return
            cmd = build_cmd(adb) + ["install", str(apk_path)]
            run_cmd(cmd)
            return
        if action == "uninstall":
            package = runtime.get("package")
            if not package:
                logger("AndroidPlugin: 'package' must be provided for uninstall action")
                return
            cmd = build_cmd(adb) + ["uninstall", str(package)]
            run_cmd(cmd)
            return
        if action == "shell":
            command = runtime.get("command")
            if not command:
                logger("AndroidPlugin: 'command' must be provided for shell action")
                return
            # Accept command as string or list
            if isinstance(command, str):
                cmdlist = shlex.split(command)
            else:
                cmdlist = [str(c) for c in command]
            cmd = build_cmd(adb) + ["shell"] + cmdlist
            run_cmd(cmd)
            return
        if action == "reboot":
            cmd = build_cmd(adb) + ["reboot"]
            run_cmd(cmd)
            return
        if action == "flash":
            img_path = runtime.get("img")
            partition = runtime.get("partition")
            if not partition or not img_path:
                logger("AndroidPlugin: 'partition' and 'img' must be provided for flash action")
                return
            cmd = build_cmd(fastboot) + ["flash", str(partition), str(img_path)]
            run_cmd(cmd)
            return
        if action == "magisk":
            # Magisk manager: install/uninstall modules etc.
            if not magisk:
                logger("AndroidPlugin: 'magisk' executable not found. Please install Magisk CLI.")
                return
            magisk_cmd = runtime.get("magisk_cmd")
            if not magisk_cmd:
                logger("AndroidPlugin: 'magisk_cmd' must be provided for magisk action")
                return
            # Accept string or list for magisk_cmd
            if isinstance(magisk_cmd, str):
                args = shlex.split(magisk_cmd)
            else:
                args = [str(a) for a in magisk_cmd]
            cmd = [magisk] + args
            run_cmd(cmd)
            return
        logger(f"AndroidPlugin: Unknown action '{action}'. Supported actions: devices, install, uninstall, shell, reboot, flash, magisk.")


def get_plugin() -> Plugin:
    return AndroidPlugin()  # type: ignore[return-value]