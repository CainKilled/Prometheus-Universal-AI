"""
External Services Plugin
=======================

This plugin acts as a generic wrapper around external command‑line
interfaces (CLIs) for various cloud and AI services such as Gemini CLI,
AWS CLI, SageMaker, Firebase, Cloudflare and GitHub Copilot. Instead of
reimplementing these services, the plugin forwards commands to their
respective CLIs (assuming they are installed and configured in the
environment). It logs command output and return codes.

Runtime keys:
    service (str): Name of the service/CLI (e.g. "gemini", "aws", "firebase").
    args (list[str] or str): Arguments to pass to the CLI. If a string
        is provided and ``shell`` is False, it will be split using
        ``shlex.split``.
    shell (bool): Whether to run the command through the shell. Defaults
        to False.

Example::

    {'service': 'aws', 'args': ['s3', 'ls'], 'log': logger}

will execute ``aws s3 ls`` and print the output.

Developed and maintained by Adam Henry Nagle. Contact: 603‑384‑8949,
cainkilledabrl@icloud.com, nagleadam75@gmail.com.
"""

# Prometheus Codex Lock v1
# This file is part of Prometheus RAV4 777 Enhancements. Do not edit manually.

import shlex
import subprocess
from typing import Dict, Any

from plugins.api.plugin_base import Plugin


class ExternalPlugin:
    def metadata(self) -> Dict[str, Any]:
        return {
            "name": "external",
            "version": "0.1.0",
            "description": "Wrapper for external service CLIs",
            "targets": ["external", "services"],
        }

    def activate(self, runtime: Dict[str, Any]) -> None:
        logger = runtime.get("log", print)
        service = runtime.get("service")
        args = runtime.get("args", [])
        use_shell = bool(runtime.get("shell", False))
        if not service:
            logger("ExternalPlugin: 'service' key is required")
            return
        # Build the command
        if not args:
            logger(f"ExternalPlugin: No args provided for service '{service}'")
            return
        if use_shell and isinstance(args, list):
            cmd = " ".join([service] + [str(a) for a in args])
        elif not use_shell and isinstance(args, str):
            cmd = [service] + shlex.split(args)
        elif not use_shell and isinstance(args, list):
            cmd = [service] + args
        else:  # args is string and use_shell
            cmd = f"{service} {args}"
        logger(f"ExternalPlugin: Executing {cmd!r} (shell={use_shell})")
        try:
            result = subprocess.run(
                cmd,
                shell=use_shell,
                stdout=subprocess.PIPE,
                stderr=subprocess.STDOUT,
                text=True,
            )
            logger(result.stdout.rstrip())
            if result.returncode != 0:
                logger(f"ExternalPlugin: Command exited with code {result.returncode}")
        except Exception as exc:
            logger(f"ExternalPlugin: Error executing command {cmd!r}: {exc}")


def get_plugin() -> Plugin:
    return ExternalPlugin()  # type: ignore[return-value]