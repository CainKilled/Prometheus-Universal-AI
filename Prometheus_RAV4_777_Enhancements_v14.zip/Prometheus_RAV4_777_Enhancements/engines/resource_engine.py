"""
Resource Engine
===============

The Resource Engine provides introspection and navigation utilities for
the Prometheus monorepo. It can list directories, summarise file sizes
and produce a simple tree representation. The runtime task may
include:

    action (str): One of ``tree``, ``summary``. Defaults to ``tree``.
    path (str): Directory to inspect. Defaults to the current
        working directory.

``tree`` returns a nested dictionary representing the directory
structure (up to a depth of 3 by default), while ``summary`` returns
the total number of files and their combined size under the path. This
engine helps you look "back and forth and side to side" inside the
    project.

    Developed and maintained by Adam Henry Nagle. Contact: 603‑384‑8949,
    cainkilledabrl@icloud.com, nagleadam75@gmail.com.
"""

from __future__ import annotations

from typing import Dict, Any, List
from pathlib import Path
import os


class ResourceEngine:
    def metadata(self) -> Dict[str, Any]:
        return {
            "name": "resource",
            "version": "1.0.0",
            "description": "Provide directory tree and file summary introspection."
        }

    def run(self, task: Dict[str, Any]) -> Dict[str, Any]:
        action = str(task.get("action", "tree")).lower()
        path = Path(task.get("path", os.getcwd()))
        if action == "tree":
            depth = int(task.get("depth", 3))
            def build_tree(p: Path, d: int) -> Any:
                if d < 0:
                    return {}
                tree: Dict[str, Any] = {}
                try:
                    for child in sorted(p.iterdir(), key=lambda x: x.name):
                        if child.is_dir():
                            tree[child.name + "/"] = build_tree(child, d - 1)
                        else:
                            tree[child.name] = None
                except Exception:
                    return {}
                return tree
            return {"ok": True, "tree": build_tree(path, depth)}
        elif action == "summary":
            file_count = 0
            total_size = 0
            for p in path.rglob("*"):
                if p.is_file():
                    file_count += 1
                    try:
                        total_size += p.stat().st_size
                    except Exception:
                        continue
            return {"ok": True, "files": file_count, "bytes": total_size}
        else:
            return {"error": f"Unknown action {action}"}


def get_engine() -> ResourceEngine:
    return ResourceEngine()