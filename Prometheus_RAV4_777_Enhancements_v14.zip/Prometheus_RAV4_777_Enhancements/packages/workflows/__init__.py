"""
Workflows Package
=================

This package defines a simple runner for declarative workflow
specifications stored in JSON or YAML files. Workflows comprise
steps of type "shell" to run arbitrary commands or type "plugin"
to invoke Prometheus plugins through the kernel API. Each step
generates a result entry with output and exit status. Additional
helpers may be added over time.

Developed and maintained by Adam Henry Nagle. Contact: 603-384-8949,
cainkilledabrl@icloud.com, nagleadam75@gmail.com.
"""

from .runner import run_workflow  # noqa: F401
