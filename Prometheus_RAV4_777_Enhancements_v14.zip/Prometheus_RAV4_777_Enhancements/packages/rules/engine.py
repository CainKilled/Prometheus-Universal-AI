"""
Rules Engine
============

This module defines a simple evaluation engine inspired by JSONLogic. A
rule is represented as a dictionary with a single key equal to an
operator name and a value containing the arguments for that operator.
Operators supported include equality (``==``), inequality (``!=``),
comparison operators (``>``, ``>=``, ``<``, ``<=``), logical
conjunction (``and``), disjunction (``or``) and membership (``in``).
Variables are referenced using ``{"var": "name"}`` and values
are looked up from the provided context dictionary. The `evaluate`
function returns a boolean result. The `compile_rule` function
produces a closure that can be reused to evaluate the rule multiple
times.

Developed and maintained by Adam Henry Nagle. Contact: 603‑384‑8949,
cainkilledabrl@icloud.com, nagleadam75@gmail.com.
"""

from __future__ import annotations

import operator as _op
from typing import Any, Dict, Callable

# Define supported operations using Python built‑ins. This subset is
# intentionally small to avoid arbitrary code execution. Additional
# operators can be added as needed by extending the OPS mapping.
OPS: Dict[str, Callable[..., Any]] = {
    "==": lambda a, b: a == b,
    "!=": lambda a, b: a != b,
    ">": lambda a, b: a > b,
    ">=": lambda a, b: a >= b,
    "<": lambda a, b: a < b,
    "<=": lambda a, b: a <= b,
    "and": lambda *xs: all(xs),
    "or": lambda *xs: any(xs),
    "in": lambda a, b: a in b,
}

def _val(expr: Any, ctx: Dict[str, Any]) -> Any:
    """Recursively evaluate an expression against a context.

    If the expression is a list, each element is evaluated and a new
    list returned. If it's a dictionary, the single key/value pair is
    interpreted as an operation. If it's a scalar, it is returned
    directly. Variable references are resolved via the ``var`` operator.
    """
    if isinstance(expr, list):
        return [_val(e, ctx) for e in expr]
    if isinstance(expr, dict):
        ((op, args),) = expr.items()
        if op == "var":
            return ctx.get(args)
        fn = OPS.get(op)
        if not fn:
            raise ValueError(f"unknown op {op}")
        # Normalise args to a list for consistency
        if not isinstance(args, list):
            args = [args]
        return fn(*[_val(a, ctx) for a in args])
    return expr

def evaluate(rule: Dict[str, Any], context: Dict[str, Any]) -> bool:
    """Evaluate a rule against a context and return a boolean result."""
    return bool(_val(rule, context))

def compile_rule(rule: Dict[str, Any]) -> Callable[[Dict[str, Any]], bool]:
    """Compile a rule into a function for repeated evaluation.

    :param rule: The rule to compile.
    :returns: A closure accepting a context dictionary and returning
              True or False.
    """
    def _compiled(context: Dict[str, Any]) -> bool:
        return evaluate(rule, context)
    return _compiled